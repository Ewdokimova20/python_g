import datetime
import json
import logging
from typing import List, Dict, Optional, Union

from jsonschema import validate, ValidationError
from peewee import DoesNotExist, OperationalError, IntegrityError, PeeweeException

import global_data.config_schema
from db.cdb import read_nka_data_from_cdb
from db.cdb.common import open_cdb_connection
from global_data import appdata
from global_data.config_schema import config
from models.bis import Bis
from models.nka import Nka
from models.signal_type import SignalType
from models.station import Station
from utils.caches import cache_bis, station_cache
from utils.coordinates.coordinates import Coordinates

logger = logging.getLogger('prepare_db')
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(logging.Formatter('СПО КНП: %(message)s'))
logger.addHandler(console)


def read_nka_and_signals_from_cdb():
    """Чтение данных о НКА из ЦБД (№ сист.точки, № в НКУ, тип КА, номера сигналов)"""
    try:
        logger.info("Устанавливается соединение с ЦБД ...")
        open_cdb_connection()
        logger.info("Установлено соединение с ЦБД")
        logger.info("Чтение данных о НКА из ЦБД")
        nka_data = read_nka_data_from_cdb()
        nka_signals = {}
        if config['cdb']['mode'] == 'new':
            from db.cdb.new import read_signals_from_cdb
            nka_signals = read_signals_from_cdb()
        if not nka_signals:
            nka_signals = config['nka_data_signals']['nka_signals']
    except(DoesNotExist, OperationalError):
        # читаем НКА и сигналы из конфига
        logger.warning(
            'Ошибка чтения списка НКА и сигналов из ЦБД. '
            'НКА и сигналы будут инициализированы из конфигурационного файла.')
        nka_data = config['nka_data_signals']['nka_data']
        nka_signals = config['nka_data_signals']['nka_signals']
    appdata.NKA = sorted([*nka_data])
    appdata.NKA_DATA = nka_data
    for nka in appdata.NKA:
        appdata.NKA_SIGNALS[nka] = []
        appdata.NKA_SIGNALS_NAME[nka] = []
        if nka in nka_signals.keys():
            for signal_name in nka_signals[nka]:
                try:
                    appdata.SIGNALS_NAME[signal_name]
                except KeyError:
                    logging.warning(f'Ошибка записи неопределенного типа сигнала:{signal_name} для НКА:{nka}')
                else:
                    signal_id = appdata.SIGNALS_NAME[signal_name]
                    appdata.NKA_SIGNALS[nka].append(signal_id)
                    appdata.NKA_SIGNALS_NAME[nka].append(signal_name)


def prepare_nka():
    """Функция обеспечивает запись номеров системных точек и условных номеров КА в ЛБД"""

    def update_or_create(sys_num, nku_num, type_ka, type_si):
        try:
            nka = Nka.get(Nka.nka_sys_number == sys_num)
            logging.debug(f"Get Nka: nka_sys_number = {sys_num}")
            if nka.nku_number != nku_num or nka.type_ka != type_ka or nka.type_si != type_si:
                (Nka
                 .update({Nka.nku_number: nku_num,
                          Nka.type_ka: type_ka,
                          Nka.type_si: type_si,
                          Nka.db_timestamp: datetime.datetime.now()})
                 .where(Nka.nka_sys_number == sys_num)) \
                    .execute()
                logging.debug(f"Update Nka: nka_sys_number = {sys_num}")
        except DoesNotExist:
            nkas.append(Nka(nka_sys_number=sys_num, nku_number=nku_num, type_ka=type_ka, type_si=type_si))
            logging.debug(f"Create Nka: nka_sys_number = {sys_num}")
        except IntegrityError as e:
            logging.error(f'Попытка записи в ЛБД существующего НКА: сист. номер {sys_num}, номер КА {nku_num}: {e}')

    logger.info("Запись номеров системных точек и условных номеров КА в ЛБД")
    nkas = []
    for nka_data in appdata.NKA_DATA.values():
        update_or_create(nka_data["sys_num"], nka_data["nku_num"], nka_data["type_ka"], nka_data["type_si"])
    return nkas


def prepare_signals():
    """Функция обеспечивает запись кода и типа сигналов в ЛБД"""

    def update_or_create(signal_name, signal_type):
        try:
            signal = SignalType.get(SignalType.signal_type_id == signal_type)
            logging.debug(f"Get signal: signal_type_id = {signal_type}")
            if signal.name != signal_name:
                (SignalType
                 .update({SignalType.name: signal_name,
                          SignalType.db_timestamp: datetime.datetime.now()})
                 .where(SignalType.signal_type_id == signal_type)) \
                    .execute()
                logging.debug(f"Update SignalType: signal_type_id = {signal_type}")
        except DoesNotExist:
            signals.append(SignalType(signal_type_id=signal_type, name=signal_name))
            logging.debug(f"Create SignalType: signal_type_id = {signal_type}")
        except IntegrityError as e:
            logging.error(f'Попытка записи в ЛБД существующего типа сигнала: код сигнала {signal_type}, '
                          f'тип сигнала {signal_name}: {e}')

    logger.info("Запись кода и типа сигналов в ЛБД")
    signals = []
    for signal_name, signal_type in appdata.SIGNALS_NAME.items():
        update_or_create(signal_name, signal_type)
    return signals


def read_bis_coordinates_from_file() -> List[Dict[str, Optional[Union[int, Dict[str, Optional[Union[int, float]]]]]]]:
    """
    Функция обеспечивает чтение координат из файла coordinates.txt

    :return bis_coordinates: список словарей, содержащих № станции, № БИС и словарь с координатами в формате xyz.
    """

    bis_coordinates = []
    try:
        json_file = open(global_data.config_schema.config['station_coordinates']['path'])
    except IOError:
        logging.error(
            f"Отсутствует файл с координатами БИС: {global_data.config_schema.config['station_coordinates']['path']}")
    else:
        with json_file:
            try:
                bis_coordinates_records = json.load(json_file)
            except ValueError:
                logging.error(
                    f"Данные координат БИС: {global_data.config_schema.config['station_coordinates']['path']} "
                    f"должны быть заданы в формате json")
            else:
                if len(bis_coordinates_records) == 0:
                    logging.error(
                        f"В настроечном файле с координатами станций и комплектов "
                        f"{global_data.config_schema.config['station_coordinates']['path']} отсутствуют записи.")
                else:
                    for record in bis_coordinates_records:
                        try:
                            validate(instance=record, schema=global_data.config_schema.station_coordinates_schema)
                            bis_coordinates.append(dict(
                                station_number=record["station"],
                                bis_number=record["bis"],
                                bis_coord=record["coord_xyz"]))
                        except ValidationError:
                            logging.error("Координаты БИС заданы в неверном формате")
        json_file.close()
    return bis_coordinates


def prepare_bis_coordinates() -> None:
    """Функция обеспечивает чтение координат БИС и их запись в ЛБД"""

    logger.info("Чтение координат БИС и их запись в ЛБД")
    bis_list = read_bis_coordinates_from_file()

    for bis in bis_list:
        station_number = bis.get("station_number")
        bis_number = bis.get("bis_number")
        bis_coord = bis.get("bis_coord")
        station = Station.get_or_create_station(station_number=station_number)
        station_cache.add_data(station=station,
                               coordinates=Coordinates(xyz=Coordinates.XYZ(x=bis_coord["x"], y=bis_coord["y"], z=bis_coord["z"])))
        try:
            current_bis = Bis.get((Bis.station == station_number) & (Bis.bis_number == bis_number))
            cache_bis.add_data(current_bis.bis_number, current_bis.station.station_number, current_bis)
            logging.debug(f"Get BIS: station = {station_number},  bis_number = {bis_number}")
        except DoesNotExist:
            new_bis = Bis.create(station=station_number,
                                 bis_number=bis_number,
                                 x_coord=bis_coord["x"],
                                 y_coord=bis_coord["y"],
                                 z_coord=bis_coord["z"])

            cache_bis.add_data(new_bis.bis_number, new_bis.station.station_number, new_bis)
            logging.debug(f"Create BIS: station = {station_number},  bis_number = {bis_number}")
        else:
            if (current_bis.x_coord != bis_coord["x"] or
                    current_bis.y_coord != bis_coord["y"] or
                    current_bis.z_coord != bis_coord["z"]):
                Bis.update(x_coord=bis_coord["x"],
                           y_coord=bis_coord["y"],
                           z_coord=bis_coord["z"]).where(Bis.id == current_bis.id).execute()
                current_bis = Bis.get(Bis.id == current_bis.id)
                cache_bis.add_data(current_bis.bis_number, current_bis.station.station_number, current_bis)
                logging.debug(f"Update BIS: station = {station_number},  bis_number = {bis_number}")


def prepare_db(ldb):
    signals = []
    nkas = []
    try:
        ldb.connect()
        # if config['tldb']['mode'] == 'sqlite':
        #     ldb.create_tables(lbd_tables_list)
        logger.info("Установлено соединение с ЛБД")
        read_nka_and_signals_from_cdb()
        nkas = prepare_nka()
        logger.info("Запись типов сигналов КА в ЛБД")
        signals = prepare_signals()
        prepare_bis_coordinates()

    except PeeweeException as e:
        logging.exception(e)
        logger.warning("Неизвестная проблема с ЛБД.")

    with ldb.atomic():
        try:
            Nka.bulk_create(nkas)
        except PeeweeException as e:
            logging.exception(f'Проблема с заполнением таблицы с НКА: {e}')

    with ldb.atomic():
        try:
            SignalType.bulk_create(signals)
        except PeeweeException:
            logger.info('Проблема с заполнением таблицы с типами сигналов.')
