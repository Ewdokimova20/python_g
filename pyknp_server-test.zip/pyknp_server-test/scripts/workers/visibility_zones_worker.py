import datetime
import logging
import time

from scripts.handle_exception import handle_exception
from scripts.reset_database_decorator import reset_database
from scripts.setup_logging import LoggingManager

logger = logging.getLogger('visibility_zones')


@reset_database
def visibility_zone_worker(exiting_event):
    logging.info('Процесс для расчета ЗРВ успешно запущен!')

    # настраивам логирование в файлы с префиксом summarize
    LoggingManager(filename_prefix='visibility_zones', need_debug_file=False).setup_logging()

    from db.db_connection import db
    from models.visibility_zone import VisibilityZone
    try:
        # Создать материализованные представления таблицы visibilityzones поБИСово, если их нет

        # Рассчитать ЗРВ для всех БИС и запись в ТЛБД
        VisibilityZone.calculate_and_update()

    except Exception as exc:
        logger.critical('Возникла ошибка при инициализации расчета ЗРВ!')
        handle_exception(type(exc), exc, exc.__traceback__)

    last_check = datetime.datetime.now()
    CHECK_INTERVAL = 60  # секунд
    SLEEP_STEP = 1  # проверять каждую секунду

    while not exiting_event.is_set():
        try:
            now = datetime.datetime.now()
            if (now - last_check).total_seconds() >= CHECK_INTERVAL:
                VisibilityZone.calculate_and_update()
                last_check = now

            time.sleep(SLEEP_STEP)

        except Exception as exc:
            logger.critical('Возникла ошибка при расчете ЗРВ!')
            handle_exception(type(exc), exc, exc.__traceback__)

    logger.info("Закрытие соединения с ЛБД для процесса расчета ЗРВ")
    db.close()
