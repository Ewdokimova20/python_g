import logging
import multiprocessing
import time
from datetime import datetime, timedelta

from global_data.config_schema import config
from scripts.handle_exception import handle_exception
from scripts.process_registry import get_zmq_manager
from scripts.reset_database_decorator import reset_database
from scripts.setup_logging import LoggingManager


@reset_database
def summarize_worker(exiting: multiprocessing.Event, process_config):
    logging.info('Процесс обобщения кадров ЦИ успешно запущен!')

    # настраивам логирование в файлы с префиксом summarize
    LoggingManager(filename_prefix='summarize').setup_logging()
    logger = logging.getLogger('summarize_worker')

    # Сначала регистрируем все инициализаторы в этом процессе
    from scripts.process_registry.register_initializers import register_bis_process_initializers
    register_bis_process_initializers()

    # Затем инициализируем реестр объектов с конфигурацией процесса
    from scripts.process_registry.process_registry import initialize_registry
    initialize_registry(process_config)

    from db.db_connection import db
    db.connect()

    zmq_manager = get_zmq_manager()

    # Настройка ZMQ PUB канала для отправки результатов контроля согласованности СИ и ЦИ в процесс контроля заклакди
    zmq_manager.setup_publisher(endpoint=process_config.get('si_embed_pub_endpoint'))

    from scripts.composers.SummarizedFrameComposer import summarized_frame_composer
    while not exiting.is_set():
        time_now = datetime.now()
        try:
            # обобщаем ЦИ с запозданием lag_interval секунд и кратностью времени в compose_period секунд
            compose_at = time_now - timedelta(seconds=config['generalized_di']['lag_interval'])
            compose_at_timestamp = round(compose_at.timestamp())
            if compose_at_timestamp % config['generalized_di']['compose_period'] == 0:
                logger.info("Выполняется обобщение кадров ЦИ")
                summarized_frame_composer.summarize_all(current_timestamp=compose_at_timestamp)
                logger.info("Обобщение кадров ЦИ завершено")
            time.sleep(1)
        except Exception as exc:
            logger.critical('Возникла ошибка при обобщении кадров ЦИ!')
            handle_exception(type(exc), exc, exc.__traceback__)

    zmq_manager.close()
    logger.info("Закрытие соединения с ЛБД для процесса обобщения кадров ЦИ")
    db.close()
