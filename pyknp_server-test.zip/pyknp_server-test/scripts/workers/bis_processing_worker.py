# scripts/workers/bis_processing_worker.py
import logging
import multiprocessing
import os
from multiprocessing import Event

from twisted.internet import reactor

from scripts.process_registry import get_zmq_manager
from scripts.setup_logging import LoggingManager

logger = logging.getLogger(__name__)


def bis_processing_worker(exiting: Event, process_config=None):
    """
    Функция обработки потока от СПО сети БИС, запускаемая в отдельном процессе.

    Args:
        exiting: Событие для сигнализации о необходимости завершения
        process_config: Конфигурация для данного процесса обработки
    """

    # Настройка логирования с учетом имени процесса
    process_name = multiprocessing.current_process().name
    LoggingManager(filename_prefix=process_name).setup_logging()
    logger = logging.getLogger(__name__)
    logger.info(f"Старт воркера приема и обработки данных от СПО сети БИС для {process_name} с PID: {os.getpid()}")

    zmq_manager = None

    try:

        # Сначала регистрируем все инициализаторы в этом процессе
        from scripts.process_registry.register_initializers import register_bis_process_initializers
        register_bis_process_initializers()

        # Затем инициализируем реестр объектов с конфигурацией процесса
        from scripts.process_registry.process_registry import initialize_registry
        initialize_registry(process_config)

        zmq_manager = get_zmq_manager()

        pub_endpoint = process_config.get('main_pub_endpoint')
        rep_endpoint = process_config.get('cmd_rep_endpoint')

        # Настраиваем PUB для отправки в главный
        zmq_manager.setup_publisher(pub_endpoint)
        logger.debug(f"Инициализирован Publisher с endpoint: {pub_endpoint}")

        # Настраиваем REP для получения команд от главного
        zmq_manager.setup_rep_server(rep_endpoint)
        zmq_manager.setup_bis_process_handlers()
        zmq_manager.start_rep_server()
        logger.debug(f"Инициализирован REP сервер для получения команд от главного процесса с endpoint: {rep_endpoint}")

        # Получаем конфигурацию для этого процесса
        bis_host = process_config.get('host')
        bis_port = process_config.get('port')
        bis_list = process_config.get('bis_list')

        logger.info(f"Перечень обрабатываемых БИС для процесса {process_name}: ({bis_list})")

        # Создаем фабрику с политикой переподключения
        from BisReciever.BisProtocol import BisClientFactory
        factory = BisClientFactory()

        def connect():
            try:
                reactor.connectTCP(bis_host, bis_port, factory)
                logger.info(f'Установлено соединение с СПО сети БИС НКУ по адресу {bis_host}:{bis_port}')
            except Exception as e:
                logger.error(
                    f"Ошибка подключения к СПО сети БИС НКУ по адресу {bis_host}:{bis_port}: {repr(e)}")
                reactor.stop()

        # Запуск логики обработки в отдельном потоке реактора
        from scripts.bis_logic.bis_logic import bis_logic
        reactor.callWhenRunning(
            lambda: reactor.callInThread(bis_logic, exiting)
        )

        def _shutdown():
            if not exiting.is_set():
                logger.info(f"[{process_name}][PID {os.getpid()}] Получен сигнал на завершение, закрываем ресурсы и reactor")
                exiting.set()
                from scripts.process_registry.process_registry import close_all_resources
                close_all_resources()  # Закрываем ресурсы ZMQ
                reactor.stop()

        reactor.addSystemEventTrigger('before', 'shutdown', _shutdown)
        reactor.callWhenRunning(connect)

        # Главный цикл реактора
        reactor.run(installSignalHandlers=0)

    except Exception as e:
        logger.error(f"Ошибка в процессе обработки БИС: {repr(e)}", exc_info=True)
    finally:
        # Закрытие всех ресурсов при выходе
        from scripts.process_registry.process_registry import close_all_resources
        close_all_resources()
        if zmq_manager:
            zmq_manager.close()
        logger.info(f"Завершение воркера приема и обработки данных от СПО сети БИС для {process_name} с PID: {os.getpid()}")
