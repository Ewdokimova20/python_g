# scripts/workers/si_embedding_verification_worker.py
import logging
import multiprocessing
import os
from multiprocessing import Event

from scripts.process_registry import get_zmq_manager
from scripts.reset_database_decorator import reset_database
from scripts.setup_logging import LoggingManager

logger = logging.getLogger(__name__)


@reset_database
def si_embedding_verification_worker(exiting: Event, process_config=None):
    """
    Оперативный контроль закладок ЭИ, ЧВП и альманахов на борт НКА

    Args:
        exiting: Событие для сигнализации о необходимости завершения
        process_config: Конфигурация для данного процесса обработки
    """

    # Настройка логирования с учетом имени процесса
    process_name = multiprocessing.current_process().name
    LoggingManager(filename_prefix=process_name).setup_logging()
    logger = logging.getLogger(__name__)
    logger.info(f"Старт воркера контроля закладок ЭИ, ЧВП и альманахов для {process_name} с PID: {os.getpid()}")

    # Сначала регистрируем все инициализаторы в этом процессе
    from scripts.process_registry.register_initializers import register_si_embed_verification_initializers
    register_si_embed_verification_initializers()

    # Затем инициализируем реестр объектов с конфигурацией процесса
    from scripts.process_registry.process_registry import initialize_registry
    initialize_registry(process_config)

    zmq_manager = get_zmq_manager()

    try:

        # Настраиваем SUB для получения данных от процесса обобщения SummarizeProcess
        zmq_manager.setup_subscriber(process_config.get('summarize_sub_endpoint'))
        zmq_manager.setup_si_embed_verif_process_handlers()
        zmq_manager.start_subscriber()

        # Настраиваем PUB для отправки данных в главный процесс
        zmq_manager.setup_publisher(process_config.get('main_pub_endpoint'))

        from utils.SI.si_embedding_verification.si_embedding_verifier import SIEmbeddingVerifier
        SIEmbeddingVerifier().run_periodic_updates(exiting)

    except Exception as e:
        logger.error(f"Ошибка в процессе контроля закладок ЭИ, ЧВП и альманахов: {repr(e)}", exc_info=True)
    finally:
        # Закрытие всех ресурсов при выходе
        zmq_manager.close()
        logger.info(f"Завершение воркера контроля закладок ЭИ, ЧВП и альманахов для {process_name} с PID: {os.getpid()}")
