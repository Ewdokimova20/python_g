import logging
from typing import List, Optional, TYPE_CHECKING

from typing_extensions import TypedDict

from communication.endpoints import MAIN_PUB_SUB_ENDPOINT, BASE_BIS_CMD_PORT, LOCAL_HOST_ENDPOINT
from global_data.config_schema import config
from utils.caches import cache_bis

if TYPE_CHECKING:
    from models.bis import Bis

logger = logging.getLogger('main')


class BisConfig(TypedDict):
    """Конфигурация процесса обработки БИС"""
    host: str  # адрес хоста СПО сети БИС
    port: int  # порт СПО сети БИС
    main_pub_endpoint: str  # сетевой адрес, по которому процесс шлет данные на главный процесс через PUB сокет
    cmd_rep_port: int  # порт, по которому процесс шлет данные на главный процесс через PUB сокет
    cmd_rep_endpoint: str  # сетевой адрес, по которому процесс принимает команды от главного процесса через REP сокет
    bis_list: List['Bis']  # список объектов БИС, которые будут обрабатываться в данном процессе


bis_process_configs: Optional[List[BisConfig]] = None


def prepare_bis_process_configs():
    """
    Подготавливает список конфигураций BIS для запуска BIS-процессов.

    Для каждого порта из конфигурации 'bis_ports' собирается список объектов BIS из кэша.
    Если для порта найден хотя бы один BIS, формируется словарь конфигурации с хостом, портом,
    main_pub_endpoint, cmd_rep_port, cmd_rep_endpoint и списком BIS.

    Returns:
        list of dict: Список конфигураций BIS, готовых к использованию в процессах.

    Raises:
        SystemExit: Если ни для одного порта не удалось собрать BIS-конфигурации,
                    функция завершает работу программы с критической ошибкой.
    """
    bis_configs: List[BisConfig] = []
    bis_ports_map = config.get('bis_ports')

    # Сетевой адрес для отправки данных на главный процесс через PUB сокет (общий для всех процессов пока)
    main_pub_endpoint = MAIN_PUB_SUB_ENDPOINT

    for i, (port, bis_pairs) in enumerate(bis_ports_map.items()):
        bis_list = [
            cache_bis.get_item_by_key(bis_number, station_number)
            for station_number, bis_number in bis_pairs
            if cache_bis.get_item_by_key(bis_number, station_number) is not None
        ]
        if bis_list:
            # Каждому процессу назначается собственный порт относительно базового
            cmd_rep_port = BASE_BIS_CMD_PORT + i
            bis_config: BisConfig = {
                'host': config['bis']['host'],
                'port': port,
                'main_pub_endpoint': main_pub_endpoint,
                'cmd_rep_port': cmd_rep_port,
                'cmd_rep_endpoint': f'{LOCAL_HOST_ENDPOINT}:{cmd_rep_port}',
                'bis_list': bis_list
            }
            bis_configs.append(bis_config)

    if not bis_configs:
        logger.critical(
            "В конфигурационном файле в секции [bis_ports] указаны БИСы, "
            "которые отсутствуют в файле координат или кэше БИС. Проверьте корректность конфигурации и данных."
        )
        raise SystemExit(1)

    global bis_process_configs
    bis_process_configs = bis_configs

    return bis_configs


def get_bis_process_configs() -> Optional[List[BisConfig]]:
    """
    Геттер для глобальной переменной bis_process_configs.

    Возвращает список конфигураций BIS-процессов, если они были подготовлены,
    иначе None.
    """
    return bis_process_configs


def get_bis_process_config_by_bis_id(bis_id: int) -> Optional[BisConfig]:
    """
    Получает конфигурацию процесса обработки БИС по заданному ID БИС

    Ищет, по какому конфигу обрабатывается данный БИС через поле конфига bis_list
    """
    for bis_config in bis_process_configs:
        for bis in bis_config['bis_list']:
            if bis.id == bis_id:
                return bis_config
    return None


def get_cmd_endpoint_by_bis_id(bis_id: int) -> Optional[str]:
    """
    Получает адрес (эндпоинт) для отправки команд для БИС с заданным ID


    Ищет, по какому конфигу обрабатывается данный БИС через поле конфига bis_list и берет оттуда поле с адресом
    """
    bis_process_config = get_bis_process_config_by_bis_id(bis_id)
    if bis_process_config:
        return bis_process_config.get('cmd_rep_endpoint')
    return None
