import json
import logging
from datetime import timedelta

from jsonschema.exceptions import ValidationError
from jsonschema.validators import validate

from global_data.config_schema import comparison_si_threshold, config, comparison_si_threshold_schema


def prepare_comparison_si_threshold():
    """Функция для чтения и записи пороговых значений для сравнения форм СИ"""
    try:
        with open(config['general']['path_comparison_si_threshold'], 'r') as file:
            comparison_si_threshold_values = json.load(file)
    except FileNotFoundError:
        logging.warning('Файл, расположенный в general.path_comparison_si_threshold, не найден')
    except json.JSONDecodeError as error:
        logging.warning('Ошибка декодирования JSON: comparison_si_threshold', error)
    else:
        try:
            validate(instance=comparison_si_threshold_values, schema=comparison_si_threshold_schema)
        except ValidationError as error:
            logging.error('Словарь пороговых значений для сравнения форм СИ задан в неверном формате', error)
        else:
            for parametr, value in comparison_si_threshold_values.items():
                if parametr in comparison_si_threshold:
                    if parametr == 'tb':
                        comparison_si_threshold[parametr] = timedelta(minutes=value)
                    else:
                        comparison_si_threshold[parametr] = value
    finally:
        file.close()
