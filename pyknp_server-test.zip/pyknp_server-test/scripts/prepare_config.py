import argparse
import configparser
import json
import logging
import os
import sys
from pathlib import Path

from global_data import appdata, config_schema
from global_data.config_schema import config as global_config
from scripts.prepare_bis_port_settings import load_bis_port_settings


def prepare_config(config_filename: str = None):
    """Формирование конфига сервера по данным из файла конфига и аргументам командной строки"""

    def config_array_to_appdata_dict(config_section: str, appdata_dict: str = None):
        """Вспомогательная функция записи секции конфига в словарь в appdata"""
        if appdata_dict:
            appdata_dict = getattr(appdata, appdata_dict)
        else:
            appdata_dict = getattr(appdata, config_section)
        for k, v in config.items(config_section):
            try:
                appdata_dict[int(k)] = int(v)
            except ValueError:
                try:
                    appdata_dict[k] = int(v)
                except ValueError:
                    pass

    def bis_control_numeric(varname: str):
        min_value = None
        try:
            min_value = config_schema.bis_control_min_values[varname]
        except KeyError:
            pass
        max_value = None
        try:
            max_value = config_schema.bis_control_max_values[varname]
        except KeyError:
            pass
        default_value = None
        try:
            default_value = config_schema.bis_control_default_values[varname]
        except KeyError:
            pass
        try:
            if varname == 'speed_residual_inaccuracy_threshold':
                var = config['bis_control'].getfloat(varname, default_value)
            else:
                var = config['bis_control'].getint(varname, default_value)
        except configparser.NoSectionError:
            var = default_value
        if (min_value is not None) and var < min_value:
            var = default_value
        if (max_value is not None) and var > max_value:
            var = default_value
        global_config['bis_control'][varname] = var

    def bis_control_boolean(varname: str):
        try:
            value = config['bis_control'].get(varname, "no")
            if value == 'yes' or value == 'True' or value == 'true' or value == 1 or value == '1':
                global_config['bis_control'][varname] = True
            else:
                global_config['bis_control'][varname] = False
        except (configparser.NoSectionError, ValueError, KeyError):
            pass

    parser = argparse.ArgumentParser(description='KNP server')
    parser.add_argument("-a", dest="bisHost", help='BIS host')
    parser.add_argument("-p", dest="bisPort", help='BIS port', type=int)
    parser.add_argument("-c", dest="configFile", help='Config filename')
    parser.add_argument("-cdb", dest="cdbMode", help='Specify cdb mode', choices=['new', 'old'])
    parser.add_argument("-tldb", dest="tldbMode", help='Specify tldb mode', choices=['sqlite', 'pg'])
    parser.add_argument("-s", dest="enableSimulatedCdb", action='store_true', default=False)
    args = parser.parse_args()

    if args.configFile:
        global_config['configFile'] = Path(args.configFile).resolve()
    elif config_filename:
        if os.path.isfile(config_filename):
            global_config['configFile'] = Path(config_filename).resolve()
    else:
        global_config['configFile'] = Path(global_config['configFile']).resolve()

    config = configparser.ConfigParser()

    try:
        with open(global_config['configFile']) as configfile:
            config.read_file(configfile)
    except FileNotFoundError:
        logging.error('Не найден файл конфигурации')
        sys.exit(-1)
    except configparser.MissingSectionHeaderError:
        logging.error('В конфигурационном файле отсутствует заголовок секции')
        sys.exit(-1)
    except configparser.ParsingError as e:
        logging.error(f'Ошибка структуры конфигурационного файла: {str(e)}')
        sys.exit(-1)

    try:
        global_config['bis']['host'] = config['bis'].get('host', None)
        global_config['bis']['port'] = config['bis'].get('port', None)  # для совместимости со старыми ветками
        global_config['postgresql']['host'] = config['postgresql'].get('host', None)
        global_config['postgresql']['port'] = config['postgresql'].get('port', None)
        global_config['postgresql']['dbname'] = config['postgresql'].get('dbname', None)
        global_config['postgresql']['tldbname'] = config['postgresql'].get('tldbname', None)
        global_config['postgresql']['username'] = config['postgresql'].get('username', None)
        global_config['postgresql']['password'] = config['postgresql'].get('password', None)
        global_config['postgresql']['schema'] = config['postgresql'].get('schema', 'knpresults')
        global_config['cdb']['host'] = config['cdb'].get('host', None)
        global_config['cdb']['port'] = config['cdb'].get('port', None)
        global_config['cdb']['dbname'] = config['cdb'].get('dbname', None)
        global_config['cdb']['username'] = config['cdb'].get('username', None)
        global_config['cdb']['password'] = config['cdb'].get('password', None)
        global_config['cdb']['schema'] = config['cdb'].get('schema', None)
        global_config['server']['port'] = config['server'].getint('port', 0)
        global_config['server']['service_interval'] = config['server'].getint('service_interval', 600)  # в секундах
        global_config['server']['storage_interval'] = config['server'].getint('storage_interval', 24 * 3)  # в часах
        global_config['server']['copy_old_data'] = config['server'].get('copy_old_data', 'no')
        global_config['server']['store_raw_packets'] = config['server'].get('store_raw_packets', 'no')
        global_config['zrv_analyse']['step'] = config['zrv_analyse'].getint('step', 300)  # в секундах
        global_config['zrv_analyse']['limit'] = config['zrv_analyse'].getint('limit', 3 * 86400)  # в секундах
        global_config['decimation']['residuals_decimation_interval'] = config['decimation'].getint(
            'residuals_decimation_interval', 10)
        global_config['decimation']['meteoparameters_decimation_interval'] = config['decimation'].getint(
            'meteoparameters_decimation_interval', 30)  # секунды
        global_config['decimation']['opmessage_decimation_interval'] = config['decimation'].getint(
            'opmessage_decimation_interval', 30)  # штук
        global_config['decimation']['nav_solution_decimation_interval'] = config['decimation'].getint(
            'nav_solution_decimation_interval', 30)  # штук
        global_config['decimation']['controls_decimation_interval'] = config['decimation'].getint(
            'controls_decimation_interval', 30)  # штук
        global_config['general']['reject_cache_depth'] = config['general'].getint('reject_cache_depth', 10)  # штук
        global_config['general']['use_average_residuals'] = config['general'].get('use_average_residuals', 'yes')
        global_config['general']['path_alarm'] = config['general'].get('path_alarm', './alarm.mp3')
        global_config['general']['path_values_pattern_L1SF'] = config['general'].get('path_values_pattern_L1SF',
                                                                                     './values_pattern_L1SF.cfg')
        global_config['general']['path_comparison_si_threshold'] = config['general'].get('path_comparison_si_threshold',
                                                                                         './comparison_si_threshold.cfg')
        global_config['opmessage']['auto_finalize_timeout'] = config['opmessage'].getint('auto_finalize_timeout', 60)
        global_config['opmessage']['auto_approve_timeout'] = config['opmessage'].getint('auto_approve_timeout', 600)

        global_config['log']['path'] = config['log'].get('path', None)
        global_config['log']['log_file_length'] = config['log'].getint('log_file_length', None)
        global_config['log']['log_backup_num'] = config['log'].getint('log_backup_num', None)
        global_config['station_coordinates']['path'] = config['station_coordinates'].get('path', None)
        allowed_hide_intervals_string = config['server'].get('allowed_hide_intervals', None)  # перечень разрешенных
        # интервалов блокировки сигнальных признаков (значения в секундах, разделенные запятыми)
        global_config['station_coordinates']['path'] = config['station_coordinates'].get('path', None)
        global_config['generalized_di']['exclude_bad_frames'] = config['generalized_di'].get('exclude_bad_frames',
                                                                                             'no')
        global_config['generalized_di']['lag_interval'] = config['generalized_di'].getint('lag_interval', 120)
        global_config['generalized_di']['compose_period'] = config['generalized_di'].getint('compose_period', 30)
        global_config['generalized_di']['frame_search_depth_for_operational_control'] = config['generalized_di'].getint(
            'frame_search_depth_for_operational_control', 2)

        global_config['di_control']['tk_difference'] = config['di_control'].getint('tk_difference', 100)

        global_config['PDOP']['full_file_name_PDOP'] = config['PDOP'].get('full_file_name_PDOP',
                                                                          'PDOPS_0.txt')  # полное имя файла, в который будут сохраняться промежуточные данные, рассчитанные при расчете PDOP перед расчетом доступности
        global_config['PDOP']['full_file_name_availability'] = config['PDOP'].get('full_file_name_availability',
                                                                                  'availability_sec_data_0.txt')
        global_config['PDOP']['nka_elevation_mask'] = config['PDOP'].getfloat('nka_elevation_mask',
                                                                              5)  # маска НКА по углу места
        global_config['PDOP']['max_pdop_na_spread'] = config['PDOP'].getint('max_pdop_na_spread', 2)
        global_config['PDOP']['PDOP_time_step'] = config['PDOP'].getint('PDOP_time_step', 120)
        global_config['PDOP']['availability_time_step'] = config['PDOP'].getint('availability_time_step', 30)

        global_config['SI']['search_depth_169'] = config['SI'].getint('search_depth_169', 3)  # в днях
        global_config['SI']['search_depth_701'] = config['SI'].getint('search_depth_701', 5)  # в днях
        global_config['SI']['search_depth_893'] = config['SI'].getint('search_depth_893', 3)  # в днях
        global_config['SI']['search_depth_895'] = config['SI'].getint('search_depth_895', 7)  # в днях
        global_config['SI']['search_depth_921'] = config['SI'].getint('search_depth_921', 7300)  # в днях - 20 лет
        global_config['SI']['search_depth_P4'] = config['SI'].getint('search_depth_P4', 6)  # в минутах

        global_config['cache']['lifetime_si_cache'] = config['cache'].getint('lifetime_si_cache', 300)  # в секундах

        # Писать ли определенные виды пакетов в ЛБД (по умолчанию - ДА для всех)
        global_config['write_instance_to_ldb']['opmessage'] = config['write_instance_to_ldb'].get('opmessage', 'yes')
        global_config['write_instance_to_ldb']['control'] = config['write_instance_to_ldb'].get('control', 'yes')
        global_config['write_instance_to_ldb']['navsolution'] = config['write_instance_to_ldb'].get('navsolution',
                                                                                                    'yes')
        global_config['write_instance_to_ldb']['knpopmessage'] = config['write_instance_to_ldb'].get('knpopmessage',
                                                                                                     'yes')

        # Читаем настройки портов СПО сети БИС
        path_bis_port_settings = config['general'].get('path_bis_port_settings', None)
        if not path_bis_port_settings:
            logging.error("Не задан путь до файла с настройками BIS портов в секции [general] параметром path_bis_port_settings")
            sys.exit(-1)

        global_config['general']['path_bis_port_settings'] = path_bis_port_settings
        global_config['bis_ports'] = load_bis_port_settings(path_bis_port_settings)

        # Период записи атомарной записи строк ЦИ
        global_config['write_instance_to_ldb']['bulk_string_insert_interval'] = config['write_instance_to_ldb'].getint(
            'bulk_string_insert_interval', 2)

        # Глубина поиска про запросе архивных невязок на интерфейсе
        global_config['interface']['history_residuals_search_depth'] = config['interface'].getint(
            'history_residuals_search_depth', 1)
        # Параметр количества максимальных точек для архивных графиков из БД Residuals
        global_config['interface']['history_residuals_chart_max_record_count'] = (
            config['interface'].getint('history_residuals_chart_max_record_count', 150_000))

        # Параметры контроля поступления измерений
        global_config['measurement_reception_control']['sufficient_rate_for_zone_meas_count'] = config[
            'measurement_reception_control'].getfloat(
            'sufficient_rate_for_zone_meas_count', 0.7)
        global_config['measurement_reception_control']['meas_acceptable_delay'] = config[
            'measurement_reception_control'].getint(
            'meas_acceptable_delay', 5)
        global_config['measurement_reception_control']['meas_acceptable_absence'] = config[
            'measurement_reception_control'].getint(
            'meas_acceptable_absence', 5)
        global_config['measurement_reception_control']['di_acceptable_error_level'] = config[
            'measurement_reception_control'].getfloat(
            'di_acceptable_error_level', 0.05)

        nka_data_signals = (config['nka_data_signals'])
        for nka, nka_list in nka_data_signals.items():
            nka_list = json.loads(nka_list)
            nka = json.loads(nka)
            global_config['nka_data_signals']['nka'].append(nka)
            global_config['nka_data_signals']['nka_data'][nka] = (dict(
                sys_num=nka, nku_num=nka_list[0], type_ka=nka_list[1], type_si=nka_list[1])
            )
            global_config['nka_data_signals']['nka_signals'][nka] = nka_list[2]
        if args.bisHost:
            global_config['bis']['host'] = args.bisHost
        if args.bisPort:
            global_config['bis']['port'] = args.bisPort
        if args.cdbMode:
            global_config['cdb']['mode'] = args.cdbMode
        if args.tldbMode:
            global_config['tldb']['mode'] = args.tldbMode
        if args.enableSimulatedCdb:
            global_config['cdb']['simulated'] = args.enableSimulatedCdb

        config_array_to_appdata_dict('reliability_control_elevation')
        config_array_to_appdata_dict('receive_control_elevation')
        config_array_to_appdata_dict('min_elevation')
        config_array_to_appdata_dict('solution_distance_threshold')

    except configparser.NoSectionError:
        logging.error("Отсутствует обязательный заголовок секции в конфигурационном файле!")
        sys.exit(-1)

    bis_control_numeric(varname='station_receiving_error_threshold')
    bis_control_numeric(varname='signal_validity_percent')
    bis_control_numeric(varname='signal_validity_analyzing_time')
    bis_control_numeric(varname='station_validity_error_threshold')
    bis_control_numeric(varname='nvz_solution_inaccuracy_threshold')
    bis_control_numeric(varname='residual_pairs_difference_threshold')
    bis_control_numeric(varname='residual_average_difference_threshold')
    bis_control_numeric(varname='speed_residual_inaccuracy_threshold')
    bis_control_numeric(varname='min_elevation_for_nav_solution')
    bis_control_numeric(varname='log_level')
    bis_control_numeric(varname='allowed_delay_for_signal_status')
    bis_control_boolean(varname='check_packet_receive_time')
    bis_control_boolean(varname='check_di_receive_in_time')
    bis_control_boolean(varname='use_troposphere_model')
    bis_control_numeric(varname='min_amount_bis_for_generalized_opmessage')
    bis_control_numeric(varname='residual_averaging_interval')
    bis_control_numeric(varname='average_residual_averaging_interval')
    bis_control_numeric(varname='max_diff_between_local_and_packet_time')
    bis_control_numeric(varname='meteodata_actual_duration')

    bis_control_boolean(varname='min_packets')

    if None in global_config['bis'].values():
        logging.error('BIS config is incomplete')
        sys.exit(-1)

    if None in global_config['postgresql'].values():
        logging.error('PostgreSQL config is incomplete')
        sys.exit(-1)

    try:
        global_config['server']['ldb'] = config['server'].get('ldb', None)
    except (configparser.NoSectionError, ValueError, KeyError):
        pass

    try:
        global_config['debug']['enable_debug_level_logging'] = config['debug'].get('enable_debug_level_logging', "no")
    except (configparser.NoSectionError, ValueError, KeyError):
        pass
    try:
        global_config['debug']['peewee_logging'] = config['debug'].get('peewee_logging', "no")
    except (configparser.NoSectionError, ValueError, KeyError):
        pass
    try:
        global_config['debug']['bis_communication_logging'] = config['debug'].get('bis_communication_logging', "no")
    except (configparser.NoSectionError, ValueError, KeyError):
        pass
    try:
        global_config['debug']['packet_stat_logging'] = config['debug'].get('packet_stat_logging', "no")
    except (configparser.NoSectionError, ValueError, KeyError):
        pass

    if allowed_hide_intervals_string:
        for allowed_hide_interval in allowed_hide_intervals_string.split(','):
            appdata.allowed_hide_intervals.append(int(allowed_hide_interval))
    else:
        logging.error('Не обнаружен параметр server.allowed_hide_intervals '
                      'с перечнем разрешенных интервалов сокрытия сигнальных флагов')
        sys.exit(-1)

    if global_config['server']['copy_old_data'] == 'yes' \
            and global_config['server']['store_raw_packets'] == 'yes':
        logging.error('Выявлен конфликт параметров server.copy_old_data и server.store_raw_packets. '
                      'Параметры не могут иметь значение yes одновременно.')
        sys.exit(-1)
    if global_config['general']['reject_cache_depth'] < 3 or global_config['general']['reject_cache_depth'] > 30:
        logging.error('Значение параметра general.reject_cache_depth должно находиться в приделах от 3 до 30.'
                      'Для иных значений не определен критерий отбраковки.')
        sys.exit(-1)
