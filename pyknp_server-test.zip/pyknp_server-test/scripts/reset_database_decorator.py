import logging
import os

import db
from db.cdb import BaseModel
from db.cdb.common import init_and_open_cdb_connection, close_cdb_connection


def reset_database(func):
    """Закрывает текущее соединение с ТЛБД, создает и привязывает новый объект базы данных"""

    def wrapper(*args, **kwargs):
        BaseModel._meta.database.close()
        new_db_conn = db.db_connection.create_tldb_connection()
        BaseModel._meta.database = db.db_connection.create_tldb_connection()
        db.db_connection.db = new_db_conn
        logging.debug(f'Объект базы данных был пересоздан для процесса: {os.getpid()}')

        # Пересоздаем соединение с ЦБД
        close_cdb_connection()
        init_and_open_cdb_connection()

        return func(*args, **kwargs)

    return wrapper
