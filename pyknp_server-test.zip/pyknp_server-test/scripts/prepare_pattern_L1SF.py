import logging
import json

from global_data import appdata
from global_data.config_schema import config


def prepare_pattern_L1SF():
    """Функция для чтения констант и значений, относящихся к ЦИ L1SF"""
    try:
        with open(config['general']['path_values_pattern_L1SF'], 'r') as file:
            appdata.values_in_pattern_L1SF = json.load(file)
    except FileNotFoundError:
        logging.warning('Файл, расположенный в general.path_values_pattern_L1SF, не найден')
    except json.JSONDecodeError as error:
        logging.warning('Ошибка декодирования JSON: values_pattern_L1SF', error)
    finally:
        file.close()
