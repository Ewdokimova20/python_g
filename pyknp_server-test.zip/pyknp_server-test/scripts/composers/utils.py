import datetime
import logging

import peewee

from data import SummarizedFramesInfo, SummarizedFrameComparison, BaseDIFrame, CDSignalFrame
from global_data import appdata
from global_data.appdata import FREQ_SIGNAL_TYPES, NKA_DATA
from global_data.config_schema import config
from models.base import db
from models.nka import Nka
from models.op_message import KNPOpSumMessage
from utils.SI.common import SIFORM, SIRecord
from utils.SI.compare_si_to_di.types import TimeData, SiFormNum, ComparisonResult, AllFormsComparison, \
    SiFormNameForClient
from utils.caches import cache_bis


def get_tk_from_summarized_frame(summarized_frame):
    """Получить параметр tk из обобщенного кадра."""
    try:
        if summarized_frame.signal_type in FREQ_SIGNAL_TYPES:
            tk = summarized_frame.tk
        else:  # кодовые
            tk = summarized_frame.time
    except AttributeError:
        return
    else:
        return tk


def find_inconsistency_in_comparison_DI_SI(comparison_result: ComparisonResult):
    """Поиск несоответствий в сравнении ЭИ, ЧВП и альманаха из обобщённой ЦИ с заложенными СИ"""
    SI_DI_inconsistency = set()  # сет СИ форм, в которых есть несоответствия СИ с ЦИ

    for name_info, info in comparison_result['forms'].items():
        if name_info == SiFormNameForClient.CLOCKP:
            data = info.get("data", ())
            for parameter in data:
                if parameter['is_valid'] is False:
                    SI_DI_inconsistency.add(SIFORM.CLOCKP)
        if name_info == SiFormNameForClient.EPHEMERIS:
            data = info.get("data", ())
            for parameter in data:
                if parameter['is_valid'] is False:
                    SI_DI_inconsistency.add(SIFORM.EPHEMERIS)
        if name_info == SiFormNameForClient.ALMANAC:
            data = info.get("data", ())
            for almanac in data.values():
                for parameter in almanac:
                    if parameter['is_valid'] is False:
                        SI_DI_inconsistency.add(SIFORM.ALMANAC)
                        break
                else:
                    continue
                break
    return SI_DI_inconsistency


def create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources):
    """Создать оперативное сообщение при несоответствии информации из обобщенного кадра с СИ"""

    tk = get_tk_from_summarized_frame(summarized_frame)
    if not tk:
        return
    SI_DI_inconsistency = find_inconsistency_in_comparison_DI_SI(comparison_result)
    if SI_DI_inconsistency:
        for source in sources:
            bis = cache_bis.get_item_by_id(source)
            if bis is None:
                return
            for si_form in SI_DI_inconsistency:
                EI_inconsistency = 0
                clock_inconsistency = 0
                almanac_inconsistency = 0
                if si_form == SIFORM.EPHEMERIS:
                    EI_inconsistency = 1
                if si_form == SIFORM.CLOCKP:
                    clock_inconsistency = 1
                if si_form == SIFORM.ALMANAC:
                    almanac_inconsistency = 1
                try:
                    KNPOpSumMessage.create(bis_id=source,
                                           nka=summarized_frame.nka,
                                           timestamp=datetime.datetime.now(),
                                           letter=-1,  # FIXME какая литера и надо ли её тут
                                           signal_type=summarized_frame.signal_type,
                                           tk=tk,
                                           EI_inconsistency=EI_inconsistency,
                                           clock_inconsistency=clock_inconsistency,
                                           almanac_inconsistency=almanac_inconsistency)
                except peewee.PeeweeException:
                    logging.debug(
                        f"Ошибка при сохранении оперативного сообщения по обобщенному кадру: signal_type {summarized_frame.signal_type}")
    return comparison_result


def save_framesources_to_ldb(summarize_frame_id, signal_type, nka, timestamp, sources):
    """Запись в ТЛБД источников обобщенного кадра """

    try:
        summarized_frame_info = SummarizedFramesInfo.create(frame_id=summarize_frame_id,
                                                            signal_type=signal_type,
                                                            nka=nka,
                                                            timestamp=timestamp,
                                                            sources=sources)
    except peewee.DoesNotExist:
        logging.debug(
            f"Не удалось сохранить источники обобщенного кадра: {summarize_frame_id}, тип сигнала {signal_type}.")
        return None
    return summarized_frame_info.id


def save_sources_for_summarize_FDframe(strings, summarize_frame_id, nka, timestamp, signal_type):
    """Сохранение источников обобщенного кадра c частотным разделением в таблицу SummarizedFramesInfo"""
    sources = set()
    for string, content in strings.items():
        if content:
            sources.add(content.bis_id)
    summarized_frame_info_id = save_framesources_to_ldb(summarize_frame_id, signal_type, nka, timestamp, sources)
    return sources, summarized_frame_info_id


def save_sources_for_summarize_frame_l2ksi(strings, summarize_frame_id, nka, timestamp, signal_type):
    """Сохранение источников обобщенного кадра L2KSI в таблицу SummarizedFramesInfo"""
    sources = set()
    for string in strings:
        if string.bis_id is not None:
            sources.add(string.bis_id)
    save_framesources_to_ldb(summarize_frame_id, signal_type, nka, timestamp, sources)


def save_sources_for_summarize_CDframe(strings, summarize_frame_id, nka, timestamp, signal_type):
    """Сохранение источников обобщенного кадра с кодовым разделением в таблицу SummarizedFramesInfo"""
    sources = set()
    for number, string in strings.items():
        if type(string) not in [list]:
            sources.add(string.bis_id)
        else:
            for one_string in string:  # строки, которые внутри содержат список
                sources.add(one_string.bis_id)
    summarized_frame_info_id = save_framesources_to_ldb(summarize_frame_id, signal_type, nka, timestamp, sources)
    return sources, summarized_frame_info_id
