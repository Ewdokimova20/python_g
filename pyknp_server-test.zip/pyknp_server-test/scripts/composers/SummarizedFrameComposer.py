import logging
import traceback
from collections import defaultdict, Counter
from datetime import timedelta, datetime
from typing import Type, List, Union

from peewee import DoesNotExist, JOIN

from data import L2KSIString, L1OFFrame, L2OFFrame, L1SFFrame, L1OCFrame, \
    L1SCFrame, L2SCFrame, L3OCFrame, CDSignalFrame, OFSignalFrame, JSONStringIdListField, BaseDIFrame
from global_data.appdata import BAD_FRAME_TK
from global_data.config_schema import config
from models.di_string.base_di_string import BaseDIString
from models.nka import Nka
from scripts.composers.utils import create_opmessage_for_inconsistency_DI_SI, save_sources_for_summarize_frame_l2ksi, \
    save_sources_for_summarize_CDframe, save_sources_for_summarize_FDframe
from utils.SI.compare_si_to_di.online_comparison_to_si.online_comparison_to_si import online_compare_to_si
from utils.almanac.update_almanac import update_almanac_lf, update_almanac_lc
from utils.caches.cache import cache_manager

logger = logging.getLogger('summarize_frame_composer')

IS_EXCLUDED_BAD_FRAME = True if config['generalized_di']['exclude_bad_frames'] == 'yes' else False
"""Исключать ли кадры с неопределенным tk при обобщении"""


class SummarizedDIFrameComposer:
    """Обощенный сборщик обобщенных кадров сигналов ГЛОНАСС"""

    string_in_frame: int = 0

    model = None
    """Класс модели ЛБД"""

    last_queried_id = None
    """Словарь последних запрошенных ID по ЛБД по типам сигналов"""

    @property
    def signal_type(self):
        """Тип сигнала, отличаться будет только у L2KSI"""
        return self.model.signal_type

    def __init__(self, model: Type[Union[OFSignalFrame, CDSignalFrame]]):
        """Иниц. буфер для накопления кадров. 1 уровень ключей - tk, 2 - системный номер НКА, 3 - тип сигнала"""
        self.frame_buffer = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        self.last_queried_id = defaultdict(lambda: 1)
        self.model = model
        self.init_frame_buffer()

    def append_frames_to_buffer(self, selected_frames):
        for frame in selected_frames:
            timestamp = round(frame.timestamp.timestamp())
            nka = frame.nka_id
            self.frame_buffer[timestamp][nka][self.signal_type].append(frame)

    def fetch_frames(self, is_init=False) -> List['BaseDIFrame']:
        """
        Извлечение кадров из базы данных на основе заданных параметров.

        Аргументы:
            ref_datetime (datetime, optional): Контрольная дата и время для запроса. По умолчанию None.

        Возвращает:
            list: Список извлеченных кадров.
        """

        selected_frames: List['BaseDIFrame'] = []
        if is_init:
            # получаем кадры при инициализации на заданную глубину
            time_now = datetime.now()
            time_depth = time_now - timedelta(seconds=config['generalized_di']['lag_interval'])
            where_condition = ((self.model.timestamp >= time_depth) &
                               (self.model.timestamp <= time_now) &
                               (self.model.bis.is_null(False)))
        else:
            # получаем кадры при повторном заполнении с последнего запрошенного id по самый свежий
            where_condition = ((self.model.id > self.last_queried_id[self.signal_type]) &
                               (self.model.bis.is_null(False)))

        if IS_EXCLUDED_BAD_FRAME:
            if issubclass(self.model, OFSignalFrame):
                where_condition = where_condition & (self.model.tk != BAD_FRAME_TK)
            elif issubclass(self.model, CDSignalFrame):
                where_condition = where_condition & (self.model.seq != 0)

        if issubclass(self.model, L1OFFrame) or issubclass(self.model, L2OFFrame):
            selected_frames = (self.model.select()
                               .join(Nka, on=(self.model.nka == Nka.nka_sys_number), join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type, on=(self.model.string1 == self.model.string_type.id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string2'),
                                     on=(self.model.string2 == self.model.string_type.alias('string2').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string3'),
                                     on=(self.model.string3 == self.model.string_type.alias('string3').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string4'),
                                     on=(self.model.string4 == self.model.string_type.alias('string4').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string5'),
                                     on=(self.model.string5 == self.model.string_type.alias('string5').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string6'),
                                     on=(self.model.string6 == self.model.string_type.alias('string6').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string7'),
                                     on=(self.model.string7 == self.model.string_type.alias('string7').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string8'),
                                     on=(self.model.string8 == self.model.string_type.alias('string8').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string9'),
                                     on=(self.model.string9 == self.model.string_type.alias('string9').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string10'),
                                     on=(self.model.string10 == self.model.string_type.alias('string10').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string11'),
                                     on=(self.model.string11 == self.model.string_type.alias('string11').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string12'),
                                     on=(self.model.string12 == self.model.string_type.alias('string12').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string13'),
                                     on=(self.model.string13 == self.model.string_type.alias('string13').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string14'),
                                     on=(self.model.string14 == self.model.string_type.alias('string14').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string15'),
                                     on=(self.model.string15 == self.model.string_type.alias('string15').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .where(where_condition)
                               )
        elif issubclass(self.model, L1SFFrame):
            selected_frames = (self.model.select()
                               .join(Nka, on=(self.model.nka == Nka.nka_sys_number), join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type, on=(self.model.string1 == self.model.string_type.id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string2'),
                                     on=(self.model.string2 == self.model.string_type.alias('string2').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string3'),
                                     on=(self.model.string3 == self.model.string_type.alias('string3').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string4'),
                                     on=(self.model.string4 == self.model.string_type.alias('string4').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string5'),
                                     on=(self.model.string5 == self.model.string_type.alias('string5').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string6'),
                                     on=(self.model.string6 == self.model.string_type.alias('string6').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string7'),
                                     on=(self.model.string7 == self.model.string_type.alias('string7').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string8'),
                                     on=(self.model.string8 == self.model.string_type.alias('string8').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string9'),
                                     on=(self.model.string9 == self.model.string_type.alias('string9').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string10'),
                                     on=(self.model.string10 == self.model.string_type.alias('string10').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .where(where_condition)
                               )

        elif issubclass(self.model, CDSignalFrame):
            selected_frames = (self.model.select()
                               .join(Nka, on=(self.model.nka == Nka.nka_sys_number), join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type, on=(self.model.string10 == self.model.string_type.id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string11'),
                                     on=(self.model.string11 == self.model.string_type.alias('string11').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string12'),
                                     on=(self.model.string12 == self.model.string_type.alias('string12').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .join(self.model.string_type.alias('string13'),
                                     on=(self.model.string13 == self.model.string_type.alias('string13').id),
                                     join_type=JOIN.LEFT_OUTER)
                               .where(where_condition)
                               )
            # достаем строки для кодовых сигналов, лежащие в массивах в поле JSONStringIdListField
            if len(selected_frames) > 0:
                array_fields = [name for name, field in self.model.__dict__.items() if
                                hasattr(field, 'field') and isinstance(field.field, JSONStringIdListField)]
                for frm in selected_frames:
                    for field in array_fields:
                        field_content = getattr(frm, field)
                        if field_content is not None:
                            setattr(frm, field,
                                    list(self.model.string_type.select().join(Nka).where(
                                        self.model.string_type.id.in_(field_content))))
        elif issubclass(self.model, L2KSIString):
            selected_frames = self.model.select().join(Nka).where(where_condition)

        return selected_frames

    def init_frame_buffer(self):
        """Инициализация буфера кадров, ждущих обобщения, из ЛБД"""

        # 1 - получаем кадры из ТЛБД
        selected_frames = self.fetch_frames(is_init=True)

        if len(selected_frames) > 0:
            # 2 - распределяем полученные кадры в буфер сборщика
            self.append_frames_to_buffer(selected_frames)
            # 3 - определяем id самого последнего полученного кадра
            self.last_queried_id[self.signal_type] = max(frame.id for frame in selected_frames)
        else:
            try:
                last_frame = self.model.select().order_by(self.model.id.desc()).get()
                self.last_queried_id[self.signal_type] = last_frame.id
            except DoesNotExist:
                pass

    def fill_frame_buffer(self):
        """Заполнение буфера кадров, ждущих обобщения, из ЛБД"""

        # 1 - получаем кадры из ТЛБД
        selected_frames = self.fetch_frames()

        if len(selected_frames) > 0:
            # 2 - распределяем полученные кадры в буфер сборщика
            self.append_frames_to_buffer(selected_frames)
            # 3 - определяем id самого последнего полученного кадра
            self.last_queried_id[self.signal_type] = max(frame.id for frame in selected_frames)

    @staticmethod
    def summarize_string(string_list: List['BaseDIString']):
        strings_passed_check = [string for string in string_list if not string.error_in_string]  # сошелся Хэмминг
        strings_not_passed_check = [string for string in string_list if string.error_in_string]  # не сошелся Хэмминг

        #  если в одной или более строк сошелся код Хэмминга
        if len(strings_passed_check) > 0:
            strings_passed_check_content = [string.int_content for string in strings_passed_check]
            #  Проверяем, сколько уникальных со содержимому строк. Если 1, то все совпали.
            unique_string_values = set(strings_passed_check_content)

            #  если все строки совпали, возвращаем любую (первую)
            if len(unique_string_values) == 1:
                return strings_passed_check[0]  # ошибок нет, все совпали
            #  если совпали не все, возвращаем самую часто встречающуюся
            else:
                string_counts_without_error = Counter(strings_passed_check_content)
                most_common_content, _ = string_counts_without_error.most_common()[0]
                for string in strings_passed_check:
                    if string.int_content == most_common_content:
                        return string  # ошибки есть, вернулась самая часто встречающаяся
                return strings_passed_check[0]  # редкий случай, если Counter выдал косячный most_common_content,
                # которого почему-то не оказалось в strings_passed_check

        #  если код Хэмминга не сошелся ни в одной строке, возвращаем самую часто встречающуюся
        if len(strings_not_passed_check) > 0:
            string_counts_with_error = Counter([string.int_content for string in strings_not_passed_check])
            most_common_content, _ = string_counts_with_error.most_common()[0]
            for string in strings_not_passed_check:
                if string.int_content == most_common_content:
                    return string  # ошибки есть, вернулась самая часто встречающаяся
            return strings_not_passed_check[0]  # редкий случай, если Counter выдал косячный most_common_content,
            # которого почему-то не оказалось в strings_not_passed_check

    def get_summarized_strings(self, frame_list: list) -> dict:
        """Ф-я выдачи словаря обощенных строк, подготовленных для записи. Ключ: номер строки, значение:строка"""

        strings = {}
        for string_num in range(1, self.string_in_frame + 1):
            # собираем все одноименные строки из всех кадров
            string_values = []
            string_name = 'string' + str(string_num)
            for frame in frame_list:
                string = getattr(frame, string_name, None)
                if string:
                    string_values.append(string)

            # а потом обобщаем их
            strings[string_num] = self.summarize_string(string_list=string_values)
        return strings

    def summarize_frame(self, frame_list: list):
        pass

    def summarize_all(self, current_timestamp: int):
        """Обобщение всего буфера накопленных кадров"""

        # Заполняем буфер кадров из ЛБД
        self.fill_frame_buffer()

        # Пробегаем буфер и обобщаем кадры с одинаковыми номером НКА, датой и типом сигнала
        for frame_timestamp in list(self.frame_buffer.keys()):
            if int(frame_timestamp) <= int(current_timestamp):
                for nka_buffer in self.frame_buffer[frame_timestamp].values():
                    for frame_list_by_signal in nka_buffer.values():
                        if len(frame_list_by_signal) > 0:
                            try:
                                self.summarize_frame(frame_list_by_signal)
                            except Exception:
                                first_frame_str = str(frame_list_by_signal[0]) if frame_list_by_signal[0] else 'None'
                                logger.warning(
                                    f'Произошла ошибка при обобщении буфера. Параметры первого кадра из списка в буфере: {first_frame_str}')
                                logger.info(traceback.format_exc())

                # Очистка старых записей буфера до заданной даты-время включительно"""
                if frame_timestamp in self.frame_buffer.keys():  # какая-то ДИЧЬ, но бывает, что time из ключей уже успел куда-то пропасть
                    del self.frame_buffer[frame_timestamp]
                else:
                    logger.info(
                        f'ДИЧЬ!: {frame_timestamp}, time in list(self.frame_buffer.keys()) = {frame_timestamp in list(self.frame_buffer.keys())}, time in self.frame_buffer.keys() = {frame_timestamp in self.frame_buffer.keys()}')


class SummarizedOFFrameComposer(SummarizedDIFrameComposer):
    """Сборщик обобщенных кадров открытых сигналов с частотным разделением"""

    string_in_frame: int = 15

    def summarize_frame(self, frame_list: list):
        strings = self.get_summarized_strings(frame_list)
        nka = cache_manager.get_nka(frame_list[0].nka_id)
        frame = frame_list[0]
        frame_data = {
            'nka': nka,
            'bis': None,
            'tk': frame.tk,
            'seq': frame.seq,
            'num': frame.num,
            'time': frame.time,
            'is_fifth': frame.is_fifth,
            'is_complete': len(strings) == self.string_in_frame,  # заурядно проверям количество независимо от качества
            'string1': strings.get(1, None),
            'string2': strings.get(2, None),
            'string3': strings.get(3, None),
            'string4': strings.get(4, None),
            'string5': strings.get(5, None),
            'string6': strings.get(6, None),
            'string7': strings.get(7, None),
            'string8': strings.get(8, None),
            'string9': strings.get(9, None),
            'string10': strings.get(10, None),
            'string11': strings.get(11, None),
            'string12': strings.get(12, None),
            'string13': strings.get(13, None),
            'string14': strings.get(14, None),
            'string15': strings.get(15, None),
            'timestamp': frame.timestamp
        }
        summarized_frame = self.model(**frame_data)
        summarized_frame_id = self.model.insert(**frame_data).on_conflict_ignore().execute()
        summarized_frame.id = summarized_frame_id

        update_almanac_lf(summarized_frame)
        sources, summarized_frame_info_id = save_sources_for_summarize_FDframe(strings, summarized_frame_id, nka,
                                                                               frame_data['timestamp'],
                                                                               self.model.signal_type)
        comparison_result = None
        if summarized_frame_info_id:
            comparison_result = online_compare_to_si(summarized_frame, summarized_frame_info_id)
        if comparison_result and sources:
            create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources)


class SummarizedSFFrameComposer(SummarizedDIFrameComposer):
    """Сборщик обобщенных кадров закрытого сигнала с частотным разделением"""

    string_in_frame: int = 10

    def summarize_frame(self, frame_list: list):
        strings = self.get_summarized_strings(frame_list)
        nka = cache_manager.get_nka(frame_list[0].nka_id)
        frame = frame_list[0]
        frame_data = {
            'nka': nka,
            'bis': None,
            'tk': frame.tk,
            'seq': frame.seq,
            'num': frame.num,
            'time': frame.time,
            'is_complete': len(strings) == self.string_in_frame,  # заурядно проверям количество независимо от качества
            'string1': strings.get(1, None),
            'string2': strings.get(2, None),
            'string3': strings.get(3, None),
            'string4': strings.get(4, None),
            'string5': strings.get(5, None),
            'string6': strings.get(6, None),
            'string7': strings.get(7, None),
            'string8': strings.get(8, None),
            'string9': strings.get(9, None),
            'string10': strings.get(10, None),
            'timestamp': frame.timestamp
        }
        summarized_frame = self.model(**frame_data)
        summarized_frame_id = self.model.insert(**frame_data).on_conflict_ignore().execute()

        sources, summarized_frame_info_id = save_sources_for_summarize_FDframe(strings, summarized_frame_id, nka,
                                                                               frame_data['timestamp'],
                                                                               self.model.signal_type)
        comparison_result = None
        if summarized_frame_info_id:
            comparison_result = online_compare_to_si(summarized_frame, summarized_frame_info_id)
        if comparison_result and sources:
            create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources)


class SummarizedCDFrameComposer(SummarizedDIFrameComposer):
    """Сборщик обобщенных кадров кодовых сигналов с любым режимом доступа"""

    string_in_frame: int = 0

    @staticmethod
    def check_if_complete(string10):
        """Проверить, полный ли кадр"""
        is_complete = False
        if string10:
            try:
                is_complete = string10.content[0]['RP']
            except (AttributeError, KeyError, IndexError):
                pass
        return is_complete

    def get_summarized_strings(self, frame_list: list) -> dict:
        summarized_strings = {}  # ключ: тип строки; значение: одиночная строка для строк ОИ, списки для остальных

        raw_strings = {}  # ключ: ОМВ строки, значение: набор строк с такой ОМВ
        for frame in frame_list:
            for single_string in frame.immediate_strings:  # ф-я фозвращает список, состоящий из одиночных строк
                if single_string is None:  # пропускаем пустые записи, соотвествующие отсутствующим в кадрах строкам
                    continue
                # будем ориентироваться по ОМВ, т.к. номера строк не уникальны в рамках кадра
                if single_string.string_omv not in raw_strings:
                    raw_strings[single_string.string_omv] = []
                raw_strings[single_string.string_omv].append(single_string)

            for same_type_strings in frame.nonimmediate_strings:  # ф-я возвращает набор наборов строк одного типа
                if same_type_strings is None:  # пропускаем пустые записи, соотвествующие отсутствующим в кадрах строкам
                    continue
                for single_string in same_type_strings:
                    if single_string is None:  # пропускаем пустые записи, соотвествующие отсутствующим в кадрах строкам
                        continue
                    if single_string.string_omv not in raw_strings:
                        raw_strings[single_string.string_omv] = []
                        summarized_strings[single_string.string_num] = []
                    raw_strings[single_string.string_omv].append(single_string)
        # а потом обобщаем их
        for omv, same_omv_strings in raw_strings.items():
            summarized_string = self.summarize_string(string_list=same_omv_strings)
            if (summarized_string.string_num >= 10) and (summarized_string.string_num <= 13):
                summarized_strings[summarized_string.string_num] = summarized_string
            else:
                summarized_strings.setdefault(summarized_string.string_num,
                                              [])  # чтобы избежать keyerror, если не был создан список для данного номера строки
                summarized_strings[summarized_string.string_num].append(summarized_string)
        return summarized_strings


class SummarizedL1OCFrameComposer(SummarizedCDFrameComposer):
    """Сборщик обобщенных кадров кодовых сигналов открытого доступа"""

    def summarize_frame(self, frame_list: list):
        strings = self.get_summarized_strings(frame_list)
        # подсчитываем количество строк в псевдокадре для дальнейшей оценке его полноты
        string_count = 0
        for strings_with_same_type in strings.values():
            string_count += len(strings_with_same_type) if type(strings_with_same_type) is list else 1

        nka = cache_manager.get_nka(frame_list[0].nka_id)
        frame = frame_list[0]
        frame_data = {
            'nka': nka,
            'bis': None,
            'seq': frame.seq,
            'time': frame.time,
            'is_complete': self.check_if_complete(strings.get(10, None)),
            'timestamp': frame.timestamp,
            'string10': strings.get(10, None),
            'string11': strings.get(11, None),
            'string12': strings.get(12, None),
            'string20': strings.get(20, None),
            'string25': strings.get(25, None),
            'string16': strings.get(16, None),
            'string31': strings.get(31, None),
            'string32': strings.get(32, None),
            'string50': strings.get(50, None),
            'string60': strings.get(60, None),
            'string0': strings.get(0, None),
            'string_other': strings.get('other', None)
        }
        summarized_frame = self.model(**frame_data)
        summarized_frame_id = self.model.insert(**frame_data).on_conflict_ignore().execute()
        summarized_frame.id = summarized_frame_id

        update_almanac_lc(summarized_frame)
        sources, summarized_frame_info_id = save_sources_for_summarize_CDframe(strings, summarized_frame_id, nka,
                                                                               frame_data['timestamp'],
                                                                               self.model.signal_type)
        comparison_result = None
        if summarized_frame_info_id:
            comparison_result = online_compare_to_si(summarized_frame, summarized_frame_info_id)
        if comparison_result and sources:
            create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources)


class SummarizedL3OCFrameComposer(SummarizedCDFrameComposer):
    """Сборщик обобщенных кадров кодовых сигналов открытого доступа"""

    def summarize_frame(self, frame_list: list):
        strings = self.get_summarized_strings(frame_list)
        # подсчитываем количество строк в псевдокадре для дальнейшей оценке его полноты
        string_count = 0
        for strings_with_same_type in strings.values():
            string_count += len(strings_with_same_type) if type(strings_with_same_type) is list else 1

        nka = cache_manager.get_nka(frame_list[0].nka_id)
        frame = frame_list[0]
        frame_data = {
            'nka': nka,
            'bis': None,
            'seq': frame.seq,
            'time': frame.time,
            'is_complete': self.check_if_complete(strings.get(10, None)),
            'timestamp': frame.timestamp,
            'string10': strings.get(10, None),
            'string11': strings.get(11, None),
            'string12': strings.get(12, None),
            'string20': strings.get(20, None),
            'string25': strings.get(25, None),
            'string16': strings.get(16, None),
            'string31': strings.get(31, None),
            'string32': strings.get(32, None),
            'string60': strings.get(60, None),
            'string0': strings.get(0, None),
            'string_other': strings.get('other', None)
        }
        summarized_frame = self.model(**frame_data)
        summarized_frame_id = self.model.insert(**frame_data).on_conflict_ignore().execute()
        summarized_frame.id = summarized_frame_id

        update_almanac_lc(summarized_frame)
        sources, summarized_frame_info_id = save_sources_for_summarize_CDframe(strings, summarized_frame_id, nka,
                                                                               frame_data['timestamp'],
                                                                               self.model.signal_type)
        comparison_result = None
        if summarized_frame_info_id:
            comparison_result = online_compare_to_si(summarized_frame, summarized_frame_info_id)
        if comparison_result and sources:
            create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources)


class SummarizedSCFrameComposer(SummarizedCDFrameComposer):
    """Сборщик обобщенных кадров кодовых сигналов закрытого доступа"""

    def summarize_frame(self, frame_list: list):
        strings = self.get_summarized_strings(frame_list)
        # подсчитываем количество строк в псевдокадре для дальнейшей оценке его полноты
        string_count = 0
        for strings_with_same_type in strings.values():
            string_count += len(strings_with_same_type) if type(strings_with_same_type) is list else 1

        nka = cache_manager.get_nka(frame_list[0].nka_id)
        frame = frame_list[0]
        frame_data = {
            'nka': nka,
            'bis': None,
            'seq': frame.seq,
            'time': frame.time,
            'timestamp': frame.timestamp,
            'is_complete': self.check_if_complete(strings.get(10, None)),
            # тривиально сравниваем количество строк с размером псевдокадра
            'string10': strings.get(10, None),
            'string11': strings.get(11, None),
            'string12': strings.get(12, None),
            'string13': strings.get(13, None),
            'string20': strings.get(20, None),
            'string25': strings.get(25, None),
            'string16': strings.get(16, None),
            'string31': strings.get(31, None),
            'string32': strings.get(32, None),
            'string60': strings.get(60, None),
            'string0': strings.get(0, None),
            'string_other': strings.get('other', None)
        }
        summarized_frame = self.model(**frame_data)
        summarized_frame_id = self.model.insert(**frame_data).on_conflict_ignore().execute()
        summarized_frame.id = summarized_frame_id

        update_almanac_lc(summarized_frame)
        sources, summarized_frame_info_id = save_sources_for_summarize_CDframe(strings, summarized_frame_id, nka,
                                                                               frame_data['timestamp'],
                                                                               self.model.signal_type)
        comparison_result = None
        if summarized_frame_info_id:
            comparison_result = online_compare_to_si(summarized_frame, summarized_frame_info_id)
        if comparison_result and sources:
            create_opmessage_for_inconsistency_DI_SI(summarized_frame, comparison_result, sources)


class SummarizedKSIFrameComposer(SummarizedDIFrameComposer):
    """Сборщик обобщенных кадров L2КСИ"""

    model: L2KSIString
    """Класс модели ЛБД"""

    @property
    def signal_type(self):
        """Тип сигнала, отличаться будет только у L2KSI"""
        return self.model.signal_id

    def summarize_frame(self, frame_list: list):  # здесь: в отличии от остальных подается список строк от разных БИС
        summarized_string = self.summarize_string(string_list=frame_list)
        nka = cache_manager.get_nka(frame_list[0].nka_id)
        summarized_frame_id = self.model.insert(nka=nka,
                                                bis=None,
                                                string_num=summarized_string.string_num,
                                                string_omv=summarized_string.string_omv,
                                                byte_content=summarized_string.byte_content,
                                                error_in_string=summarized_string.error_in_string,
                                                timestamp=frame_list[0].timestamp).on_conflict_ignore().execute()
        save_sources_for_summarize_frame_l2ksi(frame_list, summarized_frame_id, nka, frame_list[0].timestamp,
                                               self.model.signal_id)


class SummarizedFrameComposer:
    composers: dict  # словарь всех сборщиков по типам сигналов

    def __init__(self):
        self.composers = {'L1OF': SummarizedOFFrameComposer(model=L1OFFrame),
                          'L2OF': SummarizedOFFrameComposer(model=L2OFFrame),
                          'L1SF': SummarizedSFFrameComposer(model=L1SFFrame),
                          'L1OC': SummarizedL1OCFrameComposer(model=L1OCFrame),
                          'L1SC': SummarizedSCFrameComposer(model=L1SCFrame),
                          'L2SC': SummarizedSCFrameComposer(model=L2SCFrame),
                          'L3OC': SummarizedL3OCFrameComposer(model=L3OCFrame),
                          'L2KSI': SummarizedKSIFrameComposer(model=L2KSIString)}

    def summarize_all(self, current_timestamp: int):
        for signal_name, composer in self.composers.items():
            logging.info(f'Обобщение кадров для сигнала: {signal_name}')
            composer.summarize_all(current_timestamp)


summarized_frame_composer = SummarizedFrameComposer()
