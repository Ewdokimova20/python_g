import datetime
import logging
import threading

from peewee import PeeweeException, DoesNotExist

from data import Residual, KNPNavSolution, lbd_tables_list, OperativeStorageModel
from global_data.appdata import LogLevelCode
from lbd_pg import store_resides_to_bis_knp, store_nvz_to_bis_knp
from models.bis import Bis
from scripts.handle_exception import handle_exception
from scripts.reset_database_decorator import reset_database
from scripts.setup_logging import LoggingManager


# deprecated
@reset_database
def logic(exiting: threading.Event, config):
    def copy_old_data_to_lbd_pg(copy_border: datetime.datetime, copied_type):
        """Промежуточная ф-я обеспечивающая изоляцию логики работы ТЛБД и суточных ЛБД. Была введена для минимизации
        самоповторов кода"""

        """Запрашиваем данные, которые далее будут удалены чтобы спасти их в суточных ЛБД"""
        try:
            """БИС запрашивается т.к. во всех продуктах СПО КНП, которые надо переписывать в суточные ЛБД они есть.
            При необходимости переписывать данные с отсутствующим полем БИС, необходимо будет сделать исключение"""
            copied_data = (copied_type.select(copied_type, Bis).join(Bis).where(copied_type.db_timestamp < copy_border))
        except DoesNotExist:
            pass

        """Записываем данные в суточные ЛБД используя надлежащие ф-ии для каждого типа"""
        try:
            if copied_type is Residual and copied_data.exists():
                store_resides_to_bis_knp(copied_data)
            if copied_type is KNPNavSolution and copied_data.exists():
                store_nvz_to_bis_knp(copied_data)
        except PeeweeException as err:
            if config['bis_control']['log_level'] >= LogLevelCode.LL_WARNING:
                logging.error('Сбой при копировании данных в суточную ЛБД СПО КНП: ', err)

    def clean_db(cleardb_db_connection):
        """Подчищает старые записи в ЛБД"""

        """Определяем время записи в БД, до которого данные считаются неактуальными. Это время не должно быть настолько 
        малым, что создавало бы угрозу конфиктов обработки данных. Например, если поставить 2 минуты, то кадр L1OF собрать
        не удастся из-за удаления его фрагментов по данному механизму."""

        """Определяем время границы неактуальности, данные до которого следует удалить"""
        border_of_deleting = datetime.datetime.now() - datetime.timedelta(hours=config['server']['storage_interval'])

        if config['bis_control']['log_level'] >= LogLevelCode.LL_NOTICE:
            logger.info('Удаление устаревших данных из ТЛБД до момента времени ' + str(border_of_deleting))

        """Для финальных результатов обработки первичных даннных сети БИС, сформированных СПО КНП, переписываем их в ЛБД
        на базе Postgres. При неудаче не драматизируем ситуацию и удаляем их, журналируя проблему."""
        if config['server']['copy_old_data'] == 'yes':
            copy_old_data_to_lbd_pg(border_of_deleting, Residual)
            copy_old_data_to_lbd_pg(border_of_deleting, KNPNavSolution)

        """Просматриваем перечень всех таблиц, которые создавали в технологической ЛБД"""
        with cleardb_db_connection.atomic():
            for lbd_storage_class in lbd_tables_list:

                """Те из них, которые помечены как таблицы оперативного хранения, обрабатываем на предмет устаревших данных"""
                if isinstance(lbd_storage_class(), OperativeStorageModel):
                    """Выполняем удаление устаревших данных, хранящихся более отведенного времени"""
                    lbd_storage_class().remove_inactual_data(border_of_deleting)

    logging.info('Процесс обобщения кадров ЦИ успешно запущен!')

    # настраивам логирование в файлы с префиксом summarize
    LoggingManager(filename_prefix='summarize').setup_logging()
    logger = logging.getLogger('clear_db')

    from db.db_connection import db
    db.connect()

    latest_db_service_time = datetime.datetime.now().timestamp()

    while not exiting.is_set():
        try:
            """Если от последнего обслуживания прошло время, больше порогового, то запускаем его.
            Такая органиязация в отличии от обслуживания в кратные моменты исключает пропуски их при подвисаниях.
            Являющееся второстепенным относительно целевой логики СПО обслуживание должно выполняться в конце цикла, 
            т.к. даже в случае временного сбоя полная обработка пакетов будет произведена и приложение продолжит 
            изъятие и обработку следующего пакета"""
            time_now = datetime.datetime.now()
            if (time_now.timestamp() - latest_db_service_time) > config['server']['service_interval']:
                """Обновляем время позднейшего обслуживания в первую очередь для исключения ситуации повторного 
                многократного запуска обслуживания при возникновении сбоя при самом обслуживании"""
                latest_db_service_time = time_now.timestamp()

                """Запуск самого обслуживания, включающего, в первую очередь, очистку ТЛБД"""
                logger.info("Выполняется очистка ТЛБД")
                clean_db(db)
                logger.info("Очистка ТЛБД выполнена")
        except Exception as exc:
            logger.critical('Clear DB thread logic fails!')
            handle_exception(type(exc), exc, exc.__traceback__)

    logger.info("Закрытие соединения с ЛБД для процесса очистки таблиц ЛДБ")
    db.close()
