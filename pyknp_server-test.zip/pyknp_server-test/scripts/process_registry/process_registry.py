# scripts/process_registry.py
import logging
import os
import threading
from typing import Dict, Any, Callable, List

logger = logging.getLogger(__name__)


class ProcessRegistry:
    """
    Централизованный реестр объектов процесса.
    Обеспечивает правильную инициализацию и доступ к глобальным объектам в многопроцессной среде.
    """
    _instance = None
    _lock = threading.Lock()

    @classmethod
    def get_instance(cls):
        """Получение экземпляра реестра для текущего процесса"""
        if cls._instance is None:
            with cls._lock:
                # if cls._instance is None:
                cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.pid = os.getpid()
        self.registry: Dict[str, Any] = {}
        self.initializers: Dict[str, Callable] = {}
        self.dependencies: Dict[str, List[str]] = {}
        self.config = {}
        self._initialized = False
        self._initializing = False  # Добавляем флаг инициализации
        logger.debug(f"Создан реестр объектов для процесса PID: {self.pid}")

    def register_initializer(self, name: str, initializer: Callable, depends_on: List[str] = None):
        """
        Регистрация функции инициализации объекта

        Args:
            name: Имя объекта
            initializer: Функция, создающая объект
            depends_on: Список имен объектов, от которых зависит данный объект
        """
        self.initializers[name] = initializer
        self.dependencies[name] = depends_on or []

    def initialize(self, config: Dict[str, Any] = None):
        """
        Инициализация всех зарегистрированных объектов с учетом зависимостей

        Args:
            config: Конфигурация для инициализации объектов
        """
        if self._initialized:
            logger.debug("Реестр уже инициализирован")
            return self

        # Проверяем, не идет ли уже инициализация
        if self._initializing:
            logger.warning("Обнаружен рекурсивный вызов initialize(). Возвращаем текущий экземпляр.")
            return self

        # Устанавливаем флаг, показывающий, что инициализация в процессе
        self._initializing = True

        self.config = config or {}
        logger.info(f"Инициализация реестра объектов для процесса PID: {self.pid}")

        # Инициализируем объекты с учетом зависимостей
        initialized = set()
        pending = set(self.initializers.keys())

        while pending:
            # Находим объекты, все зависимости которых уже инициализированы
            ready = [name for name in pending
                     if all(dep in initialized for dep in self.dependencies.get(name, []))]

            if not ready:
                # Если нет готовых объектов, но есть ожидающие, значит есть циклическая зависимость
                logger.error(f"Обнаружена циклическая зависимость между объектами: {pending}")
                break

            # Инициализируем готовые объекты
            for name in ready:
                try:
                    logger.debug(f"Инициализация объекта: {name}")
                    obj = self.initializers[name](self)
                    self.registry[name] = obj
                    initialized.add(name)
                    pending.remove(name)
                except Exception:
                    logger.error(f"Ошибка при инициализации объекта {name}", exc_info=True)
                    # Продолжаем с другими объектами

        self._initialized = True
        self._initializing = False  # Сбрасываем флаг инициализации
        logger.info(f"Реестр объектов для процесса PID: {self.pid} инициализирован")
        return self

    def get(self, name: str, default: Any = None) -> Any:
        """
        Получение объекта из реестра по имени

        Args:
            name: Имя объекта
            default: Значение по умолчанию, если объект не найден

        Returns:
            Объект из реестра или значение по умолчанию
        """
        if not self._initialized:
            # Проверяем, не идет ли уже инициализация
            if self._initializing:
                # Если инициализация уже идет, просто возвращаем default
                # чтобы избежать рекурсивного вызова initialize()
                logger.debug(f"Инициализация в процессе, объект '{name}' пока недоступен")
                return default
            else:
                logger.warning(f"Попытка получить объект '{name}' из неинициализированного реестра")
                return default

        return self.registry.get(name, default)

    def set(self, name: str, obj: Any) -> Any:
        """
        Установка объекта в реестр

        Args:
            name: Имя объекта
            obj: Объект для установки

        Returns:
            Установленный объект
        """
        self.registry[name] = obj
        return obj

    def get_config(self) -> Dict[str, Any]:
        """
        Получение текущей конфигурации реестра

        Returns:
            Словарь с конфигурацией
        """
        return self.config

    def close_all(self):
        """Закрытие всех ресурсов в реестре"""
        for name, obj in self.registry.items():
            if hasattr(obj, 'close') and callable(getattr(obj, 'close')):
                try:
                    logger.debug(f"Закрытие ресурса: {name}")
                    obj.close()
                except Exception as e:
                    logger.error(f"Ошибка при закрытии ресурса {name}: {e}")

        self.registry.clear()
        self._initialized = False
        self._initializing = False  # Сбрасываем флаг инициализации


# Функции для удобного доступа к реестру
def get_registry() -> ProcessRegistry:
    """Получение экземпляра реестра для текущего процесса"""
    return ProcessRegistry.get_instance()


def initialize_registry(config: Dict[str, Any] = None) -> ProcessRegistry:
    """
    Инициализация реестра объектов для текущего процесса

    Args:
        config: Конфигурация для инициализации объектов
    """
    registry = get_registry()
    return registry.initialize(config)


def get_object(name: str, default: Any = None) -> Any:
    """
    Получение объекта из реестра по имени

    Args:
        name: Имя объекта
        default: Значение по умолчанию, если объект не найден
    """
    return get_registry().get(name, default)


def set_object(name: str, obj: Any) -> Any:
    """
    Функция для установки объекта в реестр

    Args:
        name: Имя объекта
        obj: Объект для установки

    Returns:
        Установленный объект
    """
    return get_registry().set(name, obj)


def register_initializer(name: str, initializer: Callable, depends_on: List[str] = None):
    """
    Регистрация функции инициализации объекта

    Args:
        name: Имя объекта
        initializer: Функция, создающая объект
        depends_on: Список имен объектов, от которых зависит данный объект
    """
    get_registry().register_initializer(name, initializer, depends_on)


def get_process_config() -> Dict[str, Any]:
    """
    Получение конфигурации из реестра текущего процесса
    """
    return get_registry().get_config()


def close_all_resources():
    """Закрытие всех ресурсов в реестре"""
    get_registry().close_all()
