# scripts/registry_getters.py
from queue import Queue
from typing import Optional, TYPE_CHECKING

# Импорт функции доступа к реестру
from .process_registry import get_object

if TYPE_CHECKING:
    from communication.process_zmq_manager import ProcessZmqManager
    from utils.caches.bis_cache import BisCache
    from utils.string_buffer.DIStringBuffer import DIStringBuffer
    from utils.validity.partial_validity import PartialValidity
    from utils.visibility.current_visibility.current_visibility import CurrentVisibility
    from utils.reception_control.message_counters.partial_message_counter import PartialMessageCounter
    from utils.residuals.recent_residuals_cache.recent_residuals_cache import RecentResidualCache
    from utils.nav_solution.recent_nav_solutions_cache.recent_nav_solutions_cache import RecentNavSolutionsCache
    from utils.statuses.nka_reception_status.partial_nka_reception_status import PartialNkaReceptionStatus
    from utils.SignalFlags import SignalFlagAggregator
    from utils.SI.si_embedding_verification.si_embedding_verifier import SIEmbeddingVerifier

__all__ = [
    'get_zmq_manager',
    'get_bis_cache',
    'get_partial_validity',
    'get_current_visibility',
    'get_partial_counters',
    'get_recent_residuals_cache',
    'get_immediate_nav_solutions_cache',
    'get_user_nav_solutions_cache',
    'get_best_nav_solutions_cache',
    'get_partial_nka_statuses',
    'get_packet_queue',
    'get_di_string_buffer',
    'get_si_embedding_verifier'
]


def get_zmq_manager() -> Optional['ProcessZmqManager']:
    """
    Получение экземпляра ZmqPublisher из реестра

    Returns:
        Экземпляр ZmqPublisher или None, если объект не найден
    """
    return get_object('zmq_manager')


def get_bis_cache() -> Optional['BisCache']:
    """
    Получение экземпляра BisCache из реестра

    Returns:
        Экземпляр BisCache или None, если объект не найден
    """
    return get_object('bis_cache')


def get_partial_validity() -> Optional['PartialValidity']:
    """
    Получение экземпляра PartialValidity из реестра

    Returns:
        Экземпляр PartialValidity или None, если объект не найден
    """
    return get_object('partial_validity')


def get_current_visibility() -> Optional['CurrentVisibility']:
    """
    Получение экземпляра CurrentVisibility из реестра

    Returns:
        Экземпляр CurrentVisibility или None, если объект не найден
    """
    return get_object('current_visibility')


def get_partial_counters() -> Optional['PartialMessageCounter']:
    """
    Получение экземпляра PartialMessageCounter из реестра

    Returns:
        Экземпляр PartialMessageCounter или None, если объект не найден
    """
    return get_object('partial_counters')


def get_recent_residuals_cache() -> Optional['RecentResidualCache']:
    """
    Получение экземпляра RecentResidualCache из реестра

    Returns:
        Экземпляр RecentResidualCache или None, если объект не найден
    """
    return get_object('recent_residuals_cache')


def get_immediate_nav_solutions_cache() -> Optional['RecentNavSolutionsCache']:
    """
    Получение экземпляра RecentNavSolutionsCache для мгновенных решений из реестра

    Returns:
        Экземпляр RecentNavSolutionsCache или None, если объект не найден
    """
    return get_object('immediate_nav_solutions_cache')


def get_user_nav_solutions_cache() -> Optional['RecentNavSolutionsCache']:
    """
    Получение экземпляра RecentNavSolutionsCache для пользовательских решений из реестра

    Returns:
        Экземпляр RecentNavSolutionsCache или None, если объект не найден
    """
    return get_object('user_nav_solutions_cache')


def get_best_nav_solutions_cache() -> Optional['RecentNavSolutionsCache']:
    """
    Получение экземпляра RecentNavSolutionsCache для лучших решений из реестра

    Returns:
        Экземпляр RecentNavSolutionsCache или None, если объект не найден
    """
    return get_object('best_nav_solutions_cache')


def get_partial_nka_statuses() -> Optional['PartialNkaReceptionStatus']:
    """
    Получение экземпляра PartialNkaReceptionStatus из реестра

    Returns:
        Экземпляр PartialNkaReceptionStatus или None, если объект не найден
    """
    return get_object('partial_nka_statuses')


def get_packet_queue() -> Optional[Queue]:
    """
    Получение экземпляра Queue для пакетов из реестра

    Returns:
        Экземпляр Queue или None, если объект не найден
    """
    return get_object('packet_queue')


def get_signal_flags_aggregator() -> Optional['SignalFlagAggregator']:
    """
    Получение экземпляра агрегатора (сборщика) сигнальных признаков из реестра глобальных объектов

    Returns:
        Экземпляр SignalFlagAggregator или None, если объект не найден
    """
    return get_object('signal_flags_aggregator')


def get_di_string_buffer() -> Optional['DIStringBuffer']:
    """
    Получение экземпляра DIStringBuffer из реестра

    Returns:
        Экземпляр DIStringBuffer или None, если объект не найден
    """
    return get_object('di_string_buffer')


def get_si_embedding_verifier() -> Optional['SIEmbeddingVerifier']:
    """
    Получение экземпляра SIEmbeddingVerifier из реестра

    Returns:
        Экземпляр SIEmbeddingVerifier или None, если объект не найден
    """
    return get_object('si_embedding_verifier')
