# Регистрируем все инициализаторы
from scripts.process_registry.process_registry import register_initializer
from scripts.process_registry.registry_object_initializers import init_packet_queue, init_bis_cache, init_di_string_buffer, \
    init_zmq_manager, init_partial_validity, init_current_visibility, init_partial_counters, init_recent_residuals_cache, \
    init_immediate_nav_solutions_cache, init_user_nav_solutions_cache, init_best_nav_solutions_cache, \
    init_signal_flags_aggregator, init_partial_nka_statuses


def register_bis_process_initializers():
    """Ргеистрация глобальных инстансов для процесса получения и обработки данных от СПО сети БИС"""
    register_initializer('packet_queue', init_packet_queue)
    register_initializer('bis_cache', init_bis_cache)
    register_initializer('di_string_buffer', init_di_string_buffer)

    # ZmqPublisher должен быть инициализирован первым, так как другие объекты зависят от него
    register_initializer('zmq_manager', init_zmq_manager)

    # Остальные объекты зависят от ZmqPublisher
    register_initializer('partial_validity', init_partial_validity, depends_on=['zmq_manager'])
    register_initializer('current_visibility', init_current_visibility, depends_on=['zmq_manager'])
    register_initializer('partial_counters', init_partial_counters, depends_on=['zmq_manager'])
    register_initializer('recent_residuals_cache', init_recent_residuals_cache, depends_on=['zmq_manager'])
    register_initializer('immediate_nav_solutions_cache', init_immediate_nav_solutions_cache, depends_on=['zmq_manager'])
    register_initializer('user_nav_solutions_cache', init_user_nav_solutions_cache, depends_on=['zmq_manager'])
    register_initializer('best_nav_solutions_cache', init_best_nav_solutions_cache, depends_on=['zmq_manager'])
    register_initializer('signal_flags_aggregator', init_signal_flags_aggregator, depends_on=['zmq_manager'])
    register_initializer('partial_nka_statuses', init_partial_nka_statuses,
                         depends_on=['partial_counters', 'current_visibility'])
