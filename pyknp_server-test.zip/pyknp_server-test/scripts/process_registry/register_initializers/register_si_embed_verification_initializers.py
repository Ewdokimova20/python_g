from scripts.process_registry.process_registry import register_initializer
from scripts.process_registry.registry_object_initializers import init_zmq_manager


def register_si_embed_verification_initializers():
    """Ргеистрация глобальных инстансов для процесса оперативного контроля и аналзи закладок"""
    register_initializer('zmq_manager', init_zmq_manager)
