import logging
import queue
from multiprocessing import current_process
from typing import TYPE_CHECKING, List

import utils
from utils.nav_solution.types import NavSolutionType

if TYPE_CHECKING:
    from scripts.process_registry import ProcessRegistry
    from models.bis import Bis

logger = logging.getLogger(__name__)


def init_bis_cache(registry: 'ProcessRegistry'):
    """Инициализация кэша объектов ТЛБД БИС с учетом конфигурации процесса"""
    from utils.caches.bis_cache import BisCache
    bis_cache = BisCache()

    # Получаем конфигурацию из реестра
    config = registry.config
    bis_list: List['Bis'] = config.get('bis_list', [])
    for bis in bis_list:
        bis_cache.add_data(bis_number=bis.bis_number, station_number=bis.station.station_number, bis=bis)

    logger.debug(f"Инициализация кэша БИС со списком: {bis_list}")
    utils.caches.cache_bis = bis_cache
    return bis_cache


def init_zmq_manager(registry: 'ProcessRegistry'):
    """Инициализация ProcessZmqManager с учетом конфигурации процесса"""
    from communication.process_zmq_manager import ProcessZmqManager

    zmq_manager = ProcessZmqManager(current_process().name)

    return zmq_manager


# Регистрация инициализатора PartialValidity
def init_partial_validity(registry: 'ProcessRegistry'):
    from utils.validity.partial_validity import PartialValidity

    # Создаем экземпляр
    partial_validity = PartialValidity()

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(partial_validity, 'set_zmq_manager'):
        partial_validity.set_zmq_manager(zmq_manager)

    return partial_validity


# Регистрация инициализатора CurrentVisibility
def init_current_visibility(registry: 'ProcessRegistry'):
    from utils.visibility.current_visibility.current_visibility import CurrentVisibility

    # Создаем экземпляр
    current_visibility = CurrentVisibility()

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(current_visibility, 'set_zmq_manager'):
        current_visibility.set_zmq_manager(zmq_manager)

    return current_visibility


# Регистрация инициализатора PartialMessageCounter
def init_partial_counters(registry: 'ProcessRegistry'):
    bis_list = registry.config.get('bis_list')
    from utils.reception_control.message_counters.partial_message_counter import PartialMessageCounter

    # Создаем экземпляр
    partial_counters = PartialMessageCounter(bis_list)

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(partial_counters, 'set_zmq_manager'):
        partial_counters.set_zmq_manager(zmq_manager)

    return partial_counters


# Регистрация инициализатора RecentResidualCache
def init_recent_residuals_cache(registry: 'ProcessRegistry'):
    from utils.residuals.recent_residuals_cache.recent_residuals_cache import RecentResidualCache
    # Создаем экземпляр
    recent_residuals_cache = RecentResidualCache()

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(recent_residuals_cache, 'set_zmq_manager'):
        recent_residuals_cache.set_zmq_manager(zmq_manager)

    return recent_residuals_cache


# Регистрация инициализатора кэша мгновенных решений НВЗ
def init_immediate_nav_solutions_cache(registry: 'ProcessRegistry'):
    # Создаем экземпляр
    from utils.nav_solution.recent_nav_solutions_cache.recent_nav_solutions_cache import RecentNavSolutionsCache
    nav_solutions_cache = RecentNavSolutionsCache(cache_type=NavSolutionType.IMMEDIATE)

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(nav_solutions_cache, 'set_zmq_manager'):
        nav_solutions_cache.set_zmq_manager(zmq_manager)

    return nav_solutions_cache


# Регистрация инициализатора кэша мгновенных решений НВЗ
def init_user_nav_solutions_cache(registry: 'ProcessRegistry'):
    # Создаем экземпляр
    from utils.nav_solution.recent_nav_solutions_cache.recent_nav_solutions_cache import RecentNavSolutionsCache
    nav_solutions_cache = RecentNavSolutionsCache(cache_type=NavSolutionType.USER)

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(nav_solutions_cache, 'set_zmq_manager'):
        nav_solutions_cache.set_zmq_manager(zmq_manager)

    return nav_solutions_cache


# Регистрация инициализатора кэша мгновенных решений НВЗ
def init_best_nav_solutions_cache(registry: 'ProcessRegistry'):
    # Создаем экземпляр
    from utils.nav_solution.recent_nav_solutions_cache.recent_nav_solutions_cache import RecentNavSolutionsCache
    nav_solutions_cache = RecentNavSolutionsCache(cache_type=NavSolutionType.BEST)

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    if hasattr(nav_solutions_cache, 'set_zmq_manager'):
        nav_solutions_cache.set_zmq_manager(zmq_manager)

    return nav_solutions_cache


# Регистрация сборщика сигнальных признаков
def init_signal_flags_aggregator(registry: 'ProcessRegistry'):
    # Создаем экземпляр
    from utils.SignalFlags import SignalFlagAggregator
    signal_flags_aggregator = SignalFlagAggregator()

    # Инъекция зависимостей
    zmq_manager = registry.registry.get('zmq_manager')
    signal_flags_aggregator.set_zmq_manager(zmq_manager)

    return signal_flags_aggregator


# Регистрация инициализатора PartialNkaReceptionStatus
def init_partial_nka_statuses(registry: 'ProcessRegistry'):
    # Инъекция зависимостей
    bis_cache = registry.registry.get('bis_cache')
    partial_counters = registry.registry.get('partial_counters')
    current_visibility = registry.registry.get('current_visibility')

    # Создаем экземпляр
    from utils.statuses.nka_reception_status.partial_nka_reception_status import PartialNkaReceptionStatus
    partial_nka_statuses = PartialNkaReceptionStatus(counter_service=partial_counters, visibility_service=current_visibility,
                                                     bis_cache=bis_cache)

    return partial_nka_statuses


# Регистрация инициализатора очереди пакетов
def init_packet_queue(registry: 'ProcessRegistry'):
    # Создаем экземпляр
    packet_queue = queue.Queue()

    return packet_queue


# Регистрация инициализатора буфера для сбора и записи строк ЦИ в БД
def init_di_string_buffer(registry: 'ProcessRegistry'):
    from utils.string_buffer.DIStringBuffer import DIStringBuffer
    di_string_buffer = DIStringBuffer()
    return di_string_buffer
