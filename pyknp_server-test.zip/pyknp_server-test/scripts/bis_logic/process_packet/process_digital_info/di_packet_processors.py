from datetime import datetime
from typing import TYPE_CHECKING, Union, Optional, Any, Type, TypeVar, Generic

from BisReciever.BisPacket import BisDigitalInfoL1OF, BisDigitalInfoL2OF, BisDigitalInfoL1SF, BisDigitalInfoL1OC, \
    BisDigitalInfoL3OC, BisDigitalInfoL2KSI, BisDigitalInfoL1SC, BisDigitalInfoL2SC
from data import L1OFString, L2OFString, L1SFString, L1OCString, L3OCString, L1SCString, L2SCString, L2KSIString
from models.di_string.cd_signal_string import CDSignalString
from models.di_string.of_signal_string import OFSignalString
from scripts.process_registry import get_partial_counters, get_current_visibility
from scripts.process_registry.registry_getters import get_signal_flags_aggregator
from utils.caches import cache_bis
from utils.caches.cache import cache_manager
from utils.visibility.types import VisibilityStatus

if TYPE_CHECKING:
    from BisReciever.BisPacket import BisDigitalInfoBase
    from models.bis import Bis
    from models.nka import Nka

FDPacketType = Union[BisDigitalInfoL1OF, BisDigitalInfoL2OF]
CDPacketType = Union[BisDigitalInfoL1OC, BisDigitalInfoL3OC, BisDigitalInfoL1SC, BisDigitalInfoL2SC, BisDigitalInfoL2KSI]

# Определяем Generic-переменную для типов строк
T_SignalString = TypeVar('T_SignalString', bound='Union[OFSignalString, CDSignalString, L1SFString]')


class DIPacketProcessor(Generic[T_SignalString]):
    """
    Базовый класс для обработчиков строк ЦИ всех видов сигналов.

    Предоставляет общую логику обработки пакетов цифровой информации,
    включая инкремент счетчиков, получение временных меток и проверку тревог.

    Attributes:
        model_class (Type[Union[OFSignalString, CDSignalString]]): Класс модели для записи в БД
    """

    def __init__(self, model_class: Type[T_SignalString]):
        """
        Инициализирует процессор с указанием класса соответствующей модели строки ЦИ.

        Args:
            model_class: Класс модели строки ЦИ для записи в БД (L1OFString, L2OFString и т.д.)
        """
        self.model_class = model_class

    def get_timestamp(self, packet: 'BisDigitalInfoBase', offset: float = 0.0) -> datetime:
        """
        Генерирует временную метку из пакета с возможным смещением.

        Args:
            packet: Пакет данных БИС
            offset: Дополнительное смещение времени в секундах (по умолчанию 0.0)

        Returns:
            Сгенерированная временная метка
        """
        return datetime.utcfromtimestamp(
            946684800 + packet.timestamp_s + packet.timestamp_ms / 1000 + offset
        )

    def increment_counters(self, packet: 'BisDigitalInfoBase', message: Any) -> None:
        """
        Увеличивает счетчики по НКА.

        Args:
            packet: Пакет данных БИС
            message: Сообщение из пакета
        """
        partial_counters = get_partial_counters()
        partial_counters.increment_nka_counters(
            packet.station_number,
            packet.bis_number,
            message.meta.nka_sys_number,
            message.meta.signal_type,
            packet.packet_id
        )

    def process_string_data(self, packet: 'BisDigitalInfoBase', string_data: Any, checksum: Optional[int] = None,
                            offset: float = 0.0) -> None:
        """
        Обрабатывает данные строки и проверяет наличие тревог.

        Выполняет следующие шаги:
        1. Получает сообщение из пакета
        2. Инкрементирует счетчики НКА
        3. Получает экземпляр БИС
        4. Записывает данные в базу данных
        5. Проверяет видимость НКА и генерирует оперативные сообщения при необходимости

        Args:
            packet: Пакет данных БИС
            string_data: Данные строки
            checksum: Контрольная сумма (опционально)
            offset: Смещение времени (по умолчанию 0.0)
        """
        message = packet.message
        self.increment_counters(packet, message)
        bis = cache_bis.get_item_by_key(packet.bis_number, packet.station_number)

        if bis is None:
            return

        nka = cache_manager.get_or_create_nka(message.meta.nka_sys_number)

        # Запись строки в БД
        di_str = self.write_to_db(
            packet=packet,
            message=message,
            bis=bis,
            nka=nka,
            timestamp=self.get_timestamp(packet, offset),
            string_data=string_data,
            checksum=checksum
        )

        if di_str:
            # Проверка видимости НКА
            current_visibility = get_current_visibility()  # получаем глобальный объект текущего состояния видимости НКА
            signal_flags_aggregator = get_signal_flags_aggregator()  # получаем глобальный объект сборщика СП
            visibility_status = current_visibility.get_status(packet.station_number, di_str.nka_id)
            if visibility_status > VisibilityStatus.OUT_OF_SIGHT:
                for knp_op_message in di_str.check_string_for_alarms():
                    knp_op_message.timestamp = datetime.now()
                    signal_flags_aggregator.add_operative_message(knp_op_message)

    def write_to_db(
            self,
            packet: 'BisDigitalInfoBase',
            message: Any,
            bis: 'Bis',
            nka: 'Nka',
            timestamp: datetime,
            string_data: Any,
            checksum: Optional[int] = None
    ) -> Any:
        """
        Базовый метод записи данных в базу данных.

        Args:
            packet: Пакет данных БИС
            message: Сообщение из пакета
            bis: Экземпляр БИС
            nka: Экземпляр НКА
            timestamp: Временная метка
            string_data: Данные строки
            checksum: Контрольная сумма

        Returns:
            Результат записи в базу данных

        Raises:
            NotImplementedError: Должен быть переопределен в классах-наследниках
        """
        raise NotImplementedError("Должен быть переопределен в наследнике")

    def process(self, packet: 'BisDigitalInfoBase') -> None:
        """
        Основной метод обработки пакета.

        Raises:
            NotImplementedError: Должен быть переопределен в классах-наследниках
        """
        raise NotImplementedError("Должен быть переопределен в наследнике")


class OFDIPacketProcessor(DIPacketProcessor[OFSignalString]):
    """
    Класс-обработчик для пакетов с частотными сигналами (L1OF, L2OF).

    Специализируется на обработке пакетов с номером строки и контрольной суммой.
    """

    def write_to_db(self, packet: FDPacketType, message: Any, bis: 'Bis', nka: 'Nka', timestamp: datetime,
                    string_data: Any,
                    checksum: Optional[int] = None):
        """
        Записывает строку ЦИ в ТЛБД для частотных сигналов и возвращает ее.
        """
        return self.model_class().write_to_db(nka, bis, timestamp, string_data.string_num, checksum or message.meta.checksum_1b,
                                              string_data.string)

    def process(self, packet):
        """
        Обрабатывает пакет с ЦИ для частотных сигналов.

        Args:
            packet: Пакет данных БИС с частотным сигналом
        """
        message = packet.message
        self.process_string_data(
            packet=packet,
            string_data=message.digital_info,
            checksum=message.meta.checksum_1b
        )


class CDDIPacketProcessor(DIPacketProcessor[CDSignalString]):
    """
    Класс-обработчик для пакетов с кодовыми сигналами (L1OC, L3OC, L1SC, L2SC, L2KSI).

    Специализируется на обработке пакетов только со строкой без дополнительных параметров.
    """

    def write_to_db(self, packet: CDPacketType, message: Any, bis: 'Bis', nka: 'Nka', timestamp: datetime, string_data: Any,
                    checksum: Optional[int] = None):
        """
        Записывает строку ЦИ кодовых сигналов в ТЛБД и возвращает ее.
        """
        return self.model_class().write_to_db(nka, bis, timestamp, string_data.string)

    def process(self, packet):
        """
        Обрабатывает пакет с ЦИ для кодовых сигналов.

        Args:
            packet: Пакет ЦИ для кодовых сигналов
        """
        message = packet.message
        self.process_string_data(packet=packet, string_data=message.digital_info)


class L1SFPacketProcessor(DIPacketProcessor[L1SFString]):
    """
    Класс-обработчик для пакетов с сигналом L1SF.

    Специализируется на обработке пакетов с двумя строками и особым порядком обработки.
    """

    def write_to_db(self, packet: 'BisDigitalInfoL1SF', message: Any, bis: 'Bis', nka: 'Nka', timestamp: datetime,
                    string_data: Any,
                    checksum: Optional[int] = None):
        """
        Записывает строку ЦИ L1SF в ТЛБД и возвращает ее.
        """
        return self.model_class().write_to_db(nka, bis, timestamp, string_data.string_num, checksum, string_data.string)

    def process(self, packet):
        """
        Обрабатывает пакет сигнала L1SF с двумя строками.

        Выполняет обработку первой и второй строк с различными смещениями времени.

        Args:
            packet: Пакет ЦИ для сигнала L1SF
        """
        message = packet.message

        # Обработка первой строки
        if message.digital_info.string1.string_num != 0:
            self.process_string_data(
                packet=packet,
                string_data=message.digital_info.string1,
                checksum=message.meta.checksum_1b,
                offset=0.000002  # Смещение для первой строки
            )

        # Обработка второй строки
        if message.digital_info.string2.string_num != 0:
            self.process_string_data(
                packet=packet,
                string_data=message.digital_info.string2,
                checksum=message.meta.checksum_2b,
                offset=0.000001  # Смещение для второй строки
            )


# Регистрация обработчиков для разных типов пакетов "Цифровая информация"
DI_PACKET_HANDLERS = {
    BisDigitalInfoL1OF: OFDIPacketProcessor(L1OFString),
    BisDigitalInfoL2OF: OFDIPacketProcessor(L2OFString),
    BisDigitalInfoL1SF: L1SFPacketProcessor(L1SFString),
    BisDigitalInfoL1OC: CDDIPacketProcessor(L1OCString),
    BisDigitalInfoL3OC: CDDIPacketProcessor(L3OCString),
    BisDigitalInfoL1SC: CDDIPacketProcessor(L1SCString),
    BisDigitalInfoL2SC: CDDIPacketProcessor(L2SCString),
    BisDigitalInfoL2KSI: CDDIPacketProcessor(L2KSIString),
}
