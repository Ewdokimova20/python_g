import logging
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from global_data.config_schema import config
from models.meteoparams import Meteoparameters
from utils.caches import cache_bis
from utils.meteo_data.meteo_data_cache import cache_meteoparameters

if TYPE_CHECKING:
    from BisReciever.BisPacket import BisMeteoData

logger = logging.getLogger(__name__)


def process_meteo(packet: 'BisMeteoData') -> None:
    """
    Обрабатывает пакеты "Метеопараметры" (0x41) от СПО сети БИС

    Декоратор вызывает данную функцию с интервалом из конфига decimation.meteoparameters_decimation_interval

    При вызове создает объекты ТЛБД на основе сообщения из пакета, пишет их в ТЛБД, а также добавляет их в кэш метеоданных

    Args:
        packet (BisMeteoData): пакет "Метеопараметры" от СПО сети БИС.

    """
    station_number, bis_number = packet.station_number, packet.bis_number
    message = packet.message
    temperature, pressure, humidity, time_second_in_day = (message.temperature, message.pressure, message.humidity,
                                                           message.second_in_day)

    meteo_datetime = (datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=time_second_in_day))

    # проверка ОДЗ (при выходе за границы маркируем)
    is_incorrect = not all((-90.0 <= temperature <= 60.0,
                            800.0 <= pressure <= 1100.0,
                            0.0 <= humidity <= 100.0))

    # выдаем предупреждение о поступающем мусоре
    if is_incorrect:
        logger.warning(
            f'Аномальное значение метеопараметров для БИС  {station_number}/{bis_number} '
            f'со значениями {pressure}, {temperature}, {humidity}.')

    # получаем экземпляр БИС
    bis = cache_bis.get_item_by_key(packet.bis_number, packet.station_number)

    # пишем в ТЛБД и в кэш метеоданных
    if bis and config['bis_control']['use_troposphere_model']:
        meteoparameters = Meteoparameters.create(
            bis=bis,
            timestamp=meteo_datetime,
            p=pressure,
            t=temperature,
            h=humidity,
            is_incorrect=is_incorrect
        )
        cache_meteoparameters.add_data(bis.id, meteoparameters)
