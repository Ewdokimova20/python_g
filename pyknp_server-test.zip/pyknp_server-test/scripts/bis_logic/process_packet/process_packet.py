from typing import TYPE_CHECKING, Dict, Type, Callable

from BisReciever.BisPacket import BisNavSolution, BisMeasurements, BisControlResults, BisOpMessage, BisMeteoData
from global_data.config_schema import config
from .process_controls import process_controls
from .process_digital_info.di_packet_processors import DI_PACKET_HANDLERS
from .process_measurements import process_measurements
from .process_meteo import process_meteo
from .process_nav_solution import process_nav_solution
from .process_opmessage import process_opmessage

if TYPE_CHECKING:
    from BisReciever.BisPacket import BaseBisPacket

# Словарь обработчиков для всех видов пакетов, кроме пакетов "Цифровая информация"
BIS_PACKET_HANDLERS: Dict[Type, Callable] = {
    BisNavSolution: lambda pkt: not config['bis_control']['min_packets'] and process_nav_solution(pkt),
    BisControlResults: lambda pkt: not config['bis_control']['min_packets'] and process_controls(pkt),
    BisMeasurements: process_measurements,
    BisOpMessage: lambda pkt: not config['bis_control']['min_packets'] and process_opmessage(pkt),
    BisMeteoData: lambda pkt: config['bis_control']['use_troposphere_model'] and pkt.should_process and process_meteo(pkt),
}


def process_packet(packet: 'BaseBisPacket') -> None:
    """
    Обработка пакета в зависимости от его типа.

    Args:
        packet: Пакет данных от СПО сети БИС одного из поддерживаемых типов
    """
    packet_type = type(packet)

    # Обработка пакетов с ЦИ
    if packet_type in DI_PACKET_HANDLERS:
        di_handler = DI_PACKET_HANDLERS[packet_type]
        di_handler.process(packet)
        return

    # Обработка других типов пакетов
    try:
        handler = BIS_PACKET_HANDLERS[packet_type]
        handler(packet)
    except KeyError:
        # Тихое игнорирование неизвестных типов пакетов
        pass
