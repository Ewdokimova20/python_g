"""Функции обработки измерительной информации"""
import logging

from peewee import DoesNotExist

from BisReciever.BisPacket import *
from data import KNPNavSolution
from global_data.config_schema import config
from utils.average_residual import average_residual
from .calc_residuals import calc_residuals
from .check_signals import check_signals
from .solve_nav_task import solve_nav_task
from .write_residuals_to_ldb import write_residuals_to_ldb
from .write_signals_to_ldb import write_signals_to_ldb

logger = logging.getLogger(__name__)


def process_measurements(packet: BisMeasurements):
    """
    Обрабатывает пакеты "1с измерения" (0x11) от СПО сети БИС

    1. Считает невязки
    2. Пишет их в ТЛБД
    3. Считает решения НВЗ
    4. Пишет их в ТЛБД

    Args:
        packet (BisMeasurements): пакет "1с измерения" от СПО сети БИС.
    """
    signals = write_signals_to_ldb(pkt=packet)
    if len(signals) > 0:
        time = signals[0].timestamp.second
        if time % config['decimation']['residuals_decimation_interval'] == 0:
            residuals, temp_bis_id = calc_residuals(signals=signals)
            if config['general']['use_average_residuals'] == 'yes':
                for residual in residuals:
                    residual.residual = average_residual.get_average_residual(residual)
            check_signals(residuals=residuals, key_bis_id=temp_bis_id)
            write_residuals_to_ldb(residuals=residuals)
            # группируем невязки по источнику сигнала
            residuals_by_signal = {}  # ключ: идентификаторсигнала, значение: список невязок для решения НВЗ
            try:
                # группируем невязки по сигналам
                for r in residuals:
                    if r.signal_1 not in residuals_by_signal:
                        residuals_by_signal[r.signal_1] = []
                    residuals_by_signal[r.signal_1].append(r)
                # for k, g in groupby(residuals, attrgetter('signal_1')):
                #     residuals_by_signal[k] = []
                #     for single_residual in g:
                #         residuals_by_signal[k].append(single_residual)
            except DoesNotExist:  # ошибка валится в классе, если приходит аномальный номер
                pass
            nav_solutions_accumulator = []
            for signal_id, residuals_group in residuals_by_signal.items():
                # в группе все невязки расчитаны для одного сигнала разных НКА, поэтому извлекаем его
                nav_solutions_accumulator += solve_nav_task(residuals=residuals_group, signal_id=signal_id)
            if nav_solutions_accumulator:
                KNPNavSolution.bulk_create(nav_solutions_accumulator)
            # если пользователь запросил N попыток определения проблемного НКА, то одну мы выполнили, уменьшаем счетчик
            # # так делать допустимо ибо пока счетчик не равен 0, то другой процесс с ним работать не должен
            # if global_data.user_navsolution_parameters.requested_check_count > 0:
            #     global_data.user_navsolution_parameters.requested_check_count -= 1
