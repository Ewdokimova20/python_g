import logging
import math
from datetime import datetime
from typing import List

from data import Residual, KNPNavSolution
from global_data import user_navsolution_parameters
from global_data.config_schema import config
from scripts.process_registry import get_immediate_nav_solutions_cache, get_best_nav_solutions_cache, get_user_nav_solutions_cache
from utils.coordinates.coordinates import Coordinates

logger = logging.getLogger(__name__)


def solve_nav_task(residuals: List[Residual], signal_id: int) -> List[KNPNavSolution]:
    immediate_nav_solutions_cache = get_immediate_nav_solutions_cache()
    user_nav_solutions_cache = get_user_nav_solutions_cache()
    best_nav_solutions_cache = get_best_nav_solutions_cache()
    nav_solutions = []
    # запоминаем некоторые параметры для упрощения доступа к ним при поиске проблемных НКА
    current_bis_id = 0
    base_deviation = math.nan
    bis_xyz = Coordinates.XYZ(x=0, y=0, z=0)
    # исключаем невязки с НКА, которые находятся ниже граничного угла (задаваемого в конфиге), а также одночастотные
    # невязки в случае, если в конфиге не задано их использование в РНЗ
    filtered_residuals = [r for r in residuals
                          if ((r.nka_elevation > config['bis_control']['min_elevation_for_nav_solution'])
                              and not r.rejected_due_to_deviation
                              and not r.signal_is_untrusted)]
    try:
        solution = KNPNavSolution.calculate(residuals=filtered_residuals, signal_id=signal_id)
        current_bis_id = solution.bis.id
        bis_xyz = solution.bis.coordinates.xyz  # запоминаем координаты для случая включенного расчета поиска проблемного НКА
        base_deviation = bis_xyz.distance(Coordinates.XYZ(x=solution.x, y=solution.y, z=solution.z))
        immediate_nav_solutions_cache.append(solution)  # добавляем в кэш свежайших НВЗ
        nav_solutions.append(solution)
    except ValueError:
        pass

    bad_nka = 0  # системный номер НКА, определенного как наиболее проблемного
    best_navsolution_deviation = 1e9  # значение наименьшего отклонения для поиска НКА, вносящего наибольшую погрешность
    # решение НВЗ с пользовательскими параметрами
    # если указаны параметры определения проблемного НКА, то проводим его выявление
    # Осуществляется для конкретной БИС и конкретного сигнала (комбинации)

    time_elapsed_from_last_user_solution = datetime.now().timestamp() - user_navsolution_parameters.user_solution_last_request_time
    should_calculate_user_solution = time_elapsed_from_last_user_solution < user_navsolution_parameters.PERMITED_TIME_FOR_USER_SOLUTION

    if not current_bis_id:
        current_bis_id = residuals[0].bis.id if residuals else None
    if (current_bis_id == user_navsolution_parameters.bis_id_for_user_solution) and \
            (signal_id == user_navsolution_parameters.signal_for_user_solution) and \
            should_calculate_user_solution is True:
        user_solution_list_nka = user_navsolution_parameters.nka_in_solution
        user_residuals = [r for r in residuals
                          if (r.nka_id in user_solution_list_nka and
                              r.nka_elevation > config['bis_control']['min_elevation_for_nav_solution']
                              and not r.rejected_due_to_deviation
                              and (user_navsolution_parameters.use_signals_with_ln or
                                   not r.signal_is_untrusted)
                              )
                          ]
        try:
            user_solution = KNPNavSolution.calculate(residuals=user_residuals, signal_id=signal_id, user_solution=True)
            bis_xyz = user_solution.bis.coordinates.xyz
            best_navsolution_deviation = bis_xyz.distance(
                Coordinates.XYZ(x=user_solution.x, y=user_solution.y, z=user_solution.z))
            user_nav_solutions_cache.append(user_solution)  # добавляем в кэш свежайших ползовательских НВЗ
            nav_solutions.append(user_solution)
        except ValueError:
            pass
        if user_navsolution_parameters.search_worst_nka and len(user_residuals) > 4:
            # если после исключения одной невязки останется три, то НВЗ не решится
            # ищем НКА, который портит решение НВЗ. Если без этого НКА лучше, то запоминаем его и лучшее решение.
            # если таких НКА несколько, то запоминаем только самого плохого и самое лучшее решение
            best_solution = None
            for nka_index in user_solution_list_nka:
                residuals_without_one = [r for r in user_residuals if r.nka_id != nka_index]
                # состав не изменился (из-за отсутствия проверяемого НКА). Нечего проверять.
                if len(user_residuals) == len(residuals_without_one):
                    continue
                solution = KNPNavSolution.calculate(residuals=residuals_without_one, signal_id=signal_id,
                                                    user_solution=True, best_solution=True)
                current_deviation = bis_xyz.distance(Coordinates.XYZ(x=solution.x, y=solution.y, z=solution.z))
                # если мы нашли решение, которое лучше ранее известного,
                # то запоминаем после исключения какого НКА это произошло
                if best_navsolution_deviation > current_deviation:
                    best_navsolution_deviation = current_deviation
                    bad_nka = nka_index
                    nav_solve_timestamp = str(solution.timestamp)
                    best_solution = solution
            if best_solution:
                best_nav_solutions_cache.append(best_solution)  # добавляем в кэш свежайших лучших НВЗ
                nav_solutions.append(best_solution)  # сохранили лучшее решение
                if not bad_nka in user_navsolution_parameters.worst_nka_result:
                    user_navsolution_parameters.worst_nka_result[bad_nka] = 0
                user_navsolution_parameters.worst_nka_result[bad_nka] += 1
                user_navsolution_parameters.last_worst_nka = bad_nka
    # возвращаем перечень результатов НВЗ на сохранение
    return nav_solutions
