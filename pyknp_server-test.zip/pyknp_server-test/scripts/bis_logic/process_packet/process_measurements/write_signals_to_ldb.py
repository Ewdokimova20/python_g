import datetime
import logging
from typing import List

from BisReciever.BisPacket import *
from data import Signal
from db.db_manager import get_database_manager
from global_data import appdata
from scripts.process_registry import get_partial_counters
from utils.caches import cache_bis
from utils.caches.cache import cache_manager

logger = logging.getLogger(__name__)


def write_signals_to_ldb(pkt: BisMeasurements) -> List[Signal]:
    """
    Функция заполнения сигналов в ЛБД по данным пакета односекундных измерений

    :param pkt: пакет односекундных измерений
    """
    message = pkt.message
    meta = message.meta
    bis = cache_bis.get_item_by_key(pkt.bis_number, pkt.station_number)
    signal_dicts: List[dict] = []
    signal_models: List[Signal] = []

    if bis is None:
        return signal_models

    packet_timestamp = datetime.datetime.utcfromtimestamp(
        (meta.num_of_days + 1826) * 24 * 60 * 60 + meta.seconds + (
                meta.nanoseconds // 1000) / 1000000)

    for measure in message.measurements:
        if measure.signal_type in appdata.SIGNAL_TYPES:
            signal = dict(signal_type=cache_manager.get_signal_type(measure.signal_type),
                          nka=cache_manager.get_or_create_nka(measure.nka_sys_number),
                          bis=bis,
                          timestamp=packet_timestamp,
                          nanoseconds=meta.nanoseconds % 1000,
                          letter=measure.letter,
                          snr=measure.snr / 10,
                          pseudorange=measure.pseudorange / 1000,
                          pseudospeed=measure.pseudospeed / 1000,
                          carrier_shift=measure.carrier_shift / 1000,
                          carrier_phase=measure.carrier_phase_integer_part + measure.carrier_phase_decimal_part / 10000)
            signal_dicts.append(signal)
            signal_models.append(Signal(**signal))
            partial_counters = get_partial_counters()
            partial_counters.increment_nka_counters(pkt.station_number, pkt.bis_number, measure.nka_sys_number,
                                                    measure.signal_type, pkt.packet_id)

    # Асинхронная запись в БД
    if signal_dicts:
        db_manager = get_database_manager()
        db_manager.queue_signals_write(signal_dicts)

    return signal_models
