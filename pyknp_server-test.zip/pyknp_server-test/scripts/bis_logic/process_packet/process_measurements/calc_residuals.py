import logging
from itertools import groupby
from operator import attrgetter
from typing import List, Set, Tuple

from peewee import DoesNotExist

from data import Signal, Residual
from utils.coordinates.nka_coordinates_calculation import update_coordinates
from utils.lib.exceptions import ResidualCalcError

logger = logging.getLogger(__name__)


def calc_residuals(signals: List[Signal]) -> Tuple[Set[Residual], int]:
    """Группирует сигналы по НКА, в каждой группе ищет сигналы L1OF и L2OF, записывает в ЛБД невязку"""

    def calc_residual_pair(signal_group: List[Signal], first_signal_id: int, second_signal_id: int,
                           residuals_accumulator: set):
        first_signal = next((signal for signal in signal_group if signal.signal_type_id == first_signal_id), None)
        second_signal = next((signal for signal in signal_group if signal.signal_type_id == second_signal_id), None)
        try:
            residual = Residual.from_signals(first_signal, second_signal)
            residuals_accumulator.add(residual)
        except ResidualCalcError:
            pass

    # т.к. в пакете все сигналы на одну МВ и от одного БИС, то получаем их однократно
    timestamp = signals[0].timestamp
    bis = signals[0].bis
    id_bis = bis.id
    signals_by_nka = []
    new_residuals = set()
    signals.sort(key=attrgetter('nka_id'))
    for k, g in groupby(signals, attrgetter('nka')):
        try:
            signals_by_nka.append(list(g))
        except DoesNotExist as err:  # ошибка валится в классе Nka, если приходит аномальный номер
            logging.error('Сбой при выполнении операции группировки сигналов по полю nka: ', err)
    for group in signals_by_nka:
        # в группе все сигналы принадлежат одному НКА, поэтому извлекаем его и определяем наличие координат
        nka = group[0].nka

        # оцениваем углы и координаты КА. Если координаты посчитаны, то вызываем расчёт невязок
        try:
            if not update_coordinates(bis, nka.nka_sys_number, timestamp):
                continue
        except ValueError as e:
            continue

        calc_residual_pair(group, 0x01, 0x09, new_residuals)  # L1OF - L2OF
        calc_residual_pair(group, 0x21, 0x29, new_residuals)  # L1SF - L2SF
        calc_residual_pair(group, 0x06, 0x0E, new_residuals)  # L1OCd - L2KSI
        calc_residual_pair(group, 0x46, 0x4E, new_residuals)  # L1OCp - L2OCp
        calc_residual_pair(group, 0x26, 0x2E, new_residuals)  # L1SCd - L2SCd
        calc_residual_pair(group, 0x66, 0x6E, new_residuals)  # L1SCp - L2SCp
        calc_residual_pair(group, 0x16, 0x00, new_residuals)  # L3OCd - None
        calc_residual_pair(group, 0x56, 0x00, new_residuals)  # L3OCp - None
    return new_residuals, id_bis
