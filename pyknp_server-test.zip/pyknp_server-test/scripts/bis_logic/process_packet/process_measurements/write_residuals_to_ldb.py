import logging
from typing import Set

from data import Residual
from db.db_manager import get_database_manager

logger = logging.getLogger(__name__)


def write_residuals_to_ldb(residuals: Set[Residual]):
    """Функция записи невязок в базу"""
    if residuals:
        db_manager = get_database_manager()
        db_manager.queue_residuals_write(list(residuals))
