import logging
from collections import defaultdict
from itertools import combinations
from typing import Set

from data import Residual
from global_data import appdata
from global_data.config_schema import config
from scripts.bis_logic.process_packet.process_measurements.reject_residuals import reject_residuals
from scripts.process_registry import get_partial_validity, get_recent_residuals_cache
from utils.average_average_residuals import average_value

logger = logging.getLogger(__name__)


def check_signals(residuals: Set[Residual], key_bis_id: int) -> None:
    if key_bis_id is None:
        return
    correct_residuals_bis = defaultdict(set)  # словарь с ключами=bis_id, значение=множество "хороших" невязок

    # отбраковка невязок согласно раздела 6 ГОСТ 8.736-2011 (анализируется предыстория невязок)
    reject_residuals(residuals)

    # берем в расчет среднего только невязки с НКА, которые находятся на углах выше угла гарантированного приема
    # и по отработанным и проверенным сигналам
    residuals_for_average = [
        r for r in set(residuals) if
        r.nka_in_guaranteed_elevation  # только если в гарантированной видимости и многолучевость слаба
        and r.signal_1 in appdata.FREQ_SIGNAL_TYPES  # FIXME используем пока только FDMA-сигналы
        and not r.signal_is_untrusted  # не используем невязки из сигналов, помеченных в ЦИ недостоверными
        and not r.rejected_due_to_deviation]  # не используем отбракованные невязки

    # по парам невязок каждый-с-каждым проверяем попарную разницу и заполняем множество "хороших" невязок
    for residual1, residual2 in combinations(residuals_for_average, 2):
        if (abs(residual1.residual - residual2.residual) < config['bis_control']['residual_pairs_difference_threshold']
                and residual1.nka_id != residual2.nka_id):
            correct_residuals_bis[key_bis_id].add(residual1)
            correct_residuals_bis[key_bis_id].add(residual2)

    correct_residuals = correct_residuals_bis[key_bis_id]
    if correct_residuals:  # если множество не пустое, то
        value = sum([r.residual for r in correct_residuals]) / len(correct_residuals)  # считаем среднее
        average_value.add_average_value(value, key_bis_id)  # добавить среднее значение в буфер
        average = average_value.get_average_value(key_bis_id)  # получить среднее значение из буфера
    else:
        average = average_value.get_average_value(key_bis_id)  # получить среднее значение из буфера

    if average is not None:
        # записываем среднее и дельту от среднего в невязки
        for residual in residuals:
            residual.average = average
            residual.delta = residual.residual - average
            residual.delta1 = residual.residual1 - average
            if residual.residual2:
                residual.delta2 = residual.residual2 - average

            # для "хороших" невязок признаем сигналы "хорошими"
            if abs(residual.delta) < config['bis_control']['residual_average_difference_threshold']:
                residual.status = True

            partial_validity = get_partial_validity()

            partial_validity.set_instant_validity(residual.bis.station.station_number,
                                                  residual.bis.bis_number,
                                                  residual.nka.nka_sys_number,
                                                  residual.signal_1, residual.status)
            if residual.signal_2:
                partial_validity.set_instant_validity(residual.bis.station.station_number,
                                                      residual.bis.bis_number,
                                                      residual.nka.nka_sys_number,
                                                      residual.signal_2, residual.status)

            # добавляем невязку в кэш мгновенных невязок
            recent_residuals_cache = get_recent_residuals_cache()
            recent_residuals_cache.append(residual)
