from datetime import datetime
from typing import TYPE_CHECKING

from global_data import appdata
from global_data.config_schema import config
from models.op_message import OpMessage
from scripts.process_registry import get_current_visibility
from scripts.process_registry.registry_getters import get_signal_flags_aggregator
from utils.caches import cache_bis
from utils.caches.cache import cache_manager
from utils.lib.packet_decimator import packet_decimator
from utils.visibility.types import VisibilityStatus

if TYPE_CHECKING:
    from BisReciever.BisPacket import BisOpMessage


@packet_decimator.decimate('decimation.opmessage_decimation_interval')
def process_opmessage(packet: 'BisOpMessage'):
    """
    Обрабатывает пакеты "Оперативное сообщение" (0x31) от СПО сети БИС

    Декоратор вызывает данную функцию с интервалом из конфига decimation.opmessage_decimation_interval

    При вызове создает объект ТЛБД оперативного сообщения на основе сообщения из пакета,
    пишет в ТЛБД по флагу config['write_instance_to_ldb']['opmessage'],
    после чего добавляет его в аккумулятор оперативных сообщений

    Args:
        packet (BisOpMessage): пакет "Оперативное сообщение" от СПО сети БИС.
    """
    m = packet.message
    if m.signal_type in appdata.SIGNAL_TYPES:
        bis = cache_bis.get_item_by_key(packet.bis_number, packet.station_number)
        if bis is not None:
            nka = cache_manager.get_or_create_nka(m.nka_sys_number)
            created_message = OpMessage(bis=bis,
                                        nka=nka,
                                        timestamp=datetime.utcfromtimestamp(
                                            (m.num_of_days + 1826) * 24 * 60 * 60 + m.num_of_seconds),
                                        letter=m.letter,
                                        signal_type=m.signal_type,
                                        snr=m.snr,
                                        not_in_sight=m.not_in_sight,
                                        excess_of_residual=m.excess_of_residual,
                                        excess_of_pseudorange_difference=m.excess_of_pseudorange_difference,
                                        excess_of_navsolution_error=m.excess_of_navsolution_error,
                                        ground_control_call=m.ground_control_call,
                                        unreliable_frame=m.unreliable_frame,
                                        unreliable_signal=m.unreliable_signal,
                                        unreliable_digital_info=m.unreliable_digital_info,
                                        tk_inconsistency=0,
                                        tb_inconsistency=0)
            if config['write_instance_to_ldb']['opmessage'] == 'yes':
                created_message.save()
            created_message.timestamp = datetime.now()

            # Формируем оперативное сообщение, если не в ЗРВ
            current_visibility = get_current_visibility()
            visibility_status = current_visibility.get_status(packet.station_number, m.nka_sys_number)
            if visibility_status > VisibilityStatus.OUT_OF_SIGHT:
                signal_flags_aggregator = get_signal_flags_aggregator()  # получаем глобальный объект сборщика СП
                signal_flags_aggregator.add_operative_message(created_message)
