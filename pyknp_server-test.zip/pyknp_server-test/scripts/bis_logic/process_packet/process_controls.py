from datetime import datetime
from itertools import chain
from typing import TYPE_CHECKING

from data import Control
from db.db_connection import db
from global_data.config_schema import config
from utils.caches import cache_bis
from utils.caches.cache import cache_manager
from utils.lib.packet_decimator import packet_decimator

if TYPE_CHECKING:
    from BisReciever.BisPacket import BisControlResults


@packet_decimator.decimate('decimation.controls_decimation_interval')
def process_controls(packet: 'BisControlResults'):
    """
    Обрабатывает пакеты "Результаты контроля" (0x32) от СПО сети БИС

    Декоратор вызывает данную функцию с интервалом из конфига decimation.opmessage_decimation_interval

    При вызове создает объекты ТЛБД на основе сообщения из пакета и пишет их в ТЛБД атомарной пачкой

    Args:
        packet (BisControlResults): пакет "Результаты контроля" от СПО сети БИС.
    """

    if config['write_instance_to_ldb']['control'] == 'no':
        return
    message = packet.message
    meta = message.meta
    bis = cache_bis.get_item_by_key(packet.bis_number, packet.station_number)
    if bis is not None:
        ts = datetime.utcfromtimestamp((meta.num_of_days + 1826) * 24 * 60 * 60 + meta.seconds)
        controls = [[Control(signal_type=signal.signal_type,
                             nka=cache_manager.get_or_create_nka(measure.nka_sys_number),
                             bis=bis,
                             timestamp=ts,
                             letter=measure.letter,
                             snr=signal.snr / 10,
                             nka_status=signal.nka_status,
                             nka_elevation=measure.elevation / 10,
                             nka_azimuth=measure.azimuth / 10) for signal in measure.signals]
                    for measure in message.measurements]
        with db.atomic():
            Control.bulk_create(chain(*controls))
