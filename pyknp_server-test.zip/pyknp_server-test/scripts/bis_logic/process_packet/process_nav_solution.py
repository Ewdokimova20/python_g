import logging
from datetime import datetime
from typing import TYPE_CHECKING

from peewee import PeeweeException

from data import NavSolution
from global_data.config_schema import config
from utils.caches import cache_bis
from utils.lib.packet_decimator import packet_decimator

if TYPE_CHECKING:
    from BisReciever.BisPacket import BisNavSolution

logger = logging.getLogger(__name__)


@packet_decimator.decimate('decimation.nav_solution_decimation_interval')
def process_nav_solution(packet: 'BisNavSolution'):
    """
    Обрабатывает пакеты "Результаты решения НЗ" (0x33) от СПО сети БИС

    Декоратор вызывает данную функцию с интервалом из конфига decimation.opmessage_decimation_interval

    При вызове создает объект ТЛБД на основе сообщения из пакета и пишет его в базу

    Args:
        packet (BisNavSolution): пакет "Результаты решения НЗ" от СПО сети БИС.
    """
    if config['write_instance_to_ldb']['navsolution'] == 'no':
        return
    message = packet.message
    if message.meta.solution_status & 0b00000001:
        try:
            s = message.solution
            bis = cache_bis.get_item_by_key(packet.bis_number, packet.station_number)
            if bis is not None:
                t = datetime.utcfromtimestamp(
                    157766400 +
                    message.meta.timestamp_days * 24 * 60 * 60 +
                    message.meta.timestamp_s +
                    message.meta.timestamp_ns * 1e-9)
                NavSolution.create(
                    bis=bis,
                    timestamp=t,
                    latitude=s.latitude * 1e-7,
                    longitude=s.longitude * 1e-7,
                    height=s.height * 1e-2,
                    latitude_error=s.latitude_error * 1e-2,
                    longitude_error=s.longitude_error * 1e-2,
                    height_error=s.height_error * 1e-2,
                    latitude_velocity=s.latitude_velocity * 1e-2,
                    longitude_velocity=s.longitude_velocity * 1e-2,
                    height_velocity=s.height_velocity * 1e-2,
                    HDOP=s.HDOP,
                    VDOP=s.VDOP
                )
        except PeeweeException as e:
            logger.debug(e)
