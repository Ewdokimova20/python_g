"""Модуль логики процесса приема и обработки данных от СПО сети БИС"""
import logging
import queue
import threading
import traceback
from datetime import datetime

from db.db_connection import db
from db.db_manager import init_database_manager, shutdown_database_manager
from global_data.appdata import STATUS_NKA_DEFINE_STEP
from scripts.bis_logic.process_packet import process_packet
from scripts.handle_exception import handle_exception
from scripts.process_registry import get_partial_validity, get_best_nav_solutions_cache, get_user_nav_solutions_cache, \
    get_immediate_nav_solutions_cache, get_packet_queue, get_partial_nka_statuses, get_recent_residuals_cache, \
    get_partial_counters, get_current_visibility, get_di_string_buffer
from utils.astro import current_celestial_state
from utils.reception_control.di_reception.di_reception_data_collector_manager import di_reception_manager
from utils.reception_control.measurement_reception.meas_reception_data_collector_manager import measurement_reception_manager

logger = logging.getLogger(__name__)


def bis_logic(exiting: threading.Event):
    """
    Функция логики процесса приема и обработки данных от СПО сети БИС.
    Работает с несколькими БИС одновременно только на одном порту СПО сети БИС.

    Раскидывает полученные пакеты от СПО сети БИС из очереди по соответствующим обработчикам и выполняет периодические задания
    """

    logger.info("Поток обработки пакетов процесса обработки запущен")

    # Запускаем поток записи в БД
    init_database_manager()

    """До начала вхождения в петлю логики работы инициализируем время позднейшего обслуживания настоящим моментом.
    Это позволяет избежать лишнего сравнения при проверке времени обслуживания для выявления необходимости первичной 
    инициализации"""

    latest_clear_counters = datetime.now()
    latest_status_nka = datetime.now()
    latest_sun_position_cal = datetime.now()  # время позднейшего обновления положения Солнца
    latest_cache_expire = datetime.now()  # время позднейшей очистки кэша

    # Получаем глобальные объекты данного процесса обработки (вместо их импорта)
    partial_validity = get_partial_validity()  # достоверность сигналов с БИС, обрабатываемых в данном процессе
    current_visibility = get_current_visibility()  # состояние видимости НКА с БИС, обрабатываемых в данном процессе
    partial_counters = get_partial_counters()  # счетчики пакетов для БИС, обрабатываемых в данном процессе
    recent_residuals_cache = get_recent_residuals_cache()  # кэш свежайших невязок
    partial_nka_statuses = get_partial_nka_statuses()  # состояние приема с НКА для БИС, обрабатываемых в данном процессе
    packet_queue = get_packet_queue()  # очередь пакетов от СПО сети БИС для данного процесса обработки
    immediate_nav_solutions_cache = get_immediate_nav_solutions_cache()  # кэш свежайших решений НВЗ
    user_nav_solutions_cache = get_user_nav_solutions_cache()  # кэш пользовательских решений НВЗ
    best_nav_solutions_cache = get_best_nav_solutions_cache()  # кэш лучших решений НВЗ
    di_string_buffer = get_di_string_buffer()  # буфер для сбора и записи строк ЦИ в БД

    try:
        current_celestial_state.recalc_sun_position(latest_sun_position_cal)  # сразу пересчитываем, т.к. ОИ может придти до
        logger.info('Первичный расчет положения Солнца завершен.')
        current_visibility.update_visibility_by_almanac(datetime.now())
        logger.info('Первичный расчет видимости НКА по альманаху завершен.')
        measurement_reception_manager.check_and_flush_to_db()  # инициал. в ТЛБД состояние приема 1с измерений по всем БИС
        di_reception_manager.check_and_flush_to_db()  # инициал. в ТЛБД состояние приема строк ЦИ по всем БИС
    except:
        logger.error(traceback.format_exc())

    def auxilary_calculations(time_now):
        nonlocal latest_clear_counters, latest_status_nka, latest_sun_position_cal, latest_cache_expire
        if latest_clear_counters.day != time_now.day:
            latest_clear_counters = time_now
            partial_counters.clear_all_counters()
            logger.debug("Произведен сброс счётчиков пакетов")
        # определение флагов состояния сигналов
        if (time_now - latest_status_nka).total_seconds() > STATUS_NKA_DEFINE_STEP:
            latest_status_nka = time_now
            partial_nka_statuses.define_packets_statuses()
            partial_validity.send_on_socket()
        # пишем в ТЛБД состояние приема 1с измерений по всем БИС, если пора
        measurement_reception_manager.check_and_flush_to_db()
        di_reception_manager.check_and_flush_to_db()
        # обновляем положение Солнца раз в минуту т.к. метры в сдвиге ФЦА дают ошибку в пределах милиметра
        if (time_now - latest_sun_position_cal).total_seconds() > 60:
            latest_sun_position_cal = time_now
            current_celestial_state.recalc_sun_position(time_now)
            current_visibility.update_visibility_by_almanac(time_now)
        # очищаем кэш невязок по таймеру для исключения ситуации когда ф-я expire не вызывается при выходен НКА из ЗРВ
        if (time_now - latest_cache_expire).total_seconds() > 1:
            latest_cache_expire = time_now
            # очищаем кэши нвз для отражения отсутствия нвз по сигналам
            immediate_nav_solutions_cache.expire()
            user_nav_solutions_cache.expire()
            best_nav_solutions_cache.expire()
            # отбрасываем самые устаревшие данные (для восстановления фильтрации например при перезахвате сигнала)
            recent_residuals_cache.expire(time_now)

        # отправляем состояние всех счетчиков через сокет
        partial_counters.send_state()

    while not exiting.is_set():
        try:
            # Берем пакет из очереди
            packet = packet_queue.get(timeout=1)

            # Увеличиваем счетчик пакетов для БИС
            partial_counters.increment_bis_counters(packet.station_number, packet.bis_number, packet.packet_id)

            # Обработка сообщения из пакета
            process_packet(packet)

            packet_queue.task_done()
            time_now = datetime.now()
            auxilary_calculations(time_now)

        except queue.Empty:
            auxilary_calculations(datetime.now())
        except Exception as exc:
            logger.critical(f'Ошибка в функции логики процесса обработки!')
            handle_exception(type(exc), exc, exc.__traceback__)

    di_string_buffer.stop()  # остановка фонового потока сбора и записи строк ЦИ в БД
    # Останавливаем поток записи в БД
    logger.info("Закрытие соединения с ЛБД")
    shutdown_database_manager()
    db.close()
    logger.info("Соединение с ЛБД закрыто")
    logger.info("Завершение работы функции логики процесса обработки")
