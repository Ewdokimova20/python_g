import json
import logging
import sys
from pathlib import Path
from typing import List, Tuple, Dict


def load_bis_port_settings(json_path: str) -> Dict[int, List[Tuple[int, int]]]:
    """
    Загружает настройки сопоставления портов и БИС из JSON-файла.

    Формат JSON:
    {
      "5040": [
        {"station": 1, "bis_number": 17},
        {"station": 2, "bis_number": 17}
      ],
      "5041": [
        {"station": 1, "bis_number": 18}
      ]
    }

    Args:
        json_path (str): Путь к JSON-файлу с настройками.

    Returns:
        Dict[int, List[Tuple[int, int]]]: Словарь, где ключ — номер порта (int),
            значение — список кортежей (station, bis_number).

    Raises:
        SystemExit: При ошибках чтения файла или неверном формате данных.
    """
    path = Path(json_path)
    if not path.is_file():
        logging.error(f"Файл настроек портов СПО сети БИС НКУ не найден: {json_path}")
        sys.exit(-1)

    try:
        with path.open('r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        logging.error(f"Ошибка при чтении файла настроек портов СПО сети БИС НКУ {json_path}: {e}")
        sys.exit(-1)

    bis_ports = {}
    for port_str, entries in data.items():
        try:
            port = int(port_str)
            bis_pairs = []
            for entry in entries:
                station = entry['station']
                bis_number = entry['bis_number']
                bis_pairs.append((station, bis_number))
            bis_ports[port] = bis_pairs
        except (KeyError, ValueError, TypeError) as e:
            logging.error(f"Ошибка обработки записи для порта {port_str}: {e}")

    return bis_ports
