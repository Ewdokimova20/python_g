"""Модуль логики приложения

Главный скрипт приложения. Содержит главную функцию сервера
КНП и клиента БИС, а также всю логику обработки данных.
"""
import datetime
import logging
import threading
import traceback

from communication.endpoints import MAIN_PUB_SUB_ENDPOINT
from db.db_connection import db
from global_data.appdata import STATUS_NKA_DEFINE_STEP
from scripts.handle_exception import handle_exception
from scripts.process_registry import get_zmq_manager
from utils.SignalFlags import signal_flag_service
from utils.generalized_opmessage import generalized_opmessage
from utils.reception_control.di_reception.di_reception_monitor import di_reception_monitor
from utils.reception_control.measurement_reception.meas_reception_monitor import measurement_reception_monitor
from utils.statuses.bis_connection import bis_connection_state
from utils.statuses.nka_reception_status.general_nka_reception_status import general_nka_statuses
from utils.summarized_frame_opmessage import add_summarized_knp_opmessage_to_accumulator

logger = logging.getLogger(__name__)


def main_logic(exiting: threading.Event):
    """
    Главная функция логики приложения

    Должна быть вызвана после получения каждого пакета от БИС
    Раскидывает полученные пакеты по функциям, которые их обрабатывают
    """

    global latest_define_status, latest_status_nka, latest_update_sumframe_opmessage, latest_update_signal_flag, latest_status_generalized_opmessage
    logger.info("Приложение запущено")

    """До начала вхождения в петлю логики работы инициализируем время позднейшего обслуживания настоящим моментом.
    Это позволяет избежать лишнего сравнения при проверке времени обслуживания для выявления необходимости первичной 
    инициализации"""

    time_now = datetime.datetime.now()
    try:
        latest_define_status = time_now  # Момент времени, в который последний раз формировались состояния
        latest_status_nka = time_now
        latest_status_generalized_opmessage = time_now  # время последнего обновления статусов обобщенных оперативных сообщений
        latest_update_sumframe_opmessage = time_now  # время последнего добавления сообщений по обобщенный кадрам в аккумулятор
        latest_update_signal_flag = time_now
        measurement_reception_monitor.update_from_db(time_now)
        di_reception_monitor.update_from_db(time_now)

        zmq_manager = get_zmq_manager()

        # Настраиваем SUB для получения данных от всех дочерних процессов
        zmq_manager.setup_subscriber(MAIN_PUB_SUB_ENDPOINT)
        zmq_manager.setup_main_process_handlers()
        zmq_manager.start_subscriber()

        # Настраиваем REQ для отправки команд в bis_process
        zmq_manager.setup_req_client(timeout_ms=5000)
    except:
        logger.error(traceback.format_exc())

    while not exiting.is_set():
        try:
            time_now = datetime.datetime.now()
            # Определение флагов состояния обмена с БИС
            if (time_now - latest_define_status).total_seconds() > STATUS_NKA_DEFINE_STEP:
                latest_define_status = time_now
                bis_connection_state.define()
            # определение флагов состояния сигналов
            if (time_now - latest_status_nka).total_seconds() > STATUS_NKA_DEFINE_STEP:
                latest_status_nka = time_now
                general_nka_statuses.define_packets_statuses()
            # добавить оперативные сообщения по обобщенным кадрам в аккумулятор
            if (time_now - latest_update_sumframe_opmessage).total_seconds() > 10:
                add_summarized_knp_opmessage_to_accumulator(latest_update_sumframe_opmessage, time_now)
                latest_update_sumframe_opmessage = time_now
            # Обновление СП (finalize группы СП, в которой нет свежих СП)
            signal_flag_service.process_signal_flags(time_now)
            # определение флагов обобщенных сообщений
            if (time_now - latest_status_generalized_opmessage).total_seconds() > 10:
                latest_status_generalized_opmessage = time_now
                generalized_opmessage.define_generalized_opmessage()
            # заполняем данные состояния приема пакетов 1с измерений
            measurement_reception_monitor.update_from_db(time_now)
            # заполняем данные состояния приема строк ЦИ
            di_reception_monitor.update_from_db(time_now)
        except Exception as exc:
            logger.critical(f'Ошибка в функции логики основного процесса!')
            handle_exception(type(exc), exc, exc.__traceback__)

    logger.info("Закрытие соединения с ЛБД")
    db.close()
    logger.info("Соединение с ЛБД закрыто")
    logger.info("Завершение работы  функции основной логики программы")
