import logging
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

import global_data.config_schema
from scripts import handle_exception


class FilenameFilter(logging.Filter):
    """
    Фильтр для добавления имени файла (__filename__) в log record.
    """

    def filter(self, record):
        record.__filename__ = Path(record.pathname).name
        return True


class LoggingManager:
    """
    Класс для настройки и управления системой логирования.

    Атрибуты:
    config (dict): Словарь с конфигурацией.
    is_debug_enabled (bool): Флаг, указывающий, включено ли логирование уровня debug.
    is_peewee_logging_enabled (bool): Флаг, указывающий, включено ли логирование peewee.
    is_bis_communication_enabled (bool): Флаг, указывающий, включено ли логирование обмена с БИС.
    is_packet_stat_enabled (bool): Флаг, указывающий, включено ли логирование счетчиков пакетов.
    log_path (str): Путь к директории для файлов логирования.
    filename_prefix (str): Префикс для названий файлов логирования.
    log_file_length (int): Максимальный размер файла логирования в байтах.
    log_backup_num (int): Количество резервных копий файлов логирования.
    root_log_level: Корневой уровень логирования
    """

    def __init__(self, config=global_data.config_schema.config, filename_prefix='', need_debug_file=True):
        self.filename_prefix = filename_prefix
        self.need_debug_file = need_debug_file
        self.log_file_length = config['log']['log_file_length']
        self.log_backup_num = config['log']['log_backup_num']
        self.log_path = config['log']['path']
        self.is_debug_enabled = config['debug']['enable_debug_level_logging'] == 'yes'
        self.is_peewee_logging_enabled = config['debug']['peewee_logging'] == 'yes'
        self.is_bis_communication_enabled = config['debug']['bis_communication_logging'] == 'yes'
        self.is_packet_stat_enabled = config['debug']['packet_stat_logging'] == 'yes'
        self.root_log_level = logging.DEBUG if self.is_debug_enabled else logging.INFO

    def create_rotating_file_handler(self, filename: str):
        """
        Создает ротируемый файловый обработчик логирования.
        """
        file_formatter = logging.Formatter(
            '%(asctime)s.%(msecs)03d %(levelname)-8s [PID %(process)d %(processName)s] %(__filename__)s: %(message)s',
            '%Y-%m-%d %H:%M:%S'
        )
        file_handler = RotatingFileHandler(
            Path(self.log_path, datetime.now().strftime('%Y_%m_%d_%H_%M_%S') + filename),
            maxBytes=self.log_file_length,
            backupCount=self.log_backup_num)
        file_handler.setFormatter(file_formatter)
        file_handler.addFilter(FilenameFilter())
        return file_handler

    @staticmethod
    def setup_console_handler():
        """
        Настраивает логирование ошибок в консоль.
        """
        handler = logging.StreamHandler()
        handler.setLevel(logging.ERROR)
        formatter = logging.Formatter(
            '%(levelname)-3s [PID %(process)d %(processName)s] %(__filename__)s: %(message)s'
        )
        handler.setFormatter(formatter)
        handler.addFilter(FilenameFilter())
        return handler

    def setup_info_handler(self):
        # Логирование информационных сообщений в файл '_common.log'
        handler = self.create_rotating_file_handler(f"_{self.filename_prefix}_common.log")
        handler.setLevel(logging.INFO)
        return handler

    def setup_debug_handler(self):
        # Логирование отладочной информации в файл '_debug.log'
        handler = self.create_rotating_file_handler(f"_{self.filename_prefix}_debug.log")
        handler.setLevel(logging.DEBUG)
        return handler

    def setup_unhandled_exception_handler(self):
        """
        Настраивает логирование необработанных исключений в файл.
        """
        sys.excepthook = handle_exception
        handler = self.create_rotating_file_handler(f"_{self.filename_prefix}_unhandled.log")
        handler.setLevel(logging.CRITICAL)
        return handler

    def setup_peewee_logger_handler(self):
        """
        Настраивает логирование для модуля peewee.
        """
        peewee_logger = logging.getLogger('peewee')
        peewee_logger.handlers = []
        peewee_logger.propagate = False
        if self.is_debug_enabled and self.is_peewee_logging_enabled:
            peewee_debug_file_handler = self.create_rotating_file_handler(f"_{self.filename_prefix}_peewee_debug.log")
            peewee_debug_file_handler.setLevel(logging.DEBUG)
            peewee_logger.addHandler(peewee_debug_file_handler)

    def setup_bis_com_logger(self):
        """
        Настраивает логирование обмена с СПО сети БИС НКУ (BisProtocol).
        """
        bis_com_logger = logging.getLogger('bis_com')
        if self.is_bis_communication_enabled:
            bis_com_file_handler = self.create_rotating_file_handler(
                f'_{self.filename_prefix}_bis_communication.log')
            bis_com_logger.addHandler(bis_com_file_handler)
        if self.is_packet_stat_enabled:
            packet_stat_file_handler = self.create_rotating_file_handler(f'_{self.filename_prefix}_packet_stat.log')
            packet_stat_file_handler.setLevel(logging.INFO)
            bis_com_logger.addHandler(packet_stat_file_handler)
        bis_com_logger.propagate = False
        return bis_com_logger

    def setup_message_stats_handler(self):
        """Настраивает логирование статистики сообщений в отдельный файл"""
        if not self.filename_prefix:  # Только для основного процесса (без префикса)
            stats_logger = logging.getLogger('zmq_message_stats')
            stats_handler = self.create_rotating_file_handler(f"_{self.filename_prefix}_zmq_message_stats.log")
            stats_handler.setLevel(logging.INFO)
            stats_logger.addHandler(stats_handler)
            stats_logger.propagate = False  # Отключаем дублирование в корневой логгер

    def setup_logging(self):
        """
        Выполняет полную настройку системы логирования.
        """
        logging.basicConfig(level=self.root_log_level,
                            format='%(asctime)s %(levelname)-8s %(name)-8s: %(message)s',
                            handlers=[])
        root_logger = logging.getLogger('')
        root_logger.handlers = []

        # Обработчик вывода в консоль
        root_logger.addHandler(self.setup_console_handler())

        # Обработчики вывода в файлы
        log_path = Path(self.log_path)
        if not log_path.is_dir():
            try:
                log_path.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                logging.error('Не удалось создать директорию для логирования: ' + str(log_path))
                return

        root_logger.addHandler(self.setup_info_handler())  # _common.log
        root_logger.addHandler(self.setup_unhandled_exception_handler())  # _unhandled.log
        self.setup_peewee_logger_handler()  # _peewee.log
        if self.is_debug_enabled and self.need_debug_file:
            root_logger.addHandler(self.setup_debug_handler())  # _debug.log
        if self.filename_prefix.startswith('BisProcess'):
            self.setup_bis_com_logger()  # _packet_stat.log и _bis_communication.log
