import logging
from typing import Union, Dict, List

import msgpack
import zmq

from communication.types import ZMQMessage
from utils.lib.encoding import encode_for_json

logger = logging.getLogger('zmq_publisher')


class ZmqPublisher:
    """
    Класс для взаимодействия дочерних процессов с главным.
    Включает PUB-SUB взаимодействие.
    """

    def __init__(self, context: zmq.Context, endpoint: str):
        self.context = context
        self.endpoint = endpoint
        self.socket = self.context.socket(zmq.PUB)
        self.socket.connect(endpoint)
        logger.debug(f"PUB сокет подключен к {endpoint}")

    def publish_data(self, topic: str, data: Union[Dict, List], bis_id: int = None, station_number: int = None):
        """Публикация данных с указанием типа"""
        message = ZMQMessage(bis_id=bis_id, station_number=station_number, data=data)
        serialized_message = msgpack.packb(message, default=encode_for_json)

        self.socket.send_multipart([
            topic.encode('utf-8'),  # Тема
            serialized_message  # Сериализованное сообщение
        ])

    def close(self):
        """Закрытие только PUB сокета"""
        try:
            if hasattr(self, 'socket') and self.socket:
                self.socket.close()
                logger.debug(f"PUB сокет {self.endpoint} закрыт")
        except Exception as e:
            logger.debug(f"Ошибка при закрытии PUB сокета: {e}")
