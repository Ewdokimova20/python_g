import logging
import threading
import time

logger = logging.getLogger('zmq_message_stats')


class ZmqMessageStats:
    """Класс для подсчёта статистики обработки сообщений"""

    def __init__(self, interval_sec: int = 3):
        self.interval_sec = interval_sec

        # Общие счётчики
        self.total_received = 0
        self.total_processed = 0

        # Счётчики за интервал
        self.received_in_interval = 0
        self.processed_in_interval = 0

        # Очередь сообщений (необработанные)
        self.queue_size = 0

        self.running = False
        self.stats_thread = None

    def message_received(self):
        """Вызывается при получении нового сообщения"""
        self.total_received += 1
        self.received_in_interval += 1
        self.queue_size += 1

    def message_processed(self):
        """Вызывается при успешной обработке сообщения"""
        self.total_processed += 1
        self.processed_in_interval += 1
        self.queue_size = max(0, self.queue_size - 1)

    def get_current_stats(self) -> dict:
        """Получить текущую статистику"""
        return {
            "total": {
                "received": self.total_received,
                "processed": self.total_processed
            },
            "current_interval": {
                "received": self.received_in_interval,
                "processed": self.processed_in_interval
            },
            "queue_size": self.queue_size
        }

    def _log_interval_stats(self):
        """Логирование статистики за интервал с выравниванием чисел"""
        while self.running:
            time.sleep(self.interval_sec)

            # Форматируем числа с фиксированной шириной 8 символов, выравнивание по правому краю
            msg = (
                f"Получено: {self.received_in_interval:8d}, "
                f"Обработано: {self.processed_in_interval:8d}, "
                f"Всего получено: {self.total_received:8d}, "
                f"Всего обработано: {self.total_processed:8d}, "
                f"Очередь: {self.queue_size:8d}"
            )

            if self.queue_size > 100:
                msg += f"\nВНИМАНИЕ: Большая очередь сообщений ({self.queue_size})"

            self.received_in_interval = 0
            self.processed_in_interval = 0

            logger.info(msg)

    def start_monitoring(self):
        """Запуск мониторинга"""
        if self.stats_thread and self.stats_thread.is_alive():
            logger.warning("Мониторинг уже запущен")
            return

        self.running = True
        self.stats_thread = threading.Thread(
            target=self._log_interval_stats,
            daemon=True
        )
        self.stats_thread.start()
        logger.info(f"Запущен мониторинг сообщений (интервал {self.interval_sec}с)")

    def stop_monitoring(self):
        """Остановка мониторинга"""
        self.running = False
        if self.stats_thread:
            self.stats_thread.join(timeout=2.0)
            if self.stats_thread.is_alive():
                logger.warning("Не удалось корректно остановить мониторинг")
            else:
                logger.info("Мониторинг остановлен")
