import logging
import threading
import time
from typing import Dict, Callable, cast, Optional

import msgpack
import zmq

from communication.types import ZMQTopic, ZMQMessage
from communication.zmq_components.zmq_subscriber.zmq_message_stats import ZmqMessageStats
from utils.lib.encoding import decode_datetime

logger = logging.getLogger('zmq_subscriber')


class ZmqSubscriber:
    """
    Компонент для подписки на сообщения с темами через SUB сокет.
    Обработчики сообщений соответствующих тем регистрируются извне через subscribe_to_topic().
    """

    def __init__(self, context: zmq.Context, endpoint: str):
        self.context = context
        self.endpoint = endpoint
        self.socket = self.context.socket(zmq.SUB)
        self.running = False
        self.listener_thread: Optional[threading.Thread] = None
        self.handlers: Dict[ZMQTopic, Callable] = {}

        self.socket.bind(endpoint)

        # Настройка неблокирующего режима с таймаутом
        self.socket.setsockopt(zmq.RCVTIMEO, 1000)  # Таймаут 1000 мс

        # Статистика сообщений
        self.stats = ZmqMessageStats(interval_sec=1)

        logger.debug(f"SUB сокет подключен к {endpoint}")

    def subscribe_to_topic(self, topic: ZMQTopic, handler: Callable[[ZMQMessage], None]):
        """Регистрирует обработчик для темы"""
        self.handlers[topic] = handler
        logger.debug(f"Зарегистрирован обработчик для темы '{topic}'")

    def start_listening(self):
        """Запускает обработчик входящих сообщений в отдельном потоке"""
        if self.listener_thread and self.listener_thread.is_alive():
            logger.error("Поток SUB-обработчика ZMQ уже запущен")
            return

        if not self.handlers:
            logger.warning("Нет зарегистрированных обработчиков для запуска SUB")
            return

        # Подписка на темы из handlers
        for topic in self.handlers:
            self.socket.setsockopt_string(zmq.SUBSCRIBE, topic)
            logger.debug(f"Подписка на тему: {topic}")

        self.running = True
        self.listener_thread = threading.Thread(target=self._listen_worker, daemon=True)
        self.listener_thread.start()
        self.stats.start_monitoring()
        logger.info(f"SUB слушатель сообщений ZMQ запущен для {self.endpoint}")

    def _listen_worker(self):
        """Рабочая функция потока для прослушивания сообщений"""
        while self.running:
            try:
                topic, message = self.socket.recv_multipart()
                self.stats.message_received()  # Регистрируем получение

                topic = topic.decode('utf-8')
                message_data = cast(ZMQMessage, msgpack.unpackb(
                    message,
                    use_list=False,
                    strict_map_key=False,
                    object_hook=decode_datetime
                ))

                # Обработка сообщения соответствующим обработчиком
                if topic in self.handlers:
                    try:
                        self.handlers[topic](message_data)
                        logger.debug(f'Успешно обработан пакет с темой {topic}')
                        self.stats.message_processed()  # Регистрируем успешную обработку
                    except Exception as e:
                        logger.warning(f"Ошибка при обработке сообщения для темы {topic}: {e}")
                else:
                    logger.warning(f"Отсутствует обработчик для темы: {topic}")

            except zmq.error.Again:
                continue
            except Exception as e:
                logger.warning(f"Ошибка в SUB-обработчике ZMQ: {e}")
                time.sleep(0.1)

    def stop(self):
        """Останавливает прослушивание"""
        self.running = False
        self.stats.stop_monitoring()
        if self.listener_thread:
            self.listener_thread.join(timeout=2.0)
            if self.listener_thread.is_alive():
                logger.warning("Не удалось корректно остановить SUB обработчик сообщений ZMQ")
            else:
                logger.info("SUB обработчик остановлен")

    def close(self):
        """Закрытие только SUB сокета (контекст управляется менеджером)"""
        self.stop()
        try:
            if hasattr(self, 'socket') and self.socket:
                self.socket.close()
                logger.debug(f"SUB сокет {self.endpoint} закрыт")
        except Exception as e:
            logger.debug(f"Ошибка при закрытии SUB сокета: {e}")
