# communication/zmq_components/zmq_req_client.py
import logging
import threading
from typing import Dict, Any, Optional

import msgpack
import zmq

from communication.types import ZMQResponse
from utils.lib.encoding import encode_for_json, decode_datetime

logger = logging.getLogger('zmq_req_client')


class ZmqReqClient:
    """
    Клиент для отправки команд в дочерние процессы через REQ/REP паттерн.
    Поддерживает таймауты и повторные попытки.
    """

    def __init__(self, context: zmq.Context, timeout_ms: int = 5000, max_retries: int = 3):
        self.context = context
        self.timeout_ms = timeout_ms
        self.max_retries = max_retries
        self._connections: Dict[str, zmq.Socket] = {}
        self._lock = threading.Lock()

    def _get_or_create_socket(self, endpoint: str) -> zmq.Socket:
        """Получает существующий сокет или создает новый для данного эндпоинта"""
        with self._lock:
            if endpoint not in self._connections:
                socket = self.context.socket(zmq.REQ)
                socket.setsockopt(zmq.RCVTIMEO, self.timeout_ms)
                socket.setsockopt(zmq.SNDTIMEO, self.timeout_ms)
                socket.setsockopt(zmq.LINGER, 1000)  # Ждем 1 сек перед закрытием
                socket.connect(endpoint)
                self._connections[endpoint] = socket
                logger.debug(f"Создан REQ сокет для {endpoint}")

            return self._connections[endpoint]

    def send_command(self, endpoint: str, command: str, data: Dict[str, Any]) -> Optional[ZMQResponse]:
        """
        Отправляет команду в дочерний процесс и ожидает ответ.

        Args:
            endpoint: ZMQ эндпоинт (например, "tcp://127.0.0.1:9101")
            command: Тип команды
            data: Данные команды

        Returns:
            Ответ от дочернего процесса или None в случае ошибки
        """
        message = {
            'command': command,
            'data': data,
        }

        for attempt in range(self.max_retries):
            try:
                socket = self._get_or_create_socket(endpoint)

                # Отправляем сообщение
                serialized_message = msgpack.packb(message, default=encode_for_json)
                socket.send(serialized_message)
                logger.debug(f"Отправлена команда '{command}' на {endpoint} (попытка {attempt + 1})")

                # Ожидаем ответ
                response_data = socket.recv()
                response: ZMQResponse = msgpack.unpackb(
                    response_data,
                    use_list=False,
                    strict_map_key=False,
                    object_hook=decode_datetime
                )

                logger.debug(f"Получен ответ от {endpoint}: {response.get('status', 'unknown')}")
                return response

            except zmq.error.Again:
                logger.warning(f"Таймаут при отправке команды '{command}' на {endpoint} (попытка {attempt + 1})")
                self._recreate_socket(endpoint)

            except Exception as e:
                logger.error(f"Ошибка при отправке команды '{command}' на {endpoint}: {e}")
                self._recreate_socket(endpoint)

        logger.error(f"Не удалось отправить команду '{command}' на {endpoint} после {self.max_retries} попыток")
        return None

    # def send_command_to_bis(self, bis_id: int, command: str, data: Optional[Dict] = None) -> Optional[ZMQResponse]:
    #     """
    #     Отправляет команду в процесс, обрабатывающий заданный bis_id
    #
    #     Args:
    #         bis_id: ID БИС
    #         command: команда для отправки
    #         data: опциональные данные команды
    #
    #     Returns:
    #         Ответ от процесса или None в случае ошибки/таймаута
    #     """
    #     endpoint = get_cmd_endpoint_by_bis_id(bis_id)
    #     if endpoint is None:
    #         logger.error(f"Не найден endpoint для bis_id={bis_id}")
    #         return None
    #
    #     try:
    #         logger.debug(f"Отправка команды '{command}' на endpoint {endpoint} для bis_id={bis_id}")
    #         response = self._send_command(endpoint=endpoint, command=command, data=data or {})
    #         logger.debug(f"Получен ответ: {response}")
    #         if response and response.get('status') == ZMQResponseStatus.SUCCESS:
    #             return response
    #     except Exception as e:
    #         logger.error(f"Ошибка при отправке команды '{command}' для bis_id={bis_id}: {e}")
    #         return None

    def _recreate_socket(self, endpoint: str):
        """Пересоздает сокет для данного эндпоинта"""
        with self._lock:
            if endpoint in self._connections:
                try:
                    self._connections[endpoint].close()
                except:
                    pass
                del self._connections[endpoint]
                logger.debug(f"Пересоздан сокет для {endpoint}")

    def close(self):
        """Закрывает все соединения"""
        with self._lock:
            for endpoint, socket in self._connections.items():
                try:
                    socket.close()
                    logger.debug(f"Закрыт REQ сокет для {endpoint}")
                except Exception as e:
                    logger.debug(f"Ошибка при закрытии сокета {endpoint}: {e}")

            self._connections.clear()
