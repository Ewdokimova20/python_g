# communication/zmq_components/zmq_rep_server.py
import logging
import threading
import time
from typing import Dict, Callable, Any, Optional

import msgpack
import zmq

from communication.types import ZMQCommand, ZMQResponse, ZMQResponseStatus
from utils.lib.encoding import encode_for_json, decode_datetime

logger = logging.getLogger('zmq_rep_server')


class ZmqRepServer:
    """
    Сервер для обработки команд (запросов) от главного процесса через REQ/REP (request-reply) паттерн ZMQ.
    Работает в отдельном потоке.
    Обработчики сообщений регистрируются извне через register_handler().
    """

    def __init__(self, context: zmq.Context, endpoint: str):
        self.context = context
        self.endpoint = endpoint
        self.socket = self.context.socket(zmq.REP)
        self.running = False
        self.server_thread: Optional[threading.Thread] = None
        self.handlers: Dict[ZMQCommand, Callable] = {}

        # Настройка сокета
        self.socket.setsockopt(zmq.RCVTIMEO, 1000)  # Таймаут получения 1 сек
        self.socket.bind(endpoint)

        logger.info(f"ZMQ REP сервер инициализирован на {endpoint}")

    def register_handler(self, command: ZMQCommand, handler: Callable[[Dict[str, Any]], Dict[str, Any]]):
        """Регистрирует обработчик для команды

        Args:
            command: Название команды
            handler: Функция-обработчик, которая принимает данные и возвращает результат
        """
        self.handlers[command] = handler
        logger.debug(f"Зарегистрирован обработчик для команды '{command}'")

    def start(self):
        """Запускает сервер в отдельном потоке"""
        if self.server_thread and self.server_thread.is_alive():
            logger.warning("ZMQ REP сервер уже запущен")
            return

        if not self.handlers:
            logger.warning("Нет зарегистрированных обработчиков для запуска REP сервера")
            return

        self.running = True
        self.server_thread = threading.Thread(target=self._server_worker, daemon=True)
        self.server_thread.start()
        logger.info(f"ZMQ REP сервер запущен в фоновом режиме на {self.endpoint}")

    def _server_worker(self):
        """Рабочая функция потока сервера"""
        while self.running:
            try:
                # Получаем сообщение с таймаутом
                message_data = self.socket.recv()

                try:
                    message = msgpack.unpackb(message_data, use_list=False, strict_map_key=False, object_hook=decode_datetime)

                    command = message.get('command')
                    data = message.get('data', {})

                    logger.debug(f"Получена команда '{command}' от главного процесса")

                    # Обрабатываем команду
                    if command in self.handlers:
                        try:
                            result = self.handlers[command](data)
                            response: ZMQResponse = {
                                'status': ZMQResponseStatus.SUCCESS,
                                'command': command,
                                'result': result,
                                'error': None,
                                'timestamp': time.time()
                            }
                            logger.debug(f"Команда '{command}' выполнена успешно")

                        except Exception as e:
                            logger.error(f"Ошибка при выполнении команды '{command}': {e}")
                            response: ZMQResponse = {
                                'status': ZMQResponseStatus.ERROR,
                                'command': command,
                                'result': None,
                                'error': str(e),
                                'timestamp': time.time()
                            }
                    else:
                        logger.warning(f"Неизвестная команда: '{command}'")
                        response: ZMQResponse = {
                            'status': ZMQResponseStatus.ERROR,
                            'command': command,
                            'result': None,
                            'error': f"Неизвестная команда: {command}",
                            'timestamp': time.time()
                        }

                    # Отправляем ответ
                    serialized_response = msgpack.packb(response, default=encode_for_json)
                    self.socket.send(serialized_response)

                except Exception as e:
                    logger.error(f"Ошибка при обработке сообщения: {e}")
                    error_response: ZMQResponse = {
                        'status': ZMQResponseStatus.ERROR,
                        'command': None,
                        'result': None,
                        'error': f"Ошибка обработки сообщения: {str(e)}",
                        'timestamp': time.time()
                    }
                    serialized_response = msgpack.packb(error_response, default=encode_for_json)
                    self.socket.send(serialized_response)

            except zmq.error.Again:
                # Таймаут - продолжаем цикл
                continue

            except Exception as e:
                logger.error(f"Критическая ошибка в ZMQ REP сервере: {e}")
                time.sleep(0.1)

    def stop(self):
        """Останавливает сервер"""
        self.running = False

        if self.server_thread:
            self.server_thread.join(timeout=2.0)
            if self.server_thread.is_alive():
                logger.warning("Не удалось корректно остановить ZMQ REP сервер")
            else:
                logger.info("ZMQ REP сервер остановлен")

    def close(self):
        """Закрывает только REP сокет"""
        self.stop()
        try:
            if hasattr(self, 'socket') and self.socket:
                self.socket.close()
                logger.debug(f"REP сокет {self.endpoint} закрыт")
        except Exception as e:
            logger.debug(f"Ошибка при закрытии REP сокета: {e}")
