from enum import Enum
from typing import Optional, Any, Union

from typing_extensions import TypedDict


class ZMQTopic(str, Enum):
    """Темы сообщений ZMQ"""
    RECENT_RESIDUALS_CACHE = "recent_residuals_cache"
    RECENT_NAV_SOLUTIONS_CACHE = "recent_nav_solutions_cache"
    CURRENT_ANGLES = "current_angles"
    PACKET_COUNTERS = "packet_counters"
    VALIDITY = "validity"
    SIGNAL_FLAGS = "signal_flags"
    NKA_OUT_OF_SIGHT = "nka_out_of_sight"
    SI_EMBEDDING_VERIFICATION = "si_embedding_verification"
    DI_TO_SI_OVERALL_VALIDITY = "di_to_si_overall_validity"


class ZMQMessage(TypedDict):
    """Формат сообщения ZMQ"""
    bis_id: Optional[int]
    station_number: Optional[int]
    data: Any


class ZMQCommand(str, Enum):
    """Возможные команды в рамках REQ_REP (request-reply) взаимодействия"""
    GET_USR_NAV_SOLUTION_PARAMS = "get_usr_nav_solution_params"
    SET_USR_NAV_SOLUTION_PARAMS = "set_usr_nav_solution_params"


class ZMQResponseStatus(str, Enum):
    """ВОзможные статусы ответа от REP сервера"""
    SUCCESS = "success"
    ERROR = "error"


class ZMQResponse(TypedDict):
    status: ZMQResponseStatus  # 'success' или 'error'
    command: Optional[str]  # команда, может быть None при ошибке обработки сообщения
    result: Optional[Any]  # результат выполнения команды, может быть None при ошибке
    error: Optional[Union[str, None]]  # текст ошибки или None
    timestamp: float  # время в формате timestamp (float)
