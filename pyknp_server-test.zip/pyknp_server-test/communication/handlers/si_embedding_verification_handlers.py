from communication.types import ZMQMessage
from scripts.process_registry import get_si_embedding_verifier


def handle_di_to_si_overall_validity(message_data: ZMQMessage) -> None:
    """Обработчик для результатов контроля ЦИ по СИ (контроля закладки СИ) по теме
    ZMQTopic.DI_TO_SI_OVERALL_VALIDITY """

    si_embedding_verifier = get_si_embedding_verifier()
    si_embedding_verifier.handle_verification_results_update(message_data['data'])
