import logging
from datetime import datetime
from typing import Dict, Any

from global_data import user_navsolution_parameters


def handle_get_usr_nav_solution_params(data: {'bis_id': int}) -> Dict[str, Any]:
    """
    Обработчик команды (запроса) на получение текущих параметров пользвательского решения НВЗ

    Args:
        data: Данные запроса с bis_id

    Returns:
        Текущие параметры из global_data.user_navsolution_parameters
    """
    logger = logging.getLogger('handle_get_usr_nav_solution_params')

    try:
        bis_id = data.get('bis_id')
        logger.debug(f"Запрос параметров анализа НВЗ для БИС {bis_id}")

        # Получаем параметры из global_data
        result = {
            'bis': user_navsolution_parameters.bis_id_for_user_solution,
            'nka_for_solution': user_navsolution_parameters.nka_in_solution,
            'signal_for_solution': user_navsolution_parameters.signal_for_user_solution,
            'use_signals_with_ln': user_navsolution_parameters.use_signals_with_ln,
            'worst_nka_search_result': user_navsolution_parameters.worst_nka_result,
            'last_worst_nka': user_navsolution_parameters.last_worst_nka,
        }

        # Обновляем время последнего запроса (аналогично GET в оригинале)
        user_navsolution_parameters.user_solution_last_request_time = datetime.now().timestamp()

        logger.debug(f"Параметры анализа НВЗ для БИС {bis_id} успешно получены")
        return result

    except Exception as e:
        logger.error(f"Ошибка при получении параметров анализа НВЗ: {e}")
        raise


def handle_set_usr_nav_solution_params(data: {'bis_id': int, 'params': Dict[str, Any]}) -> Dict[str, Any]:
    """
    Обработчик команды (запроса) на установку параметров пользвательского решения НВЗ

    Args:
        data: Данные с bis_id и новыми параметрами

    Returns:
        Статус выполнения операции
    """

    logger = logging.getLogger('handle_set_usr_nav_solution_params')

    try:
        bis_id = data.get('bis_id')
        params = data.get('params', {})

        logger.debug(f"Установка параметров анализа НВЗ для БИС {bis_id}")

        # Устанавливаем параметры в global_data (аналогично POST в оригинале)
        user_navsolution_parameters.nka_in_solution = params['nka_in_solution']
        user_navsolution_parameters.signal_for_user_solution = params['signal_for_user_solution']
        user_navsolution_parameters.bis_id_for_user_solution = params['bis_id_for_user_solution']
        user_navsolution_parameters.search_worst_nka = params['search_worst_nka']
        user_navsolution_parameters.use_signals_with_ln = params['use_signals_with_ln']
        user_navsolution_parameters.worst_nka_result = {}
        user_navsolution_parameters.user_solution_last_request_time = datetime.now().timestamp()

        logger.info(f"Параметры анализа НВЗ для БИС {bis_id} успешно установлены")

        return {
            'status': 'parameters_set',
            'bis_id': bis_id,
            'timestamp': datetime.now().timestamp()
        }

    except Exception as e:
        logger.error(f"Ошибка при установке параметров анализа НВЗ: {e}")
        raise
