from typing import List

from communication.types import ZMQMessage
from utils.SI.si_embedding_verification.si_embedding_verification_for_client import si_embedding_verification_for_client
from utils.SignalFlags import signal_flag_service
from utils.nav_solution import nav_solutions_cache_for_client
from utils.reception_control.message_counters.general_message_counter import general_message_counters
from utils.residuals import residuals_cache_for_client
from utils.validity.general_validity import general_validity
from utils.visibility.current_visibility import current_visibility_for_client


def handle_recent_residuals_cache(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.RECENT_RESIDUALS_CACHE"""
    residuals_cache_for_client.load_data(
        bis_id=message_data['bis_id'],
        data=message_data['data']
    )


def handle_recent_nav_solutions_cache(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.RECENT_NAV_SOLUTIONS_CACHE"""
    nav_solutions_cache_for_client.load_data(
        bis_id=message_data['bis_id'],
        data=message_data['data']
    )


def handle_current_angles(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.CURRENT_ANGLES"""
    current_visibility_for_client.load_data(
        station_number=message_data['station_number'],
        data=message_data['data']
    )


def handle_packet_counters(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.PACKET_COUNTERS"""
    general_message_counters.load_data(data=message_data['data'])


def handle_validity(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.VALIDITY"""
    general_validity.load_data(data=message_data['data'])


def handle_signal_flags(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.SIGNAL_FLAGS"""
    signal_flag_service.load_data(data=message_data['data'])


def handle_nka_out_of_sight(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.NKA_OUT_OF_SIGHT"""
    nkas: List[int] = message_data['data']
    for nka in nkas:
        signal_flag_service.change_notification_status(nka)


def handle_si_embedding_verification(message_data: ZMQMessage) -> None:
    """Обработчик для сообщений с темой ZMQTopic.SI_EMBEDDING_VERIFICATION"""
    si_embedding_verification_for_client.load_data(message_data['data'])
