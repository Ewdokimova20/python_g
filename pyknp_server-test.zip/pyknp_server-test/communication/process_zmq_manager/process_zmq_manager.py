# communication/process_zmq_manager.py
import logging
from typing import Optional, Dict, Callable, Any

import zmq

from communication.types import ZMQTopic, ZMQCommand, ZMQResponse, ZMQResponseStatus
from communication.zmq_components.zmq_publisher import ZmqPublisher
from communication.zmq_components.zmq_rep_server import ZmqRepServer
from communication.zmq_components.zmq_req_client import ZmqReqClient
from communication.zmq_components.zmq_subscriber import ZmqSubscriber
from scripts.prepare_bis_process_configs import get_cmd_endpoint_by_bis_id

logger = logging.getLogger('process_zmq_manager')


class ProcessZmqManager:
    """
    Универсальный менеджер всех ZMQ коммуникаций для любого процесса.
    Поддерживает все паттерны: PUB/SUB, REQ/REP
    """

    def __init__(self, process_name: str = "Unknown"):
        self.process_name = process_name
        self.context = zmq.Context()

        # Компоненты (создаются по требованию)
        self.publisher: Optional[ZmqPublisher] = None
        self.subscriber: Optional[ZmqSubscriber] = None
        self.rep_server: Optional[ZmqRepServer] = None
        self.req_client: Optional[ZmqReqClient] = None

        logger.info(f"ProcessZmqManager инициализирован для процесса '{process_name}'")

    # ==================== PUBLISHER ====================
    def setup_publisher(self, endpoint: str) -> ZmqPublisher:
        """Настраивает PUB сокет"""
        if self.publisher:
            logger.warning(f"[{self.process_name}] Publisher уже настроен")
            return self.publisher

        self.publisher = ZmqPublisher(self.context, endpoint)
        logger.info(f"[{self.process_name}] Publisher настроен для {endpoint}")
        return self.publisher

    def publish_data(self, topic: str, data, bis_id: int = None, station_number: int = None):
        """Публикует данные через PUB сокет"""
        if not self.publisher:
            raise RuntimeError(f"[{self.process_name}] Publisher не настроен")
        self.publisher.publish_data(topic, data, bis_id, station_number)

    # ==================== SUBSCRIBER ====================
    def setup_subscriber(self, endpoint: str) -> ZmqSubscriber:
        """Настраивает SUB сокет"""
        if self.subscriber:
            logger.warning(f"[{self.process_name}] Subscriber уже настроен")
            return self.subscriber

        self.subscriber = ZmqSubscriber(self.context, endpoint)
        logger.info(f"[{self.process_name}] Subscriber настроен для {endpoint}")
        return self.subscriber

    def subscribe_to_topic(self, topic: ZMQTopic, handler: Callable):
        """Подписывается на тему"""
        if not self.subscriber:
            raise RuntimeError(f"[{self.process_name}] Subscriber не настроен")
        self.subscriber.subscribe_to_topic(topic, handler)

    def start_subscriber(self):
        """Запускает subscriber"""
        if not self.subscriber:
            raise RuntimeError(f"[{self.process_name}] Subscriber не настроен")
        self.subscriber.start_listening()

    # ==================== REP SERVER ====================
    def setup_rep_server(self, endpoint: str) -> ZmqRepServer:
        """Настраивает REP сервер"""
        if self.rep_server:
            logger.warning(f"[{self.process_name}] REP сервер уже настроен")
            return self.rep_server

        self.rep_server = ZmqRepServer(self.context, endpoint)
        logger.info(f"[{self.process_name}] REP сервер настроен для {endpoint}")
        return self.rep_server

    def register_command_handler(self, command: ZMQCommand, handler: Callable[[Dict[str, Any]], Dict[str, Any]]):
        """Регистрирует обработчик команды для REP сервера"""
        if not self.rep_server:
            raise RuntimeError(f"[{self.process_name}] REP сервер не настроен")
        self.rep_server.register_handler(command, handler)

    def start_rep_server(self):
        """Запускает REP сервер"""
        if not self.rep_server:
            raise RuntimeError(f"[{self.process_name}] REP сервер не настроен")
        self.rep_server.start()

    # ==================== REQ CLIENT ====================
    def setup_req_client(self, timeout_ms: int = 5000, max_retries: int = 3) -> ZmqReqClient:
        """Настраивает REQ клиент"""
        if self.req_client:
            logger.warning(f"[{self.process_name}] REQ клиент уже настроен")
            return self.req_client

        self.req_client = ZmqReqClient(self.context, timeout_ms, max_retries)
        logger.info(f"[{self.process_name}] REQ клиент настроен")
        return self.req_client

    def send_command(self, endpoint: str, command: str, data: Dict[str, Any] = None):
        """Отправляет команду через REQ клиент"""
        if not self.req_client:
            raise RuntimeError(f"[{self.process_name}] REQ клиент не настроен")
        return self.req_client.send_command(endpoint, command, data or {})

        # ==================== BIS-PROCESS-SPECIFIC METHODS ====================

    def send_command_to_bis(self, bis_id: int, command: str, data: Optional[Dict] = None) -> Optional[ZMQResponse]:
        """
        Отправляет команду в процесс, обрабатывающий заданный bis_id.
        Удобный wrapper для работы с BIS процессами.

        Args:
            bis_id: ID БИС
            command: команда для отправки
            data: опциональные данные команды

        Returns:
            Ответ от процесса или None в случае ошибки/таймаута
        """
        if not self.req_client:
            raise RuntimeError(f"[{self.process_name}] REQ клиент не настроен")

        endpoint = get_cmd_endpoint_by_bis_id(bis_id)
        if endpoint is None:
            logger.error(f"[{self.process_name}] Не найден endpoint для bis_id={bis_id}")
            return None

        try:
            logger.debug(f"[{self.process_name}] Отправка команды '{command}' на endpoint {endpoint} для bis_id={bis_id}")
            response = self.req_client.send_command(endpoint=endpoint, command=command, data=data or {})

            if response and response.get('status') == ZMQResponseStatus.SUCCESS:
                logger.debug(f"[{self.process_name}] Получен успешный ответ от bis_id={bis_id}")
                return response
            else:
                logger.warning(f"[{self.process_name}] Получен неуспешный ответ от bis_id={bis_id}: {response}")
                return response

        except Exception as e:
            logger.error(f"[{self.process_name}] Ошибка при отправке команды '{command}' для bis_id={bis_id}: {e}")
            return None

    # ==================== LIFECYCLE ====================
    def close(self):
        """Закрывает все соединения и контекст"""
        logger.info(f"[{self.process_name}] Закрытие ProcessZmqManager")

        components = [
            ('Publisher', self.publisher),
            ('Subscriber', self.subscriber),
            ('REP Server', self.rep_server),
            ('REQ Client', self.req_client)
        ]

        for name, component in components:
            if component:
                try:
                    component.close()
                    logger.debug(f"[{self.process_name}] {name} закрыт")
                except Exception as e:
                    logger.error(f"[{self.process_name}] Ошибка при закрытии {name}: {e}")

        try:
            if self.context:
                self.context.term()
                logger.debug(f"[{self.process_name}] ZMQ контекст завершен")
        except Exception as e:
            logger.error(f"[{self.process_name}] Ошибка при завершении ZMQ контекста: {e}")

    # ===================== МЕТОДЫ РЕГИСТРАЦИИ ОБРАБОТЧИКОВ =======================
    def setup_main_process_handlers(self):
        """Настройка handlers для главного процесса"""
        if not self.subscriber:
            raise RuntimeError("Subscriber не настроен")

        from communication.handlers.main_process_handlers import (
            handle_recent_residuals_cache,
            handle_recent_nav_solutions_cache,
            handle_current_angles, handle_packet_counters, handle_validity, handle_signal_flags, handle_nka_out_of_sight,
            handle_si_embedding_verification
        )

        self.subscriber.subscribe_to_topic(ZMQTopic.RECENT_RESIDUALS_CACHE, handle_recent_residuals_cache)
        self.subscriber.subscribe_to_topic(ZMQTopic.RECENT_NAV_SOLUTIONS_CACHE, handle_recent_nav_solutions_cache)
        self.subscriber.subscribe_to_topic(ZMQTopic.CURRENT_ANGLES, handle_current_angles)
        self.subscriber.subscribe_to_topic(ZMQTopic.PACKET_COUNTERS, handle_packet_counters)
        self.subscriber.subscribe_to_topic(ZMQTopic.VALIDITY, handle_validity)
        self.subscriber.subscribe_to_topic(ZMQTopic.SIGNAL_FLAGS, handle_signal_flags)
        self.subscriber.subscribe_to_topic(ZMQTopic.NKA_OUT_OF_SIGHT, handle_nka_out_of_sight)
        self.subscriber.subscribe_to_topic(ZMQTopic.SI_EMBEDDING_VERIFICATION, handle_si_embedding_verification)

    def setup_bis_process_handlers(self):
        """Настройка handlers для bis процесса"""
        if not self.rep_server:
            raise RuntimeError("REP сервер не настроен")

        from communication.handlers.bis_process_handlers import (
            handle_get_usr_nav_solution_params,
            handle_set_usr_nav_solution_params
        )

        self.rep_server.register_handler(ZMQCommand.GET_USR_NAV_SOLUTION_PARAMS, handle_get_usr_nav_solution_params)
        self.rep_server.register_handler(ZMQCommand.SET_USR_NAV_SOLUTION_PARAMS, handle_set_usr_nav_solution_params)

    def setup_si_embed_verif_process_handlers(self):
        """Настройка handlers для главного процесса"""
        if not self.subscriber:
            raise RuntimeError("Subscriber не настроен")

        from communication.handlers.si_embedding_verification_handlers import handle_di_to_si_overall_validity

        self.subscriber.subscribe_to_topic(ZMQTopic.DI_TO_SI_OVERALL_VALIDITY, handle_di_to_si_overall_validity)
