"""Реализация протокола обмена с БИС на twisted

Реализует протокол ИЛВ между СПО сети БИС и СПО КНП.
"""
import datetime
import logging
import struct
import time
from collections import Counter, defaultdict

from peewee import PeeweeException
from twisted.internet.protocol import ClientFactory, connectionDone
from twisted.internet.task import LoopingCall
from twisted.protocols.stateful import StatefulProtocol
from twisted.python import failure

import global_data.config_schema
from data import Packet
from global_data import appdata
from scripts.process_registry import get_packet_queue
from .BisCommon import *
from .BisPacket import create_packet, BisMeasurements

logger = logging.getLogger('bis_com')

DELTA_TIME_BIS1S_LOCAL_TIME = 2
"""Допустимая разница между временем в пакете с 1с измерениями и локальным временем.
Используется для определения возможности использования меток времени пакетов 
при оценке расхождения локального времени и времени сервера БИС, по которому привязывются измерения"""

DELTA_TIME_PROCESS_PACKET = 10
"""Допустимая разница локального времени и времени пакета (с учётом разницы локального времени и 
времени сервера БИС, при котором производится обработка пакет"""


class BisProtocol(StatefulProtocol):
    """
    Протокол приема пакетов от БИС

    Реализует конечный автомат. Последовательно переходит из состояния
    ожидания заголовка пакета БИС к состоянию его обработки. Затем после
    получения тела пакета переходит в состояние обработки бизнес-логики.
    После этого переходит к начальному состоянию ожидания заголовка.
    Квитанция отправляется из обработчика бизнес-логики.
    """

    _transmitter_delay: float
    """Задержка между часами СПО сети БИС и локальными часами сервера КНП"""
    bis_delay: dict
    """Словарь-хранилище задержки передачи. Момент передачи пакета определяется по часам БИС, а приема по часам КНП"""
    _packet_counter: Counter
    """Словарь-хранилище количества принятых пакетов и отправленных квитанций за период"""
    connected: bool
    """Флаг состояния соединения с БИС"""
    has_data: bool
    """Флаг наличия данных от БИС"""

    def __init__(self):
        """
        Инициализация

        Стирает хранимый заголовок и контент
        """
        self._erase_packet_bytes()
        self._packet_counter = Counter()
        self._erase_packet_counter()
        self.bis_delay = defaultdict(int)
        self._transmitter_delay = 0
        self.lp2 = LoopingCall(self._process_counter)
        self.connected = False
        self.has_data = False
        self.prev_queue = 0
        # фиксируем время начала взаимодействия с СПО сети БИС
        appdata.BIS_PROTOCOL_START_TIME = datetime.datetime.now().replace(microsecond=0)

        return

    def _erase_packet_counter(self):
        packet_queue = get_packet_queue()
        self.prev_queue = packet_queue.qsize()
        self._packet_counter.clear()

    def _process_counter(self):
        if self._packet_counter['p'] > 2:
            self.has_data = True
        else:
            self.has_data = False
        packet_queue = get_packet_queue()
        appdata.queue_status['received'] = self._packet_counter['p']
        appdata.queue_status['processed'] = -1 * packet_queue.qsize() + self.prev_queue + \
                                            self._packet_counter['p']
        appdata.queue_status['queue'] = packet_queue.qsize()
        appdata.queue_status['packerror'] = self._packet_counter['e']
        appdata.queue_status['timeerror'] = self._packet_counter['t']
        appdata.queue_status['last_update_at'] = datetime.datetime.now()
        logger.info(f"{str(datetime.datetime.now())}\treceived\t{str(self._packet_counter['p'])}\t\
                    processed\t{str(-1 * packet_queue.qsize() + self.prev_queue + self._packet_counter['p'])}\t\
                    queue\t{str(packet_queue.qsize())}\t\
                    packerror\t{str(self._packet_counter['e'])}\t\
                    timeerror\t{str(self._packet_counter['t'])}")
        self._erase_packet_counter()

    def _erase_packet_bytes(self):
        """Стирает хранимый заголовок и контент"""

        self._header_bytes = b''
        self._content_bytes = b''

    def connectionMade(self):
        """Обработчик события успешного установления связи с БИС"""
        logging.info("Reactor: соединение с БИС установлено")
        self._erase_packet_bytes()
        self.connected = True
        self.lp2.start(1)

    def connectionLost(self, reason: failure.Failure = connectionDone):
        logging.info("Reactor: соединение с БИС потеряно")
        self.connected = False
        self.lp2.stop()

    def getInitialState(self):
        """
        Обработчик состояния ожидания заголовка пакета

        Стирает хранимый заголовок и контент, затем ждет заголовок пакета.
        Получает заголовок пакета и отправляет протокол в состояние
        обработки принятого пакета
        """

        self._erase_packet_bytes()
        return self._receive_header, BIS_HEADER_LENGTH

    def _receive_header(self, header_bytes: bytes) -> (object, int):
        """
        Обработчик состояния, когда получен заголовок

        Обрабатывает заголовок пакета и отправляет протокол в состояние,
        когда получен контент
        """

        # достаём content_length из заголовка, остальное игнорируем
        (_, _, _, _, _, _, content_length) = struct.unpack(BIS_HEADER_FORMAT, header_bytes)
        logger.debug("Header received: " + str(struct.unpack(BIS_HEADER_FORMAT, header_bytes)))
        self._header_bytes = header_bytes
        return self._receive_content, content_length

    def _receive_content(self, content_bytes: bytes) -> (object, int):
        """
        Обработчик состояния,когда получен контент

        Передает контент в бизнес-логику и возвращает протокол в состояние
        ожидания заголовка
        """
        receive_time = datetime.datetime.now()
        self._content_bytes = content_bytes
        self._application_logic(receive_time=receive_time)
        return self.getInitialState()

    def _application_logic(self, receive_time: datetime.datetime):
        """
        Обработчик логики приложения

        Создает пакет БИС по байтикам заголовка и контента. Затем
        отдает пакет в (диспетчерскую) функцию бизнес-логики
        И отправляем квитанцию
        """
        self.packet = create_packet(header=self._header_bytes, content=self._content_bytes, receive_time=receive_time)
        self._packet_counter['p'] += 1
        self._send_quittance()
        self._packet_counter['q'] += 1
        logger.debug(f"Тип сообщения: {self.packet.NAME}, ИД сообщения: {str(self.packet.packet_id)}")

        now = datetime.datetime.now().timestamp()
        packet_header_time = self.packet.get_seconds_since_1970()
        bis = self.packet.bis_number
        station = self.packet.station_number

        if isinstance(self.packet, BisMeasurements):
            packet_true_seconds = self.packet.get_true_seconds_since_1970()
            if abs(packet_true_seconds - now) < DELTA_TIME_BIS1S_LOCAL_TIME:
                self._transmitter_delay = now - packet_header_time
                self.bis_delay[(station, bis)] = now - packet_true_seconds

        packet_valid = self.packet.is_valid()
        is_packet_outdated = abs(now - packet_header_time) > global_data.config_schema.config['bis_control'][
            'max_diff_between_local_and_packet_time']
        is_packet_processing_allowed = not global_data.config_schema.config['bis_control']['check_packet_receive_time'] \
                                       or not is_packet_outdated \
                                       and packet_valid

        try:
            if global_data.config_schema.config['server']['store_raw_packets'] == 'yes':
                Packet.create(packet_identi=self.packet.packet_id,
                              packet_gen_timestamp_s=packet_header_time,
                              db_timestamp_s=now,
                              packet_gen_timestamp=datetime.datetime.fromtimestamp(packet_header_time),
                              db_timestamp=datetime.datetime.fromtimestamp(now),
                              ders=now - packet_header_time,
                              dropped=not is_packet_processing_allowed)
            if is_packet_processing_allowed:
                packet_queue = get_packet_queue()
                packet_queue.put(self.packet)
                # фейковые пакеты от БИС
                # отличаются от оригинальных только номером БИС и станции
                # fake_packet_1 = copy(self.packet)
                # fake_packet_2 = copy(self.packet)
                # fake_packet_3 = copy(self.packet)
                #
                # fake_packet_1.station_number = 3
                # fake_packet_1.bis_number = 1
                # fake_packet_2.station_number = 3
                # fake_packet_2.bis_number = 2
                # fake_packet_3.station_number = 3
                # fake_packet_3.bis_number = 3
                #
                # application.packet_queue.put(fake_packet_1)
                # application.packet_queue.put(fake_packet_2)
                # application.packet_queue.put(fake_packet_3)
                # Если нужно больше фейковых БИС, то расскомментируйте код ниже
                # fake_packet_4 = copy(self.packet)
                # fake_packet_5 = copy(self.packet)
                # fake_packet_4.station_number = 7
                # fake_packet_4.bis_number = 4
                # fake_packet_5.station_number = 7
                # fake_packet_5.bis_number = 9
                # application.packet_queue.put(fake_packet_4)
                # application.packet_queue.put(fake_packet_5)
            else:
                if not packet_valid:
                    self._packet_counter['e'] += 1
                    logger.debug('Сообщение отброшено. Ошибка контрольной суммы или длины пакета')
                elif global_data.config_schema.config['bis_control'][
                    'check_packet_receive_time'] and is_packet_outdated:
                    self._packet_counter['t'] += 1
                    # logger.debug(
                    #     f"Сообщение отброшено. Текущее время {str(now)}, время пакета {str(packet_header_time)}")
        except PeeweeException as e:
            logger.warning("Ошибка записи пакета в ТЛБД:" + str(e))

    def _send_quittance(self):
        """Функция отправки квитанции в ответ на принятый от БИС пакет"""
        quitance = self.packet.get_quitance()
        logger.debug("Квитанция: " + str(struct.unpack("< L B B L H L B B B", quitance)))
        self.transport.write(quitance)


class BisClientFactory(ClientFactory):
    """
    Фабрика клиентов БИС

    Создает экземпляры протокола клиента БИС и обрабатывает его события
    """

    protocol = BisProtocol

    def __init__(self):
        self.connectedProtocol = None
        super().__init__()

    def startedConnecting(self, connector):
        """Обработчик начала подключения к БИС"""
        logger.info('Начато подключение к БИС')

    def buildProtocol(self, address):
        """Инстанциация протокола"""
        proto = ClientFactory.buildProtocol(self, address)
        self.connectedProtocol = proto
        return proto

    def clientConnectionLost(self, connector, reason):
        """Обработчик потери подключения к БИС"""
        logger.info('Cоединение с БИС потеряно. Причина: ' + str(reason.getErrorMessage()))
        time.sleep(1)
        connector.connect()

    def clientConnectionFailed(self, connector, reason):
        """Обработчик ошибки подключения к БИС"""
        logger.info('Cоединение с БИС разорвано. Причина: ' + str(reason.getErrorMessage()))
        time.sleep(1)
        connector.connect()
