"""Описание пакетов, принимаемых от БИС

Модуль для хранения классов для описания пакетов, принимаемых от БИС.

Интерфейс пакетов описан в IBisPacket().

Базовая реализация пакета описана в BaseBisPacket().

Конкретные реализации должны наследовать BaseBisPacket().
"""
import binascii
import datetime
import logging
import struct
import time
from abc import ABCMeta, abstractmethod
from typing import NamedTuple, List, Any

from global_data import appdata
from global_data.config_schema import config
from .BisCommon import *

__all__ = ['IBisPacket',
           'BisControlResults',
           'BisMeasurements',
           'BisDigitalInfoL1OF',
           'BisDigitalInfoL2OF',
           'BisDigitalInfoL1SF',
           'BisDigitalInfoL1OC',
           'BisDigitalInfoL3OC',
           'BisDigitalInfoL1SC',
           'BisDigitalInfoL2SC',
           'BisDigitalInfoL2KSI',
           'BisMeteoData',
           'BisNavSolution',
           'BisOpMessage']

EPOCH_J2000_SECONDS = 946684800
"""Секунды c 01.01.1970 00:00 по 01.01.2000 00:00"""

LENGTH_CODEGRAM = 12
"""Длина кодограммы для сигнала с кодовым разделением согласно протоколу ИЛВ 14Ц181.4000-0 Д3"""


class IBisPacket(metaclass=ABCMeta):
    """Интерфейс пакетов БИС"""

    @abstractmethod
    def __init__(self):
        """Инициализация

        Дефолтная инициализация основных свойств пакета. Заполняет всё None
        """
        (self.checksum,
         self.bis_number,
         self.station_number,
         self.packet_id,
         self.timestamp_s,
         self.timestamp_ms,
         self.content_length,
         self.receive_time) = tuple([None] * 8)

    @property
    @abstractmethod
    def PACKET_ID(self) -> int:
        """
        ИД пакета

        Назначенный при объявлении класса ID пакета. Должен соответствовать
        14Ц181.4000-0 Д3
        """

    @property
    @abstractmethod
    def NAME(self) -> str:
        """Наименование пакета"""

    @abstractmethod
    def is_valid(self) -> bool:
        """
        Валидация пакета

        Возвращает true если пакет валидный
        """

    @abstractmethod
    def _get_message(self):
        """
        Возвращает содержимое пакета от БИС
        """
        pass

    @abstractmethod
    def get_quitance(self) -> bytes:
        """Возвращает квитанцию"""

    @abstractmethod
    def get_seconds_since_1970(self) -> float:
        """Возвращает количество целых секунд от 01 января 1970 года в часовом поясе +0"""


class BaseBisPacket(IBisPacket):
    """Базовый класс для пакетов БИС"""

    PACKET_ID = None
    NAME = 'Base packet'

    def __init__(self, header: bytes, content: bytes, receive_time: datetime.datetime):
        """Инициализация

        Байтовый заголовок и байтовое тело записываются в self.header и
        self.content соответственно.
        Данные из заголовка записываются в соответствующие атрибуты.
        """
        if len(header) != BIS_HEADER_LENGTH:
            raise ValueError('WRONG HEADER LENGTH')
        self.header = header  # байтовый заголовок
        self.content = content  # байтовый контент (тело сообщения)
        self._message = None
        (self.checksum,
         self.bis_number,
         self.station_number,
         self.packet_id,
         self.timestamp_s,
         self.timestamp_ms,
         self.content_length) = struct.unpack(BIS_HEADER_FORMAT, header)
        self.receive_time = receive_time

    @property
    def message(self):
        """Кэшируемое свойство для получения содержимого пакета (геттер)"""
        if self._message is None:
            self._message = self._get_message()
        return self._message

    def crc32_is_valid(self):
        """Проверка контрольной суммы

        Полином как в IEEE 802.3, соответственно как и в binascii.crc32
        """
        return binascii.crc32((self.header + self.content)[4:]) == self.checksum

    def content_length_is_valid(self):
        """Проверка длины

        Возвращает true если длина принятого тела пакета
        соответствует соответствует заявленной в заголовке
        """
        return len(self.content) == self.content_length

    def is_valid(self):
        """Валидация пакета

        Возвращает true если контрольная сумма валидна и длина
        принятого тела пакета соответствует заявленной в заголовке
        """
        if self.content_length_is_valid() and self.crc32_is_valid():
            return True
        else:
            return False

    def _get_message(self):
        raise NotImplementedError

    def get_quitance(self) -> bytes:
        """Возвращает квитанцию

        Квитанция в соответствии с 14Ц181.4000-0 Д3 Таблица 4.24 Специальный
        пакет «Квитанция о получении»
        """

        quitance = struct.pack('<B', 2)  # ID пакета-квитанции

        if self.is_valid():  # если мы получили валидный пакет
            quitance += struct.pack('<B', 1)
        else:
            quitance += struct.pack('<B', 0)

        (secs, msecs) = current_time()  # текущее время в (секундах, миллисекундах)
        quitance += struct.pack('<L', secs)
        quitance += struct.pack('<H', msecs)

        quitance += struct.pack('<L', self.checksum)

        quitance += struct.pack('<B', self.bis_number)

        quitance += struct.pack('<B', self.station_number)

        quitance += struct.pack('<B', self.packet_id)

        quitance_crc32 = struct.pack('<L', binascii.crc32(quitance))

        quitance = quitance_crc32 + quitance

        return quitance

    def get_seconds_since_1970(self) -> float:
        """Возвращает количество целых секунд от 01 января 1970 года в часовом поясе +0"""
        return self.timestamp_s + EPOCH_J2000_SECONDS - 3600 * 3 + self.timestamp_ms / 1000


class BisPing(BaseBisPacket):
    """Пакет 'Контроль соединения'"""
    PACKET_ID = 1
    NAME = 'Ping'

    class Ping(NamedTuple):
        """Фэйковое содержимое пакета 'Контроль соединения'"""
        content: str = 'ping'

    def _get_message(self):
        return self.Ping()


class BisControlResults(BaseBisPacket):
    """Пакет 'Результаты контроля'"""
    PACKET_ID = 0x32
    NAME = 'Control results'

    class ControlResults(NamedTuple):
        """Содержимое пакета 'Результаты контроля'"""

        class Meta(NamedTuple):
            """Метаинформация"""

            bis_health: int
            """Кодовое обозначение текущего технического состояния БИС"""

            bis_mode: int
            """Кодовое обозначение текущего режима функционирования БИС"""

            num_of_days: int
            """Число суток от 01.01.1975"""

            seconds: int
            """Число секунд от начала суток"""

            num_of_nka: int
            """Количество НКА, данные по которым передаются в пакете"""

        class Control(NamedTuple):
            """Информационный блок «Контроль НКА»"""

            class Signal(NamedTuple):
                """Блок данных сигнала

                Присутствует, если соотношение сигнал-шум сигнала больше нуля.

                Количество блоков дано в Control.num_of_blocks.
                """

                signal_type: int
                """Тип сигнала

                Описание параметров информационного блока «Тип сигнала» представлено в 
                14Ц181.4000-0 Д3 Приложении А.
                """

                snr: int
                """Соотношение сигнал/шум, 0.1 дБ """

                nka_status: int
                """Состояние НКА

                Побитовая расшифровка параметра «Состояние НКА» приведена в 
                14Ц181.4000-0 Д3 таблице 4.17
                """

            nka_sys_number: int
            """Системный номер КА"""

            letter: int
            """Литера навигационного сигнала КА"""

            elevation: int
            """Угол места НКА, 0.1 градуса"""

            azimuth: int
            """Азимут НКА, 0.1 градуса"""

            num_of_signal_blocks: int
            """Количество блоков для типов сигналов"""

            signals: List[Signal]

        meta: Meta
        """Метаинформация"""
        measurements: List[Control]
        """Список информационных блоков «Контроль НКА»"""

    def _get_message(self) -> ControlResults:
        """Возвращает содержимое пакета Результаты контроля"""
        offset = 9
        meta = self.ControlResults.Meta(*struct.unpack("< B B H L B", self.content[:offset]))
        measurements = []
        for _ in range(meta.num_of_nka):
            (nka_sys_num, letter, elevation, azimuth, num_of_signal_blocks) = \
                struct.unpack("< B b H H B", self.content[offset:offset + 7])
            offset += 7
            signals = []
            for _ in range(num_of_signal_blocks):
                signals.append(
                    self.ControlResults.Control.Signal(*struct.unpack("< B H H", self.content[offset:offset + 5])))
                offset += 5
            signals_id = {s.signal_type for s in signals}
            # защита от обработки сигналов GPS:
            # проверяем, пересекаются ли множество сигналов GPS и множество сигналов из пакета
            if not set(appdata.GPS_SIGNALS) & signals_id:
                # если нет, то добавляем данные о сигналах в список измерений
                measurements.append(
                    self.ControlResults.Control(nka_sys_number=nka_sys_num,
                                                letter=letter,
                                                elevation=elevation,
                                                azimuth=azimuth,
                                                num_of_signal_blocks=num_of_signal_blocks,
                                                signals=signals)
                )
        return self.ControlResults(meta=meta, measurements=measurements)


class BisMeasurements(BaseBisPacket):
    """Пакет односекундных измерений"""
    PACKET_ID = 17
    NAME = 'Measurements'

    class OneSecMeasurements(NamedTuple):
        """Содержимое пакета односекундных измерений"""

        class Meta(NamedTuple):
            """Метаинформация"""

            bis_health: int
            """
            Кодовое обозначение текущего технического состояния БИС

            Описание параметра «Техсостояние БИС» представлено в Протоколе 
            информационно-логического взаимодействия между БИС-Н и 
            ИВК ИС БИС-Н Приложение А п.А.7.
            """

            bis_mode: int
            """
            Кодовое обозначение текущего режима функционирования БИС

            Описание параметра «Режим функц. БИС» представлено в Протоколе 
            информационно-логического взаимодействия между БИС-Н и ИВК ИС 
            БИС-Н Приложение А п.А.6.
            """

            num_of_days: int
            """Число суток от 01.01.1975"""

            seconds: int
            """Число секунд от начала суток"""

            nanoseconds: int
            """Число секунд от начала суток, дробная часть"""

            num_info_blocks: int
            """Число передаваемых информационных блоков"""

        class Measurements(NamedTuple):
            """Односекундные измерения НКА"""

            signal_type: int
            """Тип сигнала"""

            nka_sys_number: int
            """Системный номер КА"""

            letter: int
            """Литера навигационного сигнала КА"""

            snr: int
            """Соотношение сигнал/шум, 0.1 дБ"""

            pseudorange: int
            """Полная псевдодальность кодовых измерений, мм"""

            carrier_shift: int
            """Доплеровский сдвиг несущей частоты, 1e-3 Гц"""

            carrier_phase_integer_part: int
            """Интегральная фаза несущей частоты, целая часть, цикл"""

            carrier_phase_decimal_part: int
            """Интегральная фаза несущей частоты, дробная часть, 1e-4 цикл"""

            pseudospeed: int
            """Псевдоскорость, мм/с"""

        meta: Meta
        """Метаинформация пакета односекундных измерений"""
        measurements: List[Measurements] = []
        """Блок измерений по каждому НКА"""

    def _get_message(self) -> OneSecMeasurements:
        """Возвращает содержимое пакета односекундных измерений БИС"""
        offset = 13
        meta = self.OneSecMeasurements.Meta(*struct.unpack("< B B H L L B", self.content[:offset]))
        measurements = []
        for _ in range(meta.num_info_blocks):
            measure = self.OneSecMeasurements.Measurements(*struct.unpack("< B H b H Q l l h l",
                                                                          self.content[offset:offset + 28]))
            if measure.signal_type not in appdata.GPS_SIGNALS:
                measurements.append(measure)
            offset += 28
        return self.OneSecMeasurements(meta=meta, measurements=measurements)

    def get_true_seconds_since_1970(self):
        """Возвращает количество целых секунд по данным БИС от 01 января 1970 года в часовом поясе +0"""
        meta = self.OneSecMeasurements.Meta(*struct.unpack("< B B H L L B", self.content[:13]))
        return (meta.num_of_days + 1826) * 86400 + meta.seconds - 10800


class BisDigitalInfoFabric(BaseBisPacket):
    """
    Класс-фабрика пакетов цифровой информации

    Возвращает инстанс класса, соответствущий типу принятого сигнала
    """

    PACKET_ID = 0x21
    NAME = "Digital information"

    def __new__(cls, header: bytes, content: bytes, receive_time: datetime.datetime, *args, **kwargs):
        meta = BisDigitalInfoBase.DigitalInfo.Meta(*struct.unpack("< B H H B B", content[:7]))
        receiver = None
        for DI_subclass in BisDigitalInfoBase.__subclasses__():
            if DI_subclass.SIGNAL_TYPE == meta.signal_type:
                receiver = DI_subclass(header=header, content=content, receive_time=receive_time)
            if DI_subclass.SIGNAL_TYPE is None:
                for DI_type_class in DI_subclass.__subclasses__():
                    if DI_type_class.SIGNAL_TYPE == meta.signal_type:
                        receiver = DI_type_class(header=header, content=content, receive_time=receive_time)
                    if DI_type_class.SIGNAL_TYPE is None:
                        for DI_type_subclass in DI_type_class.__subclasses__():
                            if DI_type_subclass.SIGNAL_TYPE == meta.signal_type:
                                receiver = DI_type_subclass(header=header, content=content, receive_time=receive_time)
        if not receiver:
            receiver = BisDigitalInfoBase(header=header, content=content, receive_time=receive_time)
        return receiver

    def _get_message(self):
        raise NotImplementedError("This class doesn't implement message parsing!")


class BisDigitalInfoBase(BaseBisPacket):
    """Базовый пакет Цифровая информация"""
    SIGNAL_TYPE = None

    class DigitalInfo(NamedTuple):
        """Содержимое пакета Цифровая информация"""

        class Meta(NamedTuple):
            """Метаинформация пакета цифровой информации"""

            signal_type: int
            """Тип сигнала"""

            nka_sys_number: int
            """Системный номер НКА"""

            checksum_1b: int
            """Проверочные символы: младший байт. Для L1SF содержит КХ строки 1, начиная с младшего бита"""

            checksum_2b: int
            """Проверочные символы: два старших байта. Для L1SF в младшем байте содержит КХ строки 2, начиная с младшего бита"""

            num_of_codegrams: int
            """Число кодограмм"""

        meta: Meta
        """Метаинформация"""
        digital_info: Any
        """Полезная нагрузка пакета (строки в случае L1OF)"""

    def get_meta(self):
        """Разбирает метаинформацию пакета Цифровая информация"""
        return self.DigitalInfo.Meta(*struct.unpack("< B H B H B", self.content[:7]))

    def _get_message(self) -> DigitalInfo:
        meta = self.get_meta()
        return self.DigitalInfo(meta=meta, digital_info=None)


class BisDigitalInfoL1OF(BisDigitalInfoBase):
    """Пакет цифровой информации по сигналу L1OF"""

    SIGNAL_TYPE = 0x01

    # noinspection PyPep8Naming
    class L1OF_string(NamedTuple):
        string_num: int = None
        """Номер строки"""
        string: bytes = None
        """Байты строки цифровой информации"""

    def _get_message(self):
        meta = self.get_meta()
        string_num = (self.content[7] >> 4) & 0b1111
        payload = self.L1OF_string(string_num=string_num, string=self.content[7:])
        return self.DigitalInfo(meta=meta, digital_info=payload)


class BisDigitalInfoL2OF(BisDigitalInfoBase):
    """Пакет цифровой информации по сигналу L2OF"""

    SIGNAL_TYPE = 0x09

    # noinspection PyPep8Naming
    class L2OF_string(NamedTuple):
        string_num: int = None
        """Номер строки"""
        string: bytes = None
        """Байты строки цифровой информации"""

    def _get_message(self):
        meta = self.get_meta()
        string_num = (self.content[7] >> 4) & 0b1111
        payload = self.L2OF_string(string_num=string_num, string=self.content[7:])
        return self.DigitalInfo(meta=meta, digital_info=payload)


class BisDigitalInfoL1SF(BisDigitalInfoBase):
    """Пакет цифровой информации по сигналу L1SF"""

    SIGNAL_TYPE = 0x21

    # noinspection PyPep8Naming
    class L1SF_code_message(NamedTuple):
        """Кодограмма L1SF"""

        # noinspection PyPep8Naming
        class L1SF_string(NamedTuple):
            """Строка кодограммы L1SF"""

            string_num: int = None
            """Номер строки"""
            string: bytes = None
            """Байты строки цифровой информации"""

        string1: L1SF_string
        """Первая строка кодограммы L1SF"""
        string2: L1SF_string
        """Вторая строка кодограммы L1SF"""

    # noinspection PyPep8Naming
    def get_L1SF_string(self, string_num, string):
        """Создает строку L1SF"""
        return self.L1SF_code_message.L1SF_string(string_num=string_num, string=string)

    def _get_message(self):
        meta = self.get_meta()
        string_num1 = (self.content[7] >> 4) & 0b1111
        string_num2 = (self.content[12] >> 1) & 0b1111
        string1 = self.content[7:13]
        string2 = ((int.from_bytes(self.content[12:18], byteorder='big') << 3) & 0xFFFFFFFFFFFF) \
            .to_bytes(6, byteorder='big')
        string1 = self.get_L1SF_string(string_num=string_num1, string=string1)
        string2 = self.get_L1SF_string(string_num=string_num2, string=string2)
        payload = self.L1SF_code_message(string1=string1, string2=string2)
        return self.DigitalInfo(meta=meta, digital_info=payload)


class BisDigitalInfoCDMA(BisDigitalInfoBase):
    """Пакет цифровой информации по сигналам с кодовым разделением"""

    SIGNAL_TYPE = None

    # noinspection PyPep8Naming
    class DI_String(NamedTuple):
        """Строка кодограммы ЦИ"""
        string_num: int = None
        """Номер строки"""
        string: bytes = None
        """Байты строки цифровой информации"""

    def get_type_string(self, string: bytes) -> int:
        pass

    def _get_message(self):
        meta = self.get_meta()
        message: bytes = self.content[7:]
        string = bytes()
        num_of_codegrams = meta.num_of_codegrams

        if num_of_codegrams * LENGTH_CODEGRAM > len(message):  # TODO добавить обработку аномальных строк
            logging.error('Ошибка количества кодограмм в сигнале типа {0}. Время пакета = {1}'.
                          format(self.SIGNAL_TYPE, self.receive_time))
            num_of_codegrams = len(message) // LENGTH_CODEGRAM

        for i in range(0, num_of_codegrams):
            string_start = (i * LENGTH_CODEGRAM)
            string_end = string_start + LENGTH_CODEGRAM
            code_message = message[string_start:string_end]

            substring = ((int.from_bytes(code_message[1:10], byteorder="big") >> 4)
                         & 0xFFFFFFFFFFFFFFFF).to_bytes(8, byteorder="big")
            string += substring
        # TODO в строке есть лишние нули в младших разрядах, вызванные некратностью размера строки 64-битовым фрагментам. Стоит их удалить для оптимизации
        string_num = self.get_type_string(string)

        payload = self.DI_String(string_num=string_num, string=string)
        return self.DigitalInfo(meta=meta, digital_info=payload)


class BisDigitalInfoL1OC(BisDigitalInfoCDMA):
    """Пакет цифровой информации по сигналу L1OC"""

    SIGNAL_TYPE = 0x06

    def get_type_string(self, string: bytes) -> int:
        type_string = ((int.from_bytes(string[1:3], byteorder="big") >> 6)
                       & 0b111111).to_bytes(1, byteorder="big")
        return int.from_bytes(type_string, byteorder="big")


class BisDigitalInfoL3OC(BisDigitalInfoCDMA):
    """Пакет цифровой информации по сигналу L3OC"""

    SIGNAL_TYPE = 0x16

    def get_type_string(self, string: bytes) -> int:
        type_string = ((int.from_bytes(string[2:4], byteorder="big") >> 6)
                       & 0b111111).to_bytes(1, byteorder="big")
        return int.from_bytes(type_string, byteorder="big")


class BisDigitalInfoSC(BisDigitalInfoCDMA):
    """Пакет цифровой информации по сигналу L1SC и L2SC"""

    def get_type_string(self, string: bytes) -> int:
        type_string = ((int.from_bytes(string[1:3], byteorder="big") >> 6)
                       & 0b111111).to_bytes(1, byteorder="big")
        return int.from_bytes(type_string, byteorder="big")


class BisDigitalInfoL1SC(BisDigitalInfoSC):
    """Пакет цифровой информации по сигналу L1SC"""

    SIGNAL_TYPE = 0x26


class BisDigitalInfoL2SC(BisDigitalInfoSC):
    """Пакет цифровой информации по сигналу L2SC"""

    SIGNAL_TYPE = 0x2E


class BisDigitalInfoL2KSI(BisDigitalInfoCDMA):
    """Пакет цифровой информации по сигналу L2КСИ"""

    SIGNAL_TYPE = 0x0E

    def get_type_string(self, string: bytes) -> int:
        type_string = ((int.from_bytes(string[1:3], byteorder="big") >> 6)
                       & 0b111111).to_bytes(1, byteorder="big")
        return int.from_bytes(type_string, byteorder="big")


class BisNavSolution(BaseBisPacket):
    """Пакет решения навигационной задачи силами БИС"""
    PACKET_ID = 0x33

    class NavSolution(NamedTuple):
        """Данные решения навигационной задачи"""

        class Meta(NamedTuple):
            """Метаданные пакета"""

            bis_health: int
            """Кодовое обозначение текущего технического состояния БИС"""

            bis_mode: int
            """Кодовое обозначение текущего режима функционирования БИС"""

            solution_profile: int
            """Профиль РНЗ:
                1 – только с навигационными сигналами с частотным разделением;
                2 – только с навигационными сигналами с кодовым разделением;
                3 – с навигационными сигналами с частотным и с кодовым разделением.
            """

            timestamp_days: int
            """Число суток от 01.01.1975"""

            timestamp_s: int
            """Число секунд от начала суток"""

            timestamp_ns: int
            """Число нс от начала суток"""

            solution_status: int
            """Статус РНЗ"""

        class Solution(NamedTuple):
            """Решение навигационной задачи"""

            latitude: float
            """Широта в градусах, ЦМР 1e-7"""

            longitude: float
            """Долгота в градусах, ЦМР 1e-7"""

            height: float
            """Высота в метрах, ЦМР 1e-2"""

            height_difference: float
            """Разность между высотой над эллипсоидом и высотой над уровнем моря, ЦМР 1e-2"""

            latitude_error: float
            """Оценка точности по широте в метрах, ЦМР 1e-1"""

            longitude_error: float
            """Оценка точности по долготе в метрах, ЦМР 1e-1"""

            height_error: float
            """Оценка точности по высоте в метрах, ЦМР 1e-1"""

            latitude_velocity: float
            """Скорость по широте, ЦМР 1e-2"""

            longitude_velocity: float
            """Скорость по долготе, ЦМР 1e-2"""

            height_velocity: float
            """Скорость по высоте, ЦМР 1e-2"""

            HDOP: float
            """ЦМР 1 (фактически; в протоколе ЦМР 1e-1)"""

            VDOP: float
            """ЦМР 1 (фактически; в протоколе ЦМР 1e-1)"""

        meta: Meta
        """Метаданные пакета"""

        solution: Solution = None
        """Решение навигационной задачи"""

    def _get_message(self):
        offset = 17
        meta = self.NavSolution.Meta(*struct.unpack("< B B B H L L L", self.content[:offset]))
        solution = None
        if meta.solution_status & 0b00000001 == 1:
            solution = self.NavSolution.Solution(
                *struct.unpack("< l l l h H H H l l l B B", self.content[offset:offset + 34])
            )
        return self.NavSolution(meta=meta, solution=solution)


class BisOpMessage(BaseBisPacket):
    """Пакет оперативного сообщения"""
    PACKET_ID = 0x31

    class OpMessage(NamedTuple):
        """Оперативное сообщение"""

        num_of_days: int
        """Число суток от 01.01.1975"""

        num_of_seconds: int
        """Число секунд от начала суток"""

        nka_sys_number: int
        """Системный номер КА"""

        letter: int
        """Литера навигационного сигнала"""

        signal_type: int
        """Тип сигнала"""

        snr: float
        """Отношение сигнал/шум"""

        not_in_sight: bool
        """Флаг отсутствия НКА в зоне радиовидимости"""

        excess_of_residual: bool
        """Флаг превышения значений невязок кодовой псевдодальности"""

        excess_of_pseudorange_difference: bool
        """Флаг превышения заданного порога значением разности псевдодальностей 
        по пилотной составляющей и составляющей с ЦИ"""

        excess_of_navsolution_error: bool
        """Флаг превышения погрешности решения навигационной задачи"""

        ground_control_call: bool
        """Флаг приёма в НС признака вызова НКУ"""

        unreliable_frame: bool
        """Флаг приёма в НС признака недостоверности кадра"""

        unreliable_signal: bool
        """Флаг приёма в НС признака негодности сигнала"""

        unreliable_digital_info: bool
        """Флаг приёма в НС признака недостоверности строки ЦИ"""

    def _get_message(self):
        offset = 12
        (num_of_days, num_of_seconds, nka_sys_number, letter, signal_type, snr, flags) = \
            struct.unpack("< H L B b B H B", self.content[:offset])
        return self.OpMessage(num_of_days=num_of_days,
                              num_of_seconds=num_of_seconds,
                              nka_sys_number=nka_sys_number,
                              letter=letter,
                              signal_type=signal_type,
                              snr=snr,
                              not_in_sight=flags & 0b00000001,
                              excess_of_residual=flags & 0b00000010,
                              excess_of_pseudorange_difference=flags & 0b00000100,
                              excess_of_navsolution_error=flags & 0b00001000,
                              ground_control_call=flags & 0b00010000,
                              unreliable_frame=flags & 0b00100000,
                              unreliable_signal=flags & 0b01000000,
                              unreliable_digital_info=flags & 0b10000000)


class BisMeteoData(BaseBisPacket):
    """Пакет оперативного сообщения"""
    PACKET_ID = 0x41

    class OpMessage(NamedTuple):
        """Оперативное сообщение"""

        second_in_day: int
        """Число секунд от начала суток"""

        pressure: float
        """Атмосферное давление, мБар"""

        temperature: float
        """Градусы Цельсия"""

        humidity: float
        """Относительная влажность"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._should_process = False
        """Флаг, необходимо ли брать в обработку по результатам прореживания"""
        self._message = self._get_message()
        """Сообщение, полученное из пакета"""

    def _get_message(self) -> OpMessage:
        """Парсит сообщение из битовой строки и выставляет флаг необходимости обработки согласно настройкам прореживания"""
        message = self._parse_message_from_bytes()
        # согласно настройкам по прореживанию пакетов определяем, нужно ли будет обрабатывать пакет
        self._should_process = message.second_in_day % config['decimation']['meteoparameters_decimation_interval'] == 0
        return message

    def _parse_message_from_bytes(self) -> OpMessage:
        offset = 12
        # важное примечание: формат пакета противоречит ПИЛВ в части порядка байт. Реализован по факту
        (second_in_day_hi, second_in_day_mid, second_in_day_lo, pressure_hi, pressure_lo, temperature_hi,
         temperature_n_humidity,
         humidity_lo, _) = \
            struct.unpack("< B B B B B B B B L", self.content[:offset])
        # учитваем возможную отрицательность температуры (тогда будет взведен старший бит и значения старшей тетрады будут больше 7)
        temperature_raw = (temperature_hi << 4) + ((temperature_n_humidity & 0xF0) >> 4)  # 12 бит
        temperature_sign = 1.0
        # FIXME проверить натурно представление отрицательной температуры
        if temperature_hi >= 0x80:  # анализируем старший бит. Его значение означает отрицательность
            temperature_raw ^= 0xFFF  # инвертируем все 12 бит числа (т.к. 1^0->1, 1^1->0)
            temperature_raw += 1  # прибавляем 1 по правилу вычисления отрицательных значений в дополнительном коде
            temperature_sign = -1.0  # знак учтем в виде множителя
        # формируем структуру с результатом декодировки
        return self.OpMessage(second_in_day=second_in_day_lo + (second_in_day_mid << 8) + (second_in_day_hi << 16),
                              pressure=(pressure_lo + (pressure_hi << 8)) * 0.02 * 1.33321995,  # преобразуем мм.рт.ст в мБар
                              temperature=temperature_sign * temperature_raw * 0.1,
                              humidity=(((temperature_n_humidity & 0x0F) << 8) + humidity_lo) * 0.1)

    @property
    def should_process(self) -> bool:
        """Геттер для флага необходимости брать в обработку по результатам прореживания"""
        return self._should_process


def create_packet(header: bytes, content: bytes, receive_time: datetime.datetime) -> BaseBisPacket:
    """Фабрика пакетов БИС

    Принимает байтовый заголовок и тело пакета. Возвращает инстанс подходящего
    по packet_id наследника `BaseBisPacket`
    """
    (_, _, _, packet_id, _, _, _) = struct.unpack(BIS_HEADER_FORMAT, header)
    for cls in BaseBisPacket.__subclasses__():
        if cls.PACKET_ID == packet_id:
            return cls(header=header, content=content, receive_time=receive_time)

    return BaseBisPacket(header=header, content=content, receive_time=receive_time)


def current_time() -> (int, int):
    """Текущее время

    Функция возвращает кортеж (секунды, миллисекунды), прошедшие
    с 00:00 01.01.2000
    """
    curr_time = time.time() - EPOCH_J2000_SECONDS  # время в секундах с 01 января 2000 года
    return int(curr_time // 1), int((curr_time % 1) * 1000)
