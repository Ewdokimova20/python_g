import gzip
import json
import logging
from io import BytesIO

from twisted.web import resource

from scripts.process_registry import get_zmq_manager

logger = logging.getLogger('server')

GZIP_MIN_THRESHOLD = 256
"""Минимальный порог до которого применяется сжатие gzip, байт"""


class CustomResource(resource.Resource):

    def __init__(self):
        super().__init__()
        self.zmq_manager = get_zmq_manager()

    def render(self, request):
        method_name = 'render_' + request.method.decode().upper()
        if hasattr(self, method_name):
            try:
                handler = getattr(self, method_name)
                response = handler(request)

                # Проверка заголовка Accept-Encoding
                accept_encoding = request.getHeader('Accept-Encoding')
                if accept_encoding and 'gzip' in accept_encoding and len(response) > GZIP_MIN_THRESHOLD:
                    # Сжимаем данные с помощью gzip
                    buffer = BytesIO()
                    with gzip.GzipFile(fileobj=buffer, mode='wb') as f:
                        f.write(response)
                    compressed_data = buffer.getvalue()

                    # Устанавливаем заголовки
                    request.setHeader('Content-Encoding', 'gzip')
                    request.setHeader('Content-Type', b'application/json')
                    return compressed_data
                else:
                    request.setHeader('Content-Type', b'application/json')
                    return response

            except Exception as e:
                request.setResponseCode(500)
                logger.critical(f"Необрабатываемая ошибка в конечной точке {self.__class__.__name__}: ",
                                exc_info=(type(e), e, e.__traceback__))
                return json.dumps(f"Возникла ошибка  {str(type(e))}:  {str(e)}", ensure_ascii=False).encode('utf-8')
        else:
            request.setResponseCode(405)  # Метод не разрешен
            return b"Method Not Allowed"
