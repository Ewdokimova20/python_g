import json

from KNPServer.common.datetime_encoder import DateTimeEncoder
from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from utils.SI.si_embedding_verification.si_embedding_verification_for_client import si_embedding_verification_for_client


class SIEmbeddingVerificationResource(CustomResource):
    """Ресурс для получения результатов оперативного контроля закладки СИ"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        show_retranslation_forms_str = request.args.get(b'show_retranslation_forms', [b'false'])[0].decode('utf-8').lower()
        if show_retranslation_forms_str is not None:
            show_retranslation_forms = show_retranslation_forms_str == 'true'
        else:
            request.setResponseCode(400)
            return json.dumps({'message': f'Необходимо передать show_retranslation_forms'}, cls=DateTimeEncoder).encode('utf-8')

        try:
            result = si_embedding_verification_for_client.get_data(show_retranslation_forms)
        except Exception as err:
            request.setResponseCode(500)
            return json.dumps({'message': str(err)}, cls=DateTimeEncoder).encode('utf-8')
        else:
            return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')
