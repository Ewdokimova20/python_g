import json

from KNPServer.common.datetime_encoder import DateTimeEncoder
from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from utils.reception_control.measurement_reception.meas_reception_monitor import measurement_reception_monitor


class MeasReceptionControl(CustomResource):
    """Точка для получения состояния приема 1с измерений для всех НКА и БИС"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        bis_id = request.args.get(b'bis_id', [None])
        bis_id = bis_id[0] if bis_id else None

        # Если bis_id не передан, вызываем get_all_bis_data
        if bis_id is None:
            return json.dumps(measurement_reception_monitor.get_all_bis_data(), cls=DateTimeEncoder).encode('utf-8')

        try:
            bis_id = int(bis_id)
        except ValueError:
            request.setResponseCode(400)
            return json.dumps('bis_id должен быть числом').encode('utf-8')

        return measurement_reception_monitor.get_single_bis_data(bis_id).encode('utf-8')
