import json

from KNPServer.common.datetime_encoder import DateTimeEncoder
from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from utils.generalized_opmessage import generalized_opmessage


class GeneralizedOpmessage(CustomResource):
    """Статусы обобщенных оперативных сообщений"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = generalized_opmessage.get_all_messages()
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class GeneralizedOpmessageNotification(GeneralizedOpmessage):
    """Статус сигнализации для обобщенных оперативных сообщений"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = generalized_opmessage.define_notification_flags()
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class GeneralizedOpmessageSeparately(GeneralizedOpmessage):
    """Статус сигнализации для обобщенных оперативных сообщений"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = generalized_opmessage.get_all_messages_separately()
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


generalized_opmessage_resource = GeneralizedOpmessage()
generalized_opmessage_resource.putChild(b'notifications', GeneralizedOpmessageNotification())
generalized_opmessage_resource.putChild(b'separate_data', GeneralizedOpmessageSeparately())
