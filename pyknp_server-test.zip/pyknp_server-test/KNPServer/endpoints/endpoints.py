"""Реализация сервера КНП на twisted

Скрипт описания сервера КНП и его endpoint'ов.
"""
import configparser
import datetime
import json
import logging
import os
import pathlib
import time
import traceback
import urllib
from json import JSONEncoder

import jsonschema
import peewee
from jsonschema import validate
from peewee import *
from playhouse.shortcuts import model_to_dict
from twisted.internet import reactor
from twisted.web import server, resource

import data
import global_data.config_schema
import global_data.user_navsolution_parameters
import version
from KNPServer.common.datetime_encoder import DateTimeEncoder
from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from communication.types import ZMQCommand
from data import L1OFString, L1OFFrame, L2OFFrame, L2OFString, \
    L1SFString, L1SFFrame, LFImmediateInfo, Almanac, \
    L1OCString, L1OCFrame, L3OCFrame, L3OCString, L1SCString, L2SCString, L2KSIString, \
    Residual, KNPNavSolution, L1SCFrame, L2SCFrame, SummarizedFramesInfo
from db.cdb import KaInfo, SIFormTable
from db.db_connection import db
from global_data import appdata
from global_data.appdata import SignalTypes
from lbd_pg import get_ldb_connection_status
from models.op_message import OpMessage
from utils.CheckP4inFrame import find_frame_with_P4
from utils.EI_consistency.EI_consistency_in_SI import check_EI_with_neighbor_SI
from utils.PDOP.PDOPCalculator import CalculationStatus, CalcMode
from utils.PDOP.PDOPThread import PDOP_Thread, q0
from utils.SI.compare_si_to_di.online_comparison_to_si.get_online_comparison_results import \
    get_immediate_info_online_comparison, get_almanac_online_comparison, get_single_nka_almanac_online_comparison
from utils.SI.compare_si_to_di.types import TimeData
from utils.SI.main import SI_FORMS
from utils.SignalFlags import signal_flag_service
from utils.almanac.get_almanac_slot import get_almanac_slot, cache_almanac
from utils.caches import cache_bis
from utils.generalized_opmessage import generalized_opmessage
from utils.lib.exceptions import BadEIException, ParseDIStringError, CompareEIinDIError, CompareDItoSIError
from utils.lib.get_date_from_N4_and_N import get_almanac_time_by_datetime
from utils.nav_solution import nav_solutions_cache_for_client
from utils.reception_control.message_counters.general_message_counter import general_message_counters
from utils.residuals import residuals_cache_for_client
from utils.statuses.bis_connection import bis_connection_state
from utils.visibility.current_visibility import current_visibility_for_client
from utils.visibility.visibility_zone_calculator import CalculateResult, \
    calculate_result_labels, calc_visibility_zones_for_single_nka


def ttlcachedumper(obj):
    try:
        obj.expire()
        return obj._Cache__data
    except:
        return obj.__dict__


class PathEncoder(JSONEncoder):
    # Override the default method
    def default(self, obj):
        if isinstance(obj, (pathlib.WindowsPath, pathlib.PosixPath)):
            return str(obj)


class ConnectionStatus(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps('Connection OK, Signal flags: ' + signal_flag_service.get_status()).encode('utf-8')


class PacketQueue(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(appdata.queue_status, cls=DateTimeEncoder).encode('utf-8')


class Residuals(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        limit = 600
        result = []
        nka = None
        bis = None
        try:
            nka = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'nka'][0])
        except (ValueError, KeyError):
            pass
        try:
            bis = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'bis'][0])
        except (ValueError, KeyError):
            pass
        try:
            limit = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'limit'][0])
        except (ValueError, KeyError):
            pass
        try:
            limit_value = limit if limit > 0 else 30
            rows_limit = 2 * limit_value * (15 if not nka else 1) * (6 if not bis else 1)
            subq = (Residual
                    .select(Residual.id,
                            Residual.timestamp,
                            Residual.residual,
                            Residual.speed_residual,
                            Residual.bis_id,
                            Residual.nka_id,
                            Residual.signal_1,
                            Residual.signal_2,
                            Residual.nka_elevation,
                            Residual.nka_in_guaranteed_elevation,
                            Residual.status,
                            Residual.delta,
                            Residual.delta1,
                            Residual.delta2,
                            Residual.average)
                    .where(((nka is None) or (Residual.nka_id == nka)) &
                           ((bis is None) or (Residual.bis_id == bis)) &
                           (Residual.rejected_due_to_deviation == False))
                    .order_by(Residual.id.desc())
                    .limit(rows_limit))
            time_ago = datetime.datetime.now() - datetime.timedelta(seconds=limit)
            residuals = (Residual
                         .select(subq.c.id,
                                 subq.c.timestamp,
                                 subq.c.residual,
                                 subq.c.speed_residual,
                                 subq.c.bis_id,
                                 subq.c.nka_id,
                                 subq.c.signal_1,
                                 subq.c.signal_2,
                                 subq.c.nka_elevation,
                                 subq.c.nka_in_guaranteed_elevation,
                                 subq.c.status,
                                 subq.c.delta,
                                 subq.c.delta1,
                                 subq.c.delta2,
                                 subq.c.average)
                         .from_(subq)
                         .where(subq.c.timestamp > time_ago))
            result = [r.as_small_dict() for r in residuals]
        except Residual.DoesNotExist:
            pass
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class ResidualsRejected(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        result = []
        nka = None
        bis = None
        signal = None
        try:
            nka = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'nka'][0])
        except (ValueError, KeyError):
            pass
        try:
            bis = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'bis'][0])
        except (ValueError, KeyError):
            pass
        try:
            signal = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'signal'][0])
        except (ValueError, KeyError):
            pass
        if nka is None and bis is None and signal is None:
            request.setResponseCode(400)
            return json.dumps("Не задано, по какому параметру (БИС, НКА, тип сигнала) отобразить невязки",
                              ensure_ascii=False).encode('utf-8')
        start = None
        end = None
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
            end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps("Не задан интервал запроса", ensure_ascii=False).encode('utf-8')

        try:
            subq = (Residual
                    .select(Residual.id,
                            Residual.timestamp,
                            Residual.residual,
                            Residual.speed_residual,
                            Residual.bis_id,
                            Residual.nka_id,
                            Residual.signal_1,
                            Residual.signal_2,
                            Residual.nka_elevation,
                            Residual.nka_in_guaranteed_elevation,
                            Residual.status,
                            Residual.delta,
                            Residual.delta1,
                            Residual.delta2,
                            Residual.average)
                    .where(((nka is None) or (Residual.nka_id == nka)) &
                           ((bis is None) or (Residual.bis_id == bis)) &
                           ((signal is None) or (Residual.signal_1 == signal)) &
                           (Residual.timestamp >= start) &
                           (Residual.timestamp <= end) &
                           (Residual.rejected_due_to_deviation == True)
                           )
                    .order_by(Residual.id.desc()))
            residuals = (Residual
                         .select(subq.c.id,
                                 subq.c.timestamp,
                                 subq.c.residual,
                                 subq.c.speed_residual,
                                 subq.c.bis_id,
                                 subq.c.nka_id,
                                 subq.c.signal_1,
                                 subq.c.signal_2,
                                 subq.c.nka_elevation,
                                 subq.c.nka_in_guaranteed_elevation,
                                 subq.c.status,
                                 subq.c.delta,
                                 subq.c.delta1,
                                 subq.c.delta2,
                                 subq.c.average)
                         .from_(subq))
            if len(residuals) == 0:
                raise Residual.DoesNotExist
            result = [r.as_small_dict() for r in residuals]
        except Residual.DoesNotExist:
            request.setResponseCode(404)
            return json.dumps("Отсутствуют отбракованные невязки на интервале", ensure_ascii=False).encode('utf-8')
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class ResidualGroups(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        result = {}
        is_data_present = False

        def get_first_signal_type_from_residual_pair(signal):
            """
            Получить тип первого сигнала соответствующей пары сигналов, по которым посчитана невязка
            (даже если первого сигнала нет, и невязка посчитана только по второму сигналу)
            Нужно для того, чтобы на интерфейсе отобразилось корректное имя пары (СТ, ВТ и т.д.)
            """
            residuals_pair_key_map = {
                SignalTypes.L2OF: SignalTypes.L1OF,
                SignalTypes.L2SF: SignalTypes.L1SF,
                SignalTypes.L2OCp: SignalTypes.L1OCp,
                SignalTypes.L2KSI: SignalTypes.L1OCd,
                SignalTypes.L2SCp: SignalTypes.L1SCp,
                SignalTypes.L2SCd: SignalTypes.L1SCd,
            }
            return residuals_pair_key_map.get(signal, signal)

        result, is_data_present = residuals_cache_for_client.get_latest_items()
        if not is_data_present:
            request.setResponseCode(404)
            return json.dumps("Отсутствуют данные в кэше невязок", ensure_ascii=False).encode('utf-8')
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class ArchiveResiduals(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = {}
        bis = None
        start = None
        end = None
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            bis = int(args[b'bis'][0])
            start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
            end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
        except (ValueError, KeyError):
            pass

        if bis and start and end:
            try:
                archive_residuals = Residual \
                    .select(Residual.id,
                            Residual.timestamp,
                            Residual.residual,
                            Residual.speed_residual,
                            Residual.nka_id,
                            Residual.bis_id,
                            Residual.delta,
                            Residual.delta1,
                            Residual.delta2,
                            Residual.average) \
                    .where((Residual.bis_id == bis) &
                           (Residual.timestamp >= start) &
                           (Residual.timestamp <= end))
                for n in appdata.NKA:
                    try:
                        archive_residuals_by_nka = (Residual
                                                    .select(archive_residuals.c.id,
                                                            archive_residuals.c.timestamp,
                                                            archive_residuals.c.residual,
                                                            archive_residuals.c.speed_residual,
                                                            archive_residuals.c.nka_id,
                                                            archive_residuals.c.bis_id,
                                                            archive_residuals.c.delta,
                                                            archive_residuals.c.delta1,
                                                            archive_residuals.c.delta2,
                                                            )
                                                    .from_(archive_residuals)
                                                    .where(archive_residuals.c.nka_id == n))
                        if archive_residuals_by_nka.exists():
                            result[n] = [r for r in archive_residuals_by_nka.dicts()]
                    except Residual.DoesNotExist:
                        pass
                try:
                    archive_avg_residuals = (Residual
                                             .select(archive_residuals.c.id,
                                                     archive_residuals.c.timestamp,
                                                     archive_residuals.c.average,
                                                     archive_residuals.c.bis_id)
                                             .from_(archive_residuals)
                                             .group_by(archive_residuals.c.timestamp, archive_residuals.c.id,
                                                       archive_residuals.c.average, archive_residuals.c.bis_id))
                    result['average'] = [r for r in archive_avg_residuals.dicts()]
                except Residual.DoesNotExist:
                    pass
            except Residual.DoesNotExist:
                pass
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class SignalFlags(CustomResource):
    """Получение состава сигнальных признаков, оставшихся в аккумуляторе после просмотров/подтверждений клиентом и
    не блокированные посредством действующих фильтров"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        signal_flags = []
        nka = None
        try:
            nka = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'nka'][0])
        except (ValueError, KeyError):
            signal_flags = signal_flag_service.as_dict_for_client()
        else:
            all_signal_flags = signal_flag_service.as_dict_for_client()
            for one_signal_flags in all_signal_flags:
                if one_signal_flags['nka'] == nka:
                    signal_flags.append(one_signal_flags)
        return json.dumps(signal_flags, cls=DateTimeEncoder).encode('utf-8')


class MessageGroundCall(SignalFlags):
    """Список оперативных сообщений: Вызов НКУ."""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = signal_flag_service.ground_control_call_lists()
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class SignalFlagsDelete(CustomResource):
    """Подтверждает ознакомление клиента/оператора с набором сигнальных признаков.
    Поддерживаются два сценария подтверждения:
    0. если тело запроса пустое или указан пустой состав сигнальных признаков, то все сигнальные признаки считаются
       просмотренными и все удаляются из аккумулятора
    1. если задан массив combinations, то просмотренными считаются те сигнальные признаки, идентификаторы комбинаций
       которых поданы в запросе. Только они и будут удалены.
    """

    SCHEMA_DELETE_LIST = {
        "type": "object",
        "properties": {
            "combinations": {"type": "array", "items": {"type": "number"}, "minItems": 0}
        },
        "required": []
    }

    def render_PATCH(self, request):
        request = set_headers(request, method="PATCH")
        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=self.SCHEMA_DELETE_LIST)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        except json.decoder.JSONDecodeError as e:
            request.setResponseCode(400)
            return e.msg.encode('utf-8')

        # Применяем фильтрацию если идентификатор явно определен
        try:
            result = signal_flag_service.delete_combinations(
                content['combinations'] if 'combinations' in content else [])
            generalized_opmessage.define_generalized_opmessage()
            return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')
        except KeyError as e:
            request.setResponseCode(404)
            return json.dumps(str(e)).encode('utf-8')

    def render_OPTIONS(self, request):
        request = set_headers(request, method='PATCH, OPTIONS')
        return b""


class SignalFlagsApprove(CustomResource):
    """Отключает сигнализацию для события снимая в аккумуляторе признак того, что оно новое
    Поддерживаются два сценария подтверждения:
    0. если тело запроса пустое или указан пустой состав сигнальных признаков, то все сигнальные признаки считаются
       не значимыми и для всех отключается сигнализация
    1. если задан массив combinations, то не значимыми считаются те сигнальные признаки, идентификаторы комбинаций
       которых поданы в запросе. Только они и будут помечены как не новые.
    """

    SCHEMA_APPROVE_LIST = {
        "type": "object",
        "properties": {
            "combinations": {"type": "array", "items": {"type": "number"}, "minItems": 0}
        },
        "required": []
    }

    def render_PATCH(self, request):
        request = set_headers(request, method="PATCH")
        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=self.SCHEMA_APPROVE_LIST)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        except json.decoder.JSONDecodeError as e:
            request.setResponseCode(400)
            return e.msg.encode('utf-8')

        # Применяем фильтрацию если идентификатро явно определен
        try:
            result = signal_flag_service.approve_combinations(
                content['combinations'] if 'combinations' in content else [])
            if content['combinations']:
                generalized_opmessage.update_generalized_opmessage(combinations=content['combinations'])
            else:
                generalized_opmessage.define_generalized_opmessage()
            return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')
        except KeyError as e:
            request.setResponseCode(404)
            return json.dumps(str(e), ensure_ascii=False).encode('utf-8')

    def render_OPTIONS(self, request):
        request = set_headers(request, method='PATCH, OPTIONS')
        return b""


class SignalFlagsFilterByCategory(CustomResource):
    """Общий предок всех классов задания конкретных фильтров"""

    SCHEMA_FILTER_LIST = {
        "type": "object",
        "properties": {
            "duration": {"type": "integer"},
            "items": {"type": "array", "items": {"type": "number"}, "minItems": 1}
        },
        "required": ["items"]
    }

    nka_list = []
    combination_list = []

    def set_target_list(self, content):
        pass

    def render_POST(self, request):
        request = set_headers(request, method='POST, OPTIONS, DELETE')

        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=self.SCHEMA_FILTER_LIST)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        except json.decoder.JSONDecodeError as e:
            request.setResponseCode(400)
            return e.msg.encode('utf-8')

        self.nka_list = []
        self.combination_list = []
        self.set_target_list(content)  # определяет конкретное содержимое конкретного списка
        signal_flag_service.client_service.set_filter(filtered_nka=self.nka_list,
                                                      filtered_combinations=self.combination_list)
        if self.nka_list or self.combination_list:
            generalized_opmessage.update_generalized_opmessage(nka_list=self.nka_list,
                                                               combinations=self.combination_list)
        request.setResponseCode(201)
        return b""

    def render_DELETE(self, request):
        request = set_headers(request, method='POST, OPTIONS, DELETE')
        content = {}

        try:
            items = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'items'][0].decode('utf-8')
            content['items'] = json.loads(items)
        except KeyError as err:
            request.setResponseCode(400)
            return json.dumps(str(err), ensure_ascii=False).encode('utf-8')

        self.nka_list = []
        self.combination_list = []
        self.set_target_list(content)  # определяет конкретное содержимое конкретного списка
        signal_flag_service.client_service.kill_permanent_filter(
            self.nka_list,
            self.combination_list)
        if self.nka_list or self.combination_list:
            generalized_opmessage.define_generalized_opmessage()
        request.setResponseCode(204)
        return b""

    def render_OPTIONS(self, request):
        request = set_headers(request, method='POST, DELETE, OPTIONS')
        return b""


class SignalFlagsFilterByNka(SignalFlagsFilterByCategory):
    def set_target_list(self, content):
        self.nka_list = content['items']


class SignalFlagsFilterByCombination(SignalFlagsFilterByCategory):
    def set_target_list(self, content):
        self.combination_list = content['items']


class SignalFlagsFilter(CustomResource):
    """Позволяет просматривать и в дочерних уздах задавать фильтры, скрывающие на время отображение заданных
    сигнальных признаков"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(signal_flag_service.client_service.filters_as_dict(), cls=DateTimeEncoder).encode('utf-8')


class CacheStatus(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request, content_type='text/html')
        return str(data.next_state.cache_info()).encode('utf-8')


class Config(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(global_data.config_schema.config, cls=PathEncoder).encode('utf-8')


class OpMessages(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        messages = OpMessage.select()
        result = [model_to_dict(message) for message in messages]
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class GroundCall(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        calls = LFImmediateInfo.select().where(LFImmediateInfo.ground_call > 0)
        result = [model_to_dict(call) for call in calls]
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class DigitalInfoNotInTime(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        dis = LFImmediateInfo.select().where(LFImmediateInfo.is_in_time == 0)
        result = [model_to_dict(di) for di in dis]
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class TKNotSequential(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        difference = LFImmediateInfo.frame_time - fn.LAG(LFImmediateInfo.frame_time, 1).over(
            partition_by=[LFImmediateInfo.nka_id])
        subq = (LFImmediateInfo.select(
            LFImmediateInfo.nka_id,
            LFImmediateInfo.t_k,
            difference.alias('diff')))
        query = (LFImmediateInfo
                 .select(subq.c.diff, subq.c.nka_id, subq.c.t_k)
                 .from_(subq)
                 .where(subq.c.diff != 30))
        result = [{"nka_sys_number": row.nka_id, "t_k": row.t_k, "diff": row.diff} for row in query]
        return json.dumps(result).encode('utf-8')


class NavSoltion(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        limit = 30
        result = []
        bis = None
        try:
            limit = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'limit'][0])
        except (ValueError, KeyError):
            pass
        try:
            bis = int(urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)[b'bis'][0])
        except (ValueError, KeyError):
            pass
        try:
            limit_value = limit if limit > 0 else 30
            row_limit = 2 * limit_value * (6 if bis else 1)
            subq = (KNPNavSolution
                    .select(KNPNavSolution.timestamp,
                            KNPNavSolution.id,
                            KNPNavSolution.bis_id,
                            KNPNavSolution.longitude,
                            KNPNavSolution.latitude,
                            KNPNavSolution.height,
                            KNPNavSolution.E,
                            KNPNavSolution.N,
                            KNPNavSolution.dt,
                            KNPNavSolution.U,
                            KNPNavSolution.distance,
                            KNPNavSolution.GDOP,
                            KNPNavSolution.nka_list)
                    .where(((bis is None) or (KNPNavSolution.bis_id == bis)))
                    .order_by(KNPNavSolution.id.desc())
                    .limit(row_limit))
            time_ago = datetime.datetime.now() - datetime.timedelta(seconds=limit)
            solutions = (KNPNavSolution
                         .select(subq.c.timestamp,
                                 subq.c.id,
                                 subq.c.bis_id,
                                 subq.c.longitude,
                                 subq.c.latitude,
                                 subq.c.height,
                                 subq.c.E,
                                 subq.c.N,
                                 subq.c.dt,
                                 subq.c.U,
                                 subq.c.distance,
                                 subq.c.GDOP,
                                 subq.c.nka_list)
                         .from_(subq)
                         .where(subq.c.timestamp > time_ago))
            result = [s.as_dict() for s in solutions]
        except KNPNavSolution.DoesNotExist:
            pass
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class NvzGroups(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        result, is_data_present = nav_solutions_cache_for_client.get_data()

        if not is_data_present:
            request.setResponseCode(404)
            return json.dumps("Отсутствуют данные в кэше РНЗ", ensure_ascii=False).encode('utf-8')
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class ArchiveNavSolution(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = []
        bis = None
        start = None
        end = None
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            bis = int(args[b'bis'][0])
            start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
            end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
        except (ValueError, KeyError):
            pass

        if bis and start and end:
            try:
                archive_solutions = KNPNavSolution \
                    .select(KNPNavSolution.id,
                            KNPNavSolution.timestamp,
                            KNPNavSolution.E,
                            KNPNavSolution.N,
                            KNPNavSolution.U,
                            KNPNavSolution.dt) \
                    .where((KNPNavSolution.bis_id == bis) &
                           (KNPNavSolution.timestamp >= start) &
                           (KNPNavSolution.timestamp <= end))
            except KNPNavSolution.DoesNotExist:
                request.setResponseCode(404)
                return json.dumps("Не найдены архивные данные за выбранный промежуток времени",
                                  ensure_ascii=False).encode('utf-8')
            else:
                if len(archive_solutions) > 0:
                    result = [s for s in archive_solutions.dicts()]
                else:
                    request.setResponseCode(404)
                    return json.dumps("Не найдены архивные данные за выбранный промежуток времени",
                                      ensure_ascii=False).encode('utf-8')
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class NavSolutionAnalyse(CustomResource):
    """Ставит серверу задачу выполнения анализа решения НВЗ с целью выявления НКА, вносящего наибольшую погрешность
    При GET-запросе возвращает параметры расчета и результаты анализа через REQ/REP канал
    При POST-запросе задает параметры задания через REQ/REP канал, выполнение начнется при следующем решении НВЗ.
    Пример запроса: http://localhost:8080/api/v1/nav_solution_analyse
    """

    REQUEST_SCHEMA_POST = {
        "type": "object",
        "properties": {
            "nka_for_solution": {"type": "array", "items": {"type": "number"}, "minItems": 0},
            "signal_type": {"type": "integer"},
            "bis": {"type": "integer"},
            "worst_nka_request": {"type": "boolean"},
            "use_signals_with_ln": {"type": "boolean"},
        },
        "required": ["nka_for_solution", "signal_type", "bis"],
        "additionalProperties": False
    }

    def render_GET(self, request):
        """Возвращает параметры расчета и результаты анализа через REQ/REP канал"""
        request = set_headers(request)

        try:
            # Получаем bis_id из параметров запроса или используем первый доступный
            bis_id = request.args.get(b'bis', [None])[0]
            if bis_id:
                bis_id = int(bis_id.decode('utf-8'))
            else:
                request.setResponseCode(400)
                return json.dumps('Необходимо указать номер БИС', ensure_ascii=False).encode('utf-8')

            # Отправляем команду на процесс, обрабатывающий данный БИС, для получения текущих параметров расчета
            response = self.zmq_manager.send_command_to_bis(bis_id=bis_id, command=ZMQCommand.GET_USR_NAV_SOLUTION_PARAMS,
                                                            data={'bis_id': bis_id})
            current_user_navsol_params = response.get('result')

            if response:
                return json.dumps(current_user_navsol_params).encode('utf-8')
            else:
                error_msg = response.get('error', 'Неизвестная ошибка') if response else 'Таймаут соединения'
                request.setResponseCode(500)
                return json.dumps({'message': f'Ошибка получения параметров: {error_msg}'}, ensure_ascii=False).encode('utf-8')

        except ValueError as e:
            request.setResponseCode(400)
            return json.dumps({'message': f'Некорректный bis_id: {str(e)}'}, ensure_ascii=False).encode('utf-8')
        except Exception as e:
            request.setResponseCode(500)
            return json.dumps({'message': f'Внутренняя ошибка сервера: {str(e)}'}, ensure_ascii=False).encode('utf-8')

    def render_POST(self, request):
        """Устанавливает параметры запроса расчета НВЗ с пользовательскми параметрами через REQ/REP канал"""
        request = set_headers(request, method="POST")

        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=self.REQUEST_SCHEMA_POST)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        except json.decoder.JSONDecodeError as e:
            request.setResponseCode(400)
            return e.msg.encode('utf-8')

        # Задаем параметры анализа и сбрасываем результаты прошлого анализа
        try:
            bis_id = content['bis']

            # Подготавливаем параметры для отправки
            user_navsol_params = {
                'nka_in_solution': content['nka_for_solution'],
                'signal_for_user_solution': content['signal_type'],
                'bis_id_for_user_solution': content['bis'],
                'search_worst_nka': content.get('worst_nka_request', 0),
                'use_signals_with_ln': content.get('use_signals_with_ln', 0),
            }

            # Отправляем команду установки параметров
            response = self.zmq_manager.send_command_to_bis(bis_id=bis_id, command=ZMQCommand.SET_USR_NAV_SOLUTION_PARAMS,
                                                            data={'bis_id': bis_id, 'params': user_navsol_params})
            if response:
                return json.dumps("Ok").encode('utf-8')
            else:
                error_msg = response.get('error', 'Неизвестная ошибка') if response else 'Таймаут соединения'
                request.setResponseCode(500)
                return json.dumps({'message': f'Ошибка установки параметров: {error_msg}'}, ensure_ascii=False).encode('utf-8')

        except Exception as e:
            request.setResponseCode(500)
            return json.dumps({'message': f'Внутренняя ошибка сервера: {str(e)}'}, ensure_ascii=False).encode('utf-8')

    def render_OPTIONS(self, request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""


class ReceiverStatus(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        import main
        if main.factory.connectedProtocol:
            result = {'connected': main.factory.connectedProtocol.connected,
                      'data': main.factory.connectedProtocol.has_data}
        else:
            result = {'connected': False, 'data': False}
        return json.dumps(result).encode('utf-8')


class BisControlConfig(CustomResource):
    def __init__(self):
        super(BisControlConfig, self).__init__()
        self.putChild(b'logging_levels', LoggingLevels())

    @staticmethod
    def validate_config_var(var_name, value):
        value = int(value)
        min_value = global_data.config_schema.bis_control_min_values.get(var_name, None)
        max_value = global_data.config_schema.bis_control_max_values.get(var_name, None)
        if min_value and value < min_value:
            raise ValueError
        if max_value and value > max_value:
            raise ValueError

    @staticmethod
    def update_config(data: dict):
        config = configparser.ConfigParser()
        with open(global_data.config_schema.config['configFile'], 'r') as config_file:
            config.read_file(config_file)
        for (key, value) in data.items():
            config.set('bis_control', key, str(int(value)))
            global_data.config_schema.config['bis_control'][key] = int(value)
        with open(global_data.config_schema.config['configFile'], 'w') as config_file:
            config.write(config_file)

    def render_GET(self, request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return json.dumps(global_data.config_schema.config['bis_control']).encode('utf-8')

    def render_POST(self, request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        try:
            data: dict = json.loads(request.content.read())
        except json.decoder.JSONDecodeError:
            return json.dumps({'status': appdata.ServerStatusCode.DECODE_ERROR}).encode('utf-8')
        try:
            for (k, v) in data.items():
                if k not in global_data.config_schema.config['bis_control']:
                    return json.dumps({'status': appdata.ServerStatusCode.EXCESSIVE_DATA}).encode('utf-8')
                try:
                    BisControlConfig.validate_config_var(k, v)
                except ValueError:
                    return json.dumps({'status': appdata.ServerStatusCode.BAD_DATA}).encode('utf-8')
        except AttributeError:
            return json.dumps({'status': appdata.ServerStatusCode.DATA_FORMAT_ERROR}).encode('utf-8')
        BisControlConfig.update_config(data)
        return json.dumps({'status': appdata.ServerStatusCode.OK}).encode('utf-8')

    def render_OPTIONS(self, request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""


def check_required_args(request_args, required_args):
    for arg in required_args:
        if arg not in request_args:
            raise KeyError(arg)


class DIItemResource(CustomResource):
    """Точка для выдачи единицы ЦИ по id"""

    def __init__(self, di_class=None):
        super().__init__()
        self.di_class = di_class

    def get_di_item(self, di_item_id):
        return self.di_class.get(self.di_class.id == di_item_id)

    def render_GET(self, request):
        request = set_headers(request)
        result = {}
        status_code = 200

        try:
            di_item_id = self.di_item_id
            di_item = self.get_di_item(di_item_id)
            if self.di_class != L2KSIString:
                result = di_item.as_dict()
            else:  # особая обработка для L2КСИ т.к. штатный метод as_dict строки возвращает не полный состав данных
                result = {'meta': {**di_item.meta_as_dict(), 'string_errors': {'0': di_item.error_in_string}},
                          'content': [di_item.as_dict()]}
            if hasattr(self.di_class, 'as_long_dict'):
                result['params'] = di_item.as_long_dict()
        except (ValueError, KeyError):
            result = "Ошибка в идентификаторе ЦИ"
            status_code = 400
        except ParseDIStringError as e:
            result = {'message': e.message, 'string_num': e.string_num, 'content': e.content}
            status_code = 401
        except DoesNotExist:
            result = "ЦИ не найдена"
            status_code = 404

        request.setResponseCode(status_code)
        return json.dumps(result, cls=DateTimeEncoder, ensure_ascii=False).encode('utf-8')


class BaseDIListResource(CustomResource):
    """Базовый класс точек для выдачи списка ЦИ"""

    di_class = None
    binary_di_class = None

    @staticmethod
    def parse_args(request):
        args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
        check_required_args(args, [b'nka', b'bis', b'start', b'end', b'is_db_timestamp'])
        sys_num = int(args[b'nka'][0])
        bis_id = int(args[b'bis'][0])
        start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
        end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
        is_db_timestamp_param = str(args[b'is_db_timestamp'][0], 'utf-8')
        is_db_timestamp = is_db_timestamp_param.lower() in ['true', '1', 'yes']
        return sys_num, bis_id, start, end, is_db_timestamp

    def get_di_list(self, sys_num: int, bis_id: int, start: datetime, end: datetime, is_db_timestamp: bool):
        timestamp_type = self.di_class.db_timestamp if is_db_timestamp else self.di_class.timestamp
        if bis_id != None:
            return self.di_class.select().where((self.di_class.nka_id == sys_num) &
                                                (self.di_class.bis_id == bis_id) &
                                                (timestamp_type > start) & (timestamp_type < end))

        else:
            frames = (self.di_class.select(self.di_class, SummarizedFramesInfo.sources)
                      .join(SummarizedFramesInfo, on=((self.di_class.id == SummarizedFramesInfo.frame_id) &
                                                      (self.di_class.signal_type == SummarizedFramesInfo.signal_type)),
                            join_type=JOIN.LEFT_OUTER)
                      .where((self.di_class.nka_id == sys_num) &
                             (self.di_class.bis_id == bis_id) &
                             (timestamp_type > start) & (timestamp_type < end)))
            return frames

    def render_GET(self, request):
        """Возвращает перечень кадров и их метаданных, доступных для запроса"""
        request = set_headers(request)
        result = []
        status_code = 200

        try:
            sys_num, bis_id, start, end, is_db_timestamp = self.parse_args(request)
            if bis_id == 9999:  # да, вот так тривиально мы помечаем обобщенку
                bis_id = None
            try:
                di_list = self.get_di_list(sys_num, bis_id, start, end, is_db_timestamp)
            except Exception as e:
                result = "Возникла ошибка при выдаче списка ЦИ"
                status_code = 500
                logging.warning(f"Ошибка при выдаче списка ЦИ: {str(e)}")
                logging.warning(traceback.format_exc())
            else:
                if not di_list:
                    result = "Не найдено записей по указанным параметрам"
                    status_code = 404
                else:
                    result = []
                    for di in di_list:
                        if hasattr(di, 'meta_as_dict'):
                            meta = di.meta_as_dict()
                            if di.bis_id == None and hasattr(di, 'summarizedframesinfo'):
                                meta['sources'] = di.summarizedframesinfo.sources
                            result.append(meta)

        except (ValueError, KeyError):
            result = "Ошибка параметров запроса списка ЦИ"
            status_code = 400

        request.setResponseCode(status_code)
        return json.dumps(result, cls=DateTimeEncoder, ensure_ascii=False).encode('utf-8')

    def getChildWithDefault(self, path, request):
        """Возвращает вложенный объект ресурса по указанному пути"""

        if path.isdigit():  # клиент указал идентификатор конкретного (псевдо)кадра ЦИ
            di_item_id = int(path)
            di_item_resource = DIItemResource(di_class=self.di_class)
            di_item_resource.di_item_id = di_item_id
            return di_item_resource
        elif path == b'binary' and self.binary_di_class:  # запрос ЦИ в бинарном виде
            return BinaryDIInfo(di_class=self.binary_di_class)
        else:
            return super().getChildWithDefault(path, request)


class BinaryDIInfo(BaseDIListResource):
    """Базовый класс точек для выдачи бинарной ЦИ"""

    def __init__(self, di_class=None):
        super().__init__()
        self.di_class = di_class

    def render_GET(self, request):
        request = set_headers(request)
        result = []
        status_code = 200

        try:
            di_list = self.get_di_list(*self.parse_args(request))
            if not di_list:
                result = "Не найдено записей по указанным параметрам"
                status_code = 404
            else:
                result = {di.id: di.as_binary_string() for di in di_list}
        except (ValueError, KeyError):
            result = "Ошибка параметров запроса списка ЦИ"
            status_code = 400

        request.setResponseCode(status_code)
        return json.dumps(result, ensure_ascii=False, cls=DateTimeEncoder).encode('utf-8')


class L1OFDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L1OF"""

    di_class = L1OFFrame
    binary_di_class = L1OFString


class L2OFDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L2OF"""

    di_class = L2OFFrame
    binary_di_class = L2OFString


class L1SFDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L1SF"""

    di_class = L1SFFrame
    binary_di_class = L1SFString


class L1OCDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L1OC"""

    di_class = L1OCFrame
    binary_di_class = L1OCString


class L3OCDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L3OC"""

    di_class = L3OCFrame
    binary_di_class = L3OCString


class L1SCDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L1SC"""

    di_class = L1SCFrame
    binary_di_class = L1SCString


class L2SCDiList(BaseDIListResource):
    """Точка для выдачи списка кадров L2SC"""

    di_class = L2SCFrame
    binary_di_class = L2SCString


class L2KSIDiList(BaseDIListResource):
    """Точка для выдачи списка ЦИ L2КСИ"""

    di_class = L2KSIString
    binary_di_class = L2KSIString


class Bis_Info(CustomResource):
    @staticmethod
    def render_GET(request):
        set_headers(request)
        bises = cache_bis.get_bis_list()
        result = [{'bis_id': bis.id, 'bis_number': bis.bis_number, 'station_id': bis.station_id} for bis in bises]
        return json.dumps(result).encode('utf-8')


class ComparisonDISI(CustomResource):
    """Точка для отдачи результатов сравнения ЦИ из кадра и СИ"""

    signal_db_map = {
        'L1OF': L1OFFrame,
        'L2OF': L2OFFrame,
        'L1OC': L1OCFrame,
        'L3OC': L3OCFrame,
        'L1SC': L1SCFrame,
        'L2SC': L2SCFrame,
        'L1SF': L1SFFrame,
    }

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = {}
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            frame_id = int(args[b'id'][0])
            signal_type = args[b'signal_type'][0].decode("utf-8")
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps('Ошибка входных параметров', ensure_ascii=False).encode('utf-8')
        if frame_id and signal_type:
            try:
                frame = ComparisonDISI.signal_db_map[signal_type].get_by_id(frame_id)
                result = frame.compare_to_SI()
            except CompareDItoSIError as e:
                request.setResponseCode(401)
                return json.dumps(str(e), ensure_ascii=False).encode('utf-8')
            except DoesNotExist:
                request.setResponseCode(404)
                return json.dumps("Не найдена необходимая ЦИ или СИ", ensure_ascii=False).encode('utf-8')
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class PDOP_Start(CustomResource):
    REQUEST_SCHEMA = {
        "type": "object",
        "properties": {
            "nka_list": {"type": "array", "items": {"type": "number"}, "minItems": 18},
            "zone_type": {"type": "integer"},
            "calc_mode": {"type": "integer"},
            "timestamp": {"type": "string", "format": "date-time"},

            "ln_cn_emission_intervals": {
                "type": "object",
                "patternProperties": {
                    "^[0-9]+$": {
                        "type": "array",
                        "items": {
                            "type": "array",
                            "items": {
                                "type": "string",
                                "format": "date-time"
                            }
                        }
                    }
                }
            }

        },
        "required": ["zone_type", "timestamp"]
    }

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='POST, OPTIONS')
        try:
            data: dict = json.loads(request.content.read())
            zone_type = data['zone_type']  # флаг, проводить расчет для РФ или мира (0 -  РФ , 1  - глобально)
            timestamp = data['timestamp']
            nka_list = data['nka_list']
            calc_mode = data[
                'calc_mode']  # eсли(mode = 1), то шаг сетки по долготе всегда 1 градус, если нет (mode = 0) - 1/cos(широта)
            ln_cn_emission_intervals = data['ln_cn_emission_intervals']
            jsonschema.validate(
                {'nka_list': nka_list, 'timestamp': timestamp, 'zone_type': zone_type, 'calc_mode': calc_mode,
                 'ln_cn_emission_intervals': ln_cn_emission_intervals},
                PDOP_Start.REQUEST_SCHEMA)
        except (KeyError, ValueError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')
        except (jsonschema.exceptions.ValidationError) as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        try:
            time = datetime.datetime.fromisoformat(timestamp)
            pdop_thread_status = PDOP_Thread.getstatus()
            if pdop_thread_status == CalculationStatus.CALCULATING:  # уже идет расчет.
                return json.dumps({'status': CalculationStatus.CALCULATING}).encode('utf-8')

            PDOP_Thread.PDOPcalc.almanac.almdict = {}
            satellites_with_absent_almanac = PDOP_Thread.PDOPcalc.verify_ability_of_calculation2(nka_list, time.day,
                                                                                                 time.month, time.year,
                                                                                                 True, 99)  #
            if len(satellites_with_absent_almanac) == 0:
                PDOP_Thread.createthread(
                    [nka_list, zone_type, time.day, time.month, time.year, q0, calc_mode, ln_cn_emission_intervals])
                return json.dumps({'status': pdop_thread_status}).encode('utf-8')
            else:
                request.setResponseCode(404)
                return json.dumps(
                    f'Возникла ошибка при запуске расчета: нет альманаха на следующие КА: {", ".join(str(x) for x in satellites_with_absent_almanac)}',
                    ensure_ascii=False).encode('utf-8')
        except Exception as e:
            logging.exception(e)
            return json.dumps(f'Возникла ошибка при запуске расчета: {str(e)}', ensure_ascii=False).encode('utf-8')

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='POST, OPTIONS')
        return b""


class PDOP_Status(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            status = PDOP_Thread.getstatus()
            percent = PDOP_Thread.getstatepercentage()
            result = PDOP_Thread.getresult()
            error = result.get('error', None)
            if error is not None:
                request.setResponseCode(400)
                return json.dumps(error).encode('utf-8')

            query = {}
            zone = PDOP_Thread.zone  # 0 - РФ, 1 - глобальн

            if status != CalculationStatus.NOT_STARTED:
                timestamp = PDOP_Thread.PDOPcalc.datestamp if PDOP_Thread.PDOPcalc.datestamp else None
                nka_mask = PDOP_Thread.PDOPcalc.NKA_mask
                query = {'nka_list': nka_mask, 'zone': zone, 'date': timestamp}

            if hasattr(PDOP_Thread, 'mode'):
                mode = PDOP_Thread.mode
                if mode == 0:
                    if query:
                        query['mode'] = CalcMode.PDOP
                    pdop0 = result.get('PDOP0', None)
                    pdop = result.get('PDOP', None)
                    if pdop is None and pdop0 is None:
                        output_result = {}
                    else:
                        output_result = {'pdop0': pdop0, 'pdop': pdop}
                    output = {
                        'status': status,
                        'progress': {'step': '1/1', 'percent': round(percent)},
                        'result ': output_result,
                        'query': query
                    }
                if mode == 1:
                    phase = PDOP_Thread.PDOPcalc.calc_phase
                    if query:
                        query['mode'] = CalcMode.AVAILABILITY
                    avail = result.get('avail', None)
                    nav_break = result.get('nav_break', None)
                    if avail is None and nav_break is None:
                        output_result = {}
                    else:
                        output_result = {'avail': avail, 'nav_break': nav_break}
                    output = {
                        'status': status,
                        'progress': {'step': str(phase) + '/2', 'percent': round(percent, 1)},
                        'result': output_result,
                        'result1': result,
                        'query': query
                    }
            else:
                output = {
                    'status': status,
                    'percent': percent,
                    'result ': {},
                    'mode': 'pdop'
                }
        except Exception as e:
            request.setResponseCode(500)
            return json.dumps(f'Возникла ошибка при формировании статуса: {str(e)}', ensure_ascii=False).encode('utf-8')
        return json.dumps(output, cls=DateTimeEncoder).encode('utf-8')


class PDOP_Stop_calculate(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        message = None
        if PDOP_Thread.thr.is_alive() == False:
            message = 'Невозможно остановить: расчет не запущен'
        if PDOP_Thread.thr.is_alive() == True:
            PDOP_Thread.stop()
            time.sleep(0.5)
            message = 'Расчет принудительно остановлен'
        return json.dumps({'message': message, 'status': PDOP_Thread.getstatus()}).encode('utf-8')


class AlmanacSlots(CustomResource):

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='GET, PATCH, OPTIONS')
        return b""

    def render_PATCH(self, request):
        request = set_headers(request, method="PATCH")

        try:
            Almanac.delete().execute()
            cache_almanac.clear()
            # TODO в протоколе нужно зафиксировать действие оператора по удалению альманаха
            return json.dumps("Almanac dropped", cls=DateTimeEncoder).encode('utf-8')
        except KeyError as e:
            request.setResponseCode(404)
            return json.dumps(str(e)).encode('utf-8')

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        start = None
        end = None
        result = []
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
            end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps('Некорректные параметры запроса.', ensure_ascii=False).encode('utf-8')
        for nka_sys_num in range(1, 64):
            if (start is None) or (end is None):
                almanac_slot = get_almanac_slot(nka_sys_num)
                if not almanac_slot is None:
                    result.append(almanac_slot.as_dict())
            else:
                (N4_start, NA_start, _) = get_almanac_time_by_datetime(start)
                (N4_end, NA_end, _) = get_almanac_time_by_datetime(end)
                if N4_start != N4_end:
                    request.setResponseCode(400)
                    return json.dumps("Запрошенные данные принадлежат разным четырехлетиям").encode('utf-8')
                try:
                    almanac_slots = Almanac.select().where((Almanac.nka == nka_sys_num) &
                                                           (Almanac.N4 == N4_start) &
                                                           (Almanac.N_A.between(NA_start, NA_end))).order_by(
                        Almanac.N_A.desc())
                    for a in almanac_slots:
                        result.append(a.as_dict())
                except Almanac.DoesNotExist:
                    pass
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class VisibilityZones(CustomResource):
    REQUEST_SCHEMA = {
        "type": "object",
        "properties": {
            "nka": {"type": "integer"},
            "bis": {"type": "integer"},
            "start": {"type": "string", "format": "date-time"},
            "end": {"type": "string", "format": "date-time"},
        },
        "required": ["nka", "bis", "start", "end"]
    }

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = []  # перечень зон ЗРВ в интервале
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            nka = int(args[b'nka'][0])
            bis = int(args[b'bis'][0])
            start = datetime.datetime.fromisoformat(str(args[b'start'][0], 'utf-8'))
            end = datetime.datetime.fromisoformat(str(args[b'end'][0], 'utf-8'))
            jsonschema.validate({'nka': nka, 'bis': bis, 'start': str(args[b'start'][0], 'utf-8'),
                                 'end': str(args[b'end'][0], 'utf-8')}, VisibilityZones.REQUEST_SCHEMA)
        except (ValueError, KeyError, jsonschema.ValidationError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Некорректные параметры запроса: {str(e)}', ensure_ascii=False).encode('utf-8')

        if nka and bis and start and end:
            calc_result, zones_list = calc_visibility_zones_for_single_nka(bis, nka, start,
                                                                           end)
            if calc_result != CalculateResult.Ok:
                request.setResponseCode(500)
                return json.dumps(calculate_result_labels.get(calc_result, 'Неизвестная ошибка'),
                                  ensure_ascii=False).encode('utf-8')
            else:
                result = zones_list
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')


class CheckNeighborDI(CustomResource):
    signal_db_map = {
        'L1OF': L1OFFrame,
        'L2OF': L2OFFrame,
        'L1OC': L1OCFrame,
        'L3OC': L3OCFrame,
        'L1SC': L1SCFrame,
        'L2SC': L2SCFrame,
        'L1SF': L1SFFrame,
    }

    schema = {
        "type": "object",
        "properties": {
            "id": {"type": "integer"},
            "signal_type": {"type": "string"},
            "type": {"type": "string", "enum": ["next", "previous"]}
        },
        "required": ["id", "signal_type", "type"],
        "additionalProperties": False
    }

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            frame_id = int(args[b'id'][0])
            signal_type = args[b'signal_type'][0].decode("utf-8")
            neighbor_type = args[b'type'][0].decode("utf-8")
            jsonschema.validate({'id': frame_id, 'signal_type': signal_type, 'type': neighbor_type},
                                CheckNeighborDI.schema)
        except (ValueError, KeyError, jsonschema.ValidationError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')

        frame = CheckNeighborDI.signal_db_map[signal_type].get_or_none(id=frame_id)
        if not frame:
            request.setResponseCode(404)
            return json.dumps('Не найдена искомая ЦИ', ensure_ascii=False).encode('utf-8')

        try:
            result = frame.check_EI_with_neighbor(neighbor_type)
            request.setResponseCode(200)
        except CompareEIinDIError as e:
            request.setResponseCode(401)
            return json.dumps(str(e), ensure_ascii=False).encode('utf-8')
        except BadEIException as e:
            result = e.args[0]
            request.setResponseCode(422)

        return json.dumps(result, cls=DateTimeEncoder, ensure_ascii=False).encode('utf-8')


class ImmediateDISIComparison(CustomResource):
    """Оперативная информация НС.
        Структура словаря:
            {'table_data':[{'param': 'tk',
                            'signal_type1': {'value': float, 'is_valid':bool/None},
                            'signal_type2': {'value': float, 'is_valid':bool/None},
                            ........ для всех типов сигналов свой словарь,
                            'si': {'ph_centre_fd':{'value': float/', 'is_valid':None},
                                    'centre': { data: {'value': float/', 'is_valid':None}, 'type': 'mass'/'phaseL3' }}
                            }, ...],
            'si_timestamp':{'169':[(timestamp, tb), ()]
                            '893':[(timestamp, tb), ()]}
            }
    """
    REQUEST_SCHEMA = {
        "type": "object",
        "properties": {
            "sys_num": {"type": "integer"},
        },
        "required": ["sys_num"]
    }
    nka_sys_number = None

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = get_immediate_info_online_comparison(ImmediateDISIComparison.nka_sys_number)
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        try:
            request_data: dict = json.loads(request.content.read())
            sys_num = request_data['sys_num']
            jsonschema.validate({'sys_num': sys_num}, ImmediateDISIComparison.REQUEST_SCHEMA)
            ImmediateDISIComparison.nka_sys_number = sys_num
        except (KeyError, ValueError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        return b""

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""


class AlmanacDISIComparison(CustomResource):
    """Результат оперативного сравнения альманаха из обобщенной ЦИ с СИ с одного НКА для всех типов сигналов.
        {
        <almanac_sys_num>: {
            <signal_type>: {
                'delta_T' : True|False|None,
                't_lambda': True|False|None,
                'epsilon' : True|False|None,
                'd_delta_T': True|False|None,
                'omega'   : True|False|None,
                'lambda_' : True|False|None,
                'delta_i' : True|False|None
            },
            ...
        },
        ...
        }
        • Набор ключей («delta_T», «t_lambda», …, «delta_i») фиксирован и соответствует FORM_895_PARAMS.
        • True / False – параметр прошёл / не прошёл проверку.
        • None – данные отсутствуют или некорректны.
    """

    REQUEST_SCHEMA = {
        "type": "object",
        "properties": {
            "sys_num": {"type": "integer"},
        },
        "required": ["sys_num"]
    }
    nka_sys_number = None

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = get_almanac_online_comparison(AlmanacDISIComparison.nka_sys_number)
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        try:
            request_data: dict = json.loads(request.content.read())
            sys_num = request_data['sys_num']
            jsonschema.validate({'sys_num': sys_num}, AlmanacDISIComparison.REQUEST_SCHEMA)
            AlmanacDISIComparison.nka_sys_number = sys_num
        except (KeyError, ValueError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        return b""

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""


class SingleAlmanacDISIComparison(CustomResource):
    """Для отображния подробной информации сравнения альманаха из обобщенной ЦИ с СИ:
       данные одного альмнаха для одного сигнала.
        {'table_data': [
        {
            'param': 'tk',
            'di_value': float,
            'si_value': float,
            'is_valid': bool or None
        },
        {
            'param': 'tk',
            'di_value': float,
            'si_value': float,
            'is_valid': bool or None
        },
        # Для всех параметров из FORM_895_PARAMS],
        'si_timestamp':  str }
    """
    REQUEST_SCHEMA = {
        "type": "object",
        "properties": {
            "sys_num": {"type": "integer"},
            "signal_type": {"type": "integer"},
            "almanac_sys_num": {"type": "integer"},
        },
        "required": ["sys_num", "signal_type", "almanac_sys_num"]
    }

    nka_sys_number = None
    signal_type = None
    almanac_sys_num = None

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = get_single_nka_almanac_online_comparison(SingleAlmanacDISIComparison.nka_sys_number,
                                                          SingleAlmanacDISIComparison.signal_type,
                                                          SingleAlmanacDISIComparison.almanac_sys_num)
        return json.dumps(result, cls=DateTimeEncoder).encode('utf-8')

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        try:
            request_data: dict = json.loads(request.content.read())
            sys_num = request_data['sys_num']
            signal_type = request_data['signal_type']
            almanac_sys_num = request_data['almanac_sys_num']
            jsonschema.validate({'sys_num': sys_num, 'signal_type': signal_type, "almanac_sys_num": almanac_sys_num},
                                SingleAlmanacDISIComparison.REQUEST_SCHEMA)
            SingleAlmanacDISIComparison.nka_sys_number = sys_num
            SingleAlmanacDISIComparison.signal_type = signal_type
            SingleAlmanacDISIComparison.almanac_sys_num = almanac_sys_num
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        return b""

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""


class CurrentVersion(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = {
            "version": version.__version__
        }
        return json.dumps(result).encode('utf-8')


class NkaData(CustomResource):
    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        result = appdata.NKA_DATA
        for nka in appdata.NKA_DATA.keys():
            if nka in appdata.NKA_SIGNALS:
                result[nka]['signals'] = appdata.NKA_SIGNALS_NAME[nka]
            else:
                result[nka]['signals'] = '-'
        return json.dumps(list(result.values())).encode('utf-8')


class SIForms(CustomResource):
    """Точка отдачи списка всех обрабатываемых форм СИ"""

    @staticmethod
    def get_all_forms():
        forms = set()
        for value in SI_FORMS.values():
            forms.update(value.keys())
        return list(forms)

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        forms = SIForms.get_all_forms()
        return json.dumps(forms).encode('utf-8')


class SIRecords(CustomResource):
    """Получить все СИ из ЦБД для заданного НКА на заднный период"""
    SCHEMA_SI_FORM = {
        "type": "object",
        "properties": {
            "nka": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "form": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "start": {"type": "string", "format": "date-time"},
            "end": {"type": "string", "format": "date-time"},
            "page": {"type": "integer"},
            "limit": {"type": "integer"}
        },
        "required": ["nka", "form", "start", "end"]
    }

    def render_POST(self, request):
        request = set_headers(request)
        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=self.SCHEMA_SI_FORM)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')
        try:
            content["time_start"] = content.pop("start")
            content["time_end"] = content.pop("end")
            records = SIRecords.get_SI_records(content)
            if not len(records):
                raise DoesNotExist
            return json.dumps(records, cls=DateTimeEncoder).encode('utf-8')
        except (DoesNotExist, ValueError) as err:
            request.setResponseCode(404)
            return json.dumps({'message': str(err)}, ensure_ascii=False).encode('utf-8')
        except OperationalError as err:
            request.setResponseCode(401)
            return json.dumps({'message': str(err)}, ensure_ascii=False).encode('utf-8')

    @staticmethod
    def get_SI_records(content):
        SI = SIFormTable()
        records = SI.get_records_from_cdb_by_params(**content)
        if len(records):
            result = [dict(id=rec.id, nku_num=rec.nka, timestamp=rec.timestamp, vitok=rec.vitok,
                           si_form=rec.si_form, si_format=rec.si_format, flag_cdb=rec.flag_cdb,
                           flag_sui=rec.flag_sui, flag_ka=rec.flag_ka, write_time_cdb=rec.write_time_cdb,
                           write_time_sui=rec.write_time_sui, write_time_ka=rec.write_time_ka) for rec in records]
        else:
            raise DoesNotExist('Не найдены СИ по заданным параметрам')
        return result

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='GET, POST, OPTIONS')
        return b""

    def getChild(self, path, request):
        if path == b"forms":
            return SIForms()
        return resource.NoResource()


class SIRecord(CustomResource):
    """Получить данные по фразе СИ"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            nku_num = int(args[b'nku_num'][0])  # номер НКА в НКУ
            vitok = int(args[b'rec_vitok'][0])  # Значение vitok СИ в ЦБД (для старой ЦБД вместо ID)
            rec_id = int(args[b'rec_id'][0])  # ID заданной СИ в ЦБД (для новой ЦБД, для старой всегда передается 0)
            form = int(args[b'form'][0])  # Форма СИ
            phr_num = int(args[b'phr_num'][0])  # Номер фразы
            tb = args.get(b'tb', None)  # номер 30-минутного интервала
            if tb is not None:
                tb = int(tb[0])
            N = args.get(b'n', None)  # номер суток с начала года
            if N is not None:
                N = int(N[0])
            Na = args.get(b'na', None)  # номер суток в альманахе
            if Na is not None:
                Na = int(Na[0])
            if (form == 893 or form == 169) and (tb is None or N is None):
                raise ValueError(f'Форма {form}: Нужно передать tb и N')
            elif form in [895, 701] and Na is None:
                raise ValueError(f'Форма {form}: Нужно передать Na')
            elif tb is None and N is None and Na is None and form != 921:  # у 921 нет временной привязки
                raise ValueError(f'Не переданы параметры времени')
        except (ValueError, KeyError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')

        try:
            nka_type = [nka['type_ka'] for nka in appdata.NKA_DATA.values() if
                        nka['nku_num'] == nku_num]  # FIXME при отказе от старой ЦБД не нужно
            if nka_type:
                nka_type = nka_type[0]
                form_name = SI_FORMS[nka_type][form]  # получаем имя формы ЭИ в зависимости от типа КА
                SI = form_name(nku_num=nku_num)
                record = SI.get_record_from_cdb_by_id(nka=nku_num, vitok=vitok, id=rec_id)
                if record is None:
                    raise DoesNotExist('Не найдена запись в ЦБД по указанным параметрам')
                form_name = SI_FORMS[record.si_format][
                    form]  # получаем имя формы ЭИ в зависимости от типа КА из таблицы СИ
                SI = form_name(nku_num=nku_num)
                phrase = SI.find_phrase_in_record_by_num(record=record, phr_num=phr_num)
                if phrase is None:
                    raise DoesNotExist('Не найдена фраза с указанными параметрами в указанной записи')
                result = phrase.parse_with_time(ref_time=TimeData(tb=tb, N=N, Na=Na, mode='SI'))
                return json.dumps(result).encode('utf-8')
        except (DoesNotExist) as err:
            request.setResponseCode(404)
            return json.dumps({str(err)}, ensure_ascii=False).encode('utf-8')


class CheckP4inFrame(CustomResource):
    """Возвращает tk кадра, у которого P4=1, для выбранной СИ из ЦБД"""

    def render_GET(self, request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            nku_num = int(args[b'nka'][0])  # Номер НКА в НКУ
            form = int(args[b'form'][0])  # Номер формы
            rec_id = int(args[b'rec_id'][0])  # ID заданной СИ в ЦБД (для новой ЦБД, для старой всегда передается 0)
        except (ValueError, KeyError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')
        try:
            frame = find_frame_with_P4(nku_num, rec_id, form)
            if frame is not None:
                return json.dumps({"tk": frame.tk, "timestamp": frame.timestamp}, cls=DateTimeEncoder).encode('utf-8')
            else:
                raise DoesNotExist('СИ не заложена в кадр')
        except (DoesNotExist, ValueError) as err:
            request.setResponseCode(404)
            return json.dumps(str(err), ensure_ascii=False).encode('utf-8')


class SIRecordPhrases(CustomResource):
    """Получить все фразы из заданной СИ"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            rec_id = int(args[b'rec_id'][0])  # ID заданной СИ в ЦБД (для новой ЦБД, для старой всегда передается 0)
            nku_num = int(args[b'nku_num'][0])  # номер НКА в НКУ
            vitok = int(args[b'vitok'][0])  # Значение vitok СИ в ЦБД (для старой ЦБД вместо ID)
            form = int(args[b'form'][0])  # Номер формы СИ в ЦБД
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps({'message': 'Ошибка входных параметров'}, ensure_ascii=False).encode('utf-8')
        try:
            phrases = SIRecordPhrases.split_SI_on_phrases(nku_num, rec_id, vitok, form)
            if not len(phrases):
                raise DoesNotExist("Не удалось получить список фраз при разбивке записи СИ")
            return json.dumps(phrases).encode('utf-8')
        except (DoesNotExist, ValueError) as err:
            request.setResponseCode(404)
            return json.dumps({'message': str(err)}, ensure_ascii=False).encode('utf-8')
        except OperationalError as err:
            request.setResponseCode(401)
            return json.dumps({'message': str(err)}, ensure_ascii=False).encode('utf-8')
        except Exception as err:
            request.setResponseCode(500)
            logging.warning(f'Ошибка при раскрытии списка фраз на клиенте: {str(err)}')
            return json.dumps({'message': f'Произошла неизвестная ошибка. Подробности в журнале'},
                              ensure_ascii=False).encode(
                'utf-8')

    @staticmethod
    def split_SI_on_phrases(nku_num, rec_id, vitok, form):
        result = []
        if nku_num and vitok and rec_id is not None and form is not None:
            nka_type = [nka['type_ka'] for nka in appdata.NKA_DATA.values() if
                        nka['nku_num'] == nku_num]  # FIXME при отказе от старой ЦБД не нужно
            if nka_type:
                nka_type = nka_type[0]
                form_name = SI_FORMS[nka_type][form]  # получаем имя формы ЭИ в зависимости от типа КА
                SI = form_name(nku_num=nku_num)
                record = SI.get_record_from_cdb_by_id(nka=nku_num, vitok=vitok, id=rec_id)
                if record is None:
                    raise DoesNotExist('Не найдена запись в ЦБД по указанным параметрам')
                form_name = SI_FORMS[record.si_format][
                    form]  # получаем имя формы ЭИ в зависимости от типа КА из таблицы СИ
                SI = form_name(nku_num=nku_num)
                phrases = SI.split_by_single_time_moment(record)
                if phrases:
                    for phr in phrases:
                        phr_dict = phr.as_dict()
                        phr_dict['rec_id'] = rec_id
                        phr_dict['rec_vitok'] = vitok
                        phr_dict['nka_type'] = nka_type
                        phr_dict['form'] = form
                        result.append(phr_dict)
            else:
                raise ValueError('Передан несуществующий номер НКА')
        return result


class CheckNeighborSI(CustomResource):
    """Получить результат сравнения ЭИ в текущей и соседней СИ (предыд/след)"""

    schema = {
        "type": "object",
        "properties": {
            "nku_num": {"type": "integer"},
            "rec_id": {"type": "integer"},
            "rec_vitok": {"type": "integer"},
            "tb": {"type": "integer"},
            "n": {"type": "integer"},
            "type": {"type": "string", "enum": ["next", "previous"]}
        },
        "required": ["nku_num", "rec_id", "rec_vitok", "type", "tb", "n"],
        "additionalProperties": False
    }

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            nku_num = int(args[b'nku_num'][0])  # номер НКА в НКУ
            rec_id = int(args[b'rec_id'][0])  # ID заданной СИ в ЦБД (для новой ЦБД, для старой всегда передается 0)
            vitok = int(args[b'rec_vitok'][0])  # Значение vitok СИ в ЦБД (для старой ЦБД вместо ID)
            tb = int(args[b'tb'][0])  # tb заданной СИ
            N = int(args[b'n'][0])  # N текущей СИ
            neighbor_type = args[b'type'][0].decode("utf-8")
            jsonschema.validate({'nku_num': nku_num, 'rec_id': rec_id, 'rec_vitok': vitok, 'tb': tb, 'n': N,
                                 'type': neighbor_type}, CheckNeighborSI.schema)
        except (ValueError, KeyError, jsonschema.ValidationError) as e:
            request.setResponseCode(400)
            return json.dumps(f'Ошибка входных параметров: {str(e)}', ensure_ascii=False).encode('utf-8')
        try:
            diff = CheckNeighborSI.checkEIconsistency(nku_num, rec_id, vitok, neighbor_type, N, tb)
            return json.dumps(diff, cls=DateTimeEncoder).encode('utf-8')
        except DoesNotExist as err:
            request.setResponseCode(404)
            return json.dumps(str(err), ensure_ascii=False).encode('utf-8')
        except (ValueError, BadEIException) as err:
            request.setResponseCode(401)
            return json.dumps(str(err), ensure_ascii=False).encode('utf-8')
        except OperationalError as err:
            request.setResponseCode(403)
            return json.dumps(f'Ошибка подключения к ЦБД: {str(err)}', ensure_ascii=False).encode('utf-8')

    @staticmethod
    def checkEIconsistency(nku_num, rec_id, vitok, neighbor_type, N, tb):
        diff = []
        nka_type = [nka['type_ka'] for nka in appdata.NKA_DATA.values() if
                    nka['nku_num'] == nku_num]  # FIXME при отказе от старой ЦБД не нужно
        if nka_type:
            nka_type = nka_type[0]
            form = SI_FORMS[nka_type][893]  # получаем имя формы ЭИ в зависимости от типа КА
            record = form.get_record_from_cdb_by_id(nka=nku_num, vitok=vitok, id=rec_id)
            if record:
                form = SI_FORMS[record.si_format][
                    893]  # получаем имя формы ЭИ в зависимости от типа КА, который взят из СИ
                diff = check_EI_with_neighbor_SI(form=form, record=record, nka=nku_num, time_bind=TimeData(tb=tb, N=N),
                                                 neighbor_type=neighbor_type)
            else:
                raise DoesNotExist('Не найдена запись в ЦБД по указанным параметрам')
        else:
            raise ValueError('Передан несуществующий номер НКА')
        return diff


class LoggingLevels(CustomResource):
    """Получить список уровней логирования"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(list(appdata.LogLevelCode)).encode('utf-8')


class BisesSummaryCounter(CustomResource):
    """Получить суммарные счётчики пакетов станций/БИС"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(general_message_counters.get_full_stations_counter(), cls=DateTimeEncoder).encode('utf-8')


class BisesPacketCounter(CustomResource):
    """Получить счётчики станций/БИС по видам пакетов"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(general_message_counters.get_full_bises_counter(), cls=DateTimeEncoder).encode('utf-8')


class NkasMessageCounter(CustomResource):
    """Получить счётчики станции/БИС для всех НКА по видам пакетов"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)

        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            station = int(args[b'station'][0])  # номер станции
            bis = int(args[b'bis'][0])  # номер БИС
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps('Ошибка входных параметров', ensure_ascii=False).encode('utf-8')

        if station == 0 and bis == 0:
            return json.dumps(dict()).encode('utf-8')
        else:
            return json.dumps(general_message_counters.get_fixed_bis_from_nkas_counter(station, bis),
                              cls=DateTimeEncoder).encode(
                'utf-8')


class SignalsMessageCounter(CustomResource):
    """Получить счётчики конкретного НКА для заданной станции/БИС/ c разделением по сигналам"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            args = urllib.parse.parse_qs(urllib.parse.urlparse(request.uri).query)
            station = int(args[b'station'][0])  # номер станции
            bis = int(args[b'bis'][0])  # номер БИС
            nka = int(args[b'nka'][0])  # номер НКА
        except (ValueError, KeyError):
            request.setResponseCode(400)
            return json.dumps('Ошибка входных параметров', ensure_ascii=False).encode('utf-8')

        return json.dumps(general_message_counters.get_fixed_nka_from_signals_counter(station, bis, nka),
                          cls=DateTimeEncoder).encode('utf-8')


class BisesStatuses(CustomResource):
    """Получить состояния обмена с БИС"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(bis_connection_state.get_state()).encode('utf-8')


class GeneralBisStatus(CustomResource):
    @staticmethod
    def render_GET(request):
        set_headers(request)
        status = bis_connection_state.get_general_status()
        return json.dumps(status).encode('utf-8')


class CheckTldbConnection(CustomResource):
    """Получить состояние связи с ТЛБД"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(not (db.is_closed())).encode('utf-8')


class CheckCdbConneciton(CustomResource):
    """Получить состояние связи с ЦБД"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        try:
            KaInfo.select().order_by(KaInfo.nka).exists()
        except peewee.OperationalError:
            return json.dumps(False).encode('utf-8')
        return json.dumps(True).encode('utf-8')


class CheckLdbConneciton(CustomResource):
    """Получить состояние связи с ЦБД"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(get_ldb_connection_status()).encode('utf-8')


class AnglesTable(CustomResource):
    """Получить таблицу углов для всех НКА"""

    @staticmethod
    def render_GET(request):
        request = set_headers(request)
        return json.dumps(current_visibility_for_client.get_data()).encode('utf-8')


class KillPoint(CustomResource):
    """Класс для перезагрузки сервера"""

    def render_GET(self, request):
        request = set_headers(request)
        request.write(json.dumps('OK', ensure_ascii=False).encode('utf-8'))
        request.finish()
        reactor.callLater(1, os._exit, 1)

        return server.NOT_DONE_YET
