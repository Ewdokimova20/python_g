import datetime
import json

import jsonschema
from jsonschema.validators import validate

from KNPServer.common.datetime_encoder import DateTimeEncoder
from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from data import Residual
from global_data.config_schema import config


class ArchiveResidualsTable(CustomResource):
    """
    Точка для запроса архивных невязок
    """

    request_schema = {
        "type": "object",
        "properties": {
            "nka": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "bis": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "start": {"type": "string", "format": "date-time"},
            "end": {"type": "string", "format": "date-time"},
            "signal_type": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "page": {"type": "integer"},
            "limit": {"type": "integer"},
            "is_db_timestamp": {"type": "boolean"},
            "filters": {
                "anyOf": [
                    {
                        "type": "object",
                        "properties": {
                            "nka": {"type": "object"},
                            "bis": {"type": "object"},
                            "signalIsUntrusted": {"type": "object"},
                            "rejectedDueToDeviation": {"type": "object"}
                        }
                    },
                    {"type": "null"}
                ]
            },
            "sort": {
                "anyOf": [
                    {
                        "type": "object",
                        "properties": {
                            "sort_field": {"type": "string"},
                            "sort_order": {"oneOf": [{"type": "number", "enum": [-1, 1]}, {"type": "null"}]}
                        }
                    },
                    {"type": "null"}
                ]
            }
        },
        "required": ["nka", "bis", "start", "end"],
    }

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='POST, OPTIONS')
        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=ArchiveResidualsTable.request_schema)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')

        start_datetime = datetime.datetime.fromisoformat(content.get('start'))
        end_datetime = datetime.datetime.fromisoformat(content.get('end'))
        delta = datetime.timedelta(hours=config['interface']['history_residuals_search_depth'])
        if (end_datetime - start_datetime) > delta:
            request.setResponseCode(401)
            return json.dumps(f"Выбранный период времени не должен превышать {str(delta)}", ensure_ascii=False).encode(
                'utf-8')

        residuals, total_records = ArchiveResidualsTable.get_residuals(**content)
        if len(residuals) == 0:
            request.setResponseCode(404)
            return json.dumps('Не найдено невязок для заданных параметров', ensure_ascii=False).encode('utf-8')
        residuals = [r for r in residuals.dicts()]
        return json.dumps({'data': residuals, 'total_records': total_records}, cls=DateTimeEncoder).encode('utf-8')

    @staticmethod
    def get_residuals(nka: list, bis: list, start: datetime, end: datetime, signal_type: list, is_db_timestamp: bool,
                      page: int = 0,
                      limit: int = 0,
                      filters: dict = None, sort: dict = None):

        timestamp_field = getattr(Residual, 'db_timestamp' if is_db_timestamp else 'timestamp')
        conditions = [
            timestamp_field >= start,
            timestamp_field <= end,
            Residual.nka_id.in_(nka),
            Residual.bis_id.in_(bis),
            Residual.signal_1.in_(signal_type)
        ]

        if filters:
            for field, filter_data in filters.items():
                value = filter_data.get("value")
                match_mode = filter_data.get("match_mode")
                if value is not None and match_mode == "equals":
                    if field == 'signal1':
                        field = 'signal_1'
                    conditions.append(getattr(Residual, field) == value)

        total_records = Residual.select().where(*conditions).count()

        records = []
        if sort:
            if sort['sort_order'] == 1:
                records = Residual.select().where(*conditions).order_by(
                    getattr(Residual, sort['sort_field']).asc()).paginate(page, limit)
            elif sort['sort_order'] == -1:
                records = Residual.select().where(*conditions).order_by(
                    getattr(Residual, sort['sort_field']).desc()).paginate(page, limit)
            elif sort['sort_order'] is None:
                records = Residual.select().where(*conditions).order_by(timestamp_field.desc()).paginate(page, limit)
        else:
            records = Residual.select().where(*conditions).order_by(timestamp_field.desc()).paginate(page, limit)

        return records, total_records

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='POST, OPTIONS')
        return b""
