import datetime
import io
import json

import jsonschema
import psycopg2
from jsonschema.validators import validate
from peewee import DoesNotExist

from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from global_data.config_schema import config


class ResidualsCSVExport(CustomResource):
    isLeaf = True

    request_schema = {
        "type": "object",
        "properties": {
            "nka": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "bis": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "signal_type": {"type": "array", "items": {"type": "number"}, "minItems": 1},
            "start": {"type": "string", "format": "date-time"},
            "end": {"type": "string", "format": "date-time"},
            "is_db_timestamp": {"type": "boolean"}
        },
        "required": ["nka", "bis", "start", "end"],
    }

    @staticmethod
    def render_POST(request):
        request = set_headers(request, method='POST, OPTIONS', content_type='text/csv')
        try:
            content = json.loads(request.content.read())
            validate(instance=content, schema=ResidualsCSVExport.request_schema)
        except jsonschema.exceptions.ValidationError as e:
            request.setResponseCode(400)
            return e.message.encode('utf-8')

        start_datetime = datetime.datetime.fromisoformat(content.get('start'))
        end_datetime = datetime.datetime.fromisoformat(content.get('end'))
        delta = datetime.timedelta(hours=config['interface']['history_residuals_search_depth'])
        if (end_datetime - start_datetime) > delta:
            request.setResponseCode(401)
            return json.dumps(f"Выбранный период времени не должен превышать {str(delta)}", ensure_ascii=False).encode(
                'utf-8')

        try:
            residuals_csv = ResidualsCSVExport.export_residuals(**content)
            request.setHeader(b'Content-Disposition', b'attachment; filename="residuals.csv"')
            return residuals_csv.encode('utf-8')

        except DoesNotExist:
            request.setResponseCode(404)
            return json.dumps('Не найдено невязок для заданных параметров', ensure_ascii=False).encode('utf-8')

        except psycopg2.Error as e:
            request.setResponseCode(500)
            return json.dumps(f'Ошибка ТЛБД: {str(e)}', ensure_ascii=False).encode('utf-8')

    @staticmethod
    def get_connection_params():
        """Получение параметров подключения к базе данных."""
        return {
            'database': config['postgresql']['tldbname'],
            'user': config['postgresql']['username'],
            'password': config['postgresql']['password'],
            'host': config['postgresql']['host'],
            'port': config['postgresql']['port'],
        }

    @staticmethod
    def export_residuals(nka: list, bis: list, signal_type: list, start: datetime, end: datetime, is_db_timestamp: bool):
        with psycopg2.connect(**ResidualsCSVExport.get_connection_params()) as conn:
            with conn.cursor() as cur:
                timestamp_type = 'db_timestamp' if is_db_timestamp else 'timestamp'

                # Проверка наличия записей
                cur.execute(
                    f"SELECT COUNT(*) FROM residual WHERE {timestamp_type} >= %s AND {timestamp_type} <= %s AND nka_id IN %s AND bis_id IN %s AND signal_1 IN %s",
                    (start, end, tuple(nka), tuple(bis), tuple(signal_type))
                )
                count = cur.fetchone()[0]

                if count > 0:
                    csv_file = io.StringIO()

                    # Получаем информацию о столбцах
                    cur.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'residual'")
                    columns_info = cur.fetchall()

                    # Формирование списка колонок с заменой точек на запятые
                    columns_for_select = [
                        f"REPLACE(CAST({column_name} AS TEXT), '.', ',') AS {column_name}"
                        if data_type in ['double precision', 'real', 'timestamp without time zone',
                                         'timestamp with time zone']
                        else column_name
                        for column_name, data_type in columns_info
                    ]

                    query = f"""
                    SELECT {', '.join(columns_for_select)}
                    FROM residual
                    WHERE {timestamp_type} >= %s
                      AND {timestamp_type} <= %s
                      AND nka_id IN %s
                      AND bis_id IN %s
                      AND signal_1 IN %s
                    """

                    query_params = (start, end, tuple(nka), tuple(bis), tuple(signal_type))
                    query = cur.mogrify(query, query_params).decode('utf-8')
                    cur.copy_expert(f"COPY ({query}) TO STDOUT WITH CSV HEADER DELIMITER ';'", csv_file)

                    return csv_file.getvalue()
                else:
                    raise DoesNotExist('Отсутствуют данные для заданных параметров')

    @staticmethod
    def render_OPTIONS(request):
        request = set_headers(request, method='POST, OPTIONS')
        return b""
