import datetime
import json
from typing import Optional, Union

import plotly.graph_objects as go
from peewee import DoesNotExist
from pydantic import ValidationError

from KNPServer.common.set_headers import set_headers
from KNPServer.endpoints.custom_resource import CustomResource
from KNPServer.endpoints.residuals.chart_residuals.types import RequestData, NAME_FOR_Y_AXIS, ProcessedResidualData
from data import Residual
from global_data.config_schema import config
from utils.caches import cache_bis
from utils.lib import get_residual_pair_signal, get_signal_name


class ChartResiduals(CustomResource):
    """
    Точка для запроса графиков архивных невязок
    """
    isLeaf = True

    @staticmethod
    def process_residuals_data(request_data: RequestData) -> ProcessedResidualData:
        """
        Обработка данных невязок с логикой фильтрации и прореживания по временным окнам

        Args:
            request_data (RequestData): Валидированные данные запроса

        Returns:
            ProcessedResidualData: Словарь с обработанными данными невязок

        Raises:
            DoesNotExist: Нет данных в БД для заданных параметров.
            ValueError: Количество записей превышает максимально допустимое значение или нет данных в БД для заданных параметров.
        """
        max_record_count = config['interface']['history_residuals_chart_max_record_count']

        nka = request_data.nka
        bis = request_data.bis
        start = request_data.start
        end = request_data.end
        signal_type = request_data.signal_type
        is_db_timestamp = request_data.is_db_timestamp
        time_step = request_data.time_step
        data_field = request_data.data_field
        display_rejected = request_data.display_rejected

        timestamp_field = getattr(Residual, 'db_timestamp' if is_db_timestamp else 'timestamp')

        # Создаем подзапрос с оконной функцией для прореживания
        # Группируем записи по временным окнам и выбираем первую запись из каждого окна
        subquery = f"""
        SELECT *,
               ROW_NUMBER() OVER (
                   PARTITION BY 
                       bis_id, 
                       nka_id, 
                       signal_1,
                       FLOOR(EXTRACT(EPOCH FROM {timestamp_field.column_name}) / {time_step})
                   ORDER BY {timestamp_field.column_name}
               ) as rn
        FROM {Residual._meta.table_name}
        WHERE {timestamp_field.column_name} >= %s
          AND {timestamp_field.column_name} <= %s
          AND nka_id = ANY(%s)
          AND bis_id = ANY(%s)
          AND signal_1 = ANY(%s)
          AND {data_field} IS NOT NULL
          {'' if display_rejected else 'AND rejected_due_to_deviation = false'}
        """

        # Подготавливаем параметры
        params = [
            datetime.datetime.fromisoformat(start),
            datetime.datetime.fromisoformat(end),
            nka,
            bis,
            signal_type
        ]

        # Создаем финальный запрос, который выбирает только первые записи из каждого временного окна
        final_query = f"""
            SELECT 
                bis_id, 
                nka_id, 
                signal_1, 
                {data_field}, 
                nka_elevation, 
                {timestamp_field.column_name} 
            FROM ({subquery}) as windowed_data 
            WHERE rn = 1
            ORDER BY bis_id ASC, nka_id ASC, signal_1 ASC, {timestamp_field.column_name} ASC
            LIMIT {max_record_count}
        """

        # Подсчитываем количество записей
        count_query = f"""
            SELECT COUNT(*) FROM ({subquery}) as windowed_data WHERE rn = 1
        """

        cursor = Residual._meta.database.execute_sql(count_query, params)
        record_count = cursor.fetchone()[0]

        if record_count > max_record_count:
            raise ValueError(f'Объем запрошенных данных ({record_count}) превышает максимально допустимый объем '
                             f'({max_record_count}).\n'
                             f'Измените параметры запроса, чтобы уменьшить запрашиваемый объем данных, '
                             f'и попробуйте повторить запрос.')
        if record_count == 0:
            raise DoesNotExist('Не найдено данных в БД для заданных параметров')

        # Выполняем основной запрос
        cursor = Residual._meta.database.execute_sql(final_query, params)
        columns = [desc[0] for desc in cursor.description]
        residuals = [dict(zip(columns, row)) for row in cursor.fetchall()]

        # Сбор уникальных комбинаций nka и bis
        unique_nka_bis = {}

        for entry in residuals:
            nka_bis_signal_key = (entry['nka_id'], entry['bis_id'], entry['signal_1'])
            if nka_bis_signal_key not in unique_nka_bis:
                unique_nka_bis[nka_bis_signal_key] = {
                    data_field: [],
                    'timestamp': [],
                }
                if data_field != 'nka_elevation':
                    unique_nka_bis[nka_bis_signal_key]['nka_elevation'] = []

            unique_nka_bis[nka_bis_signal_key][data_field].append(entry[data_field])
            unique_nka_bis[nka_bis_signal_key]['timestamp'].append(
                entry[timestamp_field.column_name].replace(
                    microsecond=entry[timestamp_field.column_name].microsecond // 1000 * 1000
                )
            )
            if data_field != 'nka_elevation':
                unique_nka_bis[nka_bis_signal_key]['nka_elevation'].append(entry['nka_elevation'])

        return ProcessedResidualData(
            unique_nka_bis=unique_nka_bis,
            data_field=data_field,
            line_type=request_data.line_type,
            x_axis_label='Дата/время записи в БД' if is_db_timestamp else 'Дата/время привязки'
        )

    @staticmethod
    def create_plotly_graph(processed_data: ProcessedResidualData, y_axis_limit: Optional[Union[int, float]]) -> str:
        """
        Создание графика Plotly на основе обработанных данных

        Args:
            processed_data (ProcessedResidualData): Обработанные данные невязок
            y_axis_limit (Optional[Union[int, float]]): Число для ограничения оси Y
        Returns:
            str: HTML-представление графика
        """
        fig = go.Figure()
        unique_nka_bis = processed_data.unique_nka_bis
        data_field = processed_data.data_field
        line_type = processed_data.line_type
        x_axis_label = processed_data.x_axis_label

        for (nka, bis, signal1), entries in unique_nka_bis.items():
            bis_item = cache_bis.get_item_by_id(bis)
            if bis_item is None:
                continue
            signal2 = get_residual_pair_signal(signal1)
            name_signals = f'{get_signal_name(signal1)}{f"-{get_signal_name(signal2)}" if signal2 else ""}'
            name_nka_bis = f'БИС {bis_item.station}/{bis_item.bis_number}, НКА {nka}, {name_signals}'
            y = entries[data_field]
            timestamp = entries['timestamp']
            nka_elevation = entries['nka_elevation'] if data_field != 'nka_elevation' else y
            text_tooltip = '<br>x=%{x}<br>y=%{y}<br>Угол места НКА=%{customdata}<br><extra></extra>'

            fig.add_trace(go.Scatter(
                x=timestamp,
                y=y,
                mode=line_type,
                name=name_nka_bis,
                customdata=nka_elevation,
                hovertemplate=f'{name_nka_bis}{text_tooltip}',
            ))

        # Настройки графика
        fig.update_layout(
            xaxis_title=x_axis_label,
            yaxis_title=NAME_FOR_Y_AXIS[data_field],
            xaxis_tickformat='%d.%m.%Y %H:%M:%S.%f'
        )

        fig.update_yaxes(
            tickformat=" ",
            **({"range": [-y_axis_limit, y_axis_limit]} if y_axis_limit else {}),
        )

        # Преобразование английских названий иконок в русские
        eng_to_rus_icons = """
        <script>
            // Ждем загрузки графика
            setTimeout(function() {
                // Находим все кнопки modebar и меняем их title
                document.querySelectorAll('.modebar-btn').forEach(btn => {
                    const name = btn.getAttribute('data-title');
                    const titles = {
                        'Download plot as a png': 'Скачать график как картинку',
                        'Zoom': 'Приблизить',
                        'Pan': 'Панорамировать',
                        'Zoom in': 'Увеличить',
                        'Zoom out': 'Уменьшить',
                        'Autoscale': 'Автомасштаб',
                        'Reset axes': 'Сбросить масштаб',
                        'Download plot': 'Скачать график'
                    };
                    if (titles[name]) {
                        btn.setAttribute('title', titles[name]);
                        btn.setAttribute('data-title', titles[name]);
                    }
                });
            }, 500);
        </script>
        """

        # Сохранение графика в html файл (showTips - отключает системные подсказки)
        return f"""{
        fig.to_html(
            full_html=True,
            config={
                'displaylogo': False,
                'modeBarButtonsToRemove': ['lasso2d', 'select2d'],
                'displayModeBar': True,
                'showTips': False,
            }
        )
        }
        {eng_to_rus_icons}"""

    @staticmethod
    def render_POST(request) -> bytes:
        """
        Обрабатывает POST-запрос для получения графиков.

        Args:
            request: Объект запроса, содержащий данные для обработки.

        Returns:
            bytes: HTML-представление графика в виде байтового массива.
        """
        request = set_headers(request, method='POST, OPTIONS', content_type='text/html; charset=utf-8')

        try:
            data = request.content.read()
            json_data = json.loads(data)

            # Валидация и десериализация с помощью Pydantic
            request_data = RequestData(**json_data)
            y_axis_limit = request_data.y_axis_limit

            # Обработка данных
            processed_data = ChartResiduals.process_residuals_data(request_data)

            # Создание графика
            html = ChartResiduals.create_plotly_graph(processed_data, y_axis_limit)

            request.setHeader('Content-Disposition', 'attachment; filename="graph.html"')
            return html.encode('utf-8')

        except ValidationError as e:
            request.setResponseCode(400)
            errors = [f"{', '.join(map(str, error['loc']))}: {error['msg']}" for error in e.errors()]
            return json.dumps(f'Ошибка валидации: {", ".join(errors)}', ensure_ascii=False).encode('utf-8')

        except DoesNotExist as e:
            request.setResponseCode(404)
            return json.dumps(str(e), ensure_ascii=False).encode('utf-8')

        except ValueError as e:
            request.setResponseCode(413)
            return json.dumps(str(e), ensure_ascii=False).encode('utf-8')

    @staticmethod
    def render_OPTIONS(request):
        """
        Обрабатывает OPTIONS-запрос

        Args:
            request: Объект запроса, содержащий информацию о запросе.

        Returns:
            bytes: Пустой байтовый ответ.
        """
        set_headers(request, method='POST, OPTIONS')
        return b""  # Пустой ответ для предзапроса
