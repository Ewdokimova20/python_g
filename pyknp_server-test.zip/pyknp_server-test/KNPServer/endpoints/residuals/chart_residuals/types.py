from dataclasses import dataclass
from enum import Enum
from typing import Dict, Tuple, List, Optional, Union

from pydantic import BaseModel, conlist, conint

from global_data.appdata import SignalTypes


class DataField(str, Enum):
    """
    Названия полей в таблице БД для получения данных
    """
    DELTA = "delta"
    DELTA1 = "delta1"
    DELTA2 = "delta2"
    RESIDUAL = "residual"
    RESIDUAL1 = "residual1"
    RESIDUAL2 = "residual2"
    SPEED_RESIDUAL = "speed_residual"
    AVERAGE = "average"
    NKA_ELEVATION = "nka_elevation"


# Словарь сотоставления поля с его текстовым описаниям для подписи по оси Y
NAME_FOR_Y_AXIS = {
    DataField.DELTA: "Отклонение невязки от среднего (ddS), м",
    DataField.DELTA1: "Отклонение невязки от среднего, сигнал 1 (ddS1), м",
    DataField.DELTA2: "Отклонение невязки от среднего, сигнал 2 (ddS2), м",
    DataField.RESIDUAL: "Невязка (dS), м",
    DataField.RESIDUAL1: "Невязка (dS1), сигнал 1, м",
    DataField.RESIDUAL2: "Невязка (dS2), сигнал 2, м",
    DataField.SPEED_RESIDUAL: "Невязка по псевдоскорости, м/с",
    DataField.AVERAGE: "Средняя невязка, м",
    DataField.NKA_ELEVATION: "Угол места НКА, градус",
}
'''Словарь сотоставления поля с его текстовым описаниям для подписи по оси Y'''


class LineType(str, Enum):
    """
    Перечисление для типов линий графиков.
    """
    LINES = "lines"
    """Линии"""
    MARKERS = "markers"
    """Маркеры"""
    LINES_MARKERS = "lines+markers"
    """Линия с маркерами"""


# Модель запроса
class RequestData(BaseModel):
    """
    Модель валидации данных, передаваемых в запросе

    Attributes:
        nka (List[int]): Список идентификаторов НКА
        bis (List[int]): Список идентификаторов БИС
        start (str): Дата и время начала периода
        end (str): Дата и время конца периода
        signal_type (List[SingalTypes]) Список типов сигналов
        is_db_timestamp (bool): Флаг, указывающий, искать по времени записи в БД (true) или по времени привязки (false)
        time_step (int): Шаг времени в секундах (от 1 до 60), шаг 60 необходим, чтобы отображать лишь минуты без секунд
        line_type (LineType): Тип линии для графика
        data_field (DataField): Название поля в таблице БД
        display_rejected (bool): Флаг, указывающий нужно ли отображать отбракованные невязки
        y_axis_limit (Optional[Union[int, float]]): Число для ограничения оси Y
    """
    nka: conlist(int, min_length=1)
    """Список идентификаторов НКА"""
    bis: conlist(int, min_length=1)
    """Список идентификаторов БИС"""
    start: str  # datetime не дает установить
    """Дата и время начала периода"""
    end: str  # datetime не дает установить
    """Дата и время конца периода"""
    signal_type: conlist(SignalTypes, min_length=1)
    """Тип сигнала"""
    is_db_timestamp: bool
    """Флаг, указывающий, искать по времени записи в БД (true) или по времени привязки (false)"""
    time_step: conint(ge=1, le=60) = 1
    """Шаг времени в секундах"""
    line_type: LineType = LineType.LINES_MARKERS
    """Тип линии"""
    data_field: DataField = DataField.DELTA
    """Название поля в таблице БД"""
    display_rejected: bool = False
    """Отображение отбракованных невязок"""
    y_axis_limit: Optional[Union[int, float]] = None
    """Число для ограничения оси Y"""


@dataclass
class ProcessedResidualData:
    """
    Формат данных на выходе функции обработки невязок.

    Содержит уникальные комбинации НКА и БИС, а также информацию о
    поле данных и типе линии для графиков.

    Attributes:
        unique_nka_bis (Dict[Tuple[int, int, int], Dict[str, List[float]]]): Уникальные комбинации НКА, БИС и сигнал1 с соответствующими данными
        data_field (DataField): Название поля в таблице БД
        line_type (LineType): Тип линии для график
        x_axis_label (str): Подпись оси X
    """
    unique_nka_bis: Dict[Tuple[int, int, int], Dict[str, List[float]]]
    """Словарь с ключами (НКА, БИС, Сигнал1) и значением словарь где ключами являются DataField для поля в таблице БД (для оси Y) и timestamp для оси X"""
    data_field: DataField
    """Название поля в таблице БД"""
    line_type: LineType
    """Тип линии"""
    x_axis_label: str
    """Подпись оси X"""
