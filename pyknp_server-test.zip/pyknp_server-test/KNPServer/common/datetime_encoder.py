from json import JSONEncoder

from utils.lib.encoding.encode_datetime import encode_datetime


class DateTimeEncoder(JSONEncoder):
    # Override the default method
    def default(self, obj):
        return encode_datetime(obj)
