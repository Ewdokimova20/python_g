def set_headers(request, method='GET', content_type='application/json'):
    """
    Устанавливает заголовки для ответов клиенту
    """
    request.setHeader('Access-Control-Allow-Origin', '*')
    request.setHeader('Access-Control-Allow-Methods', method)
    request.setHeader('Access-Control-Allow-Headers', 'x-prototype-version, x-requested-with, content-type')
    request.setHeader('Access-Control-Max-Age', '2520')  # 42 hours
    request.setHeader('Cache-Control', 'no-store')
    request.setHeader('Content-Type', content_type)
    return request
