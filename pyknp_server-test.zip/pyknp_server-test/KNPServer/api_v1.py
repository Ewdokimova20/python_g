from twisted.web.resource import NoResource

from KNPServer.endpoints.di_reception_control import DIReceptionControl
from KNPServer.endpoints.endpoints import *
from KNPServer.endpoints.generalized_opmessage import generalized_opmessage_resource
from KNPServer.endpoints.meas_reception_control import MeasReceptionControl
from KNPServer.endpoints.residuals.chart_residuals.chart_residuals import ChartResiduals
from KNPServer.endpoints.residuals.history_residuals import ArchiveResidualsTable
from KNPServer.endpoints.residuals.residuals_csv_export import ResidualsCSVExport
from KNPServer.endpoints.si_embedding_verification_resource import SIEmbeddingVerificationResource

api_v1 = NoResource()
di_resource = CustomResource()
api_v1.putChild(b'kill', KillPoint())
api_v1.putChild(b'di', di_resource)
di_resource.putChild(b'l1of', L1OFDiList())
di_resource.putChild(b'l2of', L2OFDiList())
di_resource.putChild(b'l1sf', L1SFDiList())
di_resource.putChild(b'l1oc', L1OCDiList())
di_resource.putChild(b'l3oc', L3OCDiList())
di_resource.putChild(b'l1sc', L1SCDiList())
di_resource.putChild(b'l2sc', L2SCDiList())
di_resource.putChild(b'l2ksi', L2KSIDiList())
api_v1.putChild(b'packet_queue', PacketQueue())
api_v1.putChild(b'connection_status', ConnectionStatus())
api_v1.putChild(b'residuals', Residuals())
api_v1.putChild(b'residuals_rejected', ResidualsRejected())
api_v1.putChild(b'residual_groups', ResidualGroups())
api_v1.putChild(b'archive_residuals', ArchiveResiduals())
api_v1.putChild(b'history_residuals', ArchiveResidualsTable())
api_v1.putChild(b'chart_residuals', ChartResiduals())
api_v1.putChild(b'opmessage', OpMessages())
api_v1.putChild(b'ground_call', GroundCall())
api_v1.putChild(b'not_in_time', DigitalInfoNotInTime())
api_v1.putChild(b'tk_not_sequential', TKNotSequential())
api_v1.putChild(b'nav_solution', NavSoltion())
api_v1.putChild(b'nav_solution_groups', NvzGroups())
api_v1.putChild(b'archive_solutions', ArchiveNavSolution())
api_v1.putChild(b'nav_solution_analyse', NavSolutionAnalyse())
api_v1.putChild(b'cache_status', CacheStatus())
api_v1.putChild(b'receiver_status', ReceiverStatus())
api_v1.putChild(b'config', Config())
api_v1.putChild(b'bis_control_config', BisControlConfig())
api_v1.putChild(b'compare_DI_SI', ComparisonDISI())
api_v1.putChild(b'check_EI_neighbor_tk', CheckNeighborDI())
api_v1.putChild(b'version', CurrentVersion())
api_v1.putChild(b'nkas', NkaData())
api_v1.putChild(b'si', SIRecords())
api_v1.putChild(b'parsed_si', SIRecord())
api_v1.putChild(b'check_p4', CheckP4inFrame())
api_v1.putChild(b'split_si', SIRecordPhrases())
api_v1.putChild(b'check_neighbor_SI', CheckNeighborSI())
api_v1.putChild(b'pdop_start', PDOP_Start())
api_v1.putChild(b'pdop_status', PDOP_Status())
api_v1.putChild(b'pdop_stop', PDOP_Stop_calculate())
api_v1.putChild(b'almanac', AlmanacSlots())
api_v1.putChild(b'visibility_zones', VisibilityZones())
api_v1.putChild(b'immediate_DI_and_SI_comparison', ImmediateDISIComparison())
api_v1.putChild(b'almanac_DI_and_SI_comparison', AlmanacDISIComparison())
api_v1.putChild(b'single_almanac_DI_and_SI_comparison', SingleAlmanacDISIComparison())
api_v1.putChild(b'residuals_csv', ResidualsCSVExport())
api_v1.putChild(b'meas_reception_data', MeasReceptionControl())
api_v1.putChild(b'di_reception_data', DIReceptionControl())
api_v1.putChild(b'generalized_opmessage', generalized_opmessage_resource)
api_v1.putChild(b'angles_table', AnglesTable())

signal_flags_resource = SignalFlags()
api_v1.putChild(b'signal_flags', signal_flags_resource)
signal_flags_resource.putChild(b'ground_call', MessageGroundCall())
signal_flags_resource.putChild(b'delete', SignalFlagsDelete())
signal_flags_resource.putChild(b'mark_as_seen', SignalFlagsApprove())

signal_flags_filters = SignalFlagsFilter()
signal_flags_resource.putChild(b'mute_alarm', signal_flags_filters)
signal_flags_filters.putChild(b'nka', SignalFlagsFilterByNka())
signal_flags_filters.putChild(b'combination', SignalFlagsFilterByCombination())

bis_resource = Bis_Info()
bis_status_resource = BisesStatuses()
api_v1.putChild(b'bis', bis_resource)
bis_resource.putChild(b'status', bis_status_resource)
bis_status_resource.putChild(b'general', GeneralBisStatus())

packet_counters_resource = BisesSummaryCounter()
api_v1.putChild(b'packet_counters', packet_counters_resource)
packet_counters_resource.putChild(b'packet_type', BisesPacketCounter())
packet_counters_resource.putChild(b'nka_message', NkasMessageCounter())
packet_counters_resource.putChild(b'signals_message', SignalsMessageCounter())

db_connection_resource = CustomResource()
api_v1.putChild(b'db_connection', db_connection_resource)
db_connection_resource.putChild(b'tldb', CheckTldbConnection())
db_connection_resource.putChild(b'cdb', CheckCdbConneciton())
db_connection_resource.putChild(b'ldb', CheckLdbConneciton())

api_v1.putChild(b'si_embedding_verification', SIEmbeddingVerificationResource())

# FIXME Рассмотреть возможность записывать детей ресурсов не тут, а в сами классах в виде:
# class SignalFlags(Resource):
#     def __init__(self):
#         Resource.__init__(self)
#         self.putChild(b'ground_call', MessageGroundCall())
#         self.putChild(b'delete', SignalFlagsDelete())
#         self.putChild(b'mark_as_seen', SignalFlagsApprove())
#         self.putChild(b'mute_alarm', SignalFlagsFilterResource())
