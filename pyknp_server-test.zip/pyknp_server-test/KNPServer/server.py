"""Реализация сервера КНП на twisted

Скрипт описания сервера КНП и его endpoint'ов.
"""
import logging
import os
import pathlib

from twisted.web import server
from twisted.web.resource import NoResource
from twisted.web.static import File

import global_data.config_schema
from KNPServer.api_v1 import api_v1


# web-интерфейс и по совместительству корневой элемент twisted
# вместо 404 отдаёт index.html
class VueWebAppFiles(File):
    childNotFound = File(pathlib.Path(__file__).resolve().parents[1].joinpath('app/index.html'))


root = VueWebAppFiles(pathlib.Path(__file__).resolve().parents[1].joinpath('app'))

# корень api
api = NoResource()
root.putChild(b'api', api)
api.putChild(b'v1', api_v1)


# раздаем мелодию для сигнализации
def set_content_type(request):
    if request.path == b'/alarm.mp3':
        request.setHeader(b'content-type', b'audio/mpeg')


try:
    if os.path.isfile(global_data.config_schema.config["general"]["path_alarm"]) and \
            global_data.config_schema.config["general"]["path_alarm"].endswith(".mp3"):
        root.putChild(b'alarm.mp3', File(global_data.config_schema.config["general"]["path_alarm"]))
        root.addSlash = True
        root.processors = {b'mp3': [set_content_type]}
    else:
        raise FileNotFoundError("Файл, расположенный в general.path_alarm, не найден или это не mp3 файл")
except FileNotFoundError as e:
    logging.error("Не удалось найти файл alarm.mp3: %s", e)

KNPServer = server.Site(root)
