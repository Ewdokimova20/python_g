import logging
import datetime

from peewee import PeeweeException
from global_data.config_schema import config
from peewee import Model, PostgresqlDatabase, IntegerField, FloatField, BooleanField, DateTimeField, CharField

ldb_pool = {}
resides_pool = {}
nvz_pool = {}
"""Два словаря, содержащие уже подключенные к суточным ЛБД классами для переписываемых в них типов"""

knp_lbd_zero_timestamp = datetime.datetime(year=2018, day=1, month=1)
"""Опорное время, от которого отсчитывается номер суточной ЛБД. Для опорной даты номер будет равен 1"""

KNP_DATABASE_COUNT = 14
"""Количество суточных ЛБД. Например, для значения 14 их номера будут с 1 по 14"""


def init_pools(pool_key: int, connection_object: PostgresqlDatabase):
    """Инициализация словарей, содержащий подключенных к суточным ЛБД классам. Для каждой подключенной ЛБД определяем
    однотипные классы, используемые как модели для записи перемещаемых данных. На их основе вызываются методы записи в
    БД. Нужно всё это чтобы не объявлять 14 классов невязок и 14 классов НВЗ (ибо субкласс Meta по документации не
    заменяется на лету)"""

    class LocalModel(Model):
        """
        Базовый класс для записи в БД
        предопределяет класс Meta для всех классов, наследующих класс Model
        """
        class Meta:
            database = connection_object
            schema = config['postgresql']['schema']  # по умолчанию knpresults

    class Residual(LocalModel):
        """Результаты расчета невязок, переписываемые из ТЛБД в суточную ЛБД"""

        bis_id: int = IntegerField()
        """БИС, для которого посчитаны невязки. Не используем первичный ключ дабы не тащить все словари за собой.
        Идентификатор численно равен: номер станции*100 + номер БИС. Это взаимооднозначное отображение, если номера БИС
        строго меньшее 100."""
        nka_id: int = IntegerField()
        """Системный номер НКА, для которого посчитаны невязки. Не используем первичный ключ дабы не тащить все словари
        за собой."""
        signal_1_id: int = IntegerField()
        """Первый тип сигнала. Не используем первичный ключ дабы не тащить все словари за собой.
        Код сигнала согласно ПИЛВ СПО КНП"""
        signal_2_id: int = IntegerField()
        """Первый тип сигнала. Не используем первичный ключ дабы не тащить все словари за собой.
        Код сигнала согласно ПИЛВ СПО КНП"""
        residual: float = FloatField()
        """Величина невязки"""
        speed_residual: float = FloatField()
        """Величина невязки псевдоскорости, м/с"""
        average: float = FloatField(default=None, null=True)
        """Среднее по 'хорошим' невязкам"""
        delta: float = FloatField(default=None, null=True)
        """Отклонение от среднего"""
        status: bool = BooleanField(default=False)
        """Статус признания 'хорошей' невязкой по критерию разницы со средней"""
        y_comb_1: float = FloatField(null=True, default=None)
        """Y-комбинация по сигналу 1"""
        y_comb_2: float = FloatField(null=True, default=None)
        """Y-комбинация по сигналу 2"""
        distance: float = FloatField()
        """Рассчетная дальность от БИС до НКА"""
        ionosphere_free_combination: float = FloatField(null=True, default=None)
        """Безионосферная комбинация"""
        tropo_delay: float = FloatField()
        """Тропосферная задержка"""
        time_freq_correction: float = FloatField()
        """Частотно-временная поправка (?)"""
        signal1_pseudorange: float = FloatField()
        """Псевдодальность по сигналу 1"""
        signal2_pseudorange: float = FloatField(null=True, default=None)
        """Псевдодальность по сигналу 2"""
        nka_x: float = FloatField(default=0)
        """x-координата НКА"""
        nka_y: float = FloatField(default=0)
        """y-координата НКА"""
        nka_z: float = FloatField(default=0)
        """z-координата НКА"""
        nka_elevation: float = FloatField(default=0)
        """Угол места нка на момент получения сигнала"""
        nka_in_guaranteed_elevation: bool = BooleanField(default=True)
        """НКА находится на угле места гарантированного приема"""
        timestamp: datetime.datetime = DateTimeField()
        """Время, на которое рассчитана невязка"""
        db_timestamp: datetime.datetime = DateTimeField(default=datetime.datetime.now)
        """Время записи в БД"""

    class KNPNavSolution(LocalModel):
        """Решение навигационной задачи силами КНП, переписываемые из ТЛБД в суточную ЛБД"""

        bis_id: int = IntegerField()
        """БИС, для которого посчитаны невязки. Не используем первичный ключ дабы не тащить все словари за собой.
        Идентификатор численно равен: номер станцции*100 + номер БИС. Ото взаимооднозначное отображение, если номера БИС 
        строго меньшее 100."""
        timestamp: datetime.datetime = DateTimeField()
        """Время, на которое получено решение"""
        latitude: float = FloatField()
        """Широта, градусы"""
        longitude: float = FloatField()
        """Долгота, градусы"""
        height: float = FloatField()
        """Высота, метры"""
        x: float = FloatField()
        """x-координата, метры"""
        y: float = FloatField()
        """y-координата, метры"""
        z: float = FloatField()
        """z-координата, метры"""
        E: float = FloatField()
        """E-координата (восток), метры"""
        N: float = FloatField()
        """отклонение по y-координате от опорного значения, метры"""
        U: float = FloatField()
        """U-координата (верх), метры"""
        dt: float = FloatField()
        """Смещение шкалы времени БИС от шкалы ГЛОНАСС в метрах"""
        distance: float = FloatField()
        """расстояние от опорной точки, метры"""
        GDOP: float = FloatField(default=0)
        """Geometric dilution of precision"""
        threshold_exceeded: bool = BooleanField(default=0)
        """Флаг превышения порога расстояния решения от опорных координат БИС"""
        nka_list: str = CharField(max_length=64)
        """Список системных номеров НКА, по невязкам которых решена задача"""
        db_timestamp: datetime.datetime = DateTimeField(default=datetime.datetime.now)
        """Время записи в БД"""

    """Сохраняем локально определенные типы данных для дальнейшей инстанциализации"""
    resides_pool[pool_key] = Residual
    nvz_pool[db_number] = KNPNavSolution


"""Приведенный далее код выполняется при инициализации. Он устанавливает подключеня и определяет типы объектов,
используемых для переписывания данных в ЛБД"""
for i in range(14):
    try:
        db_number = i + 1

        """Определяем базовую часть имени суточных ЛБД"""
        db_instance_name = config['postgresql']['dbname'] + str(db_number)

        """Устанавливаем соединение"""
        concrete_connection = PostgresqlDatabase(db_instance_name,
                                                 user=config['postgresql']['username'],
                                                 password=config['postgresql']['password'],
                                                 host=config['postgresql']['host'],
                                                 port=config['postgresql']['port'])
        logging.info(f"Подключение к ЛБД СПО КНП с номером {str(db_number)} прошло успешно")
        ldb_pool[db_number] = concrete_connection

        """Записываем в элемент словаря с соответствующим ключом определения классов, для записи данных"""
        init_pools(db_number, concrete_connection)
    except (KeyError, PeeweeException) as err:
        logging.error('Ошибка подключения к ЛБД СПО КНП. Проверьте, все ли настройки присутствуют в файле в конфигурации. ' + str(err))


def get_ldb_connection_status() -> bool:
    try:
        target_db_number = determine_target_db_number(datetime.datetime.now())
        resides_pool[target_db_number].select().exists()
        return True
    except (KeyError, PeeweeException):
        return False


def determine_target_db_number(row_timestamp: datetime.datetime) -> int:
    """Ф-я определения для конкретной строки номера суточной БД, в которую та должна быть записана.

    Как можно оптимизировать, если стремиться к идеалу, это место:
    0. Определить номер текущий суток i и граничное время удаления t
    1. Запросить записи в границах суток i, но меньших, чем t
    2. Если таких данных нет, то выход.
    3. Если что-нибудь вернулось, то переписать в соответствующую суточную ЛБД (для всех таких записей её номер один)
    4. Уменьшить i и перейти к шагу 1.

    Хотя это будет чуть быстрее, но трудозатраты на такую реализацию оценены больше, чем польза от неё.
    Недостатком относительно текущей организации является то, что если данные содержатся в интервалах дней i и i-2,
    то данные ранее i-1 дня будут недокопированы, а послу удаления они потеряются."""

    """Определяем количество дней с опорной даты"""
    row_day = int(row_timestamp.timestamp() - knp_lbd_zero_timestamp.timestamp()) // 86400
    """Не переводим время, т.к. остальные компоненты корректно будут работать в ШВ ГЛОНАСС (МДВ)"""
    return 1 + (row_day % KNP_DATABASE_COUNT)


def store_resides_to_bis_knp(data_list):
    for value in data_list:

        """Определяем, куда, в какую суточную БД, писать"""
        target_db_number = determine_target_db_number(value.timestamp)

        """"Записываем данные но с разыменованием внешни ключей. Это позволит восстановить ход событий если что
        
        Слабое место: в рамках разыменования ссылок на измерения выполняются доп.запросы в ЛБД. Устранить это не
        получится так просто, т.к. даже в случае join'а будет выполнен запрос"""
        resides_pool[target_db_number].insert(bis_id=value.bis.station_id*100+value.bis.bis_number,
                                              nka_id=value.nka_id,
                                              signal_1_id=value.signal_1,
                                              signal_2_id=value.signal_2,
                                              residual=value.residual,
                                              speed_residual=value.speed_residual,
                                              y_comb_1=value.y_comb_1,
                                              y_comb_2=value.y_comb_2,
                                              distance=value.distance,
                                              ionosphere_free_combination=value.ionosphere_free_combination,
                                              tropo_delay=value.tropo_delay,
                                              time_freq_correction=value.time_freq_correction,
                                              signal1_pseudorange=value.signal1_pseudorange,
                                              signal2_pseudorange=value.signal2_pseudorange,
                                              nka_x=value.nka_x,
                                              nka_y=value.nka_y,
                                              nka_z=value.nka_z,
                                              nka_elevation=value.nka_elevation,
                                              nka_in_guaranteed_elevation=value.nka_in_guaranteed_elevation,
                                              timestamp=value.timestamp,
                                              db_timestamp=value.db_timestamp).execute()


def store_nvz_to_bis_knp(data_list):
    for solution in data_list:

        """Определяем, куда, в какую суточную БД, писать"""
        target_db_number = determine_target_db_number(solution.timestamp)

        """"Записываем данные но с разыменованием внешни ключей. Это позволит восстановить ход событий если что"""
        nvz_pool[target_db_number].insert(bis_id=solution.bis.station_id*100+solution.bis.bis_number,
                                          latitude=solution.latitude,
                                          longitude=solution.longitude,
                                          height=solution.height,
                                          x=solution.x,
                                          y=solution.y,
                                          z=solution.z,
                                          E=solution.E,
                                          N=solution.N,
                                          U=solution.U,
                                          dt=solution.dt,
                                          distance=solution.distance,
                                          GDOP=solution.GDOP,
                                          threshold_exceeded=solution.threshold_exceeded,
                                          nka_list=solution.nka_list,
                                          timestamp=solution.timestamp,
                                          db_timestamp=solution.db_timestamp).execute()
