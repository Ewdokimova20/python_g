# Сервер КНП

- [Первое развертывание](#первое-развертывание)
- [Настройка конфигов](#настройка-конфигов)
  - [Основной конфиг `config.ini`](#основной-конфиг-configini)
  - [Конфиг с координатами беззапросных измерительных станций (БИС) `coordinates.cfg`](#конфиг-с-координатами-беззапросных-измерительных-станций-бис-coordinatescfg)
  - [Конфиг с пороговыми значениями `comparison_si_threshold.cfg`](#конфиг-с-пороговыми-значениями-comparison_si_thresholdcfg)
  - [Конфиг с настройков портов СПО сети БИС `bis_port_settings.cfg`](#конфиг-с-настройков-портов-спо-сети-бис-bis_port_settingscfg)
  - [Еще один конфиг](#еще-один-конфиг)
- [Запуск в PyCharm](#запуск-в-pycharm)
- [Секции основного конфига `config.ini`](#секции-основного-конфига)
  - [Секция `[server]`](#секция-server)
  - [Секция `[general]`](#секция-general)
  - [Секция `[decimation]`](#секция-decimation)
  - [Секция `[write_instance_to_ldb]`](#секция-write_instance_to_ldb)
  - [Секция `[di_control]`](#секция-di_control)
  - [Секция `[zrv_analyse]`](#секция-zrv_analyse)
  - [Секция `[cache]`](#секция-cache)
  - [Секция `[opmessage]`](#секция-opmessage)
  - [Секция `[SI]`](#секция-si)
  - [Секция `[interface]`](#секция-interface)
  - [Секция `[measurement_reception_control]`](#секция-measurement_reception_control)
  - [Секция `[bis_config]`](#секция-bis_config)
  - [Секция `[PDOP]`](#секция-pdop)
- [Окружение](#окружение)
  - [Установка и запуск ПКИ (имитатора)](#установка-и-запуск-пки-имитатора)
  - [Подключение к СПО сети БИС НКУ в СФУ](#подключение-к-спо-сети-бис-нку-в-сфу)
- [WEB-интерфейс](#web-интерфейс)
- [Запуск исполняемого файла из терминала](#запуск-исполняемого-файла-из-терминала)
- [API](#api)
  - [Перечень точек доступа с описанием возвращаемого результата](#перечень-точек-доступа-с-описанием-возвращаемого-результата)
  - [Ответ на запросы](#ответ-на-запросы)
  - [HTTP-статусы для ответа](#http-статусы-для-ответа)

## Первое развертывание

Для клонирования репозитория, настройки venv и установки зависимостей обратитесь
к [этой инструкции](https://gitlab.iss-reshetnev.ru/105/knp/pyknp_server/-/wikis/%D0%A0%D1%83%D0%BA%D0%BE%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%B0/pyknp-server-setup)

## Настройка конфигов

### Основной конфиг `config.ini`

[Пример конфига](https://gitlab.iss-reshetnev.ru/105/knp/pyknp_server/-/blob/develop/config_default.ini?ref_type=heads)
находится в корне проекта в файле `config_default.ini`. По умолчанию файл конфига должен
располагаться рядом с main.py и называться `config.ini`. Нужно создать файл с названием `config.ini` и скопировать туда
содержимое файла `config_default.ini`.



<details>
  <summary>Пример <code>config.ini</code></summary>

```json lines
[
  bis
]
port = 5030
host = localhost

[
  general
]
path_alarm = ./alarm.mp3
path_values_pattern_l1sf = ./config/values_pattern_L1SF.cfg
reject_cache_depth = 20
path_comparison_si_threshold = ./config/comparison_si_threshold.cfg
path_bis_port_settings = ./config/bis_port_settings.cfg
use_average_residuals = yes

[
  bis_control
]
signal_validity_percent = 90
signal_validity_analyzing_time = 10
station_receiving_error_threshold = 1
station_validity_error_threshold = 1
nvz_solution_inaccuracy_threshold = 2
residual_pairs_difference_threshold = 5
residual_average_difference_threshold = 10
speed_residual_inaccuracy_threshold = 0.1
min_elevation_for_nav_solution = 15
check_packet_receive_time = no
check_di_receive_in_time = no
use_troposphere_model = 1
log_level = 0
packets_delay_threshold = 10
min_packets = no
acceptable_packets_delay = 10
min_amount_bis_for_generalized_opmessage = 1
residual_averaging_interval = 5
average_residual_averaging_interval = 60
max_diff_between_local_and_packet_time = 3600
meteodata_actual_duration = 600

[
  decimation
]
residuals_decimation_interval = 10
meteoparameters_decimation_interval = 30
opmessage_decimation_interval = 30
nav_solution_decimation_interval = 30
controls_decimation_interval = 30

[
  write_instance_to_ldb
]
opmessage = yes
control = no
navsolution = no
knpopmessage = no
knpopsummessage = no
bulk_string_insert_interval = 2

[
  reliability_control_elevation
]
default = 15
1 = 15
4 = 15
14 = 15
20 = 15

[
  receive_control_elevation
]
default = 9
1 = 9
4 = 9
14 = 9
20 = 9

[
  min_elevation
]
default = 3
1 = 5
4 = 5
14 = 5
20 = 5

[
  solution_distance_threshold
]
default = 10
0 = 15

[
  postgresql
]
host = localhost
port = 5432
username = postgres
password = 12345678
tldbname = tldb_test
dbname = test
schema = public

[
  cdb
]
host = localhost
port = 5432
username = postgres
password = 12345678
dbname = uragan_os
schema = common

[
  server
]
port = 8083
service_interval = 60
storage_interval = 720000
copy_old_data = no
ldb = ldb.sqlite3
allowed_hide_intervals = 5,20, 100
store_raw_packets = no

[debug]
enable_debug_level_logging = yes
peewee_logging = yes
bis_communication_logging = no
packet_stat_logging = yes

[station_coordinates]
path = ./config/coordinates.cfg

[zrv_analyse]
step = 300
limit = 270000

[log]
path = ./log
log_file_length = 100000000
log_backup_num = 10

[generalized_di]
lag_interval = 60
compose_period = 15
frame_search_depth_for_operational_control = 20000
exclude_bad_frames = yes

[di_control]
tk_difference = 180

[PDOP]
full_file_name_pdop = log/PDOPS_0.txt
full_file_name_availability = log/availability_sec_data_0.txt
nka_elevation_mask = 5
max_pdop_na_spread = 2
pdop_time_step = 12000
availability_time_step = 3000

[SI]
search_depth_169 = 3
search_depth_701 = 5
search_depth_893 = 3
search_depth_895 = 7
search_depth_921 = 7300
search_depth_P4 = 6

[cache]
lifetime_si_cache = 300

[interface]
history_residuals_search_depth = 200000
history_residuals_chart_max_record_count = 100000

[measurement_reception_control]
sufficient_rate_for_zone_meas_count = 0.7
meas_acceptable_delay = 5
meas_acceptable_absence = 5
di_acceptable_error_level = 0.05

[opmessage]
auto_finalize_timeout = 60
auto_approve_timeout = 180

[nka_data_signals]
1 = [730, "14\u0424113", ["L2OF", "L1SF", "L2SF", "L3OCd"]]
2 = [747, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
3 = [744, "14\u0424113", ["L2OF", "L1SF", "L2SF", "L1OCd"]]
4 = [759, "14\u0424113", ["L2OF", "L1SF", "L2SF", "L1OCd"]]
5 = [756, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
6 = [733, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
7 = [745, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
8 = [743, "14\u0424113", ["L2OF", "L1SF", "L2SF", "L1OCd"]]
9 = [702, "14\u0424143", ["L1OF", "L2OF", "L1SF", "L2SF", "L3OCp", "L3OCd"]]
10 = [723, "14\u0424113", ["L2OF", "L1SF", "L2SF", "L1OCd"]]
11 = [705, "14\u0424143", ["L1OF", "L2OF", "L1SF", "L2SF", "L3OCp", "L3OCd"]]
12 = [758, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
13 = [721, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
14 = [752, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
15 = [757, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
16 = [761, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
17 = [751, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
18 = [754, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
19 = [720, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L1OCd"]]
20 = [719, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
21 = [755, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF", "L3OCp", "L3OCd"]]
22 = [706, "14\u0424143", ["L1OF", "L2OF", "L1SF", "L2SF"]]
23 = [732, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
24 = [760, "14\u0424113", ["L1OF", "L2OF", "L1SF", "L2SF"]]
25 = [707, "14\u0424143", ["L1OF", "L2OF", "L1SF", "L2SF", "L3OCp", "L3OCd", "L1OCp", "L1OCd", "L1SCp", "L1SCd", "L2OCp", "L2\u041a\u0421\u0418", "L2SCp", "L2SCd"]]
26 = [703, "14\u0424143", ["L2OF", "L1SF", "L2SF", "L3OCp", "L3OCd", "L1OCp", "L1OCd", "L1SCp", "L1SCd", "L2OCp", "L2\u041a\u0421\u0418", "L2SCp", "L2SCd"]]


```

</details> 

### Конфиг с координатами беззапросных измерительных станций (БИС) `coordinates.cfg`

Необходимо разместить в проекте файл `coordinates.cfg`, который будет содержать координаты всех обрабатываемых БИС в
формате json.

Можно положить в любое место и прописать относительный путь от корня проекта до этого файла в `config.ini`
в `[station_coordinates].path`. Рекомендуется для все настроечных файлов создать отдельную папку
(кроме `config.ini`, он должен лежать в корне)

<details>
  <summary>Пример <code>coordinates.cfg</code></summary>

```json
[
  {
    "station": 1,
    "bis": 17,
    "coord_xyz": {
      "x": -171819.1746,
      "y": 3572207.7905,
      "z": 5263709.1333
    }
  },
  {
    "station": 14,
    "bis": 18,
    "coord_xyz": {
      "x": -220494.737768,
      "y": 3544084.697599,
      "z": 5280768.654656
    }
  }
]

```

</details> 

### Конфиг с пороговыми значениями `comparison_si_threshold.cfg`

Файл с пороговыми значениями для сравнения ЭИ, ЧВП и альманаха с СИ `comparison_si_threshold.cfg` должен содержать
содержать данные в формате json.

Этот файл можно положить в любое место и прописать относительный путь от корня проекта до этого файла в `config.ini`
в `[general].path_comparison_si_threshold`. Рекомендуется для все настроечных файлов создать отдельную папку
(кроме `config.ini`, он должен лежать в корне)

<details>
  <summary>Пример <code>comparison_si_threshold.cfg</code></summary>

```json
{
  "tau": 3e-9,
  "gamma": 3e-12,
  "x": 2,
  "y": 2,
  "z": 2,
  "x_L3": 2,
  "y_L3": 2,
  "z_L3": 2,
  "Vx": 1,
  "Vy": 1,
  "Vz": 1,
  "Ax": 0.01,
  "Ay": 0.01,
  "Az": 0.01,
  "Ax_L3": 0.01,
  "Ay_L3": 0.01,
  "Az_L3": 0.01,
  "dX": 1,
  "dY": 1,
  "dZ": 1,
  "delta_T": 1e-2,
  "t_lambda": 0.1,
  "epsilon": 2e-6,
  "d_delta_T": 2e-4,
  "omega": 1e-4,
  "lambda_": 3e-6,
  "delta_i": 3e-6,
  "tb": 30,
  "beta": 310,
  "tau_a": 310
}
```

</details> 

### Конфиг с настройков портов СПО сети БИС `bis_port_settings.cfg`

Файл с пороговыми значениями для сравнения ЭИ, ЧВП и альманаха с СИ `bis_port_settings.cfg` должен содержать
содержать данные в формате json. Ключ верхнего уровня - номер порта СПО сети БИС НКУ, значение - массив словарей,
которые содержат номер станции и номер БИС. Данный json сопоставляет, данные каких пар станция/бис транслируются с
указанных в портов.

Можно положить в любое место и прописать относительный путь от корня проекта до этого файла в `config.ini`
в `[general].path_bis_port_settings`. Рекомендуется для все настроечных файлов создать отдельную папку
(кроме `config.ini`, он должен лежать в корне)

<details>
  <summary>Пример <code>bis_port_settings.cfg</code></summary>

```json
{
  "5040": [
    {
      "station": 1,
      "bis_number": 17
    },
    {
      "station": 2,
      "bis_number": 17
    }
  ],
  "5041": [
    {
      "station": 1,
      "bis_number": 18
    }
  ],
  "5030": [
    {
      "station": 14,
      "bis_number": 18
    }
  ]
}

```

</details> 

### Еще один конфиг
Есть еще один конфиг `values_pattern_L1SF`, который также надо разместить вместе с остальными дополнительным конфигами. 

Можно положить в любое место и прописать относительный путь от корня проекта до этого файла в `config.ini`
в `[general].path_values_pattern_l1sf`. Рекомендуется для все настроечных файлов создать отдельную папку
(кроме `config.ini`, он должен лежать в корне)


## Запуск в PyCharm

При настроенном интерпретаторе по п. [Первое развертывание](#первое-развертывание) запуск производится по кнопке Run либо Debug.

В качестве конфигурации нужно добавить файл main.py (он же является точкой входа в программу).

По умолчанию никаких ключей запуска прописывать не нужно.

Перед запуском вручную создать папку с названием `log` в корне проекта. Туда будут писаться логи.



## Окружение

Для полноценной работы СПО КНП требуется поток данных от СПО сети БИС НКУ (при штатном функционировании).

При разработке варианты обеспечить поток следующие:

1. Развернуть программный комплекс имитации (ПКИ), как локально, где ведется разработка СПО КНП, так и удаленно на
   другой виртуальной машине, с пробрасыванием туннеля до локальной машины.
2. Использовать данные СПО сети БИС, развернутого в СФУ и подключенного к стенду, получающему данные от реальных НКА.

### Установка и запуск ПКИ (имитатора)

#### Установка

Если ПКИ не установлен на машине, то необходимо
воспользоваться [этой инструкцией](https://gitlab.iss-reshetnev.ru/105/knp/pyknp_server/-/wikis/%D0%9F%D0%9A%D0%98/%D0%A3%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B0-%D0%9F%D0%9A%D0%98)
.

#### Запуск

Запуск ПКИ осуществляется
согласно [этой инструкции](https://gitlab.iss-reshetnev.ru/105/knp/pyknp_server/-/wikis/%D0%9F%D0%9A%D0%98/%D0%97%D0%B0%D0%BF%D1%83%D1%81%D0%BA-%D0%9F%D0%9A%D0%98-(%D0%B8%D0%BC%D0%B8%D1%82%D0%B0%D1%82%D0%BE%D1%80%D0%B0))
.

### Подключение к СПО сети БИС НКУ в СФУ

Для подключения к СПО сети БИС НКУ в СФУ необходимо иметь доступ к серверу `astrasfuvpn` в демилитаризованной зоне (
ДМЗ) `(192.168.30.203)` со своей рабочей машины под Windows.

Если доступа нет, получить его можно только через служебку на начальника отдела 714 с согласованием с ЗГД по
безопасности. Образец служебки: **105-4/930 от 01.10.2024**.

Если доступ есть, то нужно настроить два туннеля, один для соединения с сервером `astrasfuvpn` на машине с Windows, а
второй - для соединения машины с Windows c машиной lab105-astra.

```

192.168.30.203
login: admin105
pass: v6n@str@

```

СПО сети БИС доступно по:

```

10.2.3.200:9800

```

Настройка туннеля для putty, который пробрасывает удаленный порт 9800 на локальный порт 6202:

```

L6202 10.2.3.200:9800

```

После поднятия туннеля сервер КНП может подключаться к localhost:6202.

## WEB-интерфейс

Доступ к web-интерфейсу КНП осуществляется по пути `localhost:[порт]`.

Порт указывается в `config.ini` в секции `[server]`.

1. Актуальную сборку интерфейса скачать [отсюда](https://gitlab.iss-reshetnev.ru/105/knp/webclient/-/packages). 

2. Выбрать самый свежий пакет, который оканчивается на `_dev` или `_stable`

3. Скачать, распаковать, все файлы из папки `dist` скопировать в `[имя папки с проектом]/app`



## Запуск исполняемого файла из терминала

Как правило, исполняемый файл имеет имя `knp` или `knp_YYYY-MM-DD`, где `YYYY` - год, `MM`- месяц, `DD` - дата.

Перед запуском нужно убедиться, что у файла есть соответствующие права, либо выполнить:

```

chmod a+x knp

```

Запуск СПО производится командой

```

./knp

```

Ключи для запуска (необязательные):

| Ключ | Описание | Значение                                                                     | По умолчанию | Пример |
|------|----------|------------------------------------------------------------------------------|--------------|--------|
| `-a` | IP-адрес хоста СПО сети БИС | IP-адрес                                                                     | - | `./ knp -a 127.0.0.1` |
| `-p` | Порт, на котором слушать СПО сети БИС | Номер порта                                                                  | - | `./ knp -p 5030` |
| `-c` | Конфигурационный файл | Путь до конфигурационного файла, если он лежит не рядом с исполняемым файлом | `config.ini` | `./ knp -c opt/config.ini` |
| `-d` | Режим ЦБД | old - старая структура ЦБД, new - новая структура ЦБД                        | `new` | `./ knp -d old` |
| `-s` | Флаг использования данных имитатора | Если указан — использовать имитатор ЦБД                                      | Выключен | `./knp -s` |

## API

Сервер отдает по http (порт - в соответствии с параметром ) данные для клиента в соответствии с таблицами

### Перечень точек доступа с описанием возвращаемого результата

> ВНИМАНИЕ!
> Данная секция устарела и давно не обновлялась. Многие данные могу не соответствовать действительности либо перечень
> больше.
> Конечные точки нужно описать в коде черед докстринг и сформировать таблицу сюда через чат-бот.

Адрес точки начинается с /api, затем идёт версия (например, /v1)

<details><summary>api/v1</summary>

| Точка                            | Описание                                                                                                                                | Формат ответа                                                                                                                                                                                                      | Пример                                                                                                                                                                                                                                                                                                                                                     |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| /packet_counters                 | Счетчики пакетов                                                                                                                        | ```{"station_number":{ "bis_number":{"packet": counter}}}```                                                                                                                                                       | `{"0": {"0": {"1": 7}}}`                                                                                                                                                                                                                                                                                                                                   |
| /current_visibility              | Текущее состояние радиовидимости по станция-комплект-НКА                                                                                | ```{"station_number":{ "bis_number":{"nka": visibility_status}}}```                                                                                                                                                | `{"0": {"0": {"1": 1}}}`                                                                                                                                                                                                                                                                                                                                   |
| /current_angles                  | Текущие углы места и азимуты. Необязательные параметры: nka - номер НКА, bis = ID БИС в ЛБД                                             | array: `[{"bis_id": int, "nka_number": int, "elevation": float, "azimuth": float, "timestamp": datetime}]`                                                                                                         | `[{"bis_id": 1, "nka_number": 2, "elevation": 4.8, "azimuth": 132.6, "timestamp": "2022-04-20T12:08:25"}]`                                                                                                                                                                                                                                                 |
| /signals_receive_status          | Флаги приема по НКА-сигнал-станция-комплект                                                                                             | ```{"nka":{ "signal_type":{"station_number": {"bis_number": receive_status}}}}```                                                                                                                                  | `{"13": {"9": {"4":{"12": 2}}}}`                                                                                                                                                                                                                                                                                                                           |
| /summary_signals_receive_status  | Обобщенные флаги приема по НКА-сигнал                                                                                                   | ```{"nka":{ "signal_type": signal_status}}```                                                                                                                                                                      | `{"6": {"14":  2}}`                                                                                                                                                                                                                                                                                                                                        |
| /signal_status                   | Обобщенные флаги годности по НКА-сигнал                                                                                                 | ```{"nka":{ "signal_type": signal_status}}```                                                                                                                                                                      | `{"6": {"14":  2}}`                                                                                                                                                                                                                                                                                                                                        |
| /residuals                       | Массив невязок. Необязательные параметры: limit (default 30) - глубина запроса в секундах, nka - номер НКА, bis - ID бис в ЛБД          | ```[{"id": int, "timestamp": datetime, "residual": float, "residual_speed": float, "nka": int, "bis": int, nka_elevation:float, nka_in_guaranteed_elevation: bool, status: bool, delta: float, average: float}]``` | `[{"id": 1821, "timestamp": "2022-01-28T06:31:53.000025", "residual": 7546.350567146462, "residual_speed": 0.350567146462, "nka": 4, "bis": 1, "nka_elevation": 14.0, "nka_in_guaranteed_elevation": false, "status": true, "delta": -1.2999924057867247, "average": 7547.6505595522485}]`                                                                 |
| /eph_on_border                   | Контроль согласованности ЭИ на соседних интервалах                                                                                      | ```{"nka": ephemerides_status}```                                                                                                                                                                                  | `{"1": 0, "2": 2, "3": 1}`                                                                                                                                                                                                                                                                                                                                 |
| /opmessage                       | Оперативные сообщения БИС                                                                                                               | array: TBD                                                                                                                                                                                                         | TBD                                                                                                                                                                                                                                                                                                                                                        |
| /ground_call                     | Оперативная ЦИ с установленным флагом "Вызов НКУ"                                                                                       | array: [l1of_digital_info]                                                                                                                                                                                         | см. ЦИ l1of_digital_info                                                                                                                                                                                                                                                                                                                                   |
| /not_in_time                     | Оперативная ЦИ, пришедшая не вовремя                                                                                                    | array: [l1of_digital_info]                                                                                                                                                                                         | см. ЦИ l1of_digital_info                                                                                                                                                                                                                                                                                                                                   |
| /tk_not_sequential               | Оперативная ЦИ, пришедшая с t_k не подряд                                                                                               | array: [{"nka_sys_number": nka_sys_number, "t_k": t_k, "diff": diff}]                                                                                                                                              | `[{"nka_sys_number": 4, "t_k": 993, "diff": 90}, {"nka_sys_number": 12, "t_k": 736, "diff": 180}, {"nka_sys_number": 19, "t_k": 797, "diff": 120}]`                                                                                                                                                                                                        |
| /nav_solution                    | Решение навигационной задачи. Необязательные параметры: limit (default 30) - глубина запроса в секундах, bis - ID бис в ЛБД             | array: [nav_solution]                                                                                                                                                                                              | см nav_solution                                                                                                                                                                                                                                                                                                                                            |
| /config                          | Конфигурация сервера                                                                                                                    | см. config                                                                                                                                                                                                         | см. config                                                                                                                                                                                                                                                                                                                                                 |
| /bis_control_config              | Прием и отдача конфига сервера в части БИС                                                                                              | см. bis_config                                                                                                                                                                                                     | см. bis_config                                                                                                                                                                                                                                                                                                                                             |
| /receiver_status                 | Статус соединения и приема данных от БИС                                                                                                | ```{"connected": bool, "data": bool}```                                                                                                                                                                            | `{"connected": true, "data": false}`                                                                                                                                                                                                                                                                                                                       |
| /cache_status                    | Состояние кэша функции расчета координат                                                                                                | plain text                                                                                                                                                                                                         | `CacheInfo(hits=102763481, misses=149082, maxsize=250000, currsize=149082)`                                                                                                                                                                                                                                                                                |
| /l1of_di                         | Цифровая информация L1OF. Обязательные параметры: nka - номер НКА; start, end - начальное и конечное датавремя в ISO 8601               | массив строк цифровой информации в виде "бинарных" строк, отсортированный по возрастанию времени получения                                                                                                         | `["1100101110001000010101111100001010001110000000010101111101101000001011101101", "1101110001010111000000111000000010101101011010010111111110011000010000000100", "1110100011010011000010001000000000100011011110101011001100001110110011100111"]`                                                                                                         |
| /l2ksi_di                        | Цифровая информация L2КСИ. Обязательные параметры: nka - номер НКА; start, end - начальное и конечное датавремя в ISO 8601              | массив строк цифровой информации в виде "бинарных" строк, отсортированный по возрастанию времени получения                                                                                                         | `["1100101110001000010101111100001010001110000000010101111101101000001011101101", "1101110001010111000000111000000010101101011010010111111110011000010000000100", "1110100011010011000010001000000000100011011110101011001100001110110011100111"]`                                                                                                         |
| /l3oc_di                         | Цифровая информация L3OC. Обязательные параметры: nka - номер НКА; start, end - начальное и конечное датавремя в ISO 8601               | массив строк цифровой информации в виде "бинарных" строк, отсортированный по возрастанию времени получения                                                                                                         | `["1100101110001000010101111100001010001110000000010101111101101000001011101101", "1101110001010111000000111000000010101101011010010111111110011000010000000100", "1110100011010011000010001000000000100011011110101011001100001110110011100111"]`                                                                                                         |
| /l1of_frames                     | Список кадров L1OF. Обязательные параметры: nka - номер НКА; bis - id БИС в ЛБД; start, end - начальное и конечное датавремя в ISO 8601 | массив метаинформации кадров цифровой информации L1OF (см. L1OF Meta)                                                                                                                                              | `[{"frame_id": 6620, "bis_id": 1, "station_id": 0, "nka": 24, "tk": 1598, "seq": 1503, "num": 3, "is_complete": true, "is_fifth": false, "timestamp": "2022-04-11T12:31:00"}, {"frame_id": 6628, "bis_id": 1, "station_id": 0, "nka": 24, "tk": 1599, "seq": 1504, "num": 4, "is_complete": true, "is_fifth": false, "timestamp": "2022-04-11T12:31:30"}]` |
| /l3oc_frames                     | Список кадров L3OC. Обязательные параметры: nka - номер НКА; bis - id БИС в ЛБД; start, end - начальное и конечное датавремя в ISO 8601 | массив метаинформации кадров цифровой информации L3OC (см. L1OF Meta, с учетом отсутствия параметров num и is_fifth)                                                                                               | `[{"frame_id": 6620, "bis_id": 1, "station_id": 0, "nka": 24, "tk": 1598, "seq": 1503, "is_complete": true, "timestamp": "2022-04-11T12:31:00"}, {"frame_id": 6628, "bis_id": 1, "station_id": 0, "nka": 24, "tk": 1599, "seq": 1504, "is_complete": true, "timestamp": "2022-04-11T12:31:30"}]`                                                           |
| /l1of_frame                      | Кадр L1OF. Обязательные параметры: id - ID кадра в ЛБД                                                                                  | Кадр цифровой информации L1OF (см. L1OF Frame)                                                                                                                                                                     | см. L1OF Frame                                                                                                                                                                                                                                                                                                                                             |
| /l3oc_frame                      | Псевдокадр L3OC. Обязательные параметры: id - ID кадра в ЛБД                                                                            | Кадр цифровой информации L3OC (см. L1OF Frame учитывая нерегулярную структуру псевдокадра)                                                                                                                         | см. L1OF Frame в части общей структуры, но учитывая неругулярный состав строк в псевдокадре                                                                                                                                                                                                                                                                |
| /bis                             | Список БИСов                                                                                                                            | ```[{'bis_id': int, 'bis_number': int, 'station_id': int}]```                                                                                                                                                      | ```[{"bis_id": 1, "bis_number": 1, "station_id": 0}]```                                                                                                                                                                                                                                                                                                    |
| /signal_flags                    | Сигнальные признаки. Выдается перечень сигнальных признаков, для которых требуется внимание оперратора.                                 | ```{"nka":{ "alarm_name":{ "signal_name":{"bis_name": {"source_name": {"first":datetime, "last":datetime, "count":datetime, combination:int}}}}}}```                                                               | ```{"6": {"AlarmId.unreliable_frame": {"L2OF": {"6/17": {"SourceId.BIS": {"first": "2023-05-15T09:12:12.212227", "last": "2023-05-15T09:20:41", "count": 18, "combination": 6200900011}}}}}}```                                                                                                                                                            |
| /signal_flags/approve (PATCH)    | Подтвердить ознакомление с сиг. признаками. В теле запроса: {} или {"combinations":[список]} При отсутствии списка удаляются все.       | См. "Ответ на POST"                                                                                                                                                                                                | {status:0}                                                                                                                                                                                                                                                                                                                                                 |
| /signal_flags/filter (GET)       | Получить перечень активных фильтров. Они являются общими для всех подключений.                                                          | ```{nka: {ид_НКА:datetime}, bis: {ид_БИС:datetime}, combination:{ид_комбинации:{"nka":int, "alarm":int, "signal":int, "bis":int, :source":int, "actual:datetime"}}, allowed_durations:{№: int}}```                 | ```{nka: {6:"2023-05-15T09:12:12.212227"}, bis: {3:"2023-05-16T09:12:12.212227"}, combination:{6200900011:{"nka":5, "alarm":2, "signal":9, "bis":1, :source":1, "actual":"2023-05-16T09:13:12.212227"}}, allowed_durations:{0: 3600, 1:86400}}```                                                                                                          |
| /signal_flags/filter/nka (POST)  | Установить фильтр на скрытие НКА. В теле запроса: {"duration":время_блокир_с, "items": [ид.НКА]}                                        | См. "Ответ на POST"                                                                                                                                                                                                | {status:0}                                                                                                                                                                                                                                                                                                                                                 |
| /signal_flags/filter/bis (POST)  | Установить фильтр на скрытие БИС. В теле запроса: {"duration":время_блокир_с, "items": [ид.БИС]}                                        | См. "Ответ на POST"                                                                                                                                                                                                | {status:0}                                                                                                                                                                                                                                                                                                                                                 |
| /signal_flags/filter/combination | Установить фильтр на скрытие конкретной комбинации. В теле запроса: {"duration":время_блокир_с, "items": [ид.комбинации]}               | См. "Ответ на POST"                                                                                                                                                                                                | {status:0}                                                                                                                                                                                                                                                                                                                                                 |

</details>

### Ответ на запросы

Сервер отвечает на запросы JSON соответствующей структуры. Для каждого ответа должен проставляться валидный код.
Статусы ошибок (коды начинаются с 4) должны сопровождаться сообщением об ошибке.
Ошибка предоставляется в виде строки текста в кодироке UTF-8.

### HTTP-статусы для ответа:

> ВНИМАНИЕ!
> Данная секция устарела и давно не обновлялась.
> Не все конечные точки отдают перечень кодов ниже.

| Статус | Описание              | Комментарий                                                                    |
|--------|-----------------------|--------------------------------------------------------------------------------|
| 200    | OK                    | Успешное выполнение запроса (обычно ответ на успешный  GET)                    |
| 201    | CREATED               | Отправляется при успешном создании сущности (ответ на POST, PATCH, PUT)        |
| 400    | BAD_DATA              | Невалидные данные для запроса                                                  |
| 404    | NOT_FOUND             | Запрос обработан успешно, но соответствующие данные для ответа не были найдены |
| 422    | UNPROCESSABLE_CONTENT | Запрос понятен, но сервер не может дать успешный ответ по разным причинам      |

## Секции основного конфига

> ВНИМАНИЕ!
> Скорее всего здесь приведено описание не всех секций и не всех параметров, необходимо обновить до актуального
> состояния и поддерживать в дальнейшем

### Секция `[server]`

| Величина               | Описание                                                                                                                        | Мин | Макс | По умолчанию |
|------------------------|---------------------------------------------------------------------------------------------------------------------------------|-----|------|--------------|
| service_interval       | Периодичность обслуживания (чистки) технологической ЛБД, секунды                                                                | 1   | -    | 600          |
| storage_interval       | Глубина хранения данных в технологической ЛБД, часы                                                                             | 1   | -    | 72           |
| copy_old_data          | Разрешение копирования устаревших данных, которые запланирован к удалению, в суточную ЛБД СПО КНП, строковый, yes или no        | no  | yes  | yes          |
| store_raw_packets      | Разрешение сохранения принимаемых от СПО сети БИС пакетов в ТЛБД для нужд отладки, yes или no                                   | no  | yes  | no           |
| tldbname               | Название ТЛБД на PostgreSQL                                                                                                     | -   | -    | -            |
| allowed_hide_intervals | Перечень разрешенных интервалов скрытия оператором СПО КНП сигнальных признаков, в секундах, разделенных запятыми, без пробелов | 1   | -    | не заданы    |

### Секция `[general]`

| Величина                     | Описание                                                                          | Мин | Макс | По умолчанию                  |
|------------------------------|-----------------------------------------------------------------------------------|-----|------|-------------------------------|
| reject_cache_depth           | Глубина кэша невязок для отбраковки                                               | 3   | 30   | 10                            |
| use_average_residuals        | Усреднять ли невязки для отображения на клиенте и для использования в решении НВЗ | no  | yes  | yes                           |
| path_alarm                   | Путь к звуковому файлу                                                            | -   | -    | ./alarm.mp3                   |
| path_values_pattern_L1SF     | Путь к файлу, содержащему значения для паттернов L1SF                             | -   | -    | ./values_pattern_L1SF.cfg     |
| path_comparison_si_threshold | Путь к файлу, содержащему пороговые значения для сравнения ЦИ с СИ                | -   | -    | ./comparison_si_threshold.cfg |

### Секция `[decimation]`

| Величина                            | Описание                                                 | Мин | Макс | По умолчанию |
|-------------------------------------|----------------------------------------------------------|-----|------|--------------|
| residuals_decimation_interval       | Интервал прореживания 1с измерений при расчете невязок   | 1   | 60   | 10           |
| meteoparameters_decimation_interval | Интервал прореживания измерений метеопараметров, секунды | 1   | -    | 30           |
| opmessage_decimation_interval       | Прореживание оперативных сообщений от БИС, штук          | 1   | -    | 30           |
| nav_solution_decimation_interval    | Прореживание результатов решения НЗ, штук                | 1   | -    | 30           |
| controls_decimation_interval        | Прореживание результатов контроля, штук                  | 1   | -    | 30           |

### Секция `[write_instance_to_ldb]`

| Величина                      | Описание                                                     | Мин | Макс | По умолчанию |
|-------------------------------|--------------------------------------------------------------|-----|------|--------------|
| `opmessage`                   | Отключать ли обработку пакетов opmessage                     | no  | yes  | no           |
| `control`                     | Отключать ли обработку пакетов control                       | no  | yes  | no           |
| `navsolution`                 | Отключать ли обработку пакетов navsolution                   | no  | yes  | no           |
| `knpopmessage`                | Отключать ли обработку пакетов knpopmessage                  | no  | yes  | no           |
| `knpopsummessage`             | Отключать ли обработку пакетов knpopsummessage               | no  | yes  | no           |
| `bulk_string_insert_interval` | Период проведения атомарной транзакции по записи пачки строк | 1   | -    | 2            |

### Секция `[di_control]`

| Величина      | Описание                                                                            | Мин | Макс | По умолчанию |
|---------------|-------------------------------------------------------------------------------------|-----|------|--------------|
| tk_difference | Разница между значением метки времени в принятой ЦИ(tk) и текущим временем, секунды | 1   | -    | 100          |

### Секция `[zrv_analyse]`

| Величина | Описание                                               | Мин | Макс | По умолчанию |
|----------|--------------------------------------------------------|-----|------|--------------|
| step     | Минимальный шаг расчета положения НКА в ЗРВ, с         | -   | -    | 300          |
| limit    | Максимальная длительность интервала определения ЗРВ, с | -   | -    | 259200       |

### Секция `[cache]`

| Величина          | Описание                                  | Мин | Макс | По умолчанию |
|-------------------|-------------------------------------------|-----|------|--------------|
| lifetime_si_cache | Время жизни кэша для формы СИ, в секундах | 300 | -    | 300          |      

### Секция `[opmessage]`

| Величина              | Описание                                                                                             | Мин | Макс | По умолчанию |
|-----------------------|------------------------------------------------------------------------------------------------------|-----|------|--------------|
| auto_finalize_timeout | Временной порог для определения нужно ли финализировать просроченный сигнальный признак(СП), секунды | 30  | -    | 60           |
| auto_approve_timeout  | Временной порог для определения нужно ли убрать сигнализацию у СП, НКА которых вышло из ЗРВ, секунды | 60  | -    | 600          |

### Секция `[SI]`

| Величина           | Описание                                                       | Мин | Макс | По умолчанию |
|--------------------|----------------------------------------------------------------|-----|------|--------------|
| `search_depth_169` | Глубина поиска формы СИ 169 в ЦБД, в днях                      | 3   | -    | 3            |
| `search_depth_893` | Глубина поиска формы СИ 893 в ЦБД, в днях                      | 3   | -    | 3            |
| `search_depth_895` | Глубина поиска формы СИ 895 в ЦБД, в днях                      | 7   | -    | 7            |
| `search_depth_701` | Глубина поиска формы СИ 701 в ЦБД, в днях                      | 1   | -    | 5            |
| `search_depth_921` | Глубина поиска формы СИ 921 в ЦБД, в днях                      | -   | -    | 7300         |
| `search_depth_P4`  | Глубина поиска кадра, в котором возведен признак P4, в минутах | 6   | -    | 6            |

### Секция `[interface]`

| Величина                         | Описание                                                           | Мин | Макс | По умолчанию |
|----------------------------------|--------------------------------------------------------------------|-----|------|--------------|
| `history_residuals_search_depth` | Глубина поиска для запроса архивных невязок на интерфейсе, в часах | 1   | -    | 1            |

### Секция `[measurement_reception_control]`

Содержит параметры отслеживания состояния приема 1с измерений

| Величина                              | Описание                                                                                                                    | Мин | Макс | По умолчанию |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|-----|------|--------------|
| `sufficient_rate_for_zone_meas_count` | Доля (процент), который определяет, достаточно ли в ЗРВ пришло 1с измерений, чтобы считать, что проблем с их получением нет | 0.1 | 1    | 0.7          |
| `meas_acceptable_delay`               | Порог, который определяет максимальную допустимую задержку 1с измерений, секунд                                             | 0   | -    | 5            |
| `meas_acceptable_absence`             | Порог, который определяет максимальное допустимое отсутствие 1с измерений, секунд                                           | 0   | -    | 5            |

### Секция `[bis_config]`

| Величина                                   | Описание                                                                                                                                                                                                                                                                                                                                                 | Мин | Макс | По умолчанию |
|--------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|------|--------------|
| `station_receiving_error_threshold`        | Порог в штуках станций, по которой определяется обобщенное состояние приема сигнала "Отсутствует". Если количество станций, для которых статус приёма "Отсутствует" больше либо равно `station_receiving_error_threshold`, то делается вывод об обобщенном состоянии приема сигнала "Отсутствует". Иначе состояние приёма "Отсутствует (не подтверждено) | 1   | -    | 1            |
| `signal_validity_analyzing_time`           | Глубина в секундах буфера для определения состояния годности сигнала. У каждой тройки (БИС, НКА, сигнал) отдельный буфер                                                                                                                                                                                                                                 | 1   | 30   | 10           |
| `signal_validity_percent`                  | Порог в процентах, по которому определяется состояние "Достоверный/недостоверный" при оценке годности сигнала для каждого БИС. Если сигнал в процентном соотношении оценен как "Достоверный/недостоверный" более порогового числа раз, то делается вывод по данным этого БИС. Если оценок меньше порога, то состояние "Неопределено"                     | 1   | 100  | 90           |
| `station_validity_error_threshold`         | Порог в штуках станций, по которой определяется обобщенное состояние годности сигнала "Сбой". Если статус годности не был определён как "Ок" и количество станций, для которых хотя бы один БИС считает сингал как негодный больше либо равно `station_validity_error_threshold`, то делается вывод об обобщенном состоянии годности сигнала "Сбой"      | 1   | -    | 1            |
| `nvz_solution_inaccuracy_threshold`        | Порог в метрах для погрешности решения НВЗ                                                                                                                                                                                                                                                                                                               | 0   | -    | 50           |
| `residual_pairs_difference_threshold`      | Порог в метрах для парной разности двух невязок. Если модуль парной разности двух невязок меньше, чем `residual_pairs_difference_threshold`, то принимается решение о добавлении этих двух невязок в перечень невязок, по которым рассчитывается средняя невязка                                                                                         | 0   | -    | 5            |
| `residual_average_difference_threshold`    | Порог в метрах для разности невязки и средней невязки. Если модуль разности невязки и средней невязки меньше, чем `residual_average_difference_threshold`, то принимается решение о признании "хорошими" невязки и сигналов, по которым она рассчитана                                                                                                   | 0   | -    | 10           |
| `speed_residual_inaccuracy_threshold`      | Порог в метрах в секунду для невязки псевдоскорости.                                                                                                                                                                                                                                                                                                     | 0   | -    | 0.5          |
| `min_elevation_for_nav_solution`           | Порог в угловых градусах, по которому принимается решение об использовании невязок в РНЗ. Если угол места НКА для БИС меньше, чем `min_elevation_for_nav_solution`, то невязки, полученные с этого НКА, не используются в решении навигационной задачи для данного БИС                                                                                   | 0   | -    | 15           |
| `check_packet_receive_time`                | Флаг проверки времени поступления пакета. Если установлен в 1 или `true`, то полученные от СПО сети БИС с запозданием более 10 секунд пакеты будут отброшены и не приняты в обработку                                                                                                                                                                    | 0   | 1    | 1            |
| `check_di_receive_in_time`                 | Флаг проверки времени поступления цифровой информации. Если установлен в 1 или `true`, то полученная ЦИ с запозданием более digital_info_transmitting_delay_threshold секунд  будет помеченная как пришедшая невовремя                                                                                                                                   | 0   | 1    | 1            |
| `use_troposphere_model`                    | Флаг использования модели тропосферы при расчете невязок. Если установлен в 1 или `true`, то при наличии метеопараметров на основании координат ПЭ и модели Саастамойнена расчитывается тропосферная поправка к псевдодальности                                                                                                                          | 0   | 1    | 1            |
| `log_level`                                | Уровень подробности выводимых в файлы журнала сообщений, задающий максимальное значение. Сообщения с большим уровнем подробности будут отброшены. Позволяет изменять объем журналирования в динамике.                                                                                                                                                    | 0   | 13   | 0            |
| `acceptable_packets_delay`                 | Порог в секундах, определяющий допустимую задержку пакетов, сверх которой сигнализируется о проблеме с обменом.                                                                                                                                                                                                                                          | 1   | -    | 10           |
| `min_packets`                              | Минимизация номенклатуры пакетов, которые идут в обработку. Обрабатывается только ЦИ и 1 с измерения.                                                                                                                                                                                                                                                    | 0   | -    | 0            |
| `allowed_delay_for_signal_status`          | Порог в секундах, определяющий допустимую задержку пакетов, сверх которой сигнализируется о сбое при приёме сигнала.                                                                                                                                                                                                                                     | 1   | -    | 10           |
| `min_amount_bis_for_generalized_opmessage` | Порог в штуках станций для определения статуса обобщенных сообщений                                                                                                                                                                                                                                                                                      | 1   | -    | 1            |
| `residual_averaging_interval`              | Глубина интервала, на который производиться усреднение значений невязок, секунд                                                                                                                                                                                                                                                                          | -   | -    | 5            |
| `average_residual_averaging_interval`      | Глубина интервала, на который производиться усреднение значений среднего по хорошим невязкам, секунд                                                                                                                                                                                                                                                     | -   | -    | 5            |
| `max_diff_between_local_and_packet_time`   | Макс. допустимая разница локального времени и времени пакета, секунд                                                                                                                                                                                                                                                                                     | 60  | 1    | -            |
| `meteodata_actual_duration`                | Диапазон плюс/минус допустимости использования метеоданных, секунд                                                                                                                                                                                                                                                                                       | 0   | -    | 600          |

### Секция `[PDOP]`

| Величина                      | Описание                                                                                                                                                                              | Мин | Макс     | По умолчанию                             |
|-------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|----------|------------------------------------------|
| `full_file_name_PDOP`         | полный путь к файлу, в который сохраняются частные значения PDOP — промежуточные данные для расчета.                                                                                  | -   | -        | `utils\PDOP\PDOPS_0.txt`                 |
| `full_file_name_availability` | полный путь к файлу, в который сохраняются частные значения точек и моментов времени, где PDOP > 6 — для расчета доступности (не в полном объёме) и максимального перерыва навигации. | -   | -        | `utils\PDOP\availability_sec_data_0.txt` |
| `nka_elevation_mask`          | угол места, при превышении которого считается, что НКА находится в ЗРВ.                                                                                                               | 0   | 90       | 5                                        |
| `max_pdop_na_spread`          | максимальное число дней от требуемой даты альманаха, при котором альманах всё ещё считается найденным.                                                                                | 0   | MAX(INT) | 2                                        |
| `PDOP_time_step`              | шаг между моментами времени, на которые рассчитывается PDOP.                                                                                                                          | 0   | MAX(INT) | 120                                      |
| `availability_time_step`      | шаг между моментами времени, на которые рассчитывается доступность.                                                                                                                   | 0   | MAX(INT) | 30                                       |
