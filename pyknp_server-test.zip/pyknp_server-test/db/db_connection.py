from __future__ import annotations

import psycopg2
from peewee import PostgresqlDatabase

from global_data.config_schema import config


def create_tldb_connection():
    connection_params = {
        'database': config['postgresql']['tldbname'],
        'user': config['postgresql']['username'],
        'password': config['postgresql']['password'],
        'host': config['postgresql']['host'],
        'port': config['postgresql']['port']
    }
    connection_settings = {
        'autorollback': True,
        'isolation_level': psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT,
    }
    db_conn = PostgresqlDatabase(**connection_params, **connection_settings)
    return db_conn


db = create_tldb_connection()
