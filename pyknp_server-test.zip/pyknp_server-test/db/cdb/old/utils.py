from typing import Dict, Union
from peewee import DoesNotExist
from db.cdb.old.data_cdb import Tka


def read_nka_data_from_cdb() -> Dict[int, Dict[str, Union[int, str]]]:
    """
    Чтение данных о НКА из ЦБД (№ сист.точки, № в НКУ, тип КА)

    :return nka_data: словарь, содержащих словарь с № сист. точки, номер НКУ, тип КА
    """

    nka_data = {}
    nka_records = Tka.select(Tka.nka, Tka.tochk, Tka.nameka).where(Tka.zapr == "+").where(Tka.tochk != "00")

    # Заполняется словарь номеров системных точек и соответствующих номеров в НКУ
    if len(nka_records) == 0:
        raise DoesNotExist
    else:
        for record in nka_records:
            nka_data[int(record.tochk)] = dict(
                    sys_num=int(record.tochk), nku_num=int(record.nka), type_ka=str(record.nameka), type_si=str(record.nameka)
            )

    return nka_data
