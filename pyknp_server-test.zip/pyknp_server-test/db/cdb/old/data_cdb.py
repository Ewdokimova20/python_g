from datetime import datetime, timedelta
from functools import reduce
from typing import List, Optional

from peewee import *

from db.cdb.common import cdb
from global_data.nka_type import NkaType
from utils.SI.common import SIRecord


class BaseModel(Model):
    """Класс, от которого надо наследоваться, чтобы не прописывать строки ниже в каждом классе"""

    class Meta:
        database = cdb
        primary_key = False


class Tka(BaseModel):
    """Класс для таблиц сопоставления номера системной точки и условного номера КА"""

    nks = CharField()
    """Номер НКА"""
    podsist = CharField(null=True)
    nka = CharField(null=True)
    """Условный номер КА"""
    zapr = CharField(null=True)
    nameka = CharField(null=True)
    nletn = CharField(null=True)
    tochk = CharField(null=True)
    """Номер системной точки"""
    tcu = CharField(null=True)
    intaf = CharField(null=True)
    rasvp = CharField(null=True)
    magnr = CharField(null=True)
    tultuz = CharField(null=True)
    nplan = CharField(null=True)
    af1 = CharField(null=True)
    af2 = CharField(null=True)
    dvp = CharField(null=True)
    drk = CharField(null=True)
    vklpsh = CharField(null=True)
    vklkr = CharField(null=True)
    vklzrr = CharField(null=True)
    vklsk = CharField(null=True)
    intbakis = CharField(null=True)
    offkis = CharField(null=True)
    prodl1 = CharField(null=True)
    prodl2 = CharField(null=True)
    prodl3 = CharField(null=True)
    rs = CharField(null=True)
    rz = CharField(null=True)
    mod = CharField(null=True)
    dtul = CharField(null=True)
    dtyl = CharField(null=True)
    tyln = CharField(null=True)
    tylk = CharField(null=True)
    tyzn = CharField(null=True)
    tyzk = CharField(null=True)
    va = CharField(null=True)
    pcl1 = CharField(null=True)
    pcl2 = CharField(null=True)
    pcl3 = CharField(null=True)
    ma = CharField(null=True)


class SIFormTable(BaseModel):
    """Класс для таблиц с СИ"""
    nka = CharField()
    """Номер НКА"""
    vitok = CharField(null=True)
    """Номер витка"""
    seans = CharField(null=True)
    """Номер сеанса"""
    kip = CharField(null=True)
    """Номер КИП"""
    stvol = CharField(null=True)
    """Номер ствола"""
    nekzf = BooleanField(null=True)
    """Номер экземпляра формы"""
    tn = DateTimeField(null=True)
    """Дата-время"""
    information = BlobField(null=True)
    """Массив СИ"""
    kvit = FixedCharField(null=True)
    """Поле-квитанции"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @classmethod
    def get_records_from_cdb(cls, nka: int, time_start: datetime, time_end: datetime) -> List[SIRecord]:
        """Получить нужные записи из ЦБД"""

        result = []

        records = cls.select() \
            .where(cls.tn >= time_start) \
            .where(cls.tn <= time_end) \
            .where(cls.nka == nka).order_by(cls.tn.desc())

        if len(records):
            for record in records:
                result.append(SIRecord(id=0,
                                       nka=int(record.nka),
                                       data=record.information,
                                       vitok=int(record.vitok),
                                       timestamp=record.tn))

        return result if len(result) else []

    @classmethod
    def get_single_record_from_cdb(cls, nka: int, vitok: int, id: int) -> Optional[SIRecord]:
        """Получить нужные записи из ЦБД"""

        result = None

        record = cls.select() \
            .where(cls.vitok == vitok) \
            .where(cls.nka == nka).order_by(cls.tn.desc()).get()

        if record:
            result = SIRecord(id=id,
                              nka=int(record.nka),
                              data=record.information,
                              vitok=int(record.vitok),
                              timestamp=record.tn)

        return result

    @classmethod
    def get_records_from_cdb_by_params(cls, nka: list, form: list,
                                       time_start: datetime = datetime.now() - timedelta(minutes=300),
                                       time_end: datetime = datetime.now(), page: int = 0, limit: int = 0) -> List[
        SIRecord]:
        """Чтение данных СИ форм из ЦБД для выбранных нка и выбранных форм """

        name_si = [NkaType.KA14F113, NkaType.KA14F143]
        result = []
        from utils.SI.main import SI_FORMS

        records = []
        for type_nka in name_si:
            for single_form in form:
                si = SI_FORMS.get(type_nka)[single_form]
                record = si.select(si.nka, si.information, si.vitok, si.tn, si.kvit,
                                   Value(single_form).alias('si_form')) \
                    .where(si.tn >= time_start) \
                    .where(si.tn <= time_end) \
                    .where(si.nka.in_(nka)) \
                    .order_by(si.tn.desc())
                records.append(record)

        union_records = reduce(lambda q1, q2: q1.union_all(q2), records)
        if page != 0 and limit != 0:
            union_records = union_records.paginate(page, limit)

        if len(union_records):
            for record in union_records:
                result.append(SIRecord(id=0,
                                       nka=int(record.nka),
                                       data=record.information,
                                       vitok=int(record.vitok),
                                       timestamp=record.tn,
                                       si_form=int(record.si_form),
                                       si_format=record.si_form,
                                       flag_cdb=record.kvit,
                                       flag_sui=record.kvit,
                                       flag_ka=record.kvit,
                                       write_time_cdb=record.tn,
                                       write_time_sui=record.tn,
                                       write_time_ka=record.tn, ))
        return result
