import logging
from typing import Optional

from peewee import PostgresqlDatabase, PeeweeException

from global_data.config_schema import config

cdb: Optional[PostgresqlDatabase] = None  # Глобальный объект соединения


def init_cdb_connection():
    """
    Создает объект базы данных, но не открывает соединение.
    Вызывать один раз при старте приложения.
    """
    global cdb
    try:
        cdb = PostgresqlDatabase(
            config['cdb']['dbname'],
            user=config['cdb']['username'],
            password=config['cdb']['password'],
            host=config['cdb']['host'],
            port=config['cdb']['port']
        )
        logging.info("Объект подключения к ЦБД создан.")
    except KeyError as err:
        logging.error('Некорректные настройки ЦБД в конфигурации: %s', err)
        cdb = None


def open_cdb_connection():
    """
    Открывает соединение с базой, если оно еще не открыто.
    """
    global cdb
    if cdb is None:
        logging.error("Объект базы данных не инициализирован. Вызовите init_cdb_connection() перед открытием соединения.")
        return
    if cdb.is_closed():
        try:
            cdb.connect()
            logging.info("Соединение с ЦБД успешно открыто.")
        except PeeweeException as err:
            logging.error("Ошибка при открытии соединения с ЦБД: %s", err)
    else:
        logging.debug("Соединение с ЦБД уже открыто.")


def init_and_open_cdb_connection():
    """
    Создает объект базы данных и сразу открывает соединение.
    Удобно вызывать там, где нужно быстро инициализировать и подключиться.
    """
    init_cdb_connection()
    if cdb is not None:
        open_cdb_connection()


def close_cdb_connection():
    """
    Закрывает соединение с базой, если оно открыто.
    """
    global cdb
    if cdb and not cdb.is_closed():
        cdb.close()
        logging.info("Соединение с ЦБД закрыто.")
    else:
        logging.debug("Соединение с ЦБД уже закрыто или не инициализировано.")


init_cdb_connection()
