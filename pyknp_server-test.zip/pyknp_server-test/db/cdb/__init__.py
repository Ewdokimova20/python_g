from global_data.config_schema import config

if config['cdb']['mode'] == 'new':
    from db.cdb.new import *
elif config['cdb']['mode'] == 'old':
    from db.cdb.old import *
