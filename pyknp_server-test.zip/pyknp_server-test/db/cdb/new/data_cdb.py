import logging
from datetime import datetime, timedelta
from typing import List, Optional

from peewee import *

from db.cdb.common import cdb
from global_data.nka_type import NkaType
from utils.SI.common import SIRecord


class BaseModel(Model):
    """Класс, от которого надо наследоваться, чтобы не прописывать строки ниже в каждом классе"""

    class Meta:
        database = cdb
        schema = 'common'


class KaType(BaseModel):
    """Таблица KaType содержит информацию о типах КА системы ГЛОНАСС."""
    id = SmallIntegerField(primary_key=True)
    """Условный идентификатор типа КА"""
    name = CharField(255)
    """Индекс изделия"""
    description = CharField(255)
    """Дополнительное описание типа КА"""
    writetime = TimestampField()
    """Время записи информации в ЦБД, МДВ"""
    username = CharField(255)
    """Имя пользователя ЦБД внесшего изменения в таблицу """
    hostaddress = CharField(255)
    """IP-адрес компьютера ЦУ КК, с которого внесены изменения"""


class KaGroup(BaseModel):
    """Таблица KaGroup содержит информацию о группах КА системы ГЛОНАСС внутри типа КА."""
    id = SmallIntegerField(primary_key=True)
    """Условный идентификатор группы КА"""
    typeid = ForeignKeyField(column_name='typeid', field='id', model=KaType)
    """Условный идентификатор типа КА (из таблицы KaType)"""
    description = CharField(255)
    """Дополнительное описание группы КА"""
    writetime = TimestampField()
    """Время записи информации в ЦБД, МДВ"""
    username = CharField(255)
    """Имя пользователя ЦБД внесшего изменения в таблицу"""
    hostaddress = CharField(255)
    """IP-адрес компьютера ЦУ КК, с которого внесены изменения"""


class KaInfo(BaseModel):
    """Таблица KaInfo содержит общую информацию по КА системы ГЛОНАСС"""
    nka = SmallIntegerField(primary_key=True)
    """Номер КА в НКУ"""
    groupid = ForeignKeyField(column_name='groupid', field='id', model=KaGroup)
    """Условный идентификатор группы КА(из таблицы KaGroup)"""
    systempoint = SmallIntegerField(unique=True)
    """Системный номер КА """
    sccid = SmallIntegerField()
    """Номер управляющего центра (из таблицы Scc)"""
    state = SmallIntegerField()
    """Текущий статус КА"""
    flynka = SmallIntegerField()
    """Заводской (летный) номер КА"""
    orbitalplane = SmallIntegerField()
    """Номер орбитальной плоскости"""
    orbitalpoint = SmallIntegerField()
    """Расположение КА в системе """
    # cosmosnka = CharField(15)
    """Официальное наименование КА """
    # cosparnka = IntegerField()
    """Международный номер КА (COSPAR ID)"""
    # TODO после уточнения структуры базы в имитаторе комментарии убрать
    launchtime = TimestampField(null=False)
    """Дата запуска КА, МДВ"""
    intime = TimestampField(null=False)
    """Дата ввода КА в систему, МДВ"""
    outtime = TimestampField(null=False)
    """Дата вывода КА из системы, МДВ"""
    writetime = TimestampField(null=False)
    """Время записи информации в ЦБД, МДВ"""
    username = CharField(255)
    """Имя пользователя ЦБД внесшего изменения в таблицу"""
    hostaddress = CharField(255)
    """IP-адрес компьютера ЦУ КК, с которого внесены изменения"""


class KaSignalType(BaseModel):
    """Таблица KaSignalType содержит информацию о типах возможных сигналов, излучаемых КА системы ГЛОНАСС."""
    id = SmallIntegerField(primary_key=True)
    """Условный идентификатор типа излучаемого сигнала"""
    signal = CharField(255, unique=True)
    """Название типа излучаемого сигнала"""
    razdel = SmallIntegerField()
    """Вид разделения сигнала"""
    description = CharField(255)
    """Дополнительное описание сигнала"""
    writetime = TimestampField()
    """Время записи информации в ЦБД, МДВ"""
    username = CharField(255)
    """Имя пользователя ЦБД внесшего изменения в таблицу"""
    hostaddress = CharField(255)
    """IP-адрес компьютера ЦУ КК, с которого внесены изменения"""


class KaSignalInfo(BaseModel):
    """Таблица KaSignalInfo содержит общую информацию по излучаемым на данный момент сигналам КА системы ГЛОНАСС."""
    nka = ForeignKeyField(column_name='nka', field='nka', model=KaInfo)
    """Номер КА в НКУ (из таблицы «KaInfo»)"""
    signalid = ForeignKeyField(column_name='signalid', field='id', model=KaSignalType)
    """Условный идентификатор типа излучаемого сигнала (из таблицы «KaSignalType»)"""
    signalstate = SmallIntegerField()
    """Признак функционирования сигнала"""
    writetime = TimestampField()
    """Время записи информации в ЦБД, МДВ"""
    username = CharField(255)
    """Имя пользователя ЦБД внесшего изменения в таблицу"""
    hostaddress = CharField(255)
    """IP-адрес компьютера ЦУ КК, с которого внесены изменения"""

    class Meta:
        primary_key = False


class KaSiGroup(BaseModel):
    """Таблица KaGroupSi содержит общую информацию о группах СИ"""
    groupid = SmallIntegerField()
    """Уникальный идентификатор группы СИ"""
    name = CharField(255)
    """Название СИ"""

    class Meta:
        primary_key = False


class KaSiGroupMode(BaseModel):
    """Таблица KaGroupSiMode содержит общую информацию о группах СИ, закладываемых на каждый КА системы ГЛОНАСС"""
    nka = ForeignKeyField(column_name='nka', field='nka', model=KaInfo)
    """Номер КА в НКУ (из таблицы «KaInfo»)"""
    groupka = ForeignKeyField(column_name='groupka', field='groupid', model=KaSiGroup)
    """Уникальный идентификатор группы СИ"""

    class Meta:
        primary_key = False


class SIFormTable(BaseModel):
    """Класс для таблиц с СИ"""
    id: int = BigIntegerField(null=False)
    """Уникальный идентификатор выписки закладки СИ"""
    version: int = SmallIntegerField(null=False)
    """Номер версии данных текущей строки"""
    nekzfsi: int = IntegerField(null=False)
    """Номер версии формирования таблицы si"""
    nka: int = SmallIntegerField(null=False)
    """Номер КА в НКУ"""
    nip: int = SmallIntegerField(null=False)
    """Географическая точка средства НКУ (от 1 до 32767)"""
    kts: int = SmallIntegerField(null=False)
    """Номер ствола"""
    vitok: int = IntegerField(null=False)
    """Номер витка на котором будет производиться закладка СИ"""
    starttime: datetime = DateTimeField(null=True)
    """Дата и время начала закладки СИ МДВ"""
    endtime: datetime = DateTimeField(null=True)
    """Дата и время завершения закладки СИ МДВ"""
    formsi: int = SmallIntegerField(null=False)
    """Номер формы СИ """
    sizesi: int = SmallIntegerField(null=False)
    """Объем СИ во фразах"""
    modesi: int = SmallIntegerField(null=False)
    """Режим закладки СИ """
    formatsi: int = SmallIntegerField(null=False)
    """Формат СИ в котором должна быть сформирована информация на текущий момент времени"""
    si: bytes = BlobField(null=True)
    """Сформированный массив СИ"""
    kvit_cbd: int = SmallIntegerField(null=False)
    """Квитанция записи СИ в таблицу si_vsp"""
    kvit_sui: int = SmallIntegerField(null=False)
    """Квитанция передачи СИ на СУИ"""
    kvit_ka: int = SmallIntegerField(null=False)
    """Квитанция закладки СИ на КА"""
    time_zap_cbd: datetime = DateTimeField(null=True)
    """Дата и время записи СИ в таблицу SI МДВ"""
    time_zap_sui: datetime = DateTimeField(null=True)
    """Дата и время передачи СИ на СУИ МДВ"""
    time_zap_ka: datetime = DateTimeField(null=True)
    """Дата и время закладки СИ на КА МДВ"""

    NAME_SI = {
        0: NkaType.KA14F113,
        1: NkaType.KA14F143,
        2: NkaType.KA14F160,
    }

    class Meta:
        primary_key = False
        schema = 'nku'
        table_name = 'si_all'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @classmethod
    def get_records_from_cdb(cls, nka: int, time_start: datetime, time_end: datetime) -> List[SIRecord]:
        """Получить все записи СИ из ЦБД в заданном диапазоне времени в порядке убывания времени конца закладки"""

        result = []

        records: List[SIFormTable] = (
            cls.select(cls.id, cls.nka, cls.si, cls.vitok, cls.formsi, cls.formatsi, cls.endtime, cls.time_zap_cbd)
            .where(cls.endtime >= time_start)
            .where(cls.endtime <= time_end)
            .where(cls.nka == nka).order_by(cls.endtime.desc()))

        if len(records):
            logging.debug(f"Запрос к таблице {cls._meta.table_name} ЦБД. Получены столбцы: nka, si, time")
            for record in records:
                result.append(SIRecord(id=record.id,
                                       nka=record.nka,
                                       data=record.si,
                                       si_form=record.formsi,
                                       si_format=cls.NAME_SI.get(record.formatsi),
                                       vitok=record.vitok,
                                       write_time_cdb=record.time_zap_cbd,
                                       timestamp=record.endtime))
        return result if len(result) else []

    @classmethod
    def get_record_from_cdb(cls, nka: int, time_start: datetime, time_end: datetime) -> Optional[SIRecord]:
        """Получить самую свежую запись СИ из ЦБД в заданном диапазоне времени"""

        record: SIFormTable = (
            cls.select(cls.id, cls.nka, cls.si, cls.vitok, cls.formsi, cls.formatsi, cls.endtime, cls.time_zap_cbd)
            .where(cls.endtime >= time_start)
            .where(cls.endtime <= time_end)
            .where(cls.nka == nka).order_by(cls.endtime.desc())
            .first())

        if record is not None:
            logging.debug(f"Запрос к таблице {cls._meta.table_name} ЦБД. Получены столбцы: nka, si, time")
            return SIRecord(id=record.id,
                            nka=record.nka,
                            data=record.si,
                            si_form=record.formsi,
                            si_format=cls.NAME_SI.get(record.formatsi),
                            vitok=record.vitok,
                            write_time_cdb=record.time_zap_cbd,
                            timestamp=record.endtime)
        return None

    @classmethod
    def get_record_from_cdb_by_id(cls, nka: int, vitok: int, id: int) -> Optional[SIRecord]:
        """Получить нужную запись СИ из ЦБД по её id"""

        result = None
        record: SIFormTable = (
            cls.select(cls.id, cls.nka, cls.si, cls.vitok, cls.formatsi, cls.formsi, cls.starttime, cls.endtime,
                       cls.time_zap_cbd)
            .where(cls.id == id)
            .where(cls.nka == nka).order_by(cls.endtime.desc()).get())

        if record:
            result = SIRecord(id=record.id,
                              nka=record.nka,
                              data=record.si,
                              vitok=record.vitok,
                              start_time=record.starttime,
                              si_format=cls.NAME_SI.get(record.formatsi),
                              si_form=record.formsi,
                              write_time_cdb=record.time_zap_cbd,
                              timestamp=record.endtime)

        return result

    @classmethod
    def get_records_from_cdb_by_params(cls, nka: list, form: list,
                                       time_start: datetime = datetime.now() - timedelta(minutes=300),
                                       time_end: datetime = datetime.now(), page: int = 0, limit: int = 0) -> List[
        SIRecord]:
        """Чтение данных СИ форм из ЦБД для выбранных нка и выбранных форм """

        result = []

        records: List[SIFormTable] = (cls.select()
                                      .where(cls.nka.in_(nka))
                                      .where(cls.formsi.in_(form))
                                      .where(cls.endtime >= time_start)
                                      .where(cls.endtime <= time_end)
                                      .order_by(cls.endtime.desc())
                                      )

        if page != 0 and limit != 0:
            records = records.paginate(page, limit)

        if len(records):
            logging.debug(
                f"Запрос к таблице {cls._meta.table_name} получен список СИ со статусами закладки и доп. возможностями")
            for record in records:
                result.append(SIRecord(id=record.id,
                                       nka=record.nka,
                                       data=record.si,
                                       vitok=record.vitok,
                                       timestamp=record.endtime,
                                       si_form=record.formsi,
                                       si_format=cls.NAME_SI.get(record.formatsi),
                                       flag_cdb=record.kvit_cbd,
                                       flag_sui=record.kvit_sui,
                                       flag_ka=record.kvit_ka,
                                       write_time_cdb=record.time_zap_cbd,
                                       write_time_sui=record.time_zap_sui,
                                       write_time_ka=record.time_zap_ka,
                                       ))
        return result if len(result) else []

    @classmethod
    def get_records_from_cdb_for_operation_uplink_control(cls, nka: Optional[List[int]] = None, form: List[int] = [],
                                                          time_start: datetime = datetime.now() - timedelta(minutes=300),
                                                          time_end: datetime = datetime.now(), page: int = 0, limit: int = 0) -> \
            List[SIRecord]:
        """Чтение данных СИ форм из ЦБД для выбранных нка и выбранных форм с join на KaInfo для получения systempoint"""

        result = []

        query = (
            cls
            .select(cls, KaInfo.systempoint)
            .join(KaInfo, JOIN.LEFT_OUTER, on=(cls.nka == KaInfo.nka))
            .where(
                cls.formsi.in_(form),
                cls.endtime >= time_start,
                cls.starttime <= time_end
            )
        )

        if nka:
            query = query.where(cls.nka.in_(nka))

        query = query.order_by(cls.endtime.desc())

        if page != 0 and limit != 0:
            query = query.paginate(page, limit)

        records: List[SIFormTable] = query

        if len(records):
            logging.debug(
                f"Запрос к таблице {cls._meta.table_name} получен список СИ со статусами закладки и доп. возможностями")
            for record in records:
                result.append(SIRecord(
                    id=record.id,
                    nka=record.nka,
                    nka_sys_num=record.kainfo.systempoint,
                    data=record.si,
                    vitok=record.vitok,
                    start_time=record.starttime,
                    end_time=record.endtime,
                    timestamp=record.endtime,
                    si_form=record.formsi,
                    si_format=cls.NAME_SI.get(record.formatsi),
                    flag_cdb=record.kvit_cbd,
                    flag_sui=record.kvit_sui,
                    flag_ka=record.kvit_ka,
                    write_time_cdb=record.time_zap_cbd,
                    write_time_sui=record.time_zap_sui,
                    write_time_ka=record.time_zap_ka,
                ))
        return result if len(result) else []
