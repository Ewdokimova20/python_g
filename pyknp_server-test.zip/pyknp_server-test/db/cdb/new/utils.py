import logging
from collections import defaultdict
from typing import Dict, Union

from peewee import DoesNotExist

from db.cdb.new.data_cdb import KaInfo, KaType, KaGroup, KaSignalInfo, KaSignalType, KaSiGroupMode
from global_data.nka_type import NkaType


def read_nka_data_from_cdb() -> Dict[int, Dict[str, Union[int, str]]]:
    """
    Чтение данных о НКА из ЦБД (№ сист.точки, № в НКУ, тип КА)

    :return nka_data: словарь, содержащих словарь с № сист. точки, номер НКУ, тип КА
    """

    nka_data = {}
    # KaInfo.state == 0 - режим подготовки к запуску КА  (ФЕИТ.60391-01 90 01 стр. 22)
    # KaInfo.state == 5 - режим исследования КА  (ФЕИТ.60391-01 90 01 стр. 22)
    nka_records = (KaInfo
                   .select(KaInfo.nka, KaInfo.systempoint, KaType.name)
                   .join(KaGroup)
                   .join(KaType)
                   .where(KaInfo.state != 0, KaInfo.state != 5))

    logging.debug("Запрос к таблицам KaInfo и KaType(через KaGroup), "
                  "получены: KaInfo.nka, KaInfo.systempoint, KaType.name")

    # Получаем название СИ для каждого КА
    SI_NAME = [NkaType.KA14F113, NkaType.KA14F143, NkaType.KA14F160]

    type_ka_si = {}
    type_ka = KaSiGroupMode.select(KaSiGroupMode.nka, KaSiGroupMode.groupka).dicts()
    if len(type_ka) != 0:
        try:
            for record in type_ka:
                type_ka_si[record['nka']] = SI_NAME[record['groupka']]
        except KeyError:
            logging.error(f'Таблица KaSiGroupMode в ЦБД не соответствует ожидаемой структуре')

    # Заполняется словарь номеров системных точек и соответствующих номеров в НКУ
    if len(nka_records) == 0:
        raise DoesNotExist
    else:
        for record in nka_records:
            nka_data[record.systempoint] = dict(
                sys_num=int(record.systempoint), nku_num=int(record.nka),
                type_ka=str(record.groupid.typeid.name), type_si=type_ka_si.get(record.nka, None)
            )

    return nka_data


def read_signals_from_cdb() -> Dict[int, list]:
    """
    Чтение данных о НКА из ЦБД (№ сист.точки; типы сигналов, излучаемых КА)

    :return signals_nka_data: список кортежей, содержащих № сист. точки, список названий сигналов КА
    """

    signals_nka_data = defaultdict(list)
    signals_nka_records = (KaInfo
                           .select(KaInfo.systempoint, KaSignalType.signal)
                           .join(KaSignalInfo)
                           .join(KaSignalType)
                           .where(KaSignalInfo.signalstate == 1))  # 1- сигнал излучается.

    logging.debug("Запрос к таблицам KaInfo и KaSignalType(через KaSignalInfo), "
                  "получены: KaInfo.systempoint, KaSignalType.signal")

    for record in signals_nka_records:
        signals_nka_data[record.systempoint].append(record.kasignalinfo.signalid.signal)

    return signals_nka_data
