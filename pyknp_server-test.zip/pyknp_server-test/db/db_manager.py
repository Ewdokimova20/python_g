import logging
import queue
import threading
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Union

from peewee import PostgresqlDatabase

from data import Signal, Residual
from db.db_connection import create_tldb_connection
from utils.reception_control.measurement_reception.meas_reception_data_collector_manager import \
    measurement_reception_manager

logger = logging.getLogger(__name__)


@dataclass
class WriteTask:
    """Задача для записи в базу данных.

    Attributes:
        task_type: Тип задачи ('signals' или 'residuals')
        data: Данные для записи
        priority: Приоритет задачи (по умолчанию 0)
    """
    task_type: str
    data: List[Union[Dict[str, Any], Residual]]
    priority: int = 0


class DatabaseManager:
    """Оптимизированный менеджер базы данных с разделением чтения и записи.

    Этот класс создает два отдельных соединения с базой данных:
    - read_db: для операций чтения в основном потоке
    - write_db: для операций записи в отдельном потоке

    Использует батчинг для группировки записей и уменьшения количества транзакций.

    Attributes:
        read_db: Соединение для чтения данных
        write_db: Соединение для записи данных
        batch_size: Размер батча для группировки записей
    """

    def __init__(self):
        """Инициализация менеджера базы данных."""
        self.batch_size = 100

        # Соединение для чтения (основной поток)
        self.read_db = self._create_database_connection()

        # Соединение для записи (поток записи)
        self.write_db = self._create_database_connection()

        # Батчи для группировки записей
        self.signal_batch: List[Dict[str, Any]] = []
        self.residual_batch: List[Residual] = []
        self.last_flush = time.time()

        # Очередь и поток для записи
        self.write_queue: queue.Queue = queue.Queue()
        self.running = False
        self.writer_thread: Optional[threading.Thread] = None

        # Статистика
        self.stats = {
            'signals_written': 0,
            'residuals_written': 0,
            'flush_count': 0,
            'queue_full_errors': 0,
        }

    @staticmethod
    def _create_database_connection() -> PostgresqlDatabase:
        """Создает новое соединение с базой данных.

        Returns:
            Объект соединения с ТЛБД
        """
        return create_tldb_connection()

    def start(self) -> None:
        """Запускает поток записи в базу данных.

        Raises:
            RuntimeError: Если менеджер уже запущен
        """
        if self.running:
            raise RuntimeError("Database manager уже запущен")

        logger.info("Запуск DatabaseManager...")
        self.running = True
        self.writer_thread = threading.Thread(target=self._writer_worker, daemon=True, name="DatabaseWriter")
        self.writer_thread.start()
        logger.info("DatabaseManager успешно запущен")

    def stop(self, timeout: float = 10.0) -> None:
        """Останавливает поток записи и сбрасывает оставшиеся данные.

        Args:
            timeout: Таймаут ожидания завершения потока (секунды)
        """
        if not self.running:
            return

        logger.info("Остановка DatabaseManager...")
        self.running = False

        # Ждем завершения потока
        if self.writer_thread and self.writer_thread.is_alive():
            self.writer_thread.join(timeout=timeout)
            if self.writer_thread.is_alive():
                logger.warning("Поток записи не завершился за отведенное время")

        # Принудительно сбрасываем оставшиеся данные
        self._force_flush_all()

        logger.info("DatabaseManager остановлен")
        self._log_stats()

    def queue_signals_write(self, signals_data: List[Dict[str, Any]],
                            priority: int = 0) -> bool:
        """Добавляет сигналы в очередь для записи.

        Args:
            signals_data: Список данных сигналов для записи
            priority: Приоритет задачи (не используется в текущей реализации)

        Returns:
            True если данные успешно добавлены в очередь, False в противном случае
        """
        if not signals_data:
            logger.warning("Попытка записать пустой список сигналов")
            return False

        task = WriteTask(task_type='signals', data=signals_data, priority=priority)
        return self._queue_task(task)

    def queue_residuals_write(self, residuals_data: List[Dict[str, Any]],
                              priority: int = 0) -> bool:
        """Добавляет невязки в очередь для записи.

        Args:
            residuals_data: Список данных невязок для записи
            priority: Приоритет задачи (не используется в текущей реализации)

        Returns:
            True если данные успешно добавлены в очередь, False в противном случае
        """
        if not residuals_data:
            logger.warning("Попытка записать пустой список невязок")
            return False

        task = WriteTask(task_type='residuals', data=residuals_data, priority=priority)
        return self._queue_task(task)

    def _queue_task(self, task: WriteTask) -> bool:
        """Добавляет задачу в очередь записи.

        Args:
            task: Задача для записи

        Returns:
            True если задача успешно добавлена, False в противном случае
        """
        if not self.running:
            logger.error("Попытка добавить задачу в остановленный менеджер")
            return False

        try:
            # Неблокирующее добавление в очередь
            self.write_queue.put_nowait(task)
            logger.debug(f"Добавлена задача {task.task_type} с {len(task.data)} записями")
            return True
        except queue.Full:
            self.stats['queue_full_errors'] += 1
            logger.error(f"Очередь записи переполнена! Потеряна задача {task.task_type} "
                         f"с {len(task.data)} записями")
            return False

    def _writer_worker(self) -> None:
        """Рабочий метод потока записи.

        Обрабатывает задачи из очереди и группирует их в батчи для эффективной записи.
        """
        logger.info("Поток записи в БД запущен")

        # Привязываем модели к соединению записи только в этом потоке
        try:
            # Импортируем модели здесь, чтобы избежать циклических импортов
            Signal._meta.database = self.write_db
            Residual._meta.database = self.write_db

            while self.running:
                try:
                    self._flush_all_batches()

                    # Получаем задачу из очереди с таймаутом
                    try:
                        task = self.write_queue.get(timeout=0.5)
                    except queue.Empty:
                        self._flush_all_batches()
                        continue

                    # Обрабатываем задачу
                    self._process_write_task(task)
                    self.write_queue.task_done()

                except Exception as e:
                    logger.error(f"Ошибка в потоке записи: {e}", exc_info=True)

        except ImportError as e:
            logger.error(f"Не удалось импортировать модели: {e}")
        except Exception as e:
            logger.error(f"Критическая ошибка в потоке записи: {e}", exc_info=True)
        finally:
            # Финальный сброс при завершении
            self._force_flush_all()
            logger.info("Поток записи в БД завершен")

    def _process_write_task(self, task: WriteTask) -> None:
        """Обрабатывает задачу записи, добавляя данные в соответствующий батч.

        Args:
            task: Задача для обработки
        """
        if task.task_type == 'signals':
            self.signal_batch.extend(task.data)
            logger.debug(f"Добавлено {len(task.data)} сигналов в батч "
                         f"(всего в батче: {len(self.signal_batch)})")

            if len(self.signal_batch) >= self.batch_size:
                self._flush_signals()

        elif task.task_type == 'residuals':
            self.residual_batch.extend(task.data)
            logger.debug(f"Добавлено {len(task.data)} невязок в батч "
                         f"(всего в батче: {len(self.residual_batch)})")

            if len(self.residual_batch) >= self.batch_size:
                self._flush_residuals()
        else:
            logger.warning(f"Неизвестный тип задачи: {task.task_type}")

    def _flush_signals(self) -> None:
        """Записывает накопленные сигналы в базу данных."""
        if not self.signal_batch:
            return

        try:

            batch_size = len(self.signal_batch)
            start_time = time.time()

            with self.write_db.atomic():
                created_signals = Signal.insert_many(self.signal_batch).returning(Signal).execute()
                for item in created_signals:
                    measurement_reception_manager.update_measurement(
                        bis=self.signal_batch[0]['bis'],
                        nka=item.nka_id,
                        signal_type=item.signal_type_id,
                        timestamp=item.timestamp,
                        meas_id=item.id
                    )

            execution_time = time.time() - start_time
            self.stats['signals_written'] += batch_size
            self.stats['flush_count'] += 1

            logger.debug(f"Записано {batch_size} сигналов за {execution_time:.3f}с")
            self.signal_batch.clear()

        except Exception as e:
            logger.error(f"Ошибка при записи сигналов: {e}", exc_info=True)
            # В случае ошибки не очищаем батч, чтобы попробовать позже

    def _flush_residuals(self) -> None:
        """Записывает накопленные невязки в базу данных."""
        if not self.residual_batch:
            return

        try:

            batch_size = len(self.residual_batch)
            start_time = time.time()

            # Преобразуем объекты Residual в dict
            residual_dicts = [r.as_dict() for r in self.residual_batch]

            with self.write_db.atomic():
                query = Residual.insert_many(residual_dicts).on_conflict_ignore().returning(Residual.id)
                inserted_ids = list(query.execute())
                inserted_count = len(inserted_ids)

            execution_time = time.time() - start_time
            self.stats['residuals_written'] += inserted_count
            self.stats['flush_count'] += 1

            logger.debug(f"Записано {inserted_count} из {batch_size} невязок за {execution_time:.3f}с")
            self.residual_batch.clear()

        except Exception as e:
            logger.error(f"Ошибка при записи невязок: {e}", exc_info=True)
            # В случае ошибки не очищаем батч, чтобы попробовать позже

    def _flush_all_batches(self) -> None:
        """Записывает все накопленные батчи в базу данных."""
        if not self.signal_batch and not self.residual_batch:
            return

        logger.debug("Запись накопленных пачек в БД...")

        try:
            # Используем одну транзакцию для всех данных
            with self.write_db.atomic():
                if self.signal_batch:
                    self._flush_signals()
                if self.residual_batch:
                    self._flush_residuals()

            self.last_flush = time.time()

        except Exception as e:
            logger.error(f"Ошибка при записи пачки в БД: {e}", exc_info=True)

    def _force_flush_all(self) -> None:
        """Принудительно сбрасывает все данные при остановке."""
        if self.signal_batch or self.residual_batch:
            logger.info(f"Принудительная запись имеющихся пачек при остановке: "
                        f"{len(self.signal_batch)} signals, "
                        f"{len(self.residual_batch)} residuals")
            self._flush_all_batches()

    def get_queue_size(self) -> int:
        """Возвращает текущий размер очереди записи.

        Returns:
            Количество задач в очереди
        """
        return self.write_queue.qsize()

    def get_batch_sizes(self) -> Dict[str, int]:
        """Возвращает текущие размеры батчей.

        Returns:
            Словарь с размерами батчей сигналов и невязок
        """
        return {
            'signals': len(self.signal_batch),
            'residuals': len(self.residual_batch)
        }

    def get_stats(self) -> Dict[str, Any]:
        """Возвращает статистику работы менеджера.

        Returns:
            Словарь со статистикой
        """
        return {
            **self.stats,
            'queue_size': self.get_queue_size(),
            'batch_sizes': self.get_batch_sizes(),
            'is_running': self.running
        }

    def _log_stats(self) -> None:
        """Выводит статистику работы в лог."""
        stats = self.get_stats()
        logger.info(f"Статистика DatabaseManager: "
                    f"1c измерений записано: {stats['signals_written']}, "
                    f"невязок записано: {stats['residuals_written']}, "
                    f"итераций записи в БД: {stats['flush_count']}, "
                    f"ошибок переполнения очереди: {stats['queue_full_errors']}")


# Глобальный экземпляр менеджера
db_manager: Optional[DatabaseManager] = None


def init_database_manager() -> DatabaseManager:
    """Инициализирует глобальный менеджер базы данных.

    Args:
        config: Конфигурация подключения к базе данных
        **kwargs: Дополнительные параметры для DatabaseManager

    Returns:
        Инициализированный менеджер базы данных
    """
    global db_manager

    if db_manager is not None:
        logger.warning("Database manager уже инициализирован")
        return db_manager

    db_manager = DatabaseManager()
    db_manager.start()

    return db_manager


def get_database_manager() -> DatabaseManager:
    """Возвращает глобальный менеджер базы данных.

    Returns:
        Менеджер базы данных

    Raises:
        RuntimeError: Если менеджер не инициализирован
    """
    if db_manager is None:
        raise RuntimeError("Database manager не инициализирован. "
                           "Вызовите init_database_manager() сначала.")
    return db_manager


def shutdown_database_manager() -> None:
    """Останавливает глобальный менеджер базы данных."""
    global db_manager

    if db_manager is not None:
        db_manager.stop()
        db_manager = None
