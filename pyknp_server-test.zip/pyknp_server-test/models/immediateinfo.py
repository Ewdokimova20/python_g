import datetime

import peewee
from peewee import FloatField, ForeignKeyField, IntegerField, BooleanField, AutoField

from global_data.appdata import SPEED_OF_LIGHT
from models.base import OperativeStorageModel
from models.nka import Nka
from utils.coordinates.coordinates import Coordinates
from utils.signals import FD


class LFImmediateInfo(OperativeStorageModel):
    """
        Обобщенная оперативная информация по L1OF

        Хранит часть оперативной информации из строк, которые получены в составе цифровой информации.
        См. ИКД L1, L2 ГЛОНАСС Редакция 5.1 2008 раздел 4.4.
        На момент реализации хранит только слова, которые требуются для расчета невязок. Добавление отдельных слов
        оперативной информации должно быть выполнено в этом же классе
        """

    id = AutoField()
    """id Эфемериды (соответствует столбцу id)"""
    nka: Nka = ForeignKeyField(Nka, on_delete='CASCADE')
    """НКА, для которого собраны эфемериды"""
    signal_id: int = IntegerField()
    """Идентификатор сигнала, т.к. по разным сигналам может быть разные эфемериды (например, загрубленные)"""
    x: float = FloatField()
    """X-координата НКА в системе координат ПЗ-90.02 на момент времени tb, м"""
    y: float = FloatField()
    """Y-координата НКА в системе координат ПЗ-90.02 на момент времени tb, м"""
    z: float = FloatField()
    """Z-координата НКА в системе координат ПЗ-90.02 на момент времени tb, м"""
    Vx: float = FloatField()
    """X-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени tb, м/с"""
    Vy: float = FloatField()
    """Y-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени tb, м/с"""
    Vz: float = FloatField()
    """Z-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени tb, м/с"""
    Ax: float = FloatField()
    """X-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени tb, м/с^2"""
    Ay: float = FloatField()
    """Y-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени tb, м/с^2"""
    Az: float = FloatField()
    """Z-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени tb, м/с^2"""
    N_T: float = IntegerField()
    """
        Текущая дата

        Календарный номер суток внутри четырехлетнего интервала, начиная с 1-го января високосного года
        """
    P1: int = IntegerField()
    """
        Признак смены оперативной информации (aka признак длительности текущего кадра)

        Признак сообщает величину интервала времени в минутах между значениями t_b в данном и предыдущем кадрах.

        Расшифровка:

        0 => 0 минут;

        1 => 30 минут;

        2 => 45 минут;

        3 => 60 минут.
    """
    t_k: int = IntegerField()
    """
        Время начала кадра внутри текущих суток

        В 5 старших разрядах записывается количество целых часов, прошедших с начала текущих суток. В 6 средних
        разрядах записывается количество целых минут, а в младшем разряде  -  количество  30-секундных интервалов,
        прошедших с начала текущей минуты.
        """
    t_b: int = IntegerField()
    """
        Порядковый номер временного интервала

        Порядковый номер временного интервала внутри текущих суток по шкале системного времени ГЛОНАСС, к середине
        которого относится передаваемая в кадре оперативная информация. Длительность данного временного интервала и,
        следовательно, максимальное значение слова t_b определяются значением слова P1
        """
    gamma: float = FloatField()
    """Относительное отклонение прогнозируемого значения несущей частоты излучаемого навигационного радиосигнала 
    от номинального значения на момент времени t_b"""
    tau: float = FloatField()
    """Сдвиг шкалы времени НКА относительно шкалы времени системы ГЛОНАСС"""
    ln1: int = IntegerField()
    """Признак  недостоверности  кадра
    Означает негодность данного НКА для проведения измерений.
    """
    ln3: int = IntegerField()
    """Признак  недостоверности  кадра
    Означает негодность данного НКА для проведения измерений.
    """
    ground_call: int = IntegerField()
    """Признак 'Вызов НКУ'"""
    frame_time: int = IntegerField()
    """Время кадра в секундах от начала суток"""
    is_in_time: bool = BooleanField()
    """t_k соответствует времени получения пакета от БИС"""
    N4: int = IntegerField()
    """Номер четырехлетнего периода, первый год первого четырехлетия соответствует 1996 году"""

    def data_timestamp(self) -> datetime.datetime:
        try:
            """Возвращает координаты, скорость и ускорение из эфемерид"""
            N4 = self.N4
            Nt = self.N_T
            tb = self.t_b
            return FD.common.tb_to_datetime(tb=tb, N=Nt, N4=N4)
        except peewee.DoesNotExist:
            raise ValueError

    def coordinates(self) -> Coordinates:
        """Возвращает координаты, скорость и ускорение из эфемерид"""
        xyz = Coordinates.XYZ(x=self.x, y=self.y, z=self.z)
        vel = Coordinates.Vxyz(Vx=self.Vx, Vy=self.Vy, Vz=self.Vz)
        acc = Coordinates.Axyz(Ax=self.Ax, Ay=self.Ay, Az=self.Az)
        return Coordinates(xyz=xyz, vel=vel, acc=acc)

    def time_freq_correction(self, current_time: datetime.datetime) -> float:
        """Расчет частотно-временной поправки"""
        return (self.tau - self.gamma * (current_time.timestamp() - self.data_timestamp().timestamp())) * SPEED_OF_LIGHT

    class Meta:
        indexes = (
            (('nka', 'N_T', 't_k', 'is_in_time', 'signal_id'), True),
        )


class LCImmediateInfo(LFImmediateInfo):
    """Обобщенная оперативная информация по кодовым сигналам"""

    beta: float = FloatField()
    """Вторая производная модели изменения смещения ШВ НКА из состава ЧВП"""

    class Meta:
        indexes = (
            (('nka', 'N_T', 't_k', 'is_in_time', 'signal_id'), True),
        )

    def data_timestamp(self) -> datetime.datetime:
        return datetime.datetime(year=1996 + (self.N4 - 1) * 4, month=1, day=1) + datetime.timedelta(days=self.N_T - 1,
                                                                                                     seconds=self.t_b)
