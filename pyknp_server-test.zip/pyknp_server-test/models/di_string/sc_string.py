from global_data.appdata import SignalTypes
from models.di_string.cd_signal_string import CDSignalString
from utils.bytestring_parser import parse_string_to_params
from utils.signals.CD import L1SC_L2SC


class SCString(CDSignalString):
    """Строка цифровой информации L1SC и L2SC"""

    string_length: int = L1SC_L2SC.STRING_2SEC_BITLENGTH
    """Длина строки в битах"""

    string_duration: int = L1SC_L2SC.SC_STRING_DURATION

    parameters_description: dict = L1SC_L2SC.strings_pattern_250bit
    """Массив, описывающий шаблоны парсинга строк (кроме аномальных)"""

    service_pattern: dict = L1SC_L2SC.service_pattern
    """Шаблон парсинга служебных полей строк"""

    def get_service_fields(self) -> L1SC_L2SC.ServiceFieldsSC:
        return L1SC_L2SC.get_service_fields_sc(self.int_content)

    def get_pseudoframe_length(self) -> int:
        """Возвращает длину псевдокадра, если строка является 10, иначе None"""
        return L1SC_L2SC.get_pseudoframe_length_sc(
            self.int_content) if self.service_fields.type == 10 and not self.error_in_string else None

    def check_cyclic_code(self, string: bytes) -> bool:
        # по результатам отработки: ноль в ЦК это признак целостности
        cyclic_code = parse_string_to_params(
            self.int_content, L1SC_L2SC.service_pattern)[0].get('CC')
        return 0 if cyclic_code == 0 else L1SC_L2SC.check_cyclic_code_long(string)


class L1SCString(SCString):
    """Строка цифровой информации L1SC"""
    signal_id: int = SignalTypes.L1SCd


class L2SCString(SCString):
    """Строка цифровой информации L2SC"""
    signal_id: int = SignalTypes.L2SCd
