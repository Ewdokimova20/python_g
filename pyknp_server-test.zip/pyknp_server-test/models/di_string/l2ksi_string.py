from global_data.appdata import SignalTypes
from models.di_string.cd_signal_string import CDSignalString
from utils.CD_strings_utils import check_cyclic_code_short
from utils.bytestring_parser import parse_string_to_params
from utils.signals.CD import L2KSI


class L2KSIString(CDSignalString):
    """Строка цифровой информации L2КСИ"""

    string_length = L2KSI.L2KSI_STRING_BIT_LENGTH
    """Длина строки в битах"""

    string_duration: int = L2KSI.L2KSI_STRING_DURATION

    service_pattern: dict = L2KSI.string_L2KSI_base_pattern
    """Шаблон парсинга служебных полей строк"""

    parameters_description: dict = {
        str_type: L2KSI.string_L2KSI_base_pattern for str_type in [0, 40, 41, 42, 43, 44, 45, 46]}
    """Массив, описывающий шаблоны единообразного парсинга строк всех известных типов"""

    signal_id: int = SignalTypes.L2KSI
    """Тип сигнала"""

    signal_type = signal_id
    """Тип сигнала (нужно для рдля консистентности  с классами кадров)"""

    def get_service_fields(self) -> L2KSI.ServiceFieldsL2KSI:
        return L2KSI.get_service_fields_l2ksi(self.int_content)

    def check_cyclic_code(self, string: bytes) -> bool:
        cyclic_code = parse_string_to_params(
            self.int_content, L2KSI.string_L2KSI_base_pattern)[0].get('CC')
        return 0 if cyclic_code == 0 else check_cyclic_code_short(string)

    def meta_as_dict(self):
        return {'frame_id': self.id,
                'bis_id': self.bis_id,
                'sources': None,
                'station_id': getattr(self.bis, 'station_id', None) if self.bis_id else None,
                'nka': self.nka_id,
                'tk': self.string_omv,
                'type': self.string_num,
                'seq': self.string_omv,
                'is_complete': 1,
                'timestamp': self.timestamp,
                'db_timestamp': self.db_timestamp}

    def as_long_dict(self):
        """Представление содержимого строки в виде набора значений параметров, который включает альманаха"""

        result = {}
        string = self.as_dict()
        if string:
            for par_name, par_val in string.items():
                result[par_name] = par_val
        return result
