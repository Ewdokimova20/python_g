import functools
import logging
from abc import abstractmethod
from collections import defaultdict
from datetime import datetime
from typing import Optional, Any

from peewee import BooleanField, IntegerField, BlobField, ForeignKeyField, DateTimeField

from models.base import OperativeStorageModel
from models.bis import Bis
from models.nka import Nka
from utils.bytestring_parser import SingleParam
from utils.lib.exceptions import MissingParamError


class BaseDIString(OperativeStorageModel):
    """Базовый класс для всех строк цифровой информации (ЦИ) сигналов."""

    nka: Nka = ForeignKeyField(Nka, on_delete='CASCADE')
    """НКА, с которого принята строку"""
    bis: Bis = ForeignKeyField(Bis, on_delete='CASCADE')
    """БИС, который принял строку"""
    timestamp: datetime = DateTimeField()
    """Время формирования пакета, в котором принята строка, в секундах с 01.01.1970 с точностью до миллисекунды"""
    string_num: int = IntegerField()
    """Номер строки"""
    byte_content: bytes = BlobField()
    """
    Байтовая строка, закодированная в base64
    Содержит байты кодограммы соответствующего сигнала по 14Ц181.4000-0 Д3

    Для кодирования используется base64.b64encode(codogram).decode('utf-8')
    """
    error_in_string: bool = BooleanField(default=True)
    """
    Результат проверки циклического кода строки на ошибки.
    True (1) - Строка содержит ошибки,
    False (0) - Строка без ошибок
    """

    """ ================================ Далее идут поля, не сохраняемые в ЛБД ================================ """

    parameters_description = defaultdict(lambda: defaultdict(SingleParam))
    """Словарь строк, позволяющий на основании интерфейса базового класса декодировать строки в потомках"""
    signal_id: int = None  # идентификатор сигнала, используемый в обощенный ф-ях и конкретизируемый в потомках

    @property
    def logger(self):
        """Логгер с названием класса, в котором он вызван"""
        return logging.getLogger(self.__class__.__name__)

    @property
    @functools.lru_cache()
    def int_content(self):
        """Строка в двоичной форме, используемая ф-ей bin_value
        для выделения полей (не определена в случае заполнения из ЛБД)"""
        return self.as_int()

    @property
    @functools.lru_cache()
    def content(self):
        """Возвращает два словаря "параметр:значение", содержащихся в строке (первый декодированный, второй -- нет)"""
        return self.get_content()

    def __str__(self):
        return f"{str(self.byte_content)} {str(self.string_num)} {str(self.timestamp)}"

    @abstractmethod
    def as_int(self) -> int:
        """Метод представления строки в виде числа. """
        pass

    @abstractmethod
    def get_content(self):
        pass

    def get_param_or_none(self, key: str) -> Optional[Any]:
        """Безопасно получить значение параметра key из содержимого строки."""
        try:
            if self.content and len(self.content) > 0:
                return self.content[0].get(key, None)
        except Exception:
            pass
        return None

    def get_param(self, key: str) -> Any:
        """
        Получить значение параметра key из content[0]. Кидает исключение, если параметр/строка отсутствует.
        """
        if not self.content or len(self.content) == 0:
            raise MissingParamError(f"Свойство content пустое или отсутствует для строки {str(self)}")
        value = self.content[0].get(key, None)
        if value is None:
            raise MissingParamError(f"Параметр '{key}' не найден в свойстве content строки {str(self)}")
        return value
