from __future__ import annotations

from global_data.appdata import SignalTypes
from models.di_string.cd_signal_string import CDSignalString
from utils.signals.CD import L1OC


class L1OCString(CDSignalString):
    """Таблица принятых строк цифровой информации L1OC."""

    string_length: int = L1OC.STRING_2SEC_BITLENGTH
    """Длина строки в битах"""

    string_duration: int = L1OC.L1OC_STRING_DURATION

    parameters_description: dict = L1OC.strings_pattern_250bit
    """Массив, описывающий шаблоны парсинга строк (кроме аномальных)"""

    service_pattern: dict = L1OC.service_pattern
    """Шаблон парсинга служебных полей строк"""

    signal_id: int = SignalTypes.L1OCd

    def get_service_fields(self) -> L1OC.ServiceFieldsL1OC:
        return L1OC.get_service_fields_l1oc(self.int_content)

    def get_pseudoframe_length(self) -> int:
        """Возвращает длину псевдокадра, если строка является 10, иначе None"""
        return L1OC.get_pseudoframe_length_l1oc(
            self.int_content) if self.service_fields.type == 10 and not self.error_in_string else None

    def check_cyclic_code(self, string: bytes) -> bool:
        return L1OC.check_cyclic_code_long(string)
