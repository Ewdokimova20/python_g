from __future__ import annotations

import functools
from abc import abstractmethod
from datetime import datetime
from typing import Dict

from peewee import IntegrityError, IntegerField

from models.bis import Bis
from models.di_string.base_di_string import BaseDIString
from models.nka import Nka
from models.op_message import KNPOpMessage
from scripts.process_registry import get_di_string_buffer
from utils.CD_strings_utils import ServiceFields
from utils.bytestring_parser import parse_string_to_params
from utils.lib.exceptions import ParseDIStringError
from utils.signals.common import format_ground_call_control_raw_value


class CDSignalString(BaseDIString):
    """Таблица принятых строк цифровой информации"""

    string_omv: int = IntegerField()
    """Оцифровка метки времени, от 1 до 3 секундные интервалы в зависимости от типа сигнала"""

    """ ================================ Далее идут поля, не сохраняемые в ЛБД ================================ 
    К ним недопустимо обращаться после запроса строки из ЛБД без явного заполнения"""

    string_length: int = None
    """Длина строки в битах (Должна быть уточнена в потомках для конкретных сигналов)"""

    string_duration: int = None
    """Длительность передачи строки, секунды (Должна быть уточнена в потомках для конкретных сигналов)"""

    @property
    @functools.lru_cache()
    def string_time(self):
        # """Время строки в секундах от начала суток"""
        return self.service_fields.omv * self.string_duration

    @property
    @functools.lru_cache()
    def service_fields(self):
        """Строка в двоичной форме, используемая ф-ей bin_value
        для выделения полей (не определена в случае заполнения из ЛБД)"""
        return self.get_service_fields()

    def as_binary_string(self) -> Dict[str, datetime | str]:
        """Метод представления строки в виде бинарной строки. Имеет наиболее общее определение для строк кодовых
        сигналов"""
        num = self.int_content
        return {'db_timestamp': self.db_timestamp, 'content': f'{num:0{self.string_length}b}'}

    def as_int(self) -> int:
        """Метод представления строки в виде числа. Имеет наиболее общее определение для строк кодовых
        сигналов. Количество отбрасываемых младших нулей определяется автоматически исходя из длины строки

        Поскольку строка лежит с первого бита байтового массива и длина строки не кратна
        размеру массива, при преобразовании строки из байтового массива в число смещаемся на число бит,
        соответствующее неиспользуемому концу байтового массива"""
        return int.from_bytes(self.byte_content, byteorder='big') >> \
               ((64 * (1 + (self.string_length // 64))) -
                self.string_length)  # удаление лишних младших нулей

    def get_content(self):
        """Возвращает два словаря "параметр:значение", содержащихся в строке (первый декодированный, второй -- нет)"""

        """Проверяем достаточность данных для декодирования"""
        if self.string_num is None or not self.byte_content:
            raise ParseDIStringError(message='В строке отсутствует номер строки или содержимое. Расшифровка невозможна',
                                     string_num=self.string_num, content=self.as_int())
        """Находим необходимый набор параметров"""
        if self.string_num not in self.parameters_description.keys():
            # аномальный тип строки - значит расшифровываем строку по сервисному паттерну
            self.parameters_description[self.string_num] = self.service_pattern
            service_fields_dict, service_fields_raw = parse_string_to_params(self.int_content, self.service_pattern)
            return service_fields_dict, service_fields_raw
        """По словарям получаем параметры (и в кодированном, и в декодированном виде)"""
        return parse_string_to_params(self.int_content, self.parameters_description[self.string_num])

    def as_dict(self) -> Dict[str, Dict]:
        """Представление строки в виде набора словарей для отдачи клиенту
        Результат включает как декодированный, так и первичный вид параметров.
        Формат соответствует существующим классам строк для L1OF"""
        result = {}
        try:
            content_decoded, content_raw = self.content
        except ParseDIStringError as e:
            raise (e)
        else:
            for key, value_decoded in content_decoded.items():
                description = ''
                value_raw = f"{content_raw[key]:b}"
                try:
                    description = self.parameters_description[self.string_num][key].description
                except:
                    pass

                if key == 'j' and content_decoded['type'] == 20:
                    result['ja'] = {
                        'val': value_decoded, 'raw': value_raw, 'description': description}
                elif key != 'raw_content':
                    if key in ['x', 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az']:
                        value_decoded *= 1000  # перевод из км в метры
                    if key == 'P1':
                        value_raw = format_ground_call_control_raw_value(self.signal_id, content_raw[key])
                    result[key] = {'val': value_decoded, 'raw': value_raw, 'description': description}
                else:
                    result[key] = {
                        'val': '', 'raw': value_raw, 'description': description}
        return result

    def check_string_for_alarms(self) -> list:
        """Сходу отбрасываем строку, не прошедшую контроль целостности"""

        if self.error_in_string != 0:
            return []

        """При отсутствии признаков дальше обрабатывать нет смысла"""
        if (self.service_fields.lj == 0) and (self.service_fields.gj == 0) and (self.service_fields.P1 == 0):
            return []
        """Сохраняем сообщение и определяем его ключ для квитирования просмотра"""
        return [KNPOpMessage(bis=self.bis,
                             nka=self.nka,  # недопустимо брать j т.к. в строках альманаха указывает на передаваемый
                             timestamp=self.timestamp,
                             letter=-1,  # В кодограммах нет литеры, не заполняем
                             # Номера сигналов ГЛОНАСС по ПРИЛОЖЕНИЕ А 14Ц181.4000-0 Д3
                             signal_type=self.signal_id,
                             snr=0,
                             not_in_sight=0,
                             excess_of_residual=0,
                             excess_of_pseudorange_difference=0,
                             excess_of_navsolution_error=0,
                             ground_control_call=self.service_fields.P1,
                             unreliable_frame=0,
                             unreliable_signal=self.service_fields.gj,
                             unreliable_digital_info=self.service_fields.lj,
                             tk_inconsistency=0,
                             tb_inconsistency=0)]

    @abstractmethod
    def get_service_fields(self) -> ServiceFields:
        pass

    def get_pseudoframe_length(self) -> int:
        """Возвращает длину псевдокадра, если строка является 10, иначе None"""
        pass

    def check_cyclic_code(self, string: bytes) -> bool:
        """Проверка ЦК. Возвращает 0 при отсутствии ошибок, иначе 1."""

        pass

    def write_to_db(self, nka: Nka, bis: Bis, timestamp: datetime, byte_string: bytes) -> CDSignalString:
        """Запись байтов принятой строки в ЛБД. Помимо записи возвращается строка с заполненными вторичными полями,
        не хранящимися в БД"""
        string = None

        self.byte_content = byte_string
        serv_fields = self.service_fields
        flag_cyclic_code = self.check_cyclic_code(
            byte_string)  # проверка циклического кода

        try:
            string_data = {
                'nka': nka,
                'bis': bis,
                'timestamp': timestamp,
                'string_num': serv_fields.type,
                'string_omv': serv_fields.omv,
                'byte_content': byte_string,
                'error_in_string': flag_cyclic_code
            }
            string = self.__class__(**string_data)
            di_string_buffer = get_di_string_buffer()
            di_string_buffer.add_record(model=self.__class__, data=string_data)
        except IntegrityError as err:
            self.logger.warning(err)
            self.logger.warning(
                f'Ошибка записи строки ЦИ: КА№ {str(nka)}, БИС№ {str(bis)}, строка № {str(serv_fields.type)}, время {str(timestamp)} ')
        return string

    class Meta:
        indexes = (
            (('nka', 'bis', 'timestamp'), True),
        )
