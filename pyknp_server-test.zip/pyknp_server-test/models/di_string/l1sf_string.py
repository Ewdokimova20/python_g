from __future__ import annotations

from datetime import datetime
from typing import Dict

from peewee import IntegrityError

from global_data.appdata import SignalTypes
from models.bis import Bis
from models.di_string.base_di_string import BaseDIString
from models.nka import Nka
from models.op_message import KNPOpMessage
from scripts.process_registry import get_di_string_buffer
from utils.bytestring_parser import parse_string_to_params
from utils.signals.FD.L1SF import check_hamming_code_7b, L1SF_strings_pattern
from utils.signals.common import format_ground_call_control_raw_value


class L1SFString(BaseDIString):
    """Таблица принятых строк цифровой информации L1SF
    Формируется на основе 6 байт кодограммы L1SF по 14Ц181.4000-0 Д3"""

    signal_id: int = SignalTypes.L1SF

    parameters_description: dict = L1SF_strings_pattern

    _content: int = None
    """Внутреннее значение содержимого, которое записывается после выполнения get_content()"""

    @property
    def content(self):
        """Внутреннее значение контента, которое записывается после выполнения get_content() с учетом номера сегмента"""
        if not self._content:
            return self.get_content()
        else:
            return self._content

    def as_binary_string(self) -> Dict[str, datetime | str] | str:
        num = self.int_content
        return {'db_timestamp': self.db_timestamp, 'content': f'{num:050b}'}

    def as_int(self) -> int:
        """Метод представления строки в виде числа. """
        return (int.from_bytes(self.byte_content, byteorder='big') >> 5) << 7
        # из 48 бит (6 байт), отведенных под строку, извлекаем только старшие 43 бит (сдвиг на 5)

    def get_content(self,
                    num_in_segment: int = 1):  # TODO рассмотреть вопрос передачи номера строки в суперкаадре. Для этого требуется та же информация как и сейчас, но позволит объединить все декодировки строк с частотным разделением воедино
        """Возвращает два словаря "параметр:значение", содержащихся в строке (первый декодированный, второй -- нет)"""
        string_num = self.string_num  # паттерны для 1 кадра в сегменте остаются с 1 по 10
        # паттерны для 2 кадра 18, 19, 20 / паттерны для 3 кадра в сегменте 28, 29, 30 (паттерны 1-7 одинаковые для всех 3)
        if num_in_segment == 2 or num_in_segment == 3:
            if self.string_num in [8, 9, 10]:
                string_num = self.string_num + (num_in_segment - 1) * 10
        """Проверяем достаточность данных для декодирования"""
        if string_num is None or not self.byte_content:
            raise ValueError('Please provide string_num and byte_content')
        """Находим необходимый набор параметров"""
        if string_num not in self.parameters_description.keys():
            raise ValueError('Unknown string type ', string_num)
        """По словарям получаем параметры (и в кодированном, и в декодированном виде)"""
        content = parse_string_to_params(self.int_content, self.parameters_description[string_num])
        self._content = content
        return content

    # TODO рассмотреть вопрос передачи номера строки в суперкаадре. Для этого требуется та же информация как и сейчас, но позволит объединить все декодировки строк с частотным разделением воедино
    def as_dict(self, num_in_segment: int) -> Dict[str, Dict]:
        """Представление строки в виде набора словарей для отдачи клиенту
        Результат включает как декодированный, так и первичный вид параметров.
        Формат соответствует существующим классам строк для L1OF"""
        result = {}
        string_num = self.string_num  # паттерны для 1 кадра в сегменте остаются с 1 по 10
        # паттерны для 2 кадра 18, 19, 20 / паттерны для 3 кадра в сегменте 28, 29, 30 (паттерны 1-7 одинаковые для всех 3)
        if num_in_segment == 2 or num_in_segment == 3:
            if self.string_num in [8, 9, 10]:
                string_num = self.string_num + (num_in_segment - 1) * 10
        try:
            content_decoded, content_raw = self.get_content(num_in_segment)
        except ValueError:
            pass
        else:
            for key, value_decoded in content_decoded.items():
                value_raw = f"{content_raw[key]:b}"
                if key in ['x', 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az']:
                    value_decoded *= 1000  # перевод из км в метры
                if key == 'Bn':
                    value_raw = format_ground_call_control_raw_value(self.signal_id, content_raw[key])
                description = ''
                try:
                    description = self.parameters_description[string_num][key].description
                except:
                    pass
                result[key] = {
                    'val': value_decoded, 'raw': value_raw, 'description': description}
            return result

    def check_string_for_alarms(self) -> list:
        """Сходу отбрасываем строку, не прошедшую контроль целостности
        (но помним, что это если КХ сошелся, то это может быть ложно положительный результат)"""
        if self.error_in_string != 0:
            return []
        l_n = 0
        b_n = 0
        # Получаем содержимое строки. Если при обработке возникает ошибка, то возвращаем пустой список
        try:
            decoded_string = self.content[0]
        except (ValueError, IndexError, TypeError) as e:
            self.logger.warning(
                "Ошибка строки при проверке сигнальных признаков:" + str(e))
            return []
        """Заполняем признаки только для содержащих их строк"""
        if self.string_num == 2:
            l_n = decoded_string['ln1']
            b_n = decoded_string['Bn']
        if self.string_num == 6:
            l_n = decoded_string['ln3']

        """При отсутствии признаков дальше обрабатывать нет смысла"""
        if (l_n == 0) and (b_n == 0):
            return []
        """Сохраняем сообщение и определяем его ключ для квитирования просмотра"""
        return [KNPOpMessage(bis=self.bis,
                             nka=self.nka,
                             timestamp=self.timestamp,
                             letter=-1,  # В кодограммах нет литеры, не заполняем
                             signal_type=0x21,  # Номера сигналов ГЛОНАСС по ПРИЛОЖЕНИЕ А 14Ц181.4000-0 Д3
                             snr=0,
                             not_in_sight=0,
                             excess_of_residual=0,
                             excess_of_pseudorange_difference=0,
                             excess_of_navsolution_error=0,
                             ground_control_call=b_n,
                             unreliable_frame=l_n,
                             unreliable_signal=0,
                             unreliable_digital_info=0,
                             tk_inconsistency=0,
                             tb_inconsistency=0)]

    def write_to_db(self, nka: Nka, bis: Bis, timestamp: datetime, string_num: int, checksum_7b: int,
                    byte_string: bytes) -> L1SFString:
        """Запись байтов принятой строки в ЛБД. Помимо записи возвращается строка с заполненными вторичными полями,
        не хранящимися в БД"""
        string = None
        flag_hamming_code = check_hamming_code_7b(byte_string, checksum_7b)
        byte_content = byte_string
        self.byte_content = byte_content

        try:
            string_data = {
                'nka': nka,
                'bis': bis,
                'timestamp': timestamp,
                'string_num': string_num,
                'byte_content': byte_content,
                'error_in_string': flag_hamming_code
            }
            string = type(self)(**string_data)
            di_string_buffer = get_di_string_buffer()
            di_string_buffer.add_record(model=self.__class__, data=string_data)
        except IntegrityError as err:
            # TODO При подготовке к установке штатного ПО переделать на warning
            self.logger.warning(err)
            self.logger.warning(
                f'Ошибка записи строки {type(self).__name__}: КА№ {str(nka)}, БИС№ {str(bis)}, строка № {str(string_num)}, время {str(timestamp)} ')
        return string

    class Meta:
        indexes = (
            (('nka', 'bis', 'timestamp'), True),
        )
