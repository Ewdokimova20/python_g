from global_data.appdata import SignalTypes
from models.di_string.of_signal_string import OFSignalString


class L1OFString(OFSignalString):
    """Таблица принятых строк цифровой информации"""

    signal_id: int = SignalTypes.L1OF
