from __future__ import annotations

from datetime import datetime
from typing import Dict

from peewee import IntegrityError

from models.bis import Bis
from models.di_string.base_di_string import BaseDIString
from models.nka import Nka
from models.op_message import KNPOpMessage
from scripts.process_registry import get_di_string_buffer
from utils.bytestring_parser import parse_string_to_params
from utils.signals.FD.L1OF import L1OF_strings_pattern, check_hamming_code
from utils.signals.common import format_ground_call_control_raw_value


class OFSignalString(BaseDIString):
    """Таблица принятых строк цифровой информации сигналов с открытым доступом и частотным разделением
    Формируется на основе всех 12 байт кодограммы L1OF/L1OF по 14Ц181.4000-0 Д3
    """

    parameters_description: dict = L1OF_strings_pattern

    def as_binary_string(self) -> Dict[str, datetime | str] | str:
        num = self.int_content
        return {'db_timestamp': self.db_timestamp, 'content': f'{num:076b}'}

    def as_int(self) -> int:
        """Метод представления строки в виде числа. """
        return int.from_bytes(self.byte_content, byteorder='big') >> 20

    def get_content(self,
                    is_fifth: bool = False):  # TODO рассмотреть вопрос передачи номера строки в суперкаадре. Для этого требуется та же информация как и сейчас, но позволит объединить все декодировки строк с частотным разделением воедино
        """Возвращает два словаря "параметр:значение", содержащихся в строке (первый декодированный, второй -- нет)"""
        string_num = self.string_num  # паттерны для всех кадров кроме последнего в суперкадре остаются в диапазоне с 1 по 15
        # паттерны для строк 14 и 15 последнего кадра суперкадра
        if is_fifth and self.string_num in [14, 15]:
            string_num = self.string_num + 60
        """Проверяем достаточность данных для декодирования"""
        if string_num is None or not self.byte_content:
            raise ValueError('Please provide string_num and byte_content')
        """Находим необходимый набор параметров"""
        if string_num not in self.parameters_description.keys():
            raise ValueError('Unknown string type ', string_num)
        """По словарям получаем параметры (и в кодированном, и в декодированном виде)"""
        return parse_string_to_params(self.int_content, self.parameters_description[string_num])

    def as_dict(self,
                is_fifth=False):  # TODO рассмотреть вопрос передачи номера строки в суперкаадре. Для этого требуется та же информация как и сейчас, но позволит объединить все декодировки строк с частотным разделением воедино
        result = {}
        try:
            content_decoded, content_raw = self.get_content(is_fifth=is_fifth)
        except ValueError:
            pass
        else:
            for key, value_decoded in content_decoded.items():
                value_raw = f"{content_raw[key]:b}"
                description = ''
                try:
                    description = self.parameters_description[self.string_num][key].description
                except:
                    pass

                if key in ['x', 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az']:
                    value_decoded *= 1000  # перевод из км в метры
                if key == 'Bn':
                    value_raw = format_ground_call_control_raw_value(self.signal_id, content_raw[key])
                result[key] = {'val': value_decoded,
                               'raw': value_raw,
                               'description': description}
        return result

    def check_string_for_alarms(self) -> list:
        """Сходу отбрасываем строку, не прошедшую контроль целостности
        (но помним, что это если КХ сошелся, то это может быть ложно положительный результат)"""
        if self.error_in_string != 0:
            return []
        l_n = 0
        b_n = 0
        try:
            decoded_string = self.content[0]
        except (ValueError, IndexError, TypeError) as e:
            self.logger.warning(
                f"Ошибка строки при проверке сигнальных признаков для строки {str(self)}:" + str(e))
            return []
        """Заполняем признаки только для содержащих их строк"""
        if self.string_num == 2:
            l_n = decoded_string['ln1'] >> 2
            b_n = decoded_string['Bn'] & 3
        if self.string_num == 3:
            l_n = decoded_string['ln3']
        if self.string_num == 5:
            l_n = decoded_string['ln5']
        if self.string_num in [7, 9, 11, 13, 15]:
            l_n = decoded_string['ln_a']

        """При отсутствии признаков дальше обрабатывать нет смысла"""
        if (l_n == 0) and (b_n == 0):
            return []
        """Сохраняем сообщение и определяем его ключ для квитирования просмотра"""
        return [KNPOpMessage(bis=self.bis,
                             nka=self.nka,
                             timestamp=self.timestamp,
                             letter=-1,  # В кодограммах нет литеры, не заполняем
                             # Номера сигналов ГЛОНАСС по ПРИЛОЖЕНИЕ А 14Ц181.4000-0 Д3
                             signal_type=self.signal_id,
                             snr=0,
                             not_in_sight=0,
                             excess_of_residual=0,
                             excess_of_pseudorange_difference=0,
                             excess_of_navsolution_error=0,
                             ground_control_call=b_n,
                             unreliable_frame=l_n,
                             unreliable_signal=0,
                             unreliable_digital_info=0,
                             tk_inconsistency=0,
                             tb_inconsistency=0)]

    def write_to_db(self, nka: Nka, bis: Bis, timestamp: datetime, string_num: int, checksum_1b: int,
                    byte_string: bytes) -> OFSignalString:
        """Запись байтов принятой строки в ЛБД. Помимо записи возвращается строка с заполненными вторичными полями,
        не хранящимися в БД"""
        string = None
        flag_hamming_code = check_hamming_code(byte_string, checksum_1b)
        byte_content = byte_string
        self.byte_content = byte_content

        try:
            string_data = {
                'nka': nka,
                'bis': bis,
                'timestamp': timestamp,
                'string_num': string_num,
                'byte_content': byte_content,
                'error_in_string': flag_hamming_code
            }
            string = self.__class__(**string_data)
            di_string_buffer = get_di_string_buffer()
            di_string_buffer.add_record(model=self.__class__, data=string_data)
        except IntegrityError as err:
            # TODO При подготовке к установке штатного ПО переделать на warning
            self.logger.warning(err)
            self.logger.warning(
                f'Ошибка записи строки {type(self).__name__}: КА№ {str(nka)}, БИС№ {str(bis)}, строка № {str(string_num)}, время {str(timestamp)} ')
        return string

    class Meta:
        indexes = (
            (('nka', 'bis', 'timestamp'), True),
        )
