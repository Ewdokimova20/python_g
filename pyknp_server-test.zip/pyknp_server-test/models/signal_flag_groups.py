import datetime

import peewee
from peewee import IntegerField, DateTimeField, ForeignKeyField, AutoField

from models.base import OperativeStorageModel, BaseModel


class SignalFlagGroups(OperativeStorageModel):
    """Группы сигнальных признаков"""

    group_id = AutoField(primary_key=True)
    """Уникальный идентификатор группы"""
    nka = IntegerField()
    """Системный номер НКА, для которого выявлен СП"""
    alarm_id = IntegerField()
    """Идентификатор СП. utils.SignalFlags.types.AlarmId"""
    signal_id = IntegerField()
    """Сигнал, для которого выявлен СП. appdata.SIGNAL_TYPES"""
    alarm_value = IntegerField(null=True)
    """Если СП может принимать различные значения, то здесь оно хранится"""
    finalize_code = IntegerField(null=True)
    """Код причины завершения конкретного СП. Используется для отражения причины завершения ситуации."""
    first_appear_timestamp = DateTimeField(default=datetime.datetime.now)
    """Момент первого выявления данной комбинации"""
    last_appear_timestamp = DateTimeField(default=datetime.datetime.now)
    """Момент позднейшего выявления сигнального признака данной комбинации"""
    approved_timestamp = DateTimeField(default=datetime.datetime.now)
    """Время первого скрытия сигнального признака(отключение звуковой сигнализации)"""

    class Meta:
        table_name = 'signal_flag_groups'


class SourcesSignalFlagGroups(BaseModel):
    """Связь групп сигнальных признаков с БИС"""

    group_id = ForeignKeyField(SignalFlagGroups, backref='bis_links', on_delete='CASCADE')
    """Ссылка на группу сигнальных признаков."""
    source_id = IntegerField()
    """Источник, выявивший СП. SourceId"""
    bis_id = IntegerField()
    """Идентификатор БИС."""

    class Meta:
        # Создаем составной первичный ключ
        primary_key = peewee.CompositeKey('group_id', 'source_id', 'bis_id')
        table_name = 'sources_signal_flag_groups'
