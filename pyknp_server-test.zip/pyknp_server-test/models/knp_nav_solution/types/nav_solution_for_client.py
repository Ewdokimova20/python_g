from datetime import datetime
from typing import Optional, List

from typing_extensions import TypedDict


class NavSolutionForClient(TypedDict):
    """
    Typed dict для представления KnpNavSolution в формате словаря
    """
    id: int
    """ИД"""
    bis_id: int
    """БИС, для которого получено решение"""
    signal: int
    """Основной сигнал, по невязкам которого считается НВЗ"""
    timestamp: datetime
    """Время, на которое получено решение"""
    latitude: float
    """Широта, градусы"""
    longitude: float
    """Долгота, градусы"""
    height: float
    """Высота, метры"""
    x: float
    """x-координата, метры"""
    y: float
    """y-координата, метры"""
    z: float
    """z-координата, метры"""
    dx: Optional[float]
    """Отклонение по x-координате, метры"""
    dy: Optional[float]
    """Отклонение по y-координате, метры"""
    dz: Optional[float]
    """ОТклонение по z-координате, метры"""
    is_x_valid: Optional[bool]
    """Превысила ли x-координата порог"""
    is_y_valid: Optional[bool]
    """Превысила ли y-координата порог"""
    is_z_valid: Optional[bool]
    """Превысила ли z-координата порог"""
    E: float
    """E-координата (восток), метры"""
    N: float
    """отклонение по y-координате от опорного значения, метры"""
    U: float
    """U-координата (верх), метры"""
    dt: float
    """Смещение шкалы времени БИС от шкалы ГЛОНАСС в метрах"""
    distance: float
    """расстояние от опорной точки, метры"""
    GDOP: float
    """Geometric dilution of precision"""
    nka_list: List[int]
    """Список НКА, по невязкам которых решена задача"""
    user_solution: bool
    """Признак решения НВЗ с параметрами пользователя"""
    best_solution: bool
    """Признак решения НВЗ с параметрами пользователя которое было признано лучшим при исключении "плохого" НКА"""
