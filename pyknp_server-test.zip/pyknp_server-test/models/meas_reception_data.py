from peewee import ForeignKeyField

from data import Signal
from models.reception_control.base_reception_data import BaseReceptionData


class MeasReceptionData(BaseReceptionData):
    """
    Таблица для хранения данных о приеме 1c измерений.
    """
    measurement: Signal = ForeignKeyField(Signal, on_delete='CASCADE')
    """Последнее полученное измерения."""

    class Meta:
        table_name = 'meas_reception_data'
