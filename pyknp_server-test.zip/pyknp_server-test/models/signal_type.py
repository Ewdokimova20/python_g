from datetime import datetime

from peewee import IntegerField, CharField, DateTimeField

from models.base import BaseModel


class SignalType(BaseModel):
    """Тип сигнала.

    Тип сигнала. Должен быть заполнен в соответствии с
    14Ц181.4000-0 Д3 Приложение А.
    """

    signal_type_id: int = IntegerField(primary_key=True)
    """Код сигнала"""
    name: str = CharField(default='n/a')
    """Тип сигнала"""
    db_timestamp: datetime = DateTimeField(
        default=datetime.now)
    """Время записи в БД"""
