from __future__ import annotations

import datetime
from typing import Optional

from peewee import IntegerField, DateTimeField

from global_data.appdata import reliability_control_elevation as relce, receive_control_elevation as recce, min_elevation as me, \
    solution_distance_threshold as sdt
from models.base import BaseModel
from utils.coordinates.coordinates import Coordinates


class Station(BaseModel):
    """Станция.

    Станция беззапросных измерительных средств (БИС).
    """

    station_number: int = IntegerField(unique=True, primary_key=True)
    """Номер станции"""
    reliability_control_elevation: int = IntegerField(default=relce['default'])
    """Угол места, с которого начинается оценка достоверности нав. сигналов
    
    Должен быть заполнен по данным из файла конфигурации. Если
    в файле конфигурации отсутствует значение для конкретной станции,
    то должен быть заполнен значением по умолчанию из файла 
    конфигурации. Если в файле конфигурации отсутствует значение по
    умолчанию, то заполняется значением из appdata.reliability_control_elevation['default']
    """
    receive_control_elevation: int = IntegerField(default=recce['default'])
    """Угол места, с которого начинается контроль приёма навигационных сигналов
    
    Должен быть заполнен по данным из файла конфигурации. Если
    в файле конфигурации отсутствует значение для конкретной станции,
    то должен быть заполнен значением по умолчанию из файла 
    конфигурации. Если в файле конфигурации отсутствует значение по
    умолчанию, то заполняется значением из appdata.receive_control_elevation['default']
    """

    min_elevation: int = IntegerField(default=me['default'])
    """Угол места возможного приема сигналов НКА
    
    Должен быть заполнен по данным из файла конфигурации. Если
    в файле конфигурации отсутствует значение для конкретной станции,
    то должен быть заполнен значением по умолчанию из файла 
    конфигурации. Если в файле конфигурации отсутствует значение по
    умолчанию, то заполняется значением из appdata.min_elevation['default']
    """
    solution_distance_threshold: int = IntegerField(default=sdt['default'])
    """Порог расстояния от РНЗ до БИС"""
    db_timestamp: datetime.datetime = DateTimeField(
        default=datetime.datetime.now)
    """Время записи в БД"""
    coordinates: Optional['Coordinates'] = None
    """Координаты одного из БИС на этой станции (для расчета видимости НКА, в БД не пишется)"""

    @classmethod
    def get_or_create_station(cls, station_number: int) -> 'Station':
        """
        Возвращает существующую или создает новую станцию с заданным номером.

        :param station_number: Номер станции
        :return: Экземпляр станции
        """
        defaults = {
            'reliability_control_elevation': relce.get(station_number, relce['default']),
            'receive_control_elevation': recce.get(station_number, recce['default']),
            'min_elevation': me.get(station_number, me['default']),
            'solution_distance_threshold': sdt.get(station_number, sdt['default'])
        }

        station, created = cls.get_or_create(
            station_number=station_number,
            defaults=defaults
        )

        # Если станция уже существовала, обновляем ее значения
        if not created:
            for key, value in defaults.items():
                setattr(station, key, value)
            station.save()

        return station
