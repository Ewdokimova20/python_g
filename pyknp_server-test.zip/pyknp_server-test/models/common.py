import logging
from math import sqrt

from cachetools.func import ttl_cache

from utils.coordinates.coordinates import Coordinates

logger = logging.getLogger('models.common')

# Константы
# omega = 7.2921151467e-5  #рад/с
J2 = 1.0826257e-3
GM = 3.986004418e14  # м3/с2
AE = 6378136  # м
J2_GM_AE = 1.5 * J2 * GM * (AE * AE)

# Вычисленные значения для ускорения вычислений
# omega_sqrt = omega ** 2
# omega_mul_2 = omega * 2
OMEGA_SQRT = 5.3174943312731555e-09
OMEGA_MUL_2 = 0.000145842302934


class MList(list):

    def __add__(self, other):
        import itertools
        if type(self) is type(other):
            return MList(map(sum, itertools.zip_longest(self, other, fillvalue=0)))
        else:
            return MList([self[i] + other[i] for i in range(len(self))])

    def __mul__(self, other):
        return MList([self[i] * other for i in range(len(self))])

    def __truediv__(self, other):
        return MList([self[i] / other for i in range(len(self))])


@ttl_cache(maxsize=250000, ttl=15 * 60, typed=False)
def next_state(c: Coordinates, step: float) -> Coordinates:
    """ Функция расчета координат и скоростей на следующий шаг Рунге-Кутты
        Должна быть здесь чтобы работал @lru_cache

    Args:
        c (Coordinates): Модель Coordinates.
        step (float): текущий шаг.

    Returns:
        Coordinates: Модель Coordinates.
    """

    def glonass_diff_eq(state: MList, acc: MList) -> MList:
        """ Диффур из goGPS

        Args:
            state (MList): Координаты в XYZ (м) и вектор скорости в XYZ (м/с).
            acc (MList): Вектор ускорения в XYZ, м/(с*с).

        Returns:
            MList: MList.
        """

        x, y, z, Vx, Vy, Vz = state
        ax, ay, az = acc

        r_sq = x * x + y * y + z * z
        if r_sq <= 0:
            return MList([0, 0, 0, 0, 0, 0])
        r = sqrt(r_sq)
        r_cube = r * r_sq
        r_fifth = r_cube * r_sq
        z_sq_div_r_sq_5 = (z * z / r_sq) * 5

        a = -GM / r_cube
        b = J2_GM_AE / r_fifth

        c1 = 1 - z_sq_div_r_sq_5
        c2 = 3 - z_sq_div_r_sq_5

        a_b_mul_c1 = a - b * c1

        return MList([
            Vx,
            Vy,
            Vz,
            a_b_mul_c1 * x + OMEGA_SQRT * x + OMEGA_MUL_2 * Vy + ax,
            a_b_mul_c1 * y + OMEGA_SQRT * y - OMEGA_MUL_2 * Vx + ay,
            a * z - b * z * c2 + az
        ])

    def glonass_diff_eq_old(state, acc):
        """Диффур из ИКД, реализация по мотивам лайки"""
        # FIXME стоит прописать размерности констант и параметров чтобы не разгадывать этот ребус
        J2 = 1.08262575e-3
        mu = 3.986004418e14
        omega = 7.2921151467e-5
        ae = 6378136.0
        r = sqrt(state[0] ** 2 + state[1] ** 2 + state[2] ** 2)
        ders = MList([0, 0, 0, 0, 0, 0])
        if r ** 2 <= 0:
            return ders
        a = 1.5 * J2 * mu * (ae ** 2) / (r ** 5)
        b = 5 * (state[2] ** 2) / (r ** 2)
        c = -mu / (r ** 3) - a * (1 - b)
        ders[0:3] = state[3:6]
        ders[3] = (c + omega ** 2) * state[0] + 2 * omega * state[4] + acc[0]
        ders[4] = (c + omega ** 2) * state[1] - 2 * omega * state[3] + acc[1]
        ders[5] = (c - 2 * a) * state[2] + acc[2]
        return ders

    current_state = MList([*c.xyz, *c.vel])
    acc = MList([*c.acc])
    k1 = glonass_diff_eq(current_state, acc)
    k2 = glonass_diff_eq(current_state + (k1 / 2) * step, acc)
    k3 = glonass_diff_eq(current_state + (k2 / 2) * step, acc)
    k4 = glonass_diff_eq(current_state + k3 * step, acc)
    x, y, z, Vx, Vy, Vz = current_state + (k1 / 6) * step + (k2 / 3) * step + (k3 / 3) * step + (k4 / 6) * step
    xyz = Coordinates.XYZ(x=x, y=y, z=z)
    vel = Coordinates.Vxyz(Vx=Vx, Vy=Vy, Vz=Vz)
    return Coordinates(xyz=xyz, vel=vel, acc=c.acc)
