from __future__ import annotations

import datetime
import logging
from functools import lru_cache

from peewee import IntegerField, DateTimeField, ForeignKeyField, FloatField, AutoField

from models.base import BaseModel
from models.station import Station
from utils.coordinates.coordinates import Coordinates

logger = logging.getLogger('models.bis')


class Bis(BaseModel):
    """БИС (aka комплект).

    Беззапросное измерительное средство (БИС).
    """
    id = AutoField()
    """id БИС (соответствует столбцу id)"""
    bis_number: int = IntegerField()
    """Номер БИС (соответствует столбцу ttcinfo.stvol)"""
    station = ForeignKeyField(Station, backref='BISes')
    """Станция, в которой расположен БИС (соответствует столбцу ttcinfo.kip)"""
    x_coord: float = FloatField(default=-120000.0)
    """Координата x БИС"""
    y_coord: float = FloatField(default=350000.0)
    """Координата y БИС"""
    z_coord: float = FloatField(default=5200000.0)
    """Координата z БИС"""
    db_timestamp: datetime.datetime = DateTimeField(default=datetime.datetime.now)
    """Время записи в БД"""

    @property
    @lru_cache()
    def coordinates(self):
        """"Функция возвращает координаты текущей пары станция - БИС
        Если такая пара отсутствует, то возвращаются значения по-умолчанию

        Returns:
            Coordinates: экзмепляр класса Coordinates
        """
        try:
            xyz = Coordinates.XYZ(x=self.x_coord, y=self.y_coord, z=self.z_coord)
        except (AttributeError, KeyError):
            # отсутствуют координаты для данной комбинации Станция-БИС. Возвращаем значения по-умолчанию
            logger.error(f"Не существуют координаты для станции/БИС{str(self.station.station_number)}"
                         f"/{str(self.bis_number)}")
            # FIXME возможно, не по-тихому присваивать левые координаты, а болкировать расчет
            xyz = Coordinates.XYZ(x=-120000.0, y=350000.0, z=5200000.0)
        return Coordinates(xyz=xyz)
