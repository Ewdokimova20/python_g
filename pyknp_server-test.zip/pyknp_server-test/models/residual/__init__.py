from .types.residual_for_client import ResidualForClient
