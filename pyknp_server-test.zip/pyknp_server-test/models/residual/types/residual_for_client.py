from datetime import datetime
from typing import Optional

from typing_extensions import TypedDict


class ResidualForClient(TypedDict):
    """
    Typed dict для представления невязки в сокращенном формате
    """
    timestamp: datetime
    """Время, на которое рассчитана невязка"""
    residual: float
    """Величина невязки"""
    speed_residual: float
    """Величина невязки псевдоскорости"""
    nka: int
    """Номер НКА"""
    signal1: Optional[int]
    """Первый тип сигнала"""
    signal2: Optional[int]
    """Второй тип сигнала"""
    bis: int
    """Идентификатор БИС"""
    nka_elevation: float
    """Угол места НКА"""
    status: bool
    """Статус признания 'хорошей' невязкой"""
    delta: Optional[float]
    """Отклонение от среднего"""
    delta1: Optional[float]
    """Отклонение от среднего невязки по первому сигналу"""
    delta2: Optional[float]
    """Отклонение от среднего невязки по второму сигналу"""
    average: Optional[float]
    """Среднее по 'хорошим' невязкам"""
    status_speed_residual: bool
    """Статус невязки псевдоскорости"""
