from datetime import datetime

from peewee import ForeignKeyField, DateTimeField, IntegerField, BooleanField

from global_data.appdata import SignalTypes
from models.base import OperativeStorageModel
from models.bis import Bis
from models.nka import Nka


class KNPOpSumMessage(OperativeStorageModel):
    """Модель оперативного сообщения для обобщенной ЦИ"""
    bis: Bis = ForeignKeyField(Bis)
    """Бис, который прислал сообщения"""
    nka: Nka = ForeignKeyField(Nka)
    """НКА, для которого сформировано сообщение"""
    timestamp: datetime = DateTimeField()
    """Время сообщения"""
    letter: int = IntegerField()
    """Литера навигационного сигнала"""
    signal_type: SignalTypes = IntegerField()
    """Тип сигнала"""
    tk: int = IntegerField()
    """Время начала кадра в секундах с начала суток"""
    EI_inconsistency: bool = BooleanField()  # Несоответствие
    """Флаг несоответствия параметров ЭИ в обобщенной ЦИ с заложенными СИ"""
    clock_inconsistency: bool = BooleanField()  # Несоответствие
    """Флаг несоответствия параметров ЧВП в обобщенной ЦИ с заложенными СИ"""
    almanac_inconsistency: bool = BooleanField()  # Несоответствие
    """Флаг несоответствия параметров альманаха в обобщенной ЦИ с заложенными СИ"""
