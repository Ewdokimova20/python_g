from models.op_message.op_message import OpMessage


class KNPOpMessage(OpMessage):
    pass
