from datetime import datetime

from peewee import BooleanField, ForeignKeyField, DateTimeField, IntegerField, FloatField

from global_data.appdata import SignalTypes
from models.base import OperativeStorageModel
from models.bis import Bis
from models.nka import Nka


class OpMessage(OperativeStorageModel):
    """Модель оперативного сообщения"""

    bis: Bis = ForeignKeyField(Bis, backref='opmessage')
    """Бис, который прислал сообщения"""
    nka: Nka = ForeignKeyField(Nka, backref='opmessage')
    """НКА, для которого сформировано сообщение"""
    timestamp: datetime = DateTimeField()
    """Время сообщения"""
    letter: int = IntegerField()
    """Литера навигационного сигнала"""
    signal_type: SignalTypes = IntegerField()
    """Тип сигнала"""
    snr: float = FloatField()
    """Отношение сигнал/шум"""
    not_in_sight: bool = BooleanField()
    """Флаг отсутствия НКА в зоне радиовидимости"""
    excess_of_residual: bool = BooleanField()
    """Флаг превышения значений невязок кодовой псевдодальности"""
    excess_of_pseudorange_difference: bool = BooleanField()
    """Флаг превышения заданного порога значением разности псевдодальностей 
    по пилотной составляющей и составляющей с ЦИ"""
    excess_of_navsolution_error: bool = BooleanField()
    """Флаг превышения погрешности решения навигационной задачи"""
    ground_control_call: bool = BooleanField()
    """Флаг приёма в НС признака вызова НКУ"""
    unreliable_frame: bool = BooleanField()
    """Флаг приёма в НС признака недостоверности кадра"""
    unreliable_signal: bool = BooleanField()
    """Флаг приёма в НС признака негодности сигнала"""
    unreliable_digital_info: bool = BooleanField()
    """Флаг приёма в НС признака недостоверности строки ЦИ"""
    tk_inconsistency: bool = BooleanField()
    """Флаг несоответствия значений оцифровки метки времени в принятой ЦИ текущему времени"""
    tb_inconsistency: bool = BooleanField()
    """Флаг несоответствия значения tb значению tk"""
