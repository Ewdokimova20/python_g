from peewee import IntegerField, BooleanField

from models.reception_control.base_reception_data import BaseReceptionData


class DIReceptionData(BaseReceptionData):
    """
    Таблица для хранения данных о приеме строк ЦИ
    """
    error_count: int = IntegerField(null=True)
    """Счетчик строк ЦИ c ошибкой"""
    has_too_many_errors: bool = BooleanField(null=True)
    """Флаг показывает, превышает ли доля строк ЦИ с ошибками установленный порог."""

    class Meta:
        table_name = 'di_reception_data'
