import datetime
import logging

from peewee import ForeignKeyField, DateTimeField, FloatField, BooleanField, AutoField

from models.base import OperativeStorageModel
from models.bis import Bis

"""Одноуровневый словарь с перечнем актуальных метеоданных. Первый уровень - идентификатор БИС"""

logger = logging.getLogger('models.meteoparams')


class Meteoparameters(OperativeStorageModel):
    """Метеопараметры БИС из полученной строки ЦИ"""
    id = AutoField()
    """id Метеопараметров (соответствует столбцу id)"""
    bis: Bis = ForeignKeyField(
        Bis, backref='meteoparameters', on_delete='CASCADE')
    """БИС, который прислал метеоданные"""

    timestamp: datetime.datetime = DateTimeField(default=datetime.datetime.now)
    """Время сбора внутри сутках плюс общисистемная дата текущих суток"""

    p: float = FloatField()  # атмосферное давление, мБары
    t: float = FloatField()  # температура, градусы Цельсия
    h: float = FloatField()  # относительная влажность, %

    is_incorrect: bool = BooleanField(default=False)
    """Признак выхода метеопараметров за ОДЗ"""

    class Meta:
        indexes = (
            # non-unique index, for request data for tropospheric model
            (('bis', 'timestamp'), False),
        )
