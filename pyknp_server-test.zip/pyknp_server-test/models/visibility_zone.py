import datetime
import logging
from typing import List, Tuple

from peewee import IntegerField, DateTimeField, chunked, ForeignKeyField, CompositeKey

from data import Almanac
from global_data import appdata
from models.base import BaseModel
from utils.almanac.get_almanac_slot import get_almanac_slot
from utils.caches import cache_bis
from utils.visibility.visibility_zone_calculator import VisibilityZoneData, CalculateResult, \
    calc_visibility_zones_for_single_nka

logger = logging.getLogger('visibility_zones')


class VisibilityZone(BaseModel):
    """
    Модель для зон радиовидимости
    """
    nka = IntegerField()
    bis_id = IntegerField()
    almanac = ForeignKeyField(Almanac)
    possible_receive_time_start = DateTimeField()
    guaranteed_receive_time_start = DateTimeField()
    possible_receive_time_end = DateTimeField()
    guaranteed_receive_time_end = DateTimeField()

    class Meta:
        schema = 'visibility'
        table_name = 'visibility_zone'
        indexes = (
            (('nka', 'bis_id', 'almanac', 'guaranteed_receive_time_start'), True),
            (('nka', 'bis_id', 'almanac', 'guaranteed_receive_time_end'), True),
            (('nka', 'almanac'), True),
        )
        primary_key = CompositeKey('nka', 'bis_id', 'almanac', 'guaranteed_receive_time_start')

    def as_dict(self) -> VisibilityZoneData:
        return {
            'nka': self.nka,
            'bis_id': self.bis_id,
            'possible_receive_time_start': self.possible_receive_time_start,
            'guaranteed_receive_time_start': self.guaranteed_receive_time_start,
            'possible_receive_time_end': self.possible_receive_time_end,
            'guaranteed_receive_time_end': self.guaranteed_receive_time_end
        }

    @staticmethod
    def _round_to_minute(dt):
        """
        Округляет datetime до минуты
        """
        return dt.replace(second=0, microsecond=0)

    @classmethod
    def _update_db(cls, zones: List[VisibilityZoneData], almanac: Almanac):
        """
        Обновить рассчитанные ЗРВ в ТЛБД
        """
        with cls._meta.database.atomic():
            # Округляем все временные границы до минут
            rounded_zones = [
                {
                    'nka': zone['nka'],
                    'bis_id': zone['bis_id'],
                    'almanac': almanac,
                    'possible_receive_time_start': cls._round_to_minute(zone['possible_receive_time_start']),
                    'guaranteed_receive_time_start': cls._round_to_minute(zone['guaranteed_receive_time_start']),
                    'possible_receive_time_end': cls._round_to_minute(zone['possible_receive_time_end']),
                    'guaranteed_receive_time_end': cls._round_to_minute(zone['guaranteed_receive_time_end'])
                }
                for zone in zones
            ]

            # Вставляем новые записи пакетами по 1000, обновляя при конфликте
            for batch in chunked(rounded_zones, 1000):
                # Конфликты при вставке обрабатываются на уровне триггера вставки в партицию
                cls.insert_many(batch).execute()

    @classmethod
    def calculate_and_update(cls, days_ahead=8):
        """
        Рассчитать ЗРВ для всех БИС и обновить их в ТЛБД
        """
        current_date_midnight = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = (current_date_midnight + datetime.timedelta(days=days_ahead))
        all_bis = cache_bis.get_bis_list()
        all_nka = appdata.NKA_DATA.keys()

        for nka_id in all_nka:
            fresh_almanac = get_almanac_slot(nka_id)
            if not fresh_almanac:
                logger.warning(f"Не удалось получить последний актуальный альманах для НКА {nka_id}")
                continue

            # Получаем последнюю зону для данного НКА и альманаха
            latest_zone = (cls.select()
                           .where(cls.nka == nka_id, cls.almanac == fresh_almanac.id)
                           .order_by(cls.guaranteed_receive_time_end.desc())
                           .first())

            if latest_zone:
                start_time = latest_zone.guaranteed_receive_time_start
            else:
                start_time = current_date_midnight

            if start_time < end_date:
                new_zones = []
                for bis in all_bis:
                    result, zones = calc_visibility_zones_for_single_nka(
                        bis.id, nka_id, start_time, end_date
                    )
                    logger.info(
                        f'Досчитаны ЗРВ для НКА {nka_id} и БИС {bis.id} с {start_time} до {end_date}')
                    if result == CalculateResult.Ok:
                        new_zones.extend(zones)

                if new_zones:
                    cls._update_db(new_zones, fresh_almanac)
                    logger.info(
                        f'ЗРВ для НКА {nka_id} записаны в ТЛБД')
                else:
                    logger.info(f'Не посчитано новых зон для НКА {nka_id}')

        logger.info(f'Расчет ЗРВ окончен в {datetime.datetime.now()}')

    @classmethod
    def get_zones(cls, nka: int, bis_id: int, start: datetime.datetime, end: datetime.datetime) \
            -> Tuple[CalculateResult, List[VisibilityZoneData]]:
        """
        Получить список всех ЗРВ для заданного НКА и заданной БИС
        """
        if start > end:
            return CalculateResult.UnorderedBorders, []

        bis = cache_bis.get_item_by_id(bis_id)
        if bis is None:
            return CalculateResult.UnknownBis, []

        zones = (cls.select().where(
            (cls.nka == nka) & (cls.bis_id == bis_id) & (
                    (cls.possible_receive_time_start.between(start, end)) |
                    (cls.possible_receive_time_end.between(start, end)) | (
                            (cls.possible_receive_time_start <= start) &
                            (cls.possible_receive_time_end >= end)
                    )
            )
        ).order_by(cls.possible_receive_time_start))

        calc_result = CalculateResult.Ok

        return calc_result, [zone.as_dict() for zone in zones]
