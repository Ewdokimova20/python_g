from __future__ import annotations

import datetime

from peewee import IntegerField, DateTimeField, CharField

from global_data.nka_type import NkaType
from models.base import BaseModel


class Nka(BaseModel):
    """НКА.

    Навигационный космический аппарат из состава ГЛОНАСС.
    """

    nka_sys_number: int = IntegerField(unique=True, primary_key=True)
    """Системный номер НКА"""
    nku_number: int = IntegerField(default=0)
    """Номер НКА в НКУ"""
    type_ka: NkaType = CharField(default="")
    """Название КА"""
    type_si: NkaType = CharField(null=True)
    """Название СИ"""
    db_timestamp: datetime.datetime = DateTimeField(
        default=datetime.datetime.now)
    """Время записи в БД"""
