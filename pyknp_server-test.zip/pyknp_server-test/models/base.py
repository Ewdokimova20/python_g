"""Модуль хранения данных приложения

Модуль хранения данных приложения в ЛБД в памяти. Содержит
данные от сети БИС и из других источников и результаты расчета.

Написан на peewee
"""
from __future__ import annotations

import datetime

import peewee
from peewee import DateTimeField

from db.db_connection import db


class BaseModel(peewee.Model):
    """
    Базовый класс для записи в БД
    предопределяет класс Meta для всех классов, наследующих класс Model
    """

    class Meta:
        database = db


class OperativeStorageModel(BaseModel):
    """
    Класс для записи в БД данных с контролем их времени жизни и удалением при устаревании
    """
    db_timestamp: datetime.datetime = DateTimeField(
        index=True, default=datetime.datetime.now)
    """Время записи в БД. Используем индексацию чтобы не мучать СУБД при удалении записей, хотя поддержание индекса
    влечет накладные расходы (небольшие) по пространству и времени."""

    def remove_inactual_data(self, border_of_deleting: datetime.datetime):
        self.delete().where(type(self).db_timestamp < border_of_deleting).execute()
