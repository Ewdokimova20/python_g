from datetime import datetime

from peewee import IntegerField, BooleanField, DateTimeField, CompositeKey, ForeignKeyField

from models.base import BaseModel
from models.bis import Bis
from utils.reception_control.common.reception_status import ReceptionStatus


class BaseReceptionData(BaseModel):
    """
    Базовый класс для хранения данных о приеме 1с измерений / строк ЦИ
    """

    bis: Bis = ForeignKeyField(Bis, on_delete='CASCADE')
    """Идентификатор БИС."""
    nka: int = IntegerField()
    """Номер космического аппарата."""
    signal_type: int = IntegerField()
    """Тип сигнала."""
    reception_status: ReceptionStatus = IntegerField()
    """Состояние приема 1с измерений / строк ЦИ"""
    is_zone_count_sufficient: bool = BooleanField(null=True)
    """Флаг показывает, превышает ли процент строк ЦИ/измерений в ЗРВ от их общего количества установленный порог."""
    actual_count: int = IntegerField(null=True)
    """Счетчик фактически полученных 1с измерений / строк ЦИ"""
    zone_count: int = IntegerField(null=True)
    """Счетчик 1с измерений / строк ЦИ, полученных в гарантированной ЗРВ"""
    expected_zone_count: int = IntegerField(null=True)
    """Требуемое количество 1с измерений / строк ЦИ"""
    timestamp: datetime = DateTimeField(null=True)
    """Время привязки последнего полученного 1с измерения / строки ЦИ"""
    last_update: datetime = DateTimeField()
    """Время последнего обновления в БД"""

    class Meta:
        primary_key = CompositeKey('bis', 'nka', 'signal_type')
