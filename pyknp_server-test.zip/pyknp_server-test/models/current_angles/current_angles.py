from datetime import datetime

from peewee import FloatField, IntegerField, DateTimeField, ForeignKeyField

from models.base import BaseModel
from models.nka import Nka
from models.station import Station


class CurrentAngles(BaseModel):
    """Модель текущего (за последние 10 секунд) угла места НКА к БИС"""

    nka: Nka = ForeignKeyField(Nka, backref='current_angles', on_delete='CASCADE')
    """НКА, для которого дан угол места"""
    station: Station = ForeignKeyField(Station, backref='current_angles', on_delete='CASCADE')
    """БИС, для которого дан угол места"""
    elevation: float = FloatField()
    """Угол места НКА, градус"""
    azimuth: float = FloatField()
    """Азимут НКА, градус"""
    trend: int = IntegerField(default=0)
    """Направление (восходящее или нисходящее) по УМ"""
    visibility_state: int = IntegerField(default=0)
    """Состояние радиовидимости"""
    timestamp: datetime = DateTimeField()
    """Время, на которое дан угол места"""

    def __str__(self):
        return (
            f"НКА: {str(self.nka.nka_sys_number)}, станция/бис: {str(self.bis.station.station_number)}/{str(self.bis.bis_number)}, угол места: {str(self.elevation)}, азимут: {str(self.azimuth)}")

    def as_dict(self):
        return {'bis_number': self.bis.bis_number,
                'station_number': self.bis.station_id,
                'bis_id': self.bis_id,
                'nka_number': self.nka_id,
                'elevation': self.elevation,
                'azimuth': self.azimuth,
                'trend': self.trend,
                'timestamp': self.timestamp}

    class Meta:
        indexes = (
            (("nka", "bis"), True),
        )
