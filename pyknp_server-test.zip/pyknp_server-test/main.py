import concurrent.futures
import logging
import time
from multiprocessing import Process

from twisted.internet import reactor

from communication.endpoints import MAIN_PUB_SUB_ENDPOINT, SUMM_AND_SI_EMBED_PUB_SUB_ENDPOINT
from global_data.config_schema import config
from scripts.prepare_comparison_si_threshold import prepare_comparison_si_threshold
from scripts.prepare_config import prepare_config
from scripts.prepare_pattern_L1SF import prepare_pattern_L1SF
from scripts.setup_logging import LoggingManager
from utils.graceful_exit_manager.graceful_exit_manager import GracefulExitManager

logger = logging.getLogger('main')
console = logging.StreamHandler()
console.setLevel(logging.INFO)
console.setFormatter(
    logging.Formatter('СПО КНП: %(asctime)s %(levelname)s [PID %(process)d]: %(message)s', datefmt='%H:%M:%S'))
logger.addHandler(console)
logger.setLevel(logging.INFO)

if __name__ == '__main__':
    logger.info(f"Запуск основного процесса")

    # Создаем менеджер завершения только в главном процессе
    exit_manager = GracefulExitManager()

    # Читаем конфиг
    start_time = time.time()
    prepare_config()
    time_read_config = time.time() - start_time
    logger.info(f"Конфигурационный файл успешно прочитан за {time_read_config:.2f} с")

    # Настройка логирования
    logging_manager = LoggingManager()
    logging_manager.setup_logging()
    logging_manager.setup_message_stats_handler()
    logger.info(f"Логирование настроено")

    # Читаем настроечные файлы
    prepare_pattern_L1SF()
    prepare_comparison_si_threshold()

    # Заполняем БД
    logger.info(f"Начинается подготовка базы данных")
    start_time = time.time()
    from scripts.prepare_db import prepare_db
    from db.db_connection import db

    prepare_db(db)
    time_prepare_db = time.time() - start_time
    logger.info(f"База данных подготовлена за {time_prepare_db:.2f} с")
    db.close()
    logger.info(f"Соединение с БД закрыто")

    # Запускаем процессы и регистрируем их в exit_manager
    logger.info(f"Запуск процесса обобщения ЦИ SummarizeProcess...")
    from scripts.workers.summarize_worker import summarize_worker

    summarize_process = Process(name="SummarizeProcess", target=summarize_worker,
                                args=(exit_manager.exiting,
                                      {'si_embed_pub_endpoint': SUMM_AND_SI_EMBED_PUB_SUB_ENDPOINT}))
    summarize_process.start()
    exit_manager.register_process(summarize_process)
    logger.info(f"Процесс SummarizeProcess запущен (PID {summarize_process.pid})")

    logger.info(f"Запуск процесса расчета ЗРВ VisibilityProcess...")
    from scripts.workers.visibility_zones_worker import visibility_zone_worker

    visibility_process = Process(name="VisibilityProcess", target=visibility_zone_worker, args=(exit_manager.exiting,))
    visibility_process.start()
    exit_manager.register_process(visibility_process)
    logger.info(f"Процесс VisibilityProcess запущен (PID {visibility_process.pid})")

    logger.info(f"Запуск процесса оперативного контроля закладки СИ SIEmbeddingVerificationProcess...")
    from scripts.workers.si_embedding_verification_worker import si_embedding_verification_worker

    si_embedding_verification_process = Process(name="SIEmbeddingVerificationProcess", target=si_embedding_verification_worker,
                                                args=(exit_manager.exiting, {'main_pub_endpoint': MAIN_PUB_SUB_ENDPOINT,
                                                                             'summarize_sub_endpoint': SUMM_AND_SI_EMBED_PUB_SUB_ENDPOINT}))
    si_embedding_verification_process.start()
    exit_manager.register_process(si_embedding_verification_process)
    logger.info(f"Процесс SIEmbeddingVerificationProcess запущен (PID {si_embedding_verification_process.pid})")

    logger.info(f"Создание конфигурации для процессов приема и обработки данных от СПО сети БИС...")

    try:
        from scripts.prepare_bis_process_configs import bis_process_configs, prepare_bis_process_configs, get_bis_process_configs

        prepare_bis_process_configs()
    except SystemExit:
        exit_manager.shutdown()
        raise
    logger.info(f"Конфигурация для процессов создана")

    logger.info(f"Запуск процессов приема и обработки данных от СПО сети БИС...")
    from scripts.workers.bis_processing_worker import bis_processing_worker

    bis_processes = []
    for i, bis_config in enumerate(get_bis_process_configs()):
        proc = Process(name=f"BisProcess-{i}", target=bis_processing_worker, args=(exit_manager.exiting, bis_config))
        proc.start()
        exit_manager.register_process(proc)
        bis_processes.append(proc)
        logger.info(
            f"Запущен процесс BisProcess-{i} (PID {proc.pid}) на порту {bis_config['port']} с БИС {[f'{bis.station.station_number}/{bis.bis_number}' for bis in bis_config['bis_list']]}")
    logger.info(f"Все процессы приема и обработки данных от СПО сети БИС запущены")

    db.connect()
    logger.info(f"Установлено новое подключение к БД")

    # ===============+====== Настройка ZMQ =============================

    logger.info('Настройка ZMQ взаимодействия')
    from communication.process_zmq_manager import ProcessZmqManager
    from scripts.process_registry.process_registry import initialize_registry, set_object

    zmq_manager = ProcessZmqManager("MainProcess")

    #  Инициализируем реестр глобальных переменных и устанавливаем глобальный доступ к менеджеру
    initialize_registry()
    set_object('zmq_manager', zmq_manager)

    # Регистрируем задачу на закрытие всех ресурсов ZMQ
    exit_manager.register_cleanup_function(zmq_manager.close)

    # ================= ЗАПУСК ВЕБ-СЕРВЕРА И ЛОГИКИ =======================

    logger.info("Подготовка сервера")
    from KNPServer.server import KNPServer

    server_host = reactor.listenTCP(config['server']['port'], KNPServer)

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        executor.submit(reactor.run, installSignalHandlers=False)
        logger.info(f"Установлено соединение с клиентской частью на порту {server_host.getHost().port}")

        from scripts.main_logic.main_logic import main_logic

        executor.submit(main_logic, exit_manager.exiting)
        logger.info("Основная логика запущена")

        try:
            while not exit_manager.exiting.is_set():
                time.sleep(10)
        except KeyboardInterrupt:
            logger.info("Получена прерывающая команда (Ctrl+C)")
            exit_manager.shutdown()
