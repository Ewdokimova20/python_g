"""Application data module

Модуль хранения данных приложения. Содержит конфиг, постоянные данные,
дефолтные данные, данные от сети БИС и из других источников, результаты
расчета.

Должен быть сокращен путем выноса данных от БИС и расчетных данных.
"""
import collections
import datetime
from collections import defaultdict
from enum import IntEnum
from typing import Dict, Union, Optional

pragmas = {
    'journal_mode': 'wal',
    'cache_size': -1 * 64000,  # 64MB
    'foreign_keys': 1,
    'ignore_check_constraints': 0,
    'synchronous': 0}
"""Параметры ЛБД КНП, рекомендованные документацией peewee"""

# инициализируется здесь, потом перезаписывается при реальном старте взаимодействия
BIS_PROTOCOL_START_TIME: datetime.datetime = datetime.datetime.now().replace(microsecond=0)
"""Время начала взаимодействия с СПО сети БИС. """

nested_dict = lambda: collections.defaultdict(nested_dict)

NKA_DATA = {}
"""Данные по НКА, взятые из таблицы ЦБД (№ сист.точки, № в НКУ, тип КА, тип СИ)"""

SIGNAL_TYPES = [0x01, 0x21, 0x09, 0x29, 0x06, 0x46, 0x26, 0x66, 0x0E, 0x4E,
                0x2E, 0x6E, 0x16, 0x56]
L1_FREQ_SIGNAL_TYPES = [0x01, 0x21]
L2_FREQ_SIGNAL_TYPES = [0x09, 0x29]
L1_CODE_SIGNAL_TYPES = [0x06, 0x46, 0x26, 0x66]
L2_CODE_SIGNAL_TYPES = [0x0E, 0x4E, 0x2E, 0x6E]
L3_CODE_SIGNAL_TYPES = [0x16, 0x56]
CODE_SIGNAL_TYPES = L1_CODE_SIGNAL_TYPES + L2_CODE_SIGNAL_TYPES + L3_CODE_SIGNAL_TYPES
FREQ_SIGNAL_TYPES = L1_FREQ_SIGNAL_TYPES + L2_FREQ_SIGNAL_TYPES
"""Номера сигналов ГЛОНАСС по ПРИЛОЖЕНИЕ А 14Ц181.4000-0 Д3"""

SPEED_OF_LIGHT = 299792458
"""Скорость света, м/с"""

EARTH_ROTATION_RATE = 7.292115e-005
"""Угловая скорость вращения Земли, радиан/с"""

tolerance = 0.01
"""rel_tol для isclose"""

max_steps = 3

INTEGRATION_STEP = 1
"""Шаг интегрирования по методу Рунге-Кутты для определения координат НКА"""

GPS_SIGNALS = [0x02, 0x22, 0x0A, 0x4A, 0x1A, 0x5A]
"""Номера сигналов GPS по ПРИЛОЖЕНИЕ А 14Ц181.4000-0 Д3"""

GLONASS_SIGNALS = [signal for signal in SIGNAL_TYPES if signal not in GPS_SIGNALS]

SIGNALS_NAME = {
    "L1OF": 0x01,
    "L1SF": 0x21,
    "L2OF": 0x09,
    "L2SF": 0x29,
    "L1OCd": 0x06,
    "L1OCp": 0x46,
    "L1SCd": 0x26,
    "L1SCp": 0x66,
    "L2КСИ": 0x0E,
    "L2OCp": 0x4E,
    "L2SCd": 0x2E,
    "L2SCp": 0x6E,
    "L3OCd": 0x16,
    "L3OCp": 0x56
}
"""Значения кодов НС ГЛОНАСС из 14Ц181.4000-0 Д3 Приложение А"""


class SignalTypes(IntEnum):
    """Перечисление значений кодов НС ГЛОНАСС из 14Ц181.4000-0 Д3 Приложение А"""
    L1OF = 0x01
    L1SF = 0x21
    L2OF = 0x09
    L2SF = 0x29
    L1OCd = 0x06
    L1OCp = 0x46
    L1SCd = 0x26
    L1SCp = 0x66
    L2KSI = 0x0E
    L2OCp = 0x4E
    L2SCd = 0x2E
    L2SCp = 0x6E
    L3OCd = 0x16
    L3OCp = 0x56


SIGNALS_WITH_DI = [SignalTypes.L1OF, SignalTypes.L1SF, SignalTypes.L2OF, SignalTypes.L1OCd, SignalTypes.L1SCd, SignalTypes.L2KSI,
                   SignalTypes.L2SCd, SignalTypes.L3OCd]
"""Список сигналов, на которых передается ЦИ"""

PILOT_CODE_SIGNALS = [
    SIGNALS_NAME["L1OCp"],
    SIGNALS_NAME["L2OCp"],
    SIGNALS_NAME["L1SCp"],
    SIGNALS_NAME["L3OCp"],
    SIGNALS_NAME["L2SCp"]
]
"""Список пилотных компонент кодовых сигналов"""

DIGITAL_SIGNALS_FOR_PILOT_SIGNALS = {
    SIGNALS_NAME["L1OCp"]: SIGNALS_NAME["L1OCd"],
    SIGNALS_NAME["L2OCp"]: SIGNALS_NAME["L1OCd"],
    SIGNALS_NAME["L1SCp"]: SIGNALS_NAME["L1SCd"],
    SIGNALS_NAME["L3OCp"]: SIGNALS_NAME["L3OCd"],
    SIGNALS_NAME["L2SCp"]: SIGNALS_NAME["L2SCd"]
}
"""Словарь соответствия пилотных компонент кодовых сигналов и компонент с цифрой"""

BAD_FRAME_TK = 99999
"""tk для битых кадров"""

NKA = []
"""системный номер по данным от БИС"""

NKA_SIGNALS: Dict[int, list] = {}
"""
Cловарь по НКА с перечнем излучаемых сигналов (№ сист.точки; типы сигналов, излучаемых КА)
"""

NKA_SIGNALS_NAME: Dict[int, list] = {}
"""
Cловарь по НКА с перечнем излучаемых сигналов (№ сист.точки; названия сигналов, излучаемых КА)
"""

BIS_NKA_DCB = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
"""Трёхуровневый словарь с перечнем калибровочных поправок
Первый уровень - номер БИС, второй - номер НКА, третий - номер сигнала"""

allowed_hide_intervals = []
"""Перечень разрешенных интервалов блокировки"""

queue_status = {'received': 0, 'processed': 0, 'queue': 0, 'timeerror': 0, 'packerror': 0, 'last_update_at': None}
"""Словарь для контроля состояния обработки пакетов"""


class ValuableInfoStatus(IntEnum):
    """Состояния потока обработки информации от СПО сети БИС НКУ ( 0 - поток есть, 1 - поток повис, 2 - потока нет)"""
    FLOW_ACTIVE = 0
    FLOW_SUSPENDED = 1
    FLOW_ABSENT = 2


valuable_info_status = ValuableInfoStatus.FLOW_ACTIVE
"Статус состояния потока обработки информации от СПО сети БИС НКУ ( 0 - поток есть, 1 - поток повис, 2 - потока нет)"

SIGNALS_INDEXES = {
    0x01: 0,
    0x21: 1,
    0x09: 2,
    0x29: 3,
    0x06: 4,
    0x46: 5,
    0x26: 6,
    0x66: 7,
    0x0E: 8,
    0x4E: 9,
    0x2E: 10,
    0x6E: 11,
    0x16: 12,
    0x56: 13
}
"""Словарь сопоставления идентификатора сигнала индексу бита"""

MEAS_PACKET_TYPE = 0x11
"""Тип пакета с измерениями"""""

DI_PACKET_TYPE = 0x21
"""Тип пакета с ЦИ"""

values_in_pattern_L1SF = {}
"""Словарь содержит константы, относящиеся к ЦИ L1SF"""

reliability_control_elevation = {"default": 15}
"""Углы места гарантированных точностных характеристик. С этих углов проверяем достоверность по невязкам"""

receive_control_elevation = {"default": 9}
"""Углы места гарантированного приёма. С этих углов проверяем наличие сигналов"""

min_elevation = {"default": 5}
"""Минимальный угол приема"""

solution_distance_threshold = {"default": 10}
"""Порог расстояния РНЗ КНП от опорной точки (координат БИС)"""

NKA_coordinates = nested_dict()
"""Словарь текущих координат НКА. Обновляется при поступлении измерений от БИС для НКА"""


class SIGNALSTATUS(IntEnum):
    """Перечисление флагов приема и годности сигналов"""
    OK = 4  # прием
    ERROR_IN_MAYBE = 5  # сбой в зоне необязательного приёма
    ERROR = 3  # нестабильный приём
    UNAVAILABLE = 2  # отсутствует
    UNDEFINED = 1  # не определено
    OUT_OF_SIGHT = 0  # вне зоны радиовидимости
    NOT_ON_AIR = -1  # сигнал не излучается


class ServerStatusCode(IntEnum):
    """Перечисление состояния согласованности эфемерид на границе tb"""
    OK = 0  # согласованы
    DECODE_ERROR = -1  # ошибка декодирования JSON
    DATA_FORMAT_ERROR = -2  # неверный формат данных
    EXCESSIVE_DATA = -3  # получены избыточные данные в запросе
    BAD_DATA = -4  # некорректные данные


class LogLevelCode(IntEnum):
    """Уровни журналирования, определяющие объем выводимой в журнал информации (параметр конфигурации log_level) """
    LL_UNDEFINED = 15  # нет логирования
    LL_ALL = 13  # не должно применяться для маркирования сообщений, используется только в фильтрах для принудительного вывода всех собщений
    LL_DEBUG5 = 12  # LOG_DEBUG   # debug-level messages
    LL_DEBUG4 = 11  # LOG_DEBUG   # debug-level messages
    LL_DEBUG3 = 10  # LOG_DEBUG   # debug-level messages
    LL_DEBUG2 = 9  # LOG_DEBUG   # debug-level messages
    LL_DEBUG1 = 8  # LOG_DEBUG   # debug-level messages
    LL_INFO = 7  # LOG_INFO    # informational
    LL_NOTICE = 6  # LOG_NOTICE  # normal but significant condition
    LL_WARNING = 5  # LOG_WARNING # warning conditions
    LL_ERROR = 4  # LOG_ERR     # error conditions
    LL_LOG = 3  # LOG_CRIT    # critical conditions # принципиально важное сообщение о нормальном функционировании системы (напр., запуск функционирования)
    LL_FATAL = 2  # LOG_ALERT   # action must be taken immediately
    LL_PANIC = 1  # LOG_EMERG   # system is unusable
    LL_NONE = 0  # не должно применяться для маркирования сообщений, используется только в фильтрах для блокирования вывода всех собщений


STATUS_NKA_DEFINE_STEP = 10
"""Период определения состояния приёма сигналов НКА, с"""

RESIDUAL_SIGNAL_PAIR_MAP: Dict[Union[SignalTypes, int], Optional[Union[SignalTypes, int]]] = {
    SignalTypes.L1OF: SignalTypes.L2OF,
    SignalTypes.L2OF: SignalTypes.L1OF,
    SignalTypes.L1SF: SignalTypes.L2SF,
    SignalTypes.L2SF: SignalTypes.L1SF,
    SignalTypes.L1OCd: SignalTypes.L2KSI,
    SignalTypes.L2KSI: SignalTypes.L1OCd,
    SignalTypes.L1OCp: SignalTypes.L2OCp,
    SignalTypes.L2OCp: SignalTypes.L1OCp,
    SignalTypes.L1SCd: SignalTypes.L2SCd,
    SignalTypes.L2SCd: SignalTypes.L1SCd,
    SignalTypes.L1SCp: SignalTypes.L2SCp,
    SignalTypes.L2SCp: SignalTypes.L1SCp,
    SignalTypes.L3OCd: None,
    SignalTypes.L3OCp: None,
}
"""Словарь для получения парного сигнала для расчета невязок"""


class PacketID(IntEnum):
    """
    Перечисление идентификаторов пакетов для системы передачи информационных сообщений.

    Содержит коды пакетов, используемых в протоколе ИЛВ между СПО сети БИС НКУ и СПО КНП.

    Каждый идентификатор соответствует определенному типу информационного сообщения

    Использование:
    >>> packet_type = PacketID.MEASUREMENTS_1SEC  # Получение ID для измерений
    >>> hex(packet_type)  # Возвращает '0x11'
    """
    CONNECTION_CONTROL = 0x01
    MEASUREMENTS_1SEC = 0x11
    DIGITAL_INFO = 0x21
    OP_MESSAGE = 0x31
    CONTROL_RESULTS = 0x32
    NAV_SOLUTION_RESULTS = 0x33
    RANGE_DISCREPANCY_VALUES = 0x34
    CLOCK_OFFSET_ESTIMATION = 0x35
    TRACKING_LOSS = 0x36
    METEO_PARAMETERS = 0x41
