from datetime import timedelta

config = {'bis': {
    'bis_ports': {},
    'host': None
},
    'general': {
        'reject_cache_depth': 10,
        'use_average_residuals': 'yes',
        'path_alarm': './alarm.mp3',
        'path_values_pattern_L1SF': './values_pattern_L1SF.cfg',
        'path_comparison_si_threshold': './comparison_si_threshold.cfg',
    },
    'opmessage': {
        'auto_finalize_timeout': 60,
        'auto_approve_timeout': 600,
    },
    'decimation': {
        'residuals_decimation_interval': 10,
        'meteoparameters_decimation_interval': 30,
        'opmessage_decimation_interval': 30,
        'nav_solution_decimation_interval': 30,
        'controls_decimation_interval': 30,
    },
    'write_instance_to_ldb': {
        'opmessage': 'yes',
        'control': 'yes',
        'navsolution': 'yes',
        'knpopmessage': 'yes',
        'bulk_string_insert_interval': 2,
    },
    'zrv_analyse': {'step': 300, 'limit': 259200},
    'tldb': {
        'mode': 'pg'
    },
    'postgresql': {
        'host': None,
        'port': None,
        'username': None,
        'password': None,
        'dbname': None,
        'tldbname': None,
        'schema': 'knpresults',
    },
    'cdb': {
        'mode': 'new',
        'simulated': False,
        'host': None,
        'port': None,
        'username': None,
        'password': None,
        'dbname': None,
        'schema': 'common'
    },
    'server': {
        'port': 80,
        "ldb": None,
        'service_interval': 600,  # секунды
        'allowed_hide_intervals': None,  # перечень значений в секундах, разеделнных запятыми
        'storage_interval': 72,  # часы
        'copy_old_data': "no",
        'store_raw_packets': "no"
    },
    'debug': {
        'enable_debug_level_logging': "no",
        'peewee_logging': "no",
        "bis_communication_logging": "no",
        "packet_stat_logging": "no",
    },
    'generalized_di': {
        'exclude_bad_frames': 'no',
        'lag_interval': 120,
        'compose_period': 30,
        'frame_search_depth_for_operational_control': 2,
    },
    'di_control': {
        'tk_difference': 100,
    },
    'PDOP': {
        'full_file_name_PDOP': 'PDOPS_0.txt',
        'full_file_name_availability': 'availability_sec_data_0.txt',
        'nka_elevation_mask': 5,
        'max_pdop_na_spread': 2,
        'PDOP_time_step': 120,
        'availability_time_step': 30,
    },
    'cache': {
        'lifetime_si_cache': 300,
    },
    'SI': {
        'search_depth_169': 3,
        'search_depth_701': 5,
        'search_depth_893': 3,
        'search_depth_895': 7,
        'search_depth_921': 7300,
        'search_depth_P4': 6,
    },
    'station_coordinates': {'path': None},
    'log': {'path': None, 'log_file_length': 300000000, 'log_backup_num': 10},
    'measurement_reception_control': {'sufficient_rate_for_zone_meas_count': 0.7, 'meas_acceptable_delay': 5,
                                      'di_acceptable_error_level': 0.05,
                                      'meas_acceptable_absence': 5},
    'interface': {
        'history_residuals_search_depth': 1,
        'history_residuals_chart_max_record_count': 150_000,
    },
    'bis_control': {'signal_validity_percent': 90,
                    'signal_validity_analyzing_time': 10,
                    'station_receiving_error_threshold': 0,
                    'station_validity_error_threshold': 0,
                    'nvz_solution_inaccuracy_threshold': 2,
                    'residual_pairs_difference_threshold': 5,
                    'residual_average_difference_threshold': 10,
                    'speed_residual_inaccuracy_threshold': 0.1,
                    'min_elevation_for_nav_solution': 15,
                    'check_packet_receive_time': True,
                    'check_di_receive_in_time': True,
                    'min_packets': False,
                    'acceptable_packets_delay': 10,
                    'use_troposphere_model': True,
                    'log_level': 0,
                    'allowed_delay_for_signal_status': 10,
                    'min_amount_bis_for_generalized_opmessage': 1,
                    'residual_averaging_interval': 5,
                    'max_diff_between_local_and_packet_time': 3600,
                    'average_residual_averaging_interval': 60,
                    'meteodata_actual_duration': 600},
    'nka_data_signals': {
        'nka': [],
        'nka_data': {},
        'nka_signals': {},
    },
    'configFile': 'config.ini'}
"""Главный конфиг приложения"""

comparison_si_threshold = {
    # 169 форма
    "tau": 3e-9,
    "gamma": 3e-12,
    "beta": 3e-17,
    # 701 форма
    "tau_a": 3e-9,
    # 893 форма
    "x": 1,  # метры
    "y": 1,
    "z": 1,
    "x_L3": 1,  # метры
    "y_L3": 1,
    "z_L3": 1,
    "Vx": 1,  # метры в секунду
    "Vy": 1,
    "Vz": 1,
    "Ax": 0.01,  # 1 см/с^2
    "Ay": 0.01,
    "Az": 0.01,
    "Ax_L3": 0.01,  # 1 см/с^2
    "Ay_L3": 0.01,
    "Az_L3": 0.01,
    "dX": 1,  # метры
    "dY": 1,
    "dZ": 1,
    # 895 форма
    "delta_T": 1e-2,
    "t_lambda": 0.1,
    "epsilon": 2e-6,
    "d_delta_T": 2e-4,
    "omega": 1e-4,
    "lambda_": 3e-6,
    "delta_i": 3e-6,
    "tb": timedelta(minutes=30)
}
"""Словарь содержит пороговые значения для сравнения форм СИ"""

station_coordinates_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "station": {"type": "number"},
        "bis": {"type": "number"},
        "coord_xyz": {"type": "object",
                      "additionalProperties": False,
                      "properties": {
                          "x": {"type": "number"},
                          "y": {"type": "number"},
                          "z": {"type": "number"}
                      },
                      "required": ["x", "y", "z"],
                      }
    },
    "required": ["station", "bis", "coord_xyz"],
}
"""Схема для валидации координат БИС в формате json"""

comparison_si_threshold_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "tau": {"type": "number"},
        "gamma": {"type": "number"},
        "tau_a": {"type": "number"},
        "beta": {"type": "number"},
        "x": {"type": "number"},
        "y": {"type": "number"},
        "z": {"type": "number"},
        "x_L3": {"type": "number"},
        "y_L3": {"type": "number"},
        "z_L3": {"type": "number"},
        "Vx": {"type": "number"},
        "Vy": {"type": "number"},
        "Vz": {"type": "number"},
        "Ax": {"type": "number"},
        "Ay": {"type": "number"},
        "Az": {"type": "number"},
        "Ax_L3": {"type": "number"},
        "Ay_L3": {"type": "number"},
        "Az_L3": {"type": "number"},
        "dX": {"type": "number"},
        "dY": {"type": "number"},
        "dZ": {"type": "number"},
        "delta_T": {"type": "number"},
        "t_lambda": {"type": "number"},
        "epsilon": {"type": "number"},
        "d_delta_T": {"type": "number"},
        "omega": {"type": "number"},
        "lambda_": {"type": "number"},
        "delta_i": {"type": "number"},
        "tb": {"type": "number"}
    },
    "required": ["tau", "gamma", "beta", "tau_a", "x", "y", "z", "x_L3", "y_L3", "z_L3", "Vx", "Vy", "Vz", "Ax", "Ay",
                 "Az",
                 "Ax_L3", "Ay_L3", "Az_L3", "dX", "dY", "dZ", "delta_T", "t_lambda", "epsilon", "d_delta_T",
                 "omega", "lambda_", "delta_i", "tb"],
}
"""Схема для валидации для пороговых значений для сравнения форм СИ в формате json"""

bis_control_default_values = {
    'signal_validity_percent': 90,
    'signal_validity_analyzing_time': 10,
    'station_receiving_error_threshold': 1,
    'station_validity_error_threshold': 1,
    'nvz_solution_inaccuracy_threshold': 50,
    'residual_pairs_difference_threshold': 5,
    'residual_average_difference_threshold': 10,
    'speed_residual_inaccuracy_threshold': 0.5,
    'min_elevation_for_nav_solution': 15,
    'check_packet_receive_time': True,
    'check_di_receive_in_time': True,
    'acceptable_packets_delay': 10,
    'use_troposphere_model': True,
    'log_level': 0,
    'min_packets': False,
    'allowed_delay_for_signal_status': 10,
    'min_amount_bis_for_generalized_opmessage': 1,
    'residual_averaging_interval': 5,
    'max_diff_between_local_and_packet_time': 3600,
    'average_residual_averaging_interval': 60,
    'meteodata_actual_duration': 600
}
"""
Значения по умолчанию параметров конфигурации из секции bis_control. 
Должны быть заполнены все те, которые присутствуют в конфиге выше!
"""

bis_control_min_values = {
    'signal_validity_percent': 1,
    'signal_validity_analyzing_time': 1,
    'station_receiving_error_threshold': 0,
    'station_validity_error_threshold': 0,
    'nvz_solution_inaccuracy_threshold': 0,
    'residual_pairs_difference_threshold': 0,
    'residual_average_difference_threshold': 0,
    'speed_residual_inaccuracy_threshold': 0,
    'min_elevation_for_nav_solution': 0,
    'check_packet_receive_time': 0,
    'check_di_receive_in_time': 0,
    'use_troposphere_model': 0,
    'acceptable_packets_delay': 1,
    'log_level': 0,
    'allowed_delay_for_signal_status': 0,
    'min_amount_bis_for_generalized_opmessage': 1,
    'residual_averaging_interval': 1,
    'average_residual_averaging_interval': 1,
    'max_diff_between_local_and_packet_time': 10,
}
"""Минимальные значения параметров конфигурации из секции bis_control"""

bis_control_max_values = {
    'signal_validity_percent': 100,
    'signal_validity_analyzing_time': 30,
    'log_level': 15,
}
"""Максимальные значения параметров конфигурации из секции bis_control"""
