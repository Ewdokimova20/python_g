-- Устанавливаем схему visibility как схему по умолчанию
SET search_path TO visibility;

--1. Объявляем функцию поиска самого свежего альманаха
CREATE OR REPLACE FUNCTION days_96_from_N4_Na(N4 INTEGER, Na INTEGER) RETURNS INTEGER
AS $$
BEGIN
    RETURN (N4 - 1) * 1461 + Na;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION days_96_from_N4_Na(INTEGER, INTEGER) IS '{1,0}';
ALTER FUNCTION days_96_from_N4_Na(INTEGER, INTEGER) OWNER TO knp;
GRANT EXECUTE ON FUNCTION days_96_from_N4_Na(INTEGER, INTEGER) TO public;

CREATE OR REPLACE FUNCTION N4_Na_from_days_96(days_96 INTEGER, OUT N4_result INTEGER, OUT Na_result INTEGER)
AS $$
BEGIN
    N4_result := FLOOR( (days_96 - 1) / 1461 ) + 1;
    Na_result := days_96 - (N4_result - 1) * 1461;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION N4_Na_from_days_96(INTEGER) IS '{1,0}';
ALTER FUNCTION N4_Na_from_days_96(INTEGER) OWNER TO knp;
GRANT EXECUTE ON FUNCTION N4_Na_from_days_96(INTEGER) TO public;

CREATE OR REPLACE FUNCTION get_almanac_time_by_datetime(time_now TIMESTAMP WITH TIME ZONE, OUT N4_current INTEGER, OUT NA_current INTEGER)
AS $$
DECLARE
    seconds_in_timestamp DOUBLE PRECISION;
    current_day INTEGER;
BEGIN
    -- Преобразуем время в секунды и добавляем 3 часа (UTC+3)
    seconds_in_timestamp := EXTRACT(EPOCH FROM time_now AT TIME ZONE 'UTC+3');

    -- Вычисляем текущий день с учетом смещения
    current_day := 731 + FLOOR(seconds_in_timestamp / 86400);

    -- Вычисляем NA_current и N4_current
    NA_current := ROUND(1 + MOD(current_day, 1461));
    N4_current := ROUND(1 + FLOOR(current_day / 1461) - 7);
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION get_almanac_time_by_datetime(TIMESTAMP WITH TIME ZONE) IS '{1,0}';
ALTER FUNCTION get_almanac_time_by_datetime(TIMESTAMP WITH TIME ZONE) OWNER TO knp;
GRANT EXECUTE ON FUNCTION get_almanac_time_by_datetime(TIMESTAMP WITH TIME ZONE) TO public;

CREATE OR REPLACE FUNCTION create_almanac_query_parameters(N4_current INTEGER, NA_current INTEGER, depth INTEGER)
RETURNS TABLE(N4 INTEGER, Na_left_boundary INTEGER, Na_right_boundary INTEGER)
AS $$
DECLARE
    Na_left_boundary1 INTEGER;
    Na_right_boundary1 INTEGER;
    N4_1 INTEGER;
    N4_2 INTEGER := NULL;
    Na_left_boundary2 INTEGER := NULL;
    Na_right_boundary2 INTEGER := NULL;
    now_days_from_96 INTEGER;
    boundary_from_96 INTEGER;
    tmp_N4 INTEGER;
    tmp_Na INTEGER;
BEGIN
    N4_1 := N4_current;
    Na_left_boundary1 := NA_current - depth;
    Na_right_boundary1 := NA_current + depth;

    -- Проверяем, не выходят ли границы за пределы допустимых значений
    IF Na_left_boundary1 < 1 THEN
        Na_left_boundary1 := 1;
        now_days_from_96 := days_96_from_N4_Na(N4_current, NA_current);
        boundary_from_96 := now_days_from_96 - depth;
        -- Используем SELECT INTO для получения значений из функции
        SELECT N4_result, Na_result INTO tmp_N4, tmp_Na FROM visibility.N4_Na_from_days_96(boundary_from_96);
        IF tmp_N4 IS NOT NULL THEN
            N4_2 := tmp_N4;
            Na_left_boundary2 := tmp_Na;
            Na_right_boundary2 := 1461;
        END IF;
    ELSIF Na_right_boundary1 > 1461 THEN
        Na_right_boundary1 := 1461;
        now_days_from_96 := days_96_from_N4_Na(N4_current, NA_current);
        boundary_from_96 := now_days_from_96 + depth;
        -- Используем SELECT INTO для получения значений из функции
        SELECT N4_result, Na_result INTO tmp_N4, tmp_Na FROM visibility.N4_Na_from_days_96(boundary_from_96);
        IF tmp_N4 IS NOT NULL THEN
            N4_2 := tmp_N4;
            Na_left_boundary2 := 1;
            Na_right_boundary2 := tmp_Na;
        END IF;
    END IF;

    -- Возвращаем первый набор параметров
    RETURN QUERY SELECT N4_1 AS N4, Na_left_boundary1 AS Na_left_boundary, Na_right_boundary1 AS Na_right_boundary;

    -- Если есть второй набор параметров, возвращаем его
    IF N4_2 IS NOT NULL THEN
        RETURN QUERY SELECT N4_2 AS N4, Na_left_boundary2 AS Na_left_boundary, Na_right_boundary2 AS Na_right_boundary;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION create_almanac_query_parameters(INTEGER, INTEGER, INTEGER) IS '{1,0}';
ALTER FUNCTION create_almanac_query_parameters(INTEGER, INTEGER, INTEGER) OWNER TO knp;
GRANT EXECUTE ON FUNCTION create_almanac_query_parameters(INTEGER, INTEGER, INTEGER) TO public;

CREATE OR REPLACE FUNCTION get_almanac_slot(nka_input INTEGER)
RETURNS INTEGER AS $$
DECLARE
    request_depth INTEGER := 30;
    required_approves INTEGER := 5;
    N4_current INTEGER;
    NA_current INTEGER;
    ti INTEGER;
    almanac_id INTEGER;
    rec RECORD;
BEGIN
    -- Получаем текущие значения N4 и NA
    SELECT * INTO N4_current, NA_current FROM visibility.get_almanac_time_by_datetime(NOW());

    -- Получаем параметры запроса
    FOR rec IN SELECT * FROM visibility.create_almanac_query_parameters(N4_current, NA_current, request_depth)
    LOOP
        -- Пытаемся найти альманах
        SELECT id INTO almanac_id FROM almanac
        WHERE nka = nka_input AND
              "N4" = rec.N4 AND
              "N_A" BETWEEN rec.Na_left_boundary AND rec.Na_right_boundary AND
              approve_count > required_approves
        ORDER BY "N_A" DESC
        LIMIT 1;

        -- Если нашли, возвращаем id
        IF FOUND THEN
            RETURN almanac_id;
        END IF;
    END LOOP;

    -- Если не нашли, возвращаем NULL
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION get_almanac_slot(INTEGER) IS '{1,0}';
ALTER FUNCTION get_almanac_slot(INTEGER) OWNER TO knp;
GRANT EXECUTE ON FUNCTION get_almanac_slot(INTEGER) TO public;


--2. Создаем представление текущих зон по самому свежему альманаху

CREATE OR REPLACE FUNCTION create_current_visibility_zone_view()
RETURNS VOID AS $$
DECLARE
    parent_maclabel TEXT;
BEGIN
    -- Создаем представление
    CREATE OR REPLACE VIEW current_visibility_zone AS
    SELECT
    vz.nka,
    vz.bis_id,
    vz.guaranteed_receive_time_start as zone_start,
    vz.guaranteed_receive_time_end as zone_end
FROM
    visibility_zone vz
WHERE
    vz.almanac_id = visibility.get_almanac_slot(vz.nka)
    AND current_timestamp BETWEEN vz.guaranteed_receive_time_start AND vz.guaranteed_receive_time_end;


    -- Устанавливаем владельца
    ALTER VIEW current_visibility_zone OWNER TO knp;

    -- Получаем метку родительской таблицы
    EXECUTE 'SELECT maclabel::TEXT FROM pg_tables WHERE tablename = ''visibility_zone''' INTO parent_maclabel;

    -- Устанавливаем метку MAC для представления, если она существует
    IF parent_maclabel IS NOT NULL THEN
        EXECUTE format('MAC LABEL ON VIEW current_visibility_zone IS ''%s''', parent_maclabel);
    END IF;

    -- Предоставляем привилегии
    GRANT SELECT, UPDATE, INSERT, DELETE ON current_visibility_zone TO PUBLIC;
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION create_current_visibility_zone_view() IS '{1,0}';
ALTER FUNCTION create_current_visibility_zone_view() OWNER TO knp;
GRANT EXECUTE ON FUNCTION create_current_visibility_zone_view() TO PUBLIC;

SELECT visibility.create_current_visibility_zone_view();
