-- 0. Создание схемы visibility
CREATE SCHEMA IF NOT EXISTS visibility;
-- Устанавливаем MAC LABEL для схемы
MAC LABEL ON SCHEMA visibility IS '{1,0}';
MAC CCR   ON SCHEMA visibility IS OFF;
-- Изменяем владельца схемы на knp
ALTER SCHEMA visibility OWNER TO knp;
-- Выдаем права пользователю knp на новую схему
GRANT USAGE  ON                                    SCHEMA visibility TO PUBLIC;
GRANT SELECT,UPDATE,INSERT,DELETE ON ALL TABLES IN SCHEMA visibility TO PUBLIC;
-- Устанавливаем схему visibility как схему по умолчанию
SET search_path TO visibility;

-- 1. Создание основной таблицы visibility_zone
CREATE table if not EXISTS visibility_zone (
    bis_id INTEGER NOT NULL,
    nka INTEGER NOT NULL,
    almanac_id INTEGER REFERENCES public.almanac(id) ON DELETE CASCADE,
    possible_receive_time_start TIMESTAMP NOT NULL,
    guaranteed_receive_time_start TIMESTAMP NOT NULL,
    possible_receive_time_end TIMESTAMP NOT NULL,
    guaranteed_receive_time_end TIMESTAMP NOT NULL,
    last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (bis_id, nka, almanac_id, guaranteed_receive_time_start)  -- Составной ключ
)
WITH (MACS=FALSE);
ALTER        TABLE visibility_zone OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE visibility_zone IS '{1,0}';
MAC CCR   ON TABLE visibility_zone IS OFF;


-- Добавление комментариев к таблице и столбцам для лучшей документации
COMMENT ON TABLE visibility_zone IS 'Таблица для хранения данных о зонах видимости';
COMMENT ON COLUMN visibility_zone.bis_id IS 'Идентификатор БИС';
COMMENT ON COLUMN visibility_zone.nka IS 'Номер космического аппарата';
COMMENT ON COLUMN visibility_zone.almanac_id IS 'Идентификатор альманаха';
COMMENT ON COLUMN visibility_zone.possible_receive_time_start IS 'Время начала возможного приема';
COMMENT ON COLUMN visibility_zone.guaranteed_receive_time_start IS 'Время начала гарантированного приема';
COMMENT ON COLUMN visibility_zone.possible_receive_time_end IS 'Время окончания возможного приема';
COMMENT ON COLUMN visibility_zone.guaranteed_receive_time_end IS 'Время окончания гарантированного приема';
COMMENT ON COLUMN visibility_zone.last_update IS 'Время последнего обновления записи';

CREATE UNIQUE INDEX visibility_zone_unique_start_idx ON visibility_zone(bis_id, nka, almanac_id, guaranteed_receive_time_start);
CREATE UNIQUE INDEX visibility_zone_unique_end_idx ON visibility_zone(bis_id, nka, almanac_id, guaranteed_receive_time_end);

-- создание индекса на поиск
CREATE INDEX visibility_zone_nka_almanac_idx
  ON visibility_zone
  USING btree
  (nka, almanac_id);

-- 2. Функция для создания партиций
CREATE OR REPLACE FUNCTION create_visibility_zone_partition(bis_id INTEGER)
RETURNS VOID AS $$
DECLARE
    partition_name TEXT := format('visibility_zone_bis_%s', bis_id);
    parent_maclabel TEXT;
BEGIN
    -- Получаем метку родительской таблицы
    EXECUTE 'SELECT maclabel::TEXT FROM pg_tables WHERE tablename = ''visibility_zone''' INTO parent_maclabel;

    -- Создаем новую партицию
    EXECUTE format('
        CREATE TABLE %I (
            CHECK ( bis_id = %s )
        ) INHERITS (visibility_zone)', partition_name, bis_id);

    EXECUTE format('ALTER TABLE %I OWNER TO knp', partition_name);

    -- Устанавливаем метку MAC для новой партиции, если она существует
    IF parent_maclabel IS NOT NULL THEN
        EXECUTE format('MAC LABEL ON TABLE %I IS ''%s''', partition_name, parent_maclabel);
    END IF;

    -- Устанавливаем MAC CCR для новой партиции
    EXECUTE format('MAC CCR ON TABLE %I IS OFF', partition_name);

    -- Выдаем права на новую партицию
    EXECUTE format('GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE %I TO PUBLIC', partition_name);

    -- Создаем индексы
    -- Создание уникального индекса для обеспечения уникальности комбинации полей
    EXECUTE format('CREATE UNIQUE INDEX %I ON %I (nka, bis_id, almanac_id, guaranteed_receive_time_start)',
                   partition_name || '_unique_start_idx', partition_name);

    -- Создание уникального индекса для обеспечения уникальности комбинации полей
    EXECUTE format('CREATE UNIQUE INDEX %I ON %I (nka, bis_id, almanac_id, guaranteed_receive_time_end)',
                   partition_name || '_unique_end_idx', partition_name);

    -- Для оптимизации запроса в представлении current_nka_info_for_all_almanacs:
    EXECUTE format('CREATE INDEX %I ON %I (nka, bis_id, guaranteed_receive_time_start, guaranteed_receive_time_end)',
                   partition_name || '_nka_bis_time_idx', partition_name);

    -- Для оптимизации запросов при расчёте зон видимости
    EXECUTE format('CREATE INDEX %I ON %I (nka, almanac_id)',
                partition_name || '_nka_almanac_idx', partition_name);
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции
MAC LABEL ON FUNCTION create_visibility_zone_partition(INTEGER) IS '{1,0}';
ALTER FUNCTION create_visibility_zone_partition(INTEGER) OWNER TO knp;
GRANT EXECUTE ON FUNCTION create_visibility_zone_partition(INTEGER) TO PUBLIC;

-- 3. Триггерная функция для вставки в нужную партицию
CREATE OR REPLACE FUNCTION visibility_zone_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    partition_name TEXT := format('visibility_zone_bis_%s', NEW.bis_id);
BEGIN
    -- Первая попытка вставки
    BEGIN
        EXECUTE format('
            INSERT INTO visibility.%I AS vz (nka, bis_id, almanac_id, possible_receive_time_start, guaranteed_receive_time_start, possible_receive_time_end, guaranteed_receive_time_end, last_update)
            VALUES ($1.nka, $1.bis_id, $1.almanac_id, $1.possible_receive_time_start, $1.guaranteed_receive_time_start, $1.possible_receive_time_end, $1.guaranteed_receive_time_end, $1.last_update)
            ON CONFLICT (bis_id, nka, almanac_id, guaranteed_receive_time_start)
            DO UPDATE SET
                almanac_id = EXCLUDED.almanac_id,
                possible_receive_time_start = EXCLUDED.possible_receive_time_start,
                possible_receive_time_end = EXCLUDED.possible_receive_time_end,
                guaranteed_receive_time_end = EXCLUDED.guaranteed_receive_time_end,
                last_update = CURRENT_TIMESTAMP
        ', partition_name)
        USING NEW;

        RETURN NULL;
    EXCEPTION
        WHEN unique_violation THEN
            -- Если произошел конфликт по guaranteed_receive_time_start,
            -- пробуем вставку с обработкой конфликта по guaranteed_receive_time_end
            EXECUTE format('
                INSERT INTO visibility.%I AS vz (nka, bis_id, almanac_id, possible_receive_time_start, guaranteed_receive_time_start, possible_receive_time_end, guaranteed_receive_time_end, last_update)
                VALUES ($1.nka, $1.bis_id, $1.almanac_id, $1.possible_receive_time_start, $1.guaranteed_receive_time_start, $1.possible_receive_time_end, $1.guaranteed_receive_time_end, $1.last_update)
                ON CONFLICT (bis_id, nka, almanac_id, guaranteed_receive_time_end)
                DO UPDATE SET
                    almanac_id = EXCLUDED.almanac_id,
                    possible_receive_time_start = EXCLUDED.possible_receive_time_start,
                    guaranteed_receive_time_start = EXCLUDED.guaranteed_receive_time_start,
                    possible_receive_time_end = EXCLUDED.possible_receive_time_end,
                    last_update = CURRENT_TIMESTAMP
            ', partition_name)
            USING NEW;

            RETURN NULL; -- Возвращаем NULL после обработки конфликта
    END;

    RETURN NULL; -- Возвращаем NULL, если вставка прошла успешно
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для триггерной функции
MAC LABEL ON FUNCTION visibility_zone_insert_trigger() IS '{1,0}';
ALTER FUNCTION visibility_zone_insert_trigger() OWNER TO knp;
GRANT EXECUTE ON FUNCTION visibility_zone_insert_trigger() TO PUBLIC;

-- 4. Удаляем существующий триггер (если он есть) и создаем новый
DROP TRIGGER IF EXISTS insert_visibility_zone_trigger ON visibility_zone;

-- 5. Создаем триггер на вставку
CREATE TRIGGER insert_visibility_zone_trigger
    BEFORE INSERT ON visibility_zone
    FOR EACH ROW EXECUTE PROCEDURE visibility_zone_insert_trigger();

-- 6. Функция для проверки существования партиций, их создания при необходимости и удаления неактуальных
CREATE OR REPLACE FUNCTION init_visibility_zone_partitions()
RETURNS VOID AS $$
DECLARE
    bis_id INTEGER;
    partition_name TEXT;
    existing_partition TEXT;
BEGIN
    -- Создаем партиции для существующих bis_id
    FOR bis_id IN 1..40 LOOP
        partition_name := format('visibility_zone_bis_%s', bis_id);
        IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = partition_name) THEN
            PERFORM visibility.create_visibility_zone_partition(bis_id);
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Устанавливаем MAC LABEL для функции инициализации партиций
MAC LABEL ON FUNCTION init_visibility_zone_partitions() IS '{1,0}';
ALTER FUNCTION init_visibility_zone_partitions() OWNER TO knp;
GRANT EXECUTE ON FUNCTION init_visibility_zone_partitions() TO PUBLIC;

-- Вызов функции для инициализации партиций
SELECT init_visibility_zone_partitions();

GRANT SELECT, UPDATE, INSERT, DELETE ON ALL TABLES IN SCHEMA visibility TO PUBLIC;