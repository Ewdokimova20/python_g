-- Создание схемы для СПО МССД
CREATE SCHEMA IF NOT EXISTS mssd;

-- Создание таблицы с составным первичным ключом
CREATE TABLE mssd.priem_status (
    typeid smallint NOT NULL,
    stvol smallint NOT NULL,
    komplekt smallint NOT NULL,
    state smallint NOT NULL,
    "SIGNAL" smallint,
    writetime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (typeid, stvol)
);
WITH (MACS=FALSE);

-- Выдача прав для СПО КНП в схеме mssd
GRANT ALL PRIVILEGES ON SCHEMA mssd TO knp;
GRANT INSERT, SELECT, UPDATE, DELETE ON ALL TABLES IN SCHEMA mssd TO knp;

-- Выдача прав для СПО МССД в схеме mssd
GRANT USAGE ON SCHEMA mssd TO szssd;
GRANT SELECT ON ALL TABLES IN SCHEMA mssd TO szssd;

-- Установка владельца схемы
ALTER SCHEMA mssd OWNER TO knp

-- Установка владельца таблицы
-- ALTER TABLE mssd.priem_status OWNER TO knp;
GRANT SELECT ON TABLE mssd.priem_status TO knp;

-- MAC-команды (по разграничению доступа)
MAC LABEL ON TABLE mssd.priem_status IS '{1,0}';
MAC CCR ON TABLE mssd.priem_status IS OFF;