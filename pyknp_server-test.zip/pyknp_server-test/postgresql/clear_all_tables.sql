DO $$
DECLARE
  table_name TEXT;
BEGIN
  FOR table_name IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public')
  LOOP
    EXECUTE 'TRUNCATE TABLE ' || table_name || ' CASCADE';
    IF EXISTS (SELECT 1 FROM information_schema.sequences WHERE sequence_name = table_name || '_id_seq') THEN
      EXECUTE 'ALTER SEQUENCE ' || table_name || '_id_seq RESTART WITH 1';
    END IF;
  END LOOP;
END $$;