-- столбец может иметь значение NULL (это поведение по умолчанию)
-- типа TIMESTAMP(6), который хранит время события с точностью до микросекунды.

-- В PostgreSQL типы данных REAL и DOUBLE PRECISION представляют собой числа с плавающей запятой (floating-point numbers) разной точности.
-- Тип REAL представляет число с плавающей запятой с точностью около 6 знаков после запятой (4 байта),
-- а тип DOUBLE PRECISION - с точностью около 15 знаков после запятой (8 байт).

--SQLite автоматически создает индексы для каждой связи ForeignKey в таблицах, созданных с использованием Peewee,
-- чтобы обеспечить эффективное выполнение операций, связанных с внешними ключами. Индексы ускоряют операции поиска,
-- объединения и сортировки, связанные с внешними ключами, за счет создания структуры данных, которая позволяет быстро находить соответствующие записи.

-- PostgreSQL также создает индексы для связей ForeignKey по умолчанию.
-- Это делается для обеспечения эффективного выполнения операций, связанных с внешними ключами, таких как поиск, объединение и сортировка.
-- Создание индексов для внешних ключей ускоряет эти операции, позволяя базе данных быстро находить соответствующие записи.

-- шаблон

-- для настройки метки 1:
MAC LABEL ON DATABASE CURRENT_CATALOG IS '{1,0}';
MAC CCR   ON DATABASE CURRENT_CATALOG IS OFF;
ALTER SCHEMA public OWNER TO knp;
MAC LABEL ON SCHEMA public IS '{1,0}';
MAC CCR   ON SCHEMA public IS OFF;


-- для отладки команда: sudo -u postgres dropdb tlbd; sudo -u postgres createdb tlbd; sudo -u postgres psql -f postgre.sql tlbd

-- Навигационный космический аппарат из состава ГЛОНАСС.
CREATE TABLE nka (
    nka_sys_number INTEGER NOT NULL PRIMARY KEY,
    nku_number INTEGER DEFAULT 0,
    type_ka VARCHAR(255) DEFAULT '',
    type_si VARCHAR(255) NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE nka OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE nka IS '{1,0}';
MAC CCR   ON TABLE nka IS OFF;


-- Станция беззапросных измерительных средств (БИС).
CREATE TABLE station (
    station_number INTEGER NOT NULL PRIMARY KEY,
    reliability_control_elevation INTEGER DEFAULT 15,
    receive_control_elevation   INTEGER DEFAULT 9,
    min_elevation INTEGER DEFAULT 5,
    solution_distance_threshold INTEGER DEFAULT 10,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE station OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE station IS '{1,0}';
MAC CCR   ON TABLE station IS OFF;



-- Беззапросное измерительное средство (БИС).
CREATE TABLE bis (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_number INTEGER NOT NULL,
    station_id INTEGER NOT NULL REFERENCES Station (station_number),
    x_coord DOUBLE PRECISION DEFAULT -120000.0,
    y_coord DOUBLE PRECISION DEFAULT 350000.0,
    z_coord DOUBLE PRECISION DEFAULT 5200000.0,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE bis OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE bis IS '{1,0}';
MAC CCR   ON TABLE bis IS OFF;



-- Тип сигнала
CREATE TABLE signaltype (
    signal_type_id INTEGER NOT NULL PRIMARY KEY,
    name VARCHAR(255) DEFAULT 'n/a',
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE signaltype OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE signaltype IS '{1,0}';
MAC CCR   ON TABLE signaltype IS OFF;

-- Сигнал, принятый БИС от НКА ГЛОНАСС.
CREATE TABLE signal (
    id SERIAL NOT NULL PRIMARY KEY,
    signal_type_id INTEGER NOT NULL REFERENCES signaltype (signal_type_id) ON DELETE CASCADE,
    nka_id INTEGER NOT NULL REFERENCES nka (nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER NOT NULL REFERENCES bis (id) ON DELETE CASCADE,
    timestamp TIMESTAMP(6) NOT NULL,
    nanoseconds INTEGER DEFAULT 0,
    letter INTEGER NOT NULL,
    snr DOUBLE PRECISION NOT NULL,
    pseudorange DOUBLE PRECISION NOT NULL,
    pseudospeed DOUBLE PRECISION NOT NULL,
    carrier_shift DOUBLE PRECISION NOT NULL,
    carrier_phase DOUBLE PRECISION NOT NULL,
--    status BOOLEAN DEFAULT FALSE,
--    checked BOOLEAN DEFAULT FALSE,
--    residuals_excluded BOOLEAN DEFAULT FALSE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE signal OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE signal IS '{1,0}';
MAC CCR   ON TABLE signal IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE signal_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX signal_db_timestamp ON signal(db_timestamp);

CREATE INDEX signal_nka_id_bis_id_type_timestamp
  ON public.signal
  USING btree
  (nka_id, bis_id, signal_type_id, "timestamp");


-- Результаты контроля НКА.
CREATE TABLE control (
    id SERIAL NOT NULL PRIMARY KEY,
    signal_type_id INTEGER REFERENCES signaltype (signal_type_id) ON DELETE CASCADE,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP NOT NULL,
    letter INTEGER NOT NULL,
    snr DOUBLE PRECISION NOT NULL,
    nka_status INTEGER NOT NULL,
    nka_elevation DOUBLE PRECISION NOT NULL,
    nka_azimuth DOUBLE PRECISION NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE control OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE control IS '{1,0}';
MAC CCR   ON TABLE control IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE control_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX control_nka_id_bis_id ON control (nka_id, bis_id);
CREATE INDEX control_db_timestamp ON control(db_timestamp);



-- Таблица принятых строк цифровой информации L1OFString
CREATE TABLE l1ofstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1ofstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1ofstring IS '{1,0}';
MAC CCR   ON TABLE l1ofstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1ofstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l1ofstring_nka_id_bis_id_timestamp ON l1ofstring (nka_id, bis_id, timestamp);
CREATE INDEX l1ofstring_db_timestamp ON l1ofstring(db_timestamp);



-- Таблица принятых строк цифровой информации L2OFString
CREATE TABLE l2ofstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l2ofstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l2ofstring IS '{1,0}';
MAC CCR   ON TABLE l2ofstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l2ofstring_id_seq CYCLE MAXVALUE 2147483647;


CREATE UNIQUE INDEX l2ofstring_nka_id_bis_id_timestamp ON l2ofstring (nka_id, bis_id, timestamp);
CREATE INDEX l2ofstring_db_timestamp ON l2ofstring(db_timestamp);



-- Таблица принятых строк цифровой информации L1SF
CREATE TABLE l1sfstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(6) NOT NULL,
    string_num INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1sfstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1sfstring IS '{1,0}';
MAC CCR   ON TABLE l1sfstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1sfstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l1sfstring_nka_id_bis_id_timestamp ON l1sfstring (nka_id, bis_id, timestamp);
CREATE INDEX l1sfstring_db_timestamp ON l1sfstring(db_timestamp);



-- Не создана в sqlite : Таблица принятых строк цифровой информации L1OC.
CREATE TABLE l1ocstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    string_omv INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1ocstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1ocstring IS '{1,0}';
MAC CCR   ON TABLE l1ocstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1ocstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l1ocstring_nka_id_bis_id_timestamp ON l1ocstring (nka_id, bis_id, timestamp);
CREATE INDEX l1ocstring_db_timestamp ON l1ocstring(db_timestamp);



-- Строка цифровой информации L3OC
CREATE TABLE l3ocstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    string_omv INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l3ocstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l3ocstring IS '{1,0}';
MAC CCR   ON TABLE l3ocstring IS OFF;

-- Сделать последвательность циклической
ALTER SEQUENCE l3ocstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l3ocstring_nka_id_bis_id_timestamp ON l3ocstring (nka_id, bis_id, timestamp);
CREATE INDEX l3ocstring_db_timestamp ON l3ocstring(db_timestamp);



-- Строка цифровой информации L2КСИ
CREATE TABLE l2ksistring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    string_omv INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l2ksistring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l2ksistring IS '{1,0}';
MAC CCR   ON TABLE l2ksistring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l2ksistring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l2ksistring_nka_id_bis_id_timestamp ON l2ksistring (nka_id, bis_id, timestamp);
CREATE INDEX l2ksistring_db_timestamp ON l2ksistring(db_timestamp);



-- Кадр ЦИ L1OC
CREATE TABLE l1ocframe (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string20 TEXT,
    string25 TEXT,
    string16 TEXT,
    string31 TEXT,
    string32 TEXT,
    string50 TEXT,
    string60 TEXT,
    string0 TEXT,
    -- string1: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    -- string2: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other TEXT,
    is_complete BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1ocframe OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1ocframe IS '{1,0}';
MAC CCR   ON TABLE l1ocframe IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1ocframe_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l1ocframe_search ON l1ocframe (nka_id, bis_id, timestamp);
CREATE INDEX l1ocframe_db_timestamp ON l1ocframe(db_timestamp);



-- Кадр ЦИ L3OC
CREATE TABLE l3ocframe (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string20 TEXT,
    string25 TEXT,
    string16 TEXT,
    string31 TEXT,
    string32 TEXT,
    string60 TEXT,
    string0 TEXT,
    -- string1: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    -- string2: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other TEXT,
    is_complete BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l3ocframe OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l3ocframe IS '{1,0}';
MAC CCR   ON TABLE l3ocframe IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l3ocframe_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l3ocframe_search ON l3ocframe (nka_id, bis_id, timestamp);
CREATE INDEX l3ocframe_db_timestamp ON l3ocframe(db_timestamp);



-- Рассчитанные эфемериды НКА
-- deprecated
--CREATE TABLE ephemeris (
--    id SERIAL NOT NULL PRIMARY KEY,
--    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
--    x DOUBLE PRECISION NOT NULL,
--    y DOUBLE PRECISION NOT NULL,
--    z DOUBLE PRECISION NOT NULL,
--    "Vx" DOUBLE PRECISION NOT NULL,
--    "Vy" DOUBLE PRECISION NOT NULL,
--    "Vz" DOUBLE PRECISION NOT NULL,
--    "Ax" DOUBLE PRECISION NOT NULL,
--    "Ay" DOUBLE PRECISION NOT NULL,
--    "Az" DOUBLE PRECISION NOT NULL,
--    t TIMESTAMP NOT NULL,
--    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
--)
--WITH (MACS=FALSE);
--ALTER        TABLE ephemeris OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
--MAC LABEL ON TABLE ephemeris IS '{1,0}';
--MAC CCR   ON TABLE ephemeris IS OFF;
--
--CREATE INDEX ephemeris_db_timestamp ON ephemeris(db_timestamp);



-- Обобщенная оперативная информация по сигналам с частотным разделением
CREATE TABLE lfimmediateinfo (
    id SERIAL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    signal_id INTEGER NOT NULL,
    x DOUBLE PRECISION NOT NULL,
    y DOUBLE PRECISION NOT NULL,
    z DOUBLE PRECISION NOT NULL,
    "Vx" DOUBLE PRECISION NOT NULL,
    "Vy" DOUBLE PRECISION NOT NULL,
    "Vz" DOUBLE PRECISION NOT NULL,
    "Ax" DOUBLE PRECISION NOT NULL,
    "Ay" DOUBLE PRECISION NOT NULL,
    "Az" DOUBLE PRECISION NOT NULL,
    "N_T" INTEGER NOT NULL,
    "P1" INTEGER NOT NULL,
    t_k INTEGER NOT NULL,
    t_b INTEGER NOT NULL,
    gamma DOUBLE PRECISION NOT NULL,
    tau DOUBLE PRECISION NOT NULL,
    ln1 INTEGER NOT NULL,
    ln3 INTEGER NOT NULL,
    ground_call INTEGER NOT NULL,
    frame_time INTEGER NOT NULL,
    is_in_time BOOLEAN NOT NULL,
    "N4" INTEGER NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE lfimmediateinfo OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE lfimmediateinfo IS '{1,0}';
MAC CCR   ON TABLE lfimmediateinfo IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE lfimmediateinfo_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX lfimmediateinfo_db_timestamp ON lfimmediateinfo(db_timestamp);
CREATE INDEX lfimmediateinfo_search ON lfimmediateinfo (nka_id, signal_id);
CREATE UNIQUE INDEX lfimmediateinfo_nka_id_N_T_t_k_is_in_time ON lfimmediateinfo (nka_id, "N_T", t_k, is_in_time, signal_id);


CREATE TABLE almanac(
    id SERIAL PRIMARY KEY,
    nka INTEGER NOT NULL,
    source_nka INTEGER NOT NULL DEFAULT 0,
    source_signal INTEGER NOT NULL DEFAULT 0,
    "N_A" INTEGER NOT NULL,
    "N4" INTEGER NOT NULL,
    "approve_count" INTEGER NOT NULL DEFAULT 0,
    "Tlambda_A" DOUBLE PRECISION NOT NULL,
    "deltaT_A" DOUBLE PRECISION NOT NULL,
    "deltaI_A" DOUBLE PRECISION NOT NULL,
    "deltaTdot" DOUBLE PRECISION NOT NULL,
    "e_A" DOUBLE PRECISION NOT NULL,
    "omega_A" DOUBLE PRECISION NOT NULL,
    "lambda_A" DOUBLE PRECISION NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE almanac OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE almanac IS '{1,0}';
MAC CCR   ON TABLE almanac IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE almanac_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX almanac_db_timestamp ON almanac(db_timestamp);
CREATE UNIQUE INDEX almanac_nka_N4_N_A ON almanac (nka, "N4", "N_A");


-- Чрезвычайно редко изменяющиеся данные кодовых сигналов.
CREATE TABLE lcstabledata (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    signal_type_id INTEGER NOT NULL,
    r DOUBLE PRECISION NOT NULL,
    b DOUBLE PRECISION NOT NULL,
    n DOUBLE PRECISION NOT NULL,
    dt DOUBLE PRECISION NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE lcstabledata OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE lcstabledata IS '{1,0}';
MAC CCR   ON TABLE lcstabledata IS OFF;

ALTER SEQUENCE lcstabledata_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX lcstabledata_nka_id_signal_type_id ON lcstabledata (nka_id, signal_type_id);



-- Обобщенная оперативная информация по кодовым сигналам
CREATE TABLE lcimmediateinfo (
    id SERIAL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    x DOUBLE PRECISION NOT NULL,
    y DOUBLE PRECISION NOT NULL,
    z DOUBLE PRECISION NOT NULL,
    "Vx" DOUBLE PRECISION NOT NULL,
    "Vy" DOUBLE PRECISION NOT NULL,
    "Vz" DOUBLE PRECISION NOT NULL,
    "Ax" DOUBLE PRECISION NOT NULL,
    "Ay" DOUBLE PRECISION NOT NULL,
    "Az" DOUBLE PRECISION NOT NULL,
    "N_T" INTEGER NOT NULL,
    "P1" INTEGER NOT NULL,
    t_k INTEGER NOT NULL,
    t_b INTEGER NOT NULL,
    gamma DOUBLE PRECISION NOT NULL,
    tau DOUBLE PRECISION NOT NULL,
    ln1 INTEGER NOT NULL,
    ln3 INTEGER NOT NULL,
    ground_call INTEGER NOT NULL,
    frame_time INTEGER NOT NULL,
    is_in_time BOOLEAN NOT NULL,
    beta DOUBLE PRECISION NOT NULL,
    "N4" INTEGER NOT NULL,
    signal_id INTEGER NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE lcimmediateinfo OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE lcimmediateinfo IS '{1,0}';
MAC CCR   ON TABLE lcimmediateinfo IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE lcimmediateinfo_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX lcimmediateinfo_db_timestamp ON lcimmediateinfo(db_timestamp);
CREATE INDEX lcimmediateinfo_search ON lcimmediateinfo (nka_id, signal_id);
CREATE UNIQUE INDEX lcimmediateinfo_nka_id_N_T_t_k_is_in_time_signal_id ON lcimmediateinfo (nka_id, "N_T", t_k, is_in_time, signal_id);



-- Модель невязки
CREATE TABLE residual (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id) ON DELETE CASCADE,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    signal_1 INTEGER DEFAULT NULL,
    signal_2 INTEGER DEFAULT NULL,
    residual DOUBLE PRECISION NOT NULL,
    residual1 DOUBLE PRECISION,
    residual2 DOUBLE PRECISION,
    speed_residual DOUBLE PRECISION NOT NULL,
    average DOUBLE PRECISION DEFAULT NULL,
    delta DOUBLE PRECISION DEFAULT NULL,
    delta1 DOUBLE PRECISION DEFAULT NULL,
    delta2 DOUBLE PRECISION DEFAULT NULL,
    status BOOLEAN DEFAULT FALSE,
    y_comb_1 DOUBLE PRECISION DEFAULT NULL,
    y_comb_2 DOUBLE PRECISION DEFAULT NULL,
    distance DOUBLE PRECISION NOT NULL,
    ionosphere_free_combination DOUBLE PRECISION DEFAULT NULL,
    tropo_delay DOUBLE PRECISION NOT NULL,
    time_freq_correction DOUBLE PRECISION NOT NULL,
    signal1_pseudorange DOUBLE PRECISION NOT NULL,
    signal2_pseudorange DOUBLE PRECISION DEFAULT NULL,
    nka_x DOUBLE PRECISION DEFAULT 0,
    nka_y DOUBLE PRECISION DEFAULT 0,
    nka_z DOUBLE PRECISION DEFAULT 0,
    nka_elevation DOUBLE PRECISION DEFAULT 0,
    nka_in_guaranteed_elevation BOOLEAN NOT NULL DEFAULT True,
    signal_is_untrusted BOOLEAN NOT NULL DEFAULT False,
    rejected_due_to_deviation BOOLEAN NOT NULL DEFAULT False,
    timestamp TIMESTAMP NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE residual OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE residual IS '{1,0}';
MAC CCR   ON TABLE residual IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE residual_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX residual_db_timestamp ON residual(db_timestamp);
CREATE UNIQUE INDEX residual_nka_id_bis_id_signal_1_timestamp ON residual (nka_id, bis_id, signal_1, timestamp);
CREATE INDEX residual_rejected_due_to_deviation_signal_1_timestamp ON residual (rejected_due_to_deviation, signal_1, timestamp);

-- Модель текущего (за последние 10 секунд) угла места НКА к БИС
CREATE TABLE currentangles (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    station_id INTEGER NOT NULL REFERENCES station(station_number) ON DELETE CASCADE,
    elevation DOUBLE PRECISION NOT NULL,
    azimuth DOUBLE PRECISION NOT NULL,
    visibility_state INTEGER NOT NULL,
    trend INTEGER DEFAULT 0,
    timestamp TIMESTAMP NOT NULL
)
WITH (MACS=FALSE);
ALTER        TABLE currentangles OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE currentangles IS '{1,0}';
MAC CCR   ON TABLE currentangles IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE currentangles_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX currentangles_nka_id_station_id ON currentangles (nka_id, station_id);
CREATE INDEX idx_currentangles_visibility_state ON currentangles(visibility_state);



-- Модель результатов решения навигационной задачи
CREATE TABLE navsolution (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    height DOUBLE PRECISION NOT NULL,
    latitude_error DOUBLE PRECISION NOT NULL,
    longitude_error DOUBLE PRECISION NOT NULL,
    height_error DOUBLE PRECISION NOT NULL,
    latitude_velocity DOUBLE PRECISION NOT NULL,
    longitude_velocity DOUBLE PRECISION NOT NULL,
    height_velocity DOUBLE PRECISION NOT NULL,
    "HDOP" DOUBLE PRECISION NOT NULL,
    "VDOP" DOUBLE PRECISION NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE navsolution OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE navsolution IS '{1,0}';
MAC CCR   ON TABLE navsolution IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE navsolution_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX navsolution_db_timestamp ON navsolution(db_timestamp);



-- Решение навигационной задачи силами КНП
CREATE TABLE knpnavsolution (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id),
    signal_id INTEGER NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    height DOUBLE PRECISION NOT NULL,
    x DOUBLE PRECISION NOT NULL,
    y DOUBLE PRECISION NOT NULL,
    z DOUBLE PRECISION NOT NULL,
    "E" DOUBLE PRECISION NOT NULL,
    "N" DOUBLE PRECISION NOT NULL,
    "U" DOUBLE PRECISION NOT NULL,
    dt DOUBLE PRECISION NOT NULL,
    distance DOUBLE PRECISION NOT NULL,
    "GDOP" DOUBLE PRECISION NOT NULL DEFAULT 0,
    threshold_exceeded BOOLEAN NOT NULL DEFAULT FALSE,
    nka_list VARCHAR(64) NOT NULL,
    user_solution BOOLEAN NOT NULL DEFAULT FALSE,
    best_solution BOOLEAN NOT NULL DEFAULT FALSE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE knpnavsolution OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE knpnavsolution IS '{1,0}';
MAC CCR   ON TABLE knpnavsolution IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE knpnavsolution_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX knpnavsolution_db_timestamp ON knpnavsolution(db_timestamp);



-- Модель времени получения и времени из заголовка пакета
CREATE TABLE packet (
    id SERIAL NOT NULL PRIMARY KEY,
    packet_identi INTEGER NOT NULL,
    packet_gen_timestamp_s DOUBLE PRECISION NOT NULL,
    db_timestamp_s DOUBLE PRECISION NOT NULL,
    ders DOUBLE PRECISION NOT NULL,
    packet_gen_timestamp TIMESTAMP NOT NULL,
    dropped BOOLEAN NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE packet OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE packet IS '{1,0}';
MAC CCR   ON TABLE packet IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE packet_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX packet_db_timestamp ON packet(db_timestamp);



--  Модель оперативного сообщения
CREATE TABLE opmessage (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id),
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number),
    timestamp TIMESTAMP NOT NULL,
    letter INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    snr DOUBLE PRECISION NOT NULL,
    not_in_sight BOOLEAN NOT NULL,
    excess_of_residual BOOLEAN NOT NULL,
    excess_of_pseudorange_difference BOOLEAN NOT NULL,
    excess_of_navsolution_error BOOLEAN NOT NULL,
    ground_control_call BOOLEAN NOT NULL,
    unreliable_frame BOOLEAN NOT NULL,
    unreliable_signal BOOLEAN NOT NULL,
    unreliable_digital_info BOOLEAN NOT NULL,
    tk_inconsistency BOOLEAN NOT NULL,
    tb_inconsistency BOOLEAN NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE opmessage OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE opmessage IS '{1,0}';
MAC CCR   ON TABLE opmessage IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE opmessage_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX opmessage_db_timestamp ON opmessage(db_timestamp);

--  Модель оперативного сообщения
CREATE TABLE knpopmessage (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id),
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number),
    timestamp TIMESTAMP NOT NULL,
    letter INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    snr DOUBLE PRECISION NOT NULL,
    not_in_sight BOOLEAN NOT NULL,
    excess_of_residual BOOLEAN NOT NULL,
    excess_of_pseudorange_difference BOOLEAN NOT NULL,
    excess_of_navsolution_error BOOLEAN NOT NULL,
    ground_control_call BOOLEAN NOT NULL,
    unreliable_frame BOOLEAN NOT NULL,
    unreliable_signal BOOLEAN NOT NULL,
    unreliable_digital_info BOOLEAN NOT NULL,
    tk_inconsistency BOOLEAN NOT NULL,
    tb_inconsistency BOOLEAN NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE knpopmessage OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE knpopmessage IS '{1,0}';
MAC CCR   ON TABLE knpopmessage IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE knpopmessage_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX knpopmessage_db_timestamp ON knpopmessage(db_timestamp);


--  Модель оперативного сообщения по обобщенной ЦИ
CREATE TABLE knpopsummessage (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER NOT NULL REFERENCES bis(id),
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number),
    timestamp TIMESTAMP NOT NULL,
    letter INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    tk INTEGER NOT NULL,
    "EI_inconsistency" BOOLEAN NOT NULL,
    clock_inconsistency BOOLEAN NOT NULL,
    almanac_inconsistency BOOLEAN NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE knpopsummessage OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE knpopsummessage IS '{1,0}';
MAC CCR   ON TABLE knpopsummessage IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE knpopsummessage_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX knpopsummessage_timestamp ON knpopsummessage(timestamp);
CREATE INDEX knpopsummessage_db_timestamp ON knpopsummessage(db_timestamp);

-- Кадр ЦИ L1OF
CREATE TABLE l1offrame (
    id SERIAL  NOT NULL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    tk INTEGER NOT NULL,
    seq INTEGER NOT NULL,
    num INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string1_id INTEGER,
    string2_id INTEGER,
    string3_id INTEGER,
    string4_id INTEGER,
    string5_id INTEGER,
    string6_id INTEGER,
    string7_id INTEGER,
    string8_id INTEGER,
    string9_id INTEGER,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string13_id INTEGER,
    string14_id INTEGER,
    string15_id INTEGER,
    is_fifth BOOLEAN NOT NULL DEFAULT FALSE,
    is_complete BOOLEAN NOT NULL DEFAULT TRUE,
    timestamp TIMESTAMP NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1offrame OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1offrame IS '{1,0}';
MAC CCR   ON TABLE l1offrame IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1offrame_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l1offrame_search ON l1offrame (nka_id, bis_id, timestamp);
CREATE INDEX l1offrame_db_timestamp ON l1offrame(db_timestamp);



-- Кадр ЦИ L2OF"
CREATE TABLE l2offrame (
    id SERIAL  NOT NULL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    tk INTEGER NOT NULL,
    seq INTEGER NOT NULL,
    num INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string1_id INTEGER,
    string2_id INTEGER,
    string3_id INTEGER,
    string4_id INTEGER,
    string5_id INTEGER,
    string6_id INTEGER,
    string7_id INTEGER,
    string8_id INTEGER,
    string9_id INTEGER,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string13_id INTEGER,
    string14_id INTEGER,
    string15_id INTEGER,
    is_fifth BOOLEAN NOT NULL DEFAULT FALSE,
    is_complete BOOLEAN NOT NULL DEFAULT TRUE,
    timestamp TIMESTAMP NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l2offrame OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l2offrame IS '{1,0}';
MAC CCR   ON TABLE l2offrame IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l2offrame_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l2offrame_search ON l2offrame (nka_id, bis_id, timestamp);
CREATE INDEX l2offrame_db_timestamp ON l2offrame(db_timestamp);



--  Кадр ЦИ L1SF
CREATE TABLE l1sfframe (
    id SERIAL  NOT NULL PRIMARY KEY,
    nka_id INTEGER NOT NULL REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    tk INTEGER NOT NULL,
    seq INTEGER NOT NULL,
    num INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string1_id INTEGER,
    string2_id INTEGER,
    string3_id INTEGER,
    string4_id INTEGER,
    string5_id INTEGER,
    string6_id INTEGER,
    string7_id INTEGER,
    string8_id INTEGER,
    string9_id INTEGER,
    string10_id INTEGER,
    is_complete BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1sfframe OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1sfframe IS '{1,0}';
MAC CCR   ON TABLE l1sfframe IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1sfframe_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l1sfframe_search ON l1sfframe (nka_id, bis_id, timestamp);
CREATE INDEX l1sfframe_db_timestamp ON l1sfframe(db_timestamp);


-- Строка цифровой информации l1sc
CREATE TABLE l1scstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    string_omv INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1scstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1scstring IS '{1,0}';
MAC CCR   ON TABLE l1scstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1scstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l1scstring_nka_id_bis_id_timestamp ON l1scstring (nka_id, bis_id, timestamp);
CREATE INDEX l1scstring_db_timestamp ON l1scstring(db_timestamp);



-- Кадр ЦИ l1sc
CREATE TABLE l1scframe (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string13_id INTEGER,
    string20 TEXT,
    string25 TEXT,
    string16 TEXT,
    string31 TEXT,
    string32 TEXT,
    string60 TEXT,
    string0 TEXT,
    -- string1: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    -- string2: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other TEXT,
    is_complete BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l1scframe OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l1scframe IS '{1,0}';
MAC CCR   ON TABLE l1scframe IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l1scframe_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l1scframe_search ON l1scframe (nka_id, bis_id, timestamp);
CREATE INDEX l1scframe_db_timestamp ON l1scframe(db_timestamp);



-- Строка цифровой информации l2sc
CREATE TABLE l2scstring (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(3) NOT NULL,
    string_num INTEGER NOT NULL,
    string_omv INTEGER NOT NULL,
    byte_content BYTEA NOT NULL,
    error_in_string BOOLEAN DEFAULT TRUE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l2scstring OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l2scstring IS '{1,0}';
MAC CCR   ON TABLE l2scstring IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l2scstring_id_seq CYCLE MAXVALUE 2147483647;

CREATE UNIQUE INDEX l2scstring_nka_id_bis_id_timestamp ON l2scstring (nka_id, bis_id, timestamp);
CREATE INDEX l2scstring_db_timestamp ON l2scstring(db_timestamp);



-- Кадр ЦИ l2sc
CREATE TABLE l2scframe (
    id SERIAL NOT NULL PRIMARY KEY,
    nka_id INTEGER REFERENCES nka(nka_sys_number) ON DELETE CASCADE,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    time INTEGER NOT NULL,
    string10_id INTEGER,
    string11_id INTEGER,
    string12_id INTEGER,
    string13_id INTEGER,
    string20 TEXT,
    string25 TEXT,
    string16 TEXT,
    string31 TEXT,
    string32 TEXT,
    string60 TEXT,
    string0 TEXT,
    -- string1: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    -- string2: CDSignalString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other TEXT,
    is_complete BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE l2scframe OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE l2scframe IS '{1,0}';
MAC CCR   ON TABLE l2scframe IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE l2scframe_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX l2scframe_search ON l2scframe (nka_id, bis_id, timestamp);
CREATE INDEX l2scframe_db_timestamp ON l2scframe(db_timestamp);

--Сводная таблица информации об обобщенных кадрах всех типов сигналов
CREATE TABLE summarized_frames_info (
    id SERIAL NOT NULL PRIMARY KEY,
    frame_id INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    nka_id INTEGER REFERENCES nka(nka_sys_number),
    timestamp TIMESTAMP,
    sources TEXT NOT NULL,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER TABLE summarized_frames_info OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE summarized_frames_info IS '{1,0}';
MAC CCR   ON TABLE summarized_frames_info IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE summarized_frames_info_id_seq   CYCLE    MAXVALUE 2147483647;

CREATE UNIQUE INDEX summarized_frames_info_frame_id_signal_type ON summarized_frames_info(frame_id, signal_type);
CREATE INDEX summarized_frame_search ON summarized_frames_info(nka_id, signal_type, timestamp);
CREATE INDEX summarized_frames_info_db_timestamp ON summarized_frames_info(db_timestamp);


--Таблица для сохранения результатов сравнения ЭИ и ЧВП из обобщенного кадра с СИ
CREATE TABLE summarized_frame_comparison (
    id SERIAL NOT NULL PRIMARY KEY,
    frame_info_id INTEGER,
    almanac_sys_num INTEGER,
    name TEXT NOT NULL,
    param_value TEXT,
    is_valid INTEGER,
    si_value DOUBLE PRECISION,
    si_timestamp TIMESTAMP,
    si_phrase_tb INTEGER,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER TABLE summarized_frame_comparison OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE summarized_frame_comparison IS '{1,0}';
MAC CCR   ON TABLE summarized_frame_comparison IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE summarized_frame_comparison_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX summarized_frame_comparison_search ON summarized_frame_comparison(frame_info_id);
CREATE INDEX summarized_frame_comparison_db_timestamp ON summarized_frame_comparison(db_timestamp);


-- Метеопараметры от БИС
CREATE TABLE meteoparameters (
    id SERIAL NOT NULL PRIMARY KEY,
    bis_id INTEGER REFERENCES bis(id) ON DELETE CASCADE,
    timestamp TIMESTAMP(0) NOT NULL,
    p DOUBLE PRECISION NOT NULL,
    t DOUBLE PRECISION NOT NULL,
    h DOUBLE PRECISION NOT NULL,
    is_incorrect BOOLEAN DEFAULT FALSE,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE meteoparameters OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE meteoparameters IS '{1,0}';
MAC CCR   ON TABLE meteoparameters IS OFF;

-- Сделать последовательность циклической
ALTER SEQUENCE meteoparameters_id_seq CYCLE MAXVALUE 2147483647;

CREATE INDEX meteoparameters_search       ON meteoparameters(bis_id, timestamp);
CREATE INDEX meteoparameters_db_timestamp ON meteoparameters(db_timestamp);


CREATE TABLE meas_reception_data (
    bis_id INTEGER NOT NULL REFERENCES bis(id) ON DELETE CASCADE,
    nka INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    reception_status INTEGER NOT NULL,
    is_zone_count_sufficient BOOLEAN,
    measurement_id INTEGER REFERENCES signal(id) ON DELETE CASCADE,
    timestamp TIMESTAMP,
    actual_count INTEGER,
    zone_count INTEGER,
    expected_zone_count INTEGER,
    last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (bis_id, nka, signal_type)
)
WITH (MACS=FALSE);

-- Если нужно изменить владельца таблицы на knp
ALTER        TABLE meas_reception_data OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE meas_reception_data IS '{1,0}';
MAC CCR   ON TABLE meas_reception_data IS OFF;

-- Добавим индексы для улучшения производительности запросов
CREATE INDEX idx_meas_reception_data_nka_bis ON meas_reception_data(nka, bis_id);
CREATE INDEX idx_meas_reception_data_measurement ON meas_reception_data(measurement_id);

-- Добавим комментарии к таблице и столбцам для лучшей документации
COMMENT ON TABLE meas_reception_data IS 'Таблица для хранения данных о приеме 1с измерений';
COMMENT ON COLUMN meas_reception_data.bis_id IS 'Идентификатор БИС';
COMMENT ON COLUMN meas_reception_data.nka IS 'Номер космического аппарата';
COMMENT ON COLUMN meas_reception_data.signal_type IS 'Тип сигнала';
COMMENT ON COLUMN meas_reception_data.reception_status IS 'Состояние приема';
COMMENT ON COLUMN meas_reception_data.is_zone_count_sufficient IS 'Флаг, показывающий, что процент измерений в ЗРВ от общего количества измерений превышает установленный порог';
COMMENT ON COLUMN meas_reception_data.measurement_id IS 'Измерение';
COMMENT ON COLUMN meas_reception_data.timestamp IS 'Время пакета';
COMMENT ON COLUMN meas_reception_data.actual_count IS 'Счетчик измерений фактический';
COMMENT ON COLUMN meas_reception_data.zone_count IS 'Счетчик измерений в ЗРВ (гарантированной)';
COMMENT ON COLUMN meas_reception_data.expected_zone_count IS 'Требуемое количество измерений в ЗРВ';
COMMENT ON COLUMN meas_reception_data.last_update IS 'Время последнего обновления';

CREATE TABLE di_reception_data (
    bis_id INTEGER NOT NULL REFERENCES bis(id) ON DELETE CASCADE,
    nka INTEGER NOT NULL,
    signal_type INTEGER NOT NULL,
    reception_status INTEGER NOT NULL,
    is_zone_count_sufficient BOOLEAN,
    has_too_many_errors BOOLEAN,
    timestamp TIMESTAMP,
    actual_count INTEGER,
    error_count INTEGER,
    zone_count INTEGER,
    expected_zone_count INTEGER,
    last_update TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (bis_id, nka, signal_type)
)
WITH (MACS=FALSE);

-- Если нужно изменить владельца таблицы на knp
ALTER        TABLE di_reception_data OWNER TO knp; -- если может понадобиться изменять структуры из под пользователя knp
MAC LABEL ON TABLE di_reception_data IS '{1,0}';
MAC CCR   ON TABLE di_reception_data IS OFF;

-- Добавим индексы для улучшения производительности запросов
CREATE INDEX idx_di_reception_data_nka_bis ON di_reception_data(nka, bis_id);

-- Добавим комментарии к таблице и столбцам для лучшей документации
COMMENT ON TABLE di_reception_data IS 'Таблица для хранения данных о приеме ЦИ';
COMMENT ON COLUMN di_reception_data.bis_id IS 'Идентификатор БИС';
COMMENT ON COLUMN di_reception_data.nka IS 'Номер космического аппарата';
COMMENT ON COLUMN di_reception_data.signal_type IS 'Тип сигнала';
COMMENT ON COLUMN di_reception_data.reception_status IS 'Состояние приема в зависимости от видимости';
COMMENT ON COLUMN di_reception_data.is_zone_count_sufficient IS 'Флаг, показывающий, что процент строк ЦИ в ЗРВ от общего количества  превышает установленный порог';
COMMENT ON COLUMN di_reception_data.timestamp IS 'Время пакета';
COMMENT ON COLUMN di_reception_data.actual_count IS 'Счетчик строк ЦИ фактический';
COMMENT ON COLUMN di_reception_data.error_count IS 'Счетчик строк ЦИ с ошибками';
COMMENT ON COLUMN di_reception_data.has_too_many_errors IS 'Флаг, превышает ли доля строк с ошибками установленный порог';
COMMENT ON COLUMN di_reception_data.zone_count IS 'Счетчик строк ЦИ в ЗРВ (гарантированной)';
COMMENT ON COLUMN di_reception_data.expected_zone_count IS 'Требуемое количество строк ЦИ в ЗРВ';
COMMENT ON COLUMN di_reception_data.last_update IS 'Время последнего обновления';


-- Группы сигнальных признаков
CREATE TABLE signal_flag_groups (
    group_id SERIAL NOT NULL PRIMARY KEY,
    nka INTEGER NOT NULL,
    alarm_id INTEGER NOT NULL,
    signal_id INTEGER NOT NULL,
    alarm_value INTEGER,
    finalize_code INTEGER,
    first_appear_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_appear_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_timestamp TIMESTAMP,
    db_timestamp TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
)
WITH (MACS=FALSE);
ALTER        TABLE signal_flag_groups OWNER TO knp;
MAC LABEL ON TABLE signal_flag_groups IS '{1,0}';
MAC CCR   ON TABLE signal_flag_groups IS OFF;

ALTER SEQUENCE signal_flag_groups_group_id_seq CYCLE MAXVALUE 2147483647;
CREATE INDEX signal_flag_groups_first_appear_timestamp ON signal_flag_groups(first_appear_timestamp);
CREATE INDEX signal_flag_groups_db_timestamp ON signal_flag_groups(db_timestamp);

-- Связь групп сигнальных признаков с БИС
CREATE TABLE sources_signal_flag_groups (
    group_id INTEGER NOT NULL REFERENCES signal_flag_groups(group_id) ON DELETE CASCADE,
    source_id INTEGER NOT NULL,
    bis_id INTEGER NOT NULL,
    PRIMARY KEY (group_id, source_id, bis_id)
)
WITH (MACS=FALSE);
ALTER        TABLE sources_signal_flag_groups OWNER TO knp;
MAC LABEL ON TABLE sources_signal_flag_groups IS '{1,0}';
MAC CCR   ON TABLE sources_signal_flag_groups IS OFF;


--MAC LABEL ON SEQUENCE public.ephemeris_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.bis_id_seq                  IS '{1,0}';
MAC LABEL ON SEQUENCE public.control_id_seq              IS '{1,0}';
MAC LABEL ON SEQUENCE public.currentangles_id_seq        IS '{1,0}';
MAC LABEL ON SEQUENCE public.knpnavsolution_id_seq       IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1ocframe_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1ocstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1offrame_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.lfimmediateinfo_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1ofstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1scframe_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1scstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1sfframe_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l1sfstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l2ksistring_id_seq          IS '{1,0}';
MAC LABEL ON SEQUENCE public.l2offrame_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l2ofstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l2scframe_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l2scstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.l3ocframe_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.l3ocstring_id_seq           IS '{1,0}';
MAC LABEL ON SEQUENCE public.lcimmediateinfo_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.almanac_id_seq              IS '{1,0}';
MAC LABEL ON SEQUENCE public.lcstabledata_id_seq         IS '{1,0}';
MAC LABEL ON SEQUENCE public.navsolution_id_seq          IS '{1,0}';
MAC LABEL ON SEQUENCE public.opmessage_id_seq            IS '{1,0}';
MAC LABEL ON SEQUENCE public.knpopmessage_id_seq         IS '{1,0}';
MAC LABEL ON SEQUENCE public.packet_id_seq               IS '{1,0}';
MAC LABEL ON SEQUENCE public.residual_id_seq             IS '{1,0}';
MAC LABEL ON SEQUENCE public.signal_id_seq               IS '{1,0}';
MAC LABEL ON SEQUENCE public.summarized_frames_info_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.summarized_frame_comparison_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.meteoparameters_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.knpopsummessage_id_seq      IS '{1,0}';
MAC LABEL ON SEQUENCE public.signal_flag_groups_group_id_seq      IS '{1,0}';


-- выдача дискреционных прав
GRANT USAGE  ON                                    SCHEMA public TO PUBLIC;
GRANT SELECT,UPDATE,INSERT,DELETE ON ALL TABLES IN SCHEMA public TO PUBLIC;
