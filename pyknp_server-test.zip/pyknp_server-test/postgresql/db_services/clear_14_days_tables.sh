#!/bin/sh
echo "Временной интервал очистики в днях:${1:-30}"
del=$(date -d "-${1:-30} days" +"%Y-%m-%d %H:%M:%S");

for number in 1 2 3 4 5 6 7 8 9 10 11 12 13 14
do
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.ci_l2ksi WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.ci_l2ksi;" 
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.ci_lc WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.ci_lc;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.ci_lof WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.ci_lof;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.ci_lsf WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.ci_lsf;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.delta_d WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.delta_d;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.izm_1s WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.izm_1s;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.meteo WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.meteo;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.os WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.os;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.rez_kon WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.rez_kon;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.rnz WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.rnz;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.track_failure WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.track_failure;"
psql -d "bis_knp_$number" -c "DELETE FROM dailydata.ts_offset WHERE tr < '$del';" && psql -d "bis_knp_$number" -c  "VACUUM dailydata.ts_offset;"
done && echo "Очистка завершена"
