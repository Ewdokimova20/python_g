#!/bin/sh

export PGPASSFILE=/db_backups/lbd_knp_skzpn/script/pgpass
today=$(date +"%Y_%m_%d");
timenow=$(date +"%H:%M:%S")
LOG=/db_backups/lbd_knp_skzpn/tldb/log/$today

del_time=$(date -d "-7 days" +"%Y-%m-%d %H:%M:%S");
DB_NAME=tlbd

exec $1 >> $LOG

echo "$timenow Service TLDB. Name $DB_NAME. Time from '$del_time'" >>$LOG
echo "Service TLDB. Name $DB_NAME. Time from '$del_time'"

# Функция для выполнения SQL-запросов
execute_sql() {
    psql -h localhost -p 5432 -U postgres -d "$DB_NAME" -c "$1" >> "$LOG"
}

# Массив с именами таблиц, которые чистятся по времени из db_timestamp
tables=(
    "public.almanac"
    "public.control"
    "public.knpnavsolution"
    "public.knpopmessage"
    "public.knpopsummessage"
    "public.l1ocframe"
    "public.l1ocstring"
    "public.l1offrame"
    "public.l1ofstring"
    "public.l1scframe"
    "public.l1scstring"
    "public.l1sfframe"
    "public.l1sfstring"
    "public.l2ksistring"
    "public.l2offrame"
    "public.l2ofstring"
    "public.l2scframe"
    "public.l2scstring"
    "public.l3ocframe"
    "public.l3ocstring"
    "public.lcimmediateinfo"
    "public.lcstabledata"
    "public.meteoparameters"
    "public.navsolution"
    "public.opmessage"
    "public.packet"
    "public.residual"
    "public.summarized_frames_info"
    "public.summarized_frame_comparison"
    "public.signal_flag_groups"
)

# Обработка каждой таблицы из списка tables
for TABLE_NAME in "${tables[@]}"; do
    echo "$TABLE_NAME" >> "$LOG"
    execute_sql "DELETE FROM $TABLE_NAME WHERE db_timestamp < '$del_time';"
    execute_sql "VACUUM $TABLE_NAME;"
done

# Вакумирование таблицы currentangles
TABLE_NAME="public.currentangles"
echo "$TABLE_NAME" >> "$LOG"
execute_sql "VACUUM $TABLE_NAME;"

# Очистка таблицы visibility_zone и её партиций
TABLE_NAME="visibility.visibility_zone"
echo "$TABLE_NAME" >> "$LOG"
execute_sql "DELETE FROM $TABLE_NAME WHERE last_update < '$del_time';"
execute_sql "VACUUM $TABLE_NAME;"

# Очистка таблицы signal отдельно, так как срок хранения данных 12 часов
short_del_time=$(date -d "-12 hours" +"%Y-%m-%d %H:%M:%S");
TABLE_NAME="public.signal"
echo "$TABLE_NAME" >> "$LOG"
execute_sql "DELETE FROM $TABLE_NAME WHERE last_update < '$short_del_time';"
execute_sql "VACUUM $TABLE_NAME;"

echo "Service TLDB complite" >>$LOG
