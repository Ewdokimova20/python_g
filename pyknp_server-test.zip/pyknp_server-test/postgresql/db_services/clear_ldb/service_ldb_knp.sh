#!/bin/sh

export PGPASSFILE=/db_backups/lbd_knp_skzpn/script/pgpass
today=$(date +"%Y_%m_%d");
timenow=$(date +"%H:%M:%S")
LOG=/db_backups/lbd_knp_skzpn/ldb/log/$today

del_time=$(date -d "-60 days" +"%Y-%m-%d %H:%M:%S");

shema="\"DailyData\""

for number in 1 2 3 4 5 6 7 8 9 10 11 12 13 14
do
DB_NAME="bis_knp_$number"
echo "Обслуживание базы $DB_NAME"

TABLE_NAME=ci_l2ksi
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d bis_knp_1 -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d bis_knp_1 -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=ci_lc
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=ci_lof
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=ci_lsf
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=delta_d
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=izm_1s
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=meteo
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=os
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=rez_kon
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=rnz
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=track_failure
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

TABLE_NAME=ts_offset
echo "Clearing $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "DELETE FROM $shema.$TABLE_NAME WHERE t_inform < '$del_time';">>$LOG
echo "Vacuum $DB_NAME $shema.$TABLE_NAME">>$LOG
psql -h localhost -p 5432 --username postgres -w -d $DB_NAME -c "VACUUM $shema.$TABLE_NAME;">>$LOG

done 

echo "Очистка завершена"
