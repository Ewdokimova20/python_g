CREATE SCHEMA IF NOT EXISTS partition AUTHORIZATION knp;
        MAC LABEL ON SCHEMA partition IS '{1,0}';
        MAC CCR ON SCHEMA partition IS OFF;        
        
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_1 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_1 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_2 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_2 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_3 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_3 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_4 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_4 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_5 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_5 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_6 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_6 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_7 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_7 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_8 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_8 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_9 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_9 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_10 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_10 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_11 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_11 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_12 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_12 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_13 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_13 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_14 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_14 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_15 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_15 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_16 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_16 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_17 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_17 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_18 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_18 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_19 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_19 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_20 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_20 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_21 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_21 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_22 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_22 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_23 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_23 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_24 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_24 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_25 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_25 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_26 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_26 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_27 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_27 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_28 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_28 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_29 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_29 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_30 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_30 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_31 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_31 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_32 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_32 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_33 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_33 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_34 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_34 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_35 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_35 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_36 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_36 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_37 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_37 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_38 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_38 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_39 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_39 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_40 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_40 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_41 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_41 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_42 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_42 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_43 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_43 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_44 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_44 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1offrame_bis_45 ( LIKE l1offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1offrame_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1offrame_bis_45 inherit l1offrame;
        ALTER TABLE partition.l1offrame_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1offrame_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1offrame_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1offrame_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1offrame_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1offrame_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1offrame_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1offrame_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1offrame_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1offrame_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1offrame_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1offrame_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1offrame_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1offrame_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1offrame_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1offrame_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1offrame_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1offrame_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1offrame_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1offrame_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1offrame_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1offrame_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1offrame_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1offrame_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1offrame_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1offrame_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1offrame_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1offrame_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1offrame_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1offrame_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1offrame_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1offrame_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1offrame_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1offrame_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1offrame_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1offrame_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1offrame_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1offrame_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1offrame_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1offrame_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1offrame_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1offrame_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1offrame_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1offrame_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1offrame_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1offrame_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1offrame_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1offrame_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1offrame_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1offrame WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1offrame    
            AFTER INSERT ON l1offrame
            FOR EACH ROW EXECUTE PROCEDURE l1offrame_insert_trigger();   
        MAC LABEL ON FUNCTION l1offrame_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_1 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_1 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_2 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_2 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_3 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_3 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_4 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_4 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_5 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_5 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_6 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_6 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_7 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_7 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_8 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_8 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_9 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_9 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_10 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_10 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_11 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_11 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_12 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_12 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_13 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_13 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_14 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_14 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_15 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_15 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_16 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_16 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_17 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_17 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_18 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_18 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_19 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_19 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_20 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_20 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_21 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_21 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_22 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_22 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_23 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_23 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_24 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_24 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_25 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_25 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_26 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_26 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_27 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_27 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_28 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_28 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_29 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_29 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_30 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_30 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_31 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_31 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_32 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_32 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_33 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_33 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_34 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_34 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_35 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_35 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_36 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_36 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_37 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_37 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_38 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_38 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_39 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_39 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_40 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_40 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_41 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_41 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_42 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_42 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_43 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_43 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_44 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_44 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2offrame_bis_45 ( LIKE l2offrame including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2offrame_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2offrame_bis_45 inherit l2offrame;
        ALTER TABLE partition.l2offrame_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2offrame_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l2offrame_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l2offrame_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l2offrame_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l2offrame_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l2offrame_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l2offrame_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l2offrame_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l2offrame_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l2offrame_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l2offrame_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l2offrame_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l2offrame_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l2offrame_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l2offrame_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l2offrame_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l2offrame_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l2offrame_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l2offrame_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l2offrame_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l2offrame_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l2offrame_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l2offrame_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l2offrame_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l2offrame_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l2offrame_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l2offrame_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l2offrame_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l2offrame_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l2offrame_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l2offrame_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l2offrame_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l2offrame_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l2offrame_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l2offrame_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l2offrame_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l2offrame_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l2offrame_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l2offrame_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l2offrame_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l2offrame_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l2offrame_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l2offrame_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l2offrame_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l2offrame_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l2offrame_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l2offrame_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l2offrame_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l2offrame WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l2offrame    
            AFTER INSERT ON l2offrame
            FOR EACH ROW EXECUTE PROCEDURE l2offrame_insert_trigger();   
        MAC LABEL ON FUNCTION l2offrame_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_1 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_1 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_2 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_2 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_3 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_3 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_4 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_4 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_5 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_5 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_6 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_6 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_7 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_7 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_8 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_8 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_9 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_9 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_10 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_10 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_11 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_11 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_12 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_12 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_13 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_13 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_14 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_14 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_15 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_15 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_16 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_16 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_17 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_17 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_18 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_18 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_19 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_19 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_20 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_20 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_21 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_21 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_22 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_22 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_23 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_23 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_24 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_24 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_25 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_25 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_26 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_26 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_27 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_27 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_28 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_28 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_29 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_29 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_30 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_30 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_31 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_31 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_32 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_32 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_33 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_33 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_34 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_34 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_35 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_35 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_36 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_36 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_37 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_37 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_38 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_38 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_39 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_39 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_40 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_40 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_41 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_41 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_42 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_42 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_43 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_43 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_44 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_44 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfframe_bis_45 ( LIKE l1sfframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfframe_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfframe_bis_45 inherit l1sfframe;
        ALTER TABLE partition.l1sfframe_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfframe_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfframe_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1sfframe_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1sfframe_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1sfframe_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1sfframe_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1sfframe_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1sfframe_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1sfframe_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1sfframe_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1sfframe_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1sfframe_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1sfframe_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1sfframe_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1sfframe_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1sfframe_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1sfframe_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1sfframe_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1sfframe_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1sfframe_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1sfframe_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1sfframe_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1sfframe_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1sfframe_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1sfframe_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1sfframe_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1sfframe_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1sfframe_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1sfframe_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1sfframe_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1sfframe_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1sfframe_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1sfframe_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1sfframe_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1sfframe_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1sfframe_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1sfframe_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1sfframe_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1sfframe_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1sfframe_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1sfframe_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1sfframe_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1sfframe_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1sfframe_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1sfframe_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1sfframe_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1sfframe_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1sfframe_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1sfframe WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1sfframe    
            AFTER INSERT ON l1sfframe
            FOR EACH ROW EXECUTE PROCEDURE l1sfframe_insert_trigger();   
        MAC LABEL ON FUNCTION l1sfframe_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_1 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_1 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_2 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_2 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_3 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_3 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_4 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_4 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_5 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_5 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_6 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_6 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_7 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_7 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_8 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_8 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_9 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_9 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_10 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_10 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_11 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_11 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_12 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_12 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_13 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_13 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_14 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_14 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_15 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_15 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_16 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_16 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_17 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_17 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_18 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_18 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_19 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_19 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_20 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_20 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_21 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_21 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_22 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_22 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_23 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_23 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_24 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_24 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_25 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_25 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_26 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_26 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_27 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_27 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_28 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_28 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_29 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_29 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_30 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_30 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_31 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_31 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_32 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_32 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_33 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_33 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_34 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_34 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_35 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_35 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_36 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_36 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_37 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_37 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_38 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_38 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_39 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_39 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_40 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_40 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_41 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_41 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_42 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_42 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_43 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_43 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_44 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_44 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocstring_bis_45 ( LIKE l1ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocstring_bis_45 inherit l1ocstring;
        ALTER TABLE partition.l1ocstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1ocstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1ocstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1ocstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1ocstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1ocstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1ocstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1ocstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1ocstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1ocstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1ocstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1ocstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1ocstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1ocstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1ocstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1ocstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1ocstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1ocstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1ocstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1ocstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1ocstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1ocstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1ocstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1ocstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1ocstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1ocstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1ocstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1ocstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1ocstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1ocstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1ocstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1ocstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1ocstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1ocstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1ocstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1ocstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1ocstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1ocstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1ocstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1ocstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1ocstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1ocstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1ocstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1ocstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1ocstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1ocstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1ocstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1ocstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1ocstring    
            AFTER INSERT ON l1ocstring
            FOR EACH ROW EXECUTE PROCEDURE l1ocstring_insert_trigger();   
        MAC LABEL ON FUNCTION l1ocstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_1 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_1 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_2 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_2 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_3 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_3 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_4 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_4 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_5 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_5 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_6 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_6 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_7 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_7 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_8 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_8 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_9 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_9 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_10 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_10 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_11 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_11 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_12 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_12 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_13 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_13 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_14 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_14 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_15 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_15 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_16 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_16 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_17 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_17 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_18 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_18 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_19 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_19 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_20 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_20 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_21 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_21 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_22 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_22 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_23 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_23 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_24 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_24 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_25 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_25 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_26 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_26 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_27 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_27 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_28 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_28 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_29 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_29 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_30 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_30 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_31 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_31 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_32 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_32 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_33 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_33 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_34 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_34 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_35 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_35 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_36 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_36 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_37 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_37 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_38 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_38 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_39 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_39 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_40 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_40 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_41 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_41 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_42 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_42 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_43 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_43 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_44 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_44 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocstring_bis_45 ( LIKE l3ocstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocstring_bis_45 inherit l3ocstring;
        ALTER TABLE partition.l3ocstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l3ocstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l3ocstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l3ocstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l3ocstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l3ocstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l3ocstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l3ocstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l3ocstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l3ocstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l3ocstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l3ocstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l3ocstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l3ocstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l3ocstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l3ocstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l3ocstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l3ocstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l3ocstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l3ocstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l3ocstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l3ocstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l3ocstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l3ocstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l3ocstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l3ocstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l3ocstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l3ocstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l3ocstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l3ocstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l3ocstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l3ocstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l3ocstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l3ocstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l3ocstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l3ocstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l3ocstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l3ocstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l3ocstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l3ocstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l3ocstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l3ocstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l3ocstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l3ocstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l3ocstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l3ocstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l3ocstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l3ocstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l3ocstring    
            AFTER INSERT ON l3ocstring
            FOR EACH ROW EXECUTE PROCEDURE l3ocstring_insert_trigger();   
        MAC LABEL ON FUNCTION l3ocstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_1 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_1 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_2 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_2 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_3 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_3 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_4 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_4 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_5 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_5 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_6 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_6 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_7 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_7 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_8 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_8 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_9 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_9 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_10 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_10 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_11 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_11 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_12 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_12 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_13 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_13 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_14 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_14 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_15 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_15 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_16 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_16 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_17 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_17 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_18 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_18 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_19 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_19 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_20 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_20 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_21 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_21 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_22 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_22 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_23 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_23 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_24 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_24 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_25 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_25 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_26 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_26 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_27 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_27 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_28 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_28 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_29 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_29 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_30 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_30 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_31 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_31 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_32 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_32 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_33 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_33 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_34 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_34 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_35 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_35 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_36 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_36 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_37 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_37 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_38 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_38 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_39 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_39 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_40 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_40 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_41 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_41 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_42 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_42 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_43 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_43 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_44 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_44 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scstring_bis_45 ( LIKE l1scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scstring_bis_45 inherit l1scstring;
        ALTER TABLE partition.l1scstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1scstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1scstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1scstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1scstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1scstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1scstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1scstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1scstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1scstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1scstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1scstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1scstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1scstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1scstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1scstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1scstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1scstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1scstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1scstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1scstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1scstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1scstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1scstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1scstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1scstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1scstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1scstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1scstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1scstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1scstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1scstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1scstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1scstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1scstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1scstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1scstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1scstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1scstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1scstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1scstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1scstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1scstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1scstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1scstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1scstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1scstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1scstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1scstring    
            AFTER INSERT ON l1scstring
            FOR EACH ROW EXECUTE PROCEDURE l1scstring_insert_trigger();   
        MAC LABEL ON FUNCTION l1scstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_1 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_1 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_2 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_2 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_3 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_3 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_4 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_4 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_5 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_5 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_6 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_6 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_7 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_7 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_8 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_8 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_9 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_9 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_10 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_10 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_11 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_11 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_12 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_12 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_13 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_13 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_14 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_14 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_15 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_15 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_16 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_16 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_17 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_17 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_18 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_18 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_19 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_19 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_20 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_20 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_21 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_21 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_22 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_22 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_23 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_23 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_24 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_24 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_25 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_25 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_26 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_26 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_27 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_27 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_28 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_28 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_29 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_29 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_30 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_30 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_31 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_31 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_32 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_32 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_33 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_33 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_34 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_34 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_35 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_35 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_36 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_36 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_37 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_37 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_38 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_38 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_39 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_39 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_40 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_40 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_41 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_41 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_42 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_42 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_43 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_43 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_44 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_44 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scstring_bis_45 ( LIKE l2scstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scstring_bis_45 inherit l2scstring;
        ALTER TABLE partition.l2scstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l2scstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l2scstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l2scstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l2scstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l2scstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l2scstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l2scstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l2scstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l2scstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l2scstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l2scstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l2scstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l2scstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l2scstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l2scstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l2scstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l2scstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l2scstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l2scstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l2scstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l2scstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l2scstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l2scstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l2scstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l2scstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l2scstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l2scstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l2scstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l2scstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l2scstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l2scstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l2scstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l2scstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l2scstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l2scstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l2scstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l2scstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l2scstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l2scstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l2scstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l2scstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l2scstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l2scstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l2scstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l2scstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l2scstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l2scstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l2scstring    
            AFTER INSERT ON l2scstring
            FOR EACH ROW EXECUTE PROCEDURE l2scstring_insert_trigger();   
        MAC LABEL ON FUNCTION l2scstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_1 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_1 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_2 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_2 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_3 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_3 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_4 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_4 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_5 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_5 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_6 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_6 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_7 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_7 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_8 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_8 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_9 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_9 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_10 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_10 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_11 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_11 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_12 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_12 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_13 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_13 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_14 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_14 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_15 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_15 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_16 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_16 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_17 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_17 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_18 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_18 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_19 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_19 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_20 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_20 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_21 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_21 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_22 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_22 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_23 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_23 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_24 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_24 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_25 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_25 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_26 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_26 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_27 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_27 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_28 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_28 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_29 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_29 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_30 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_30 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_31 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_31 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_32 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_32 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_33 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_33 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_34 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_34 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_35 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_35 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_36 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_36 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_37 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_37 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_38 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_38 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_39 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_39 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_40 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_40 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_41 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_41 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_42 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_42 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_43 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_43 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_44 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_44 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ocframe_bis_45 ( LIKE l1ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ocframe_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ocframe_bis_45 inherit l1ocframe;
        ALTER TABLE partition.l1ocframe_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ocframe_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ocframe_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1ocframe_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1ocframe_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1ocframe_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1ocframe_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1ocframe_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1ocframe_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1ocframe_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1ocframe_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1ocframe_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1ocframe_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1ocframe_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1ocframe_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1ocframe_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1ocframe_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1ocframe_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1ocframe_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1ocframe_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1ocframe_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1ocframe_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1ocframe_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1ocframe_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1ocframe_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1ocframe_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1ocframe_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1ocframe_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1ocframe_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1ocframe_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1ocframe_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1ocframe_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1ocframe_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1ocframe_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1ocframe_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1ocframe_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1ocframe_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1ocframe_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1ocframe_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1ocframe_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1ocframe_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1ocframe_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1ocframe_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1ocframe_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1ocframe_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1ocframe_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1ocframe_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1ocframe_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1ocframe_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1ocframe WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1ocframe    
            AFTER INSERT ON l1ocframe
            FOR EACH ROW EXECUTE PROCEDURE l1ocframe_insert_trigger();   
        MAC LABEL ON FUNCTION l1ocframe_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_1 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_1 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_2 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_2 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_3 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_3 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_4 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_4 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_5 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_5 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_6 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_6 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_7 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_7 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_8 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_8 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_9 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_9 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_10 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_10 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_11 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_11 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_12 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_12 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_13 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_13 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_14 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_14 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_15 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_15 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_16 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_16 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_17 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_17 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_18 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_18 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_19 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_19 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_20 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_20 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_21 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_21 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_22 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_22 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_23 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_23 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_24 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_24 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_25 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_25 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_26 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_26 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_27 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_27 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_28 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_28 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_29 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_29 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_30 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_30 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_31 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_31 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_32 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_32 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_33 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_33 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_34 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_34 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_35 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_35 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_36 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_36 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_37 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_37 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_38 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_38 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_39 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_39 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_40 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_40 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_41 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_41 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_42 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_42 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_43 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_43 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_44 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_44 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l3ocframe_bis_45 ( LIKE l3ocframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l3ocframe_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l3ocframe_bis_45 inherit l3ocframe;
        ALTER TABLE partition.l3ocframe_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l3ocframe_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l3ocframe_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l3ocframe_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l3ocframe_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l3ocframe_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l3ocframe_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l3ocframe_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l3ocframe_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l3ocframe_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l3ocframe_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l3ocframe_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l3ocframe_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l3ocframe_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l3ocframe_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l3ocframe_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l3ocframe_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l3ocframe_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l3ocframe_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l3ocframe_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l3ocframe_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l3ocframe_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l3ocframe_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l3ocframe_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l3ocframe_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l3ocframe_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l3ocframe_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l3ocframe_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l3ocframe_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l3ocframe_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l3ocframe_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l3ocframe_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l3ocframe_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l3ocframe_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l3ocframe_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l3ocframe_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l3ocframe_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l3ocframe_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l3ocframe_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l3ocframe_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l3ocframe_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l3ocframe_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l3ocframe_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l3ocframe_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l3ocframe_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l3ocframe_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l3ocframe_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l3ocframe_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l3ocframe_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l3ocframe WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l3ocframe    
            AFTER INSERT ON l3ocframe
            FOR EACH ROW EXECUTE PROCEDURE l3ocframe_insert_trigger();   
        MAC LABEL ON FUNCTION l3ocframe_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_1 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_1 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_2 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_2 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_3 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_3 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_4 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_4 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_5 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_5 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_6 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_6 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_7 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_7 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_8 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_8 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_9 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_9 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_10 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_10 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_11 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_11 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_12 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_12 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_13 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_13 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_14 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_14 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_15 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_15 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_16 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_16 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_17 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_17 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_18 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_18 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_19 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_19 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_20 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_20 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_21 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_21 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_22 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_22 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_23 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_23 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_24 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_24 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_25 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_25 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_26 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_26 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_27 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_27 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_28 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_28 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_29 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_29 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_30 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_30 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_31 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_31 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_32 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_32 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_33 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_33 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_34 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_34 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_35 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_35 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_36 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_36 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_37 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_37 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_38 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_38 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_39 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_39 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_40 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_40 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_41 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_41 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_42 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_42 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_43 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_43 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_44 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_44 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1scframe_bis_45 ( LIKE l1scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1scframe_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1scframe_bis_45 inherit l1scframe;
        ALTER TABLE partition.l1scframe_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1scframe_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1scframe_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1scframe_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1scframe_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1scframe_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1scframe_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1scframe_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1scframe_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1scframe_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1scframe_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1scframe_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1scframe_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1scframe_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1scframe_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1scframe_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1scframe_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1scframe_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1scframe_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1scframe_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1scframe_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1scframe_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1scframe_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1scframe_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1scframe_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1scframe_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1scframe_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1scframe_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1scframe_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1scframe_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1scframe_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1scframe_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1scframe_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1scframe_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1scframe_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1scframe_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1scframe_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1scframe_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1scframe_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1scframe_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1scframe_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1scframe_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1scframe_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1scframe_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1scframe_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1scframe_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1scframe_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1scframe_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1scframe_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1scframe WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1scframe    
            AFTER INSERT ON l1scframe
            FOR EACH ROW EXECUTE PROCEDURE l1scframe_insert_trigger();   
        MAC LABEL ON FUNCTION l1scframe_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_1 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_1 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_2 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_2 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_3 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_3 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_4 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_4 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_5 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_5 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_6 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_6 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_7 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_7 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_8 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_8 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_9 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_9 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_10 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_10 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_11 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_11 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_12 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_12 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_13 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_13 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_14 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_14 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_15 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_15 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_16 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_16 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_17 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_17 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_18 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_18 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_19 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_19 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_20 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_20 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_21 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_21 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_22 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_22 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_23 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_23 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_24 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_24 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_25 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_25 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_26 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_26 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_27 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_27 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_28 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_28 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_29 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_29 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_30 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_30 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_31 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_31 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_32 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_32 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_33 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_33 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_34 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_34 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_35 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_35 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_36 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_36 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_37 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_37 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_38 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_38 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_39 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_39 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_40 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_40 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_41 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_41 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_42 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_42 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_43 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_43 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_44 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_44 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2scframe_bis_45 ( LIKE l2scframe including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2scframe_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2scframe_bis_45 inherit l2scframe;
        ALTER TABLE partition.l2scframe_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2scframe_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l2scframe_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l2scframe_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l2scframe_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l2scframe_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l2scframe_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l2scframe_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l2scframe_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l2scframe_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l2scframe_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l2scframe_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l2scframe_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l2scframe_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l2scframe_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l2scframe_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l2scframe_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l2scframe_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l2scframe_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l2scframe_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l2scframe_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l2scframe_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l2scframe_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l2scframe_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l2scframe_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l2scframe_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l2scframe_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l2scframe_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l2scframe_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l2scframe_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l2scframe_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l2scframe_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l2scframe_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l2scframe_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l2scframe_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l2scframe_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l2scframe_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l2scframe_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l2scframe_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l2scframe_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l2scframe_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l2scframe_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l2scframe_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l2scframe_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l2scframe_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l2scframe_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l2scframe_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l2scframe_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l2scframe_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l2scframe WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l2scframe    
            AFTER INSERT ON l2scframe
            FOR EACH ROW EXECUTE PROCEDURE l2scframe_insert_trigger();   
        MAC LABEL ON FUNCTION l2scframe_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_1 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_1 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_2 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_2 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_3 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_3 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_4 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_4 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_5 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_5 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_6 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_6 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_7 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_7 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_8 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_8 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_9 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_9 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_10 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_10 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_11 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_11 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_12 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_12 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_13 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_13 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_14 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_14 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_15 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_15 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_16 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_16 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_17 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_17 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_18 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_18 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_19 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_19 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_20 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_20 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_21 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_21 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_22 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_22 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_23 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_23 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_24 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_24 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_25 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_25 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_26 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_26 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_27 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_27 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_28 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_28 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_29 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_29 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_30 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_30 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_31 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_31 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_32 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_32 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_33 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_33 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_34 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_34 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_35 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_35 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_36 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_36 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_37 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_37 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_38 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_38 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_39 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_39 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_40 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_40 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_41 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_41 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_42 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_42 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_43 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_43 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_44 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_44 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1ofstring_bis_45 ( LIKE l1ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1ofstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1ofstring_bis_45 inherit l1ofstring;
        ALTER TABLE partition.l1ofstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1ofstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1ofstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1ofstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1ofstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1ofstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1ofstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1ofstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1ofstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1ofstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1ofstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1ofstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1ofstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1ofstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1ofstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1ofstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1ofstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1ofstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1ofstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1ofstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1ofstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1ofstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1ofstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1ofstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1ofstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1ofstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1ofstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1ofstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1ofstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1ofstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1ofstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1ofstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1ofstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1ofstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1ofstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1ofstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1ofstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1ofstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1ofstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1ofstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1ofstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1ofstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1ofstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1ofstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1ofstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1ofstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1ofstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1ofstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1ofstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1ofstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1ofstring    
            AFTER INSERT ON l1ofstring
            FOR EACH ROW EXECUTE PROCEDURE l1ofstring_insert_trigger();   
        MAC LABEL ON FUNCTION l1ofstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_1 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_1 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_2 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_2 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_3 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_3 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_4 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_4 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_5 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_5 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_6 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_6 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_7 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_7 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_8 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_8 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_9 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_9 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_10 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_10 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_11 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_11 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_12 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_12 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_13 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_13 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_14 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_14 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_15 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_15 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_16 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_16 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_17 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_17 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_18 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_18 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_19 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_19 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_20 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_20 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_21 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_21 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_22 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_22 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_23 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_23 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_24 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_24 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_25 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_25 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_26 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_26 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_27 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_27 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_28 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_28 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_29 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_29 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_30 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_30 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_31 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_31 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_32 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_32 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_33 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_33 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_34 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_34 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_35 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_35 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_36 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_36 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_37 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_37 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_38 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_38 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_39 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_39 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_40 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_40 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_41 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_41 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_42 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_42 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_43 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_43 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_44 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_44 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l2ofstring_bis_45 ( LIKE l2ofstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l2ofstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l2ofstring_bis_45 inherit l2ofstring;
        ALTER TABLE partition.l2ofstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l2ofstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l2ofstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l2ofstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l2ofstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l2ofstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l2ofstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l2ofstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l2ofstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l2ofstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l2ofstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l2ofstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l2ofstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l2ofstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l2ofstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l2ofstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l2ofstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l2ofstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l2ofstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l2ofstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l2ofstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l2ofstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l2ofstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l2ofstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l2ofstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l2ofstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l2ofstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l2ofstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l2ofstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l2ofstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l2ofstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l2ofstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l2ofstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l2ofstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l2ofstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l2ofstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l2ofstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l2ofstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l2ofstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l2ofstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l2ofstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l2ofstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l2ofstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l2ofstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l2ofstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l2ofstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l2ofstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l2ofstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l2ofstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l2ofstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l2ofstring    
            AFTER INSERT ON l2ofstring
            FOR EACH ROW EXECUTE PROCEDURE l2ofstring_insert_trigger();   
        MAC LABEL ON FUNCTION l2ofstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_1 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_1 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_2 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_2 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_3 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_3 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_4 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_4 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_5 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_5 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_6 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_6 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_7 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_7 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_8 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_8 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_9 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_9 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_10 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_10 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_11 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_11 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_12 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_12 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_13 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_13 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_14 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_14 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_15 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_15 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_16 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_16 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_17 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_17 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_18 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_18 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_19 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_19 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_20 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_20 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_21 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_21 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_22 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_22 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_23 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_23 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_24 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_24 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_25 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_25 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_26 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_26 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_27 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_27 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_28 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_28 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_29 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_29 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_30 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_30 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_31 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_31 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_32 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_32 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_33 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_33 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_34 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_34 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_35 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_35 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_36 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_36 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_37 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_37 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_38 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_38 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_39 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_39 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_40 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_40 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_41 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_41 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_42 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_42 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_43 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_43 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_44 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_44 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.l1sfstring_bis_45 ( LIKE l1sfstring including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.l1sfstring_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.l1sfstring_bis_45 inherit l1sfstring;
        ALTER TABLE partition.l1sfstring_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.l1sfstring_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.l1sfstring_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            l1sfstring_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.l1sfstring_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.l1sfstring_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.l1sfstring_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.l1sfstring_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.l1sfstring_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.l1sfstring_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.l1sfstring_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.l1sfstring_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.l1sfstring_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.l1sfstring_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.l1sfstring_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.l1sfstring_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.l1sfstring_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.l1sfstring_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.l1sfstring_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.l1sfstring_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.l1sfstring_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.l1sfstring_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.l1sfstring_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.l1sfstring_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.l1sfstring_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.l1sfstring_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.l1sfstring_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.l1sfstring_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.l1sfstring_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.l1sfstring_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.l1sfstring_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.l1sfstring_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.l1sfstring_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.l1sfstring_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.l1sfstring_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.l1sfstring_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.l1sfstring_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.l1sfstring_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.l1sfstring_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.l1sfstring_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.l1sfstring_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.l1sfstring_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.l1sfstring_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.l1sfstring_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.l1sfstring_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.l1sfstring_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.l1sfstring_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.l1sfstring_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.l1sfstring_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY l1sfstring WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_l1sfstring    
            AFTER INSERT ON l1sfstring
            FOR EACH ROW EXECUTE PROCEDURE l1sfstring_insert_trigger();   
        MAC LABEL ON FUNCTION l1sfstring_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_1 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_1 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_2 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_2 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_3 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_3 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_4 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_4 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_5 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_5 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_6 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_6 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_7 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_7 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_8 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_8 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_9 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_9 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_10 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_10 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_11 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_11 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_12 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_12 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_13 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_13 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_14 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_14 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_15 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_15 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_16 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_16 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_17 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_17 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_18 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_18 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_19 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_19 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_20 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_20 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_21 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_21 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_22 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_22 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_23 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_23 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_24 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_24 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_25 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_25 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_26 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_26 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_27 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_27 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_28 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_28 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_29 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_29 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_30 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_30 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_31 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_31 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_32 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_32 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_33 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_33 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_34 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_34 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_35 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_35 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_36 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_36 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_37 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_37 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_38 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_38 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_39 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_39 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_40 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_40 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_41 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_41 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_42 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_42 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_43 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_43 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_44 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_44 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.opmessage_bis_45 ( LIKE opmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.opmessage_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.opmessage_bis_45 inherit opmessage;
        ALTER TABLE partition.opmessage_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.opmessage_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.opmessage_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            opmessage_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.opmessage_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.opmessage_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.opmessage_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.opmessage_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.opmessage_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.opmessage_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.opmessage_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.opmessage_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.opmessage_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.opmessage_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.opmessage_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.opmessage_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.opmessage_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.opmessage_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.opmessage_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.opmessage_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.opmessage_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.opmessage_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.opmessage_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.opmessage_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.opmessage_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.opmessage_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.opmessage_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.opmessage_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.opmessage_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.opmessage_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.opmessage_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.opmessage_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.opmessage_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.opmessage_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.opmessage_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.opmessage_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.opmessage_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.opmessage_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.opmessage_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.opmessage_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.opmessage_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.opmessage_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.opmessage_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.opmessage_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.opmessage_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.opmessage_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.opmessage_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.opmessage_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.opmessage_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY opmessage WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_opmessage    
            AFTER INSERT ON opmessage
            FOR EACH ROW EXECUTE PROCEDURE opmessage_insert_trigger();   
        MAC LABEL ON FUNCTION opmessage_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.residual_bis_1 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_1 inherit residual;
        ALTER TABLE partition.residual_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_2 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_2 inherit residual;
        ALTER TABLE partition.residual_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_3 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_3 inherit residual;
        ALTER TABLE partition.residual_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_4 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_4 inherit residual;
        ALTER TABLE partition.residual_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_5 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_5 inherit residual;
        ALTER TABLE partition.residual_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_6 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_6 inherit residual;
        ALTER TABLE partition.residual_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_7 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_7 inherit residual;
        ALTER TABLE partition.residual_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_8 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_8 inherit residual;
        ALTER TABLE partition.residual_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_9 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_9 inherit residual;
        ALTER TABLE partition.residual_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_10 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_10 inherit residual;
        ALTER TABLE partition.residual_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_11 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_11 inherit residual;
        ALTER TABLE partition.residual_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_12 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_12 inherit residual;
        ALTER TABLE partition.residual_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_13 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_13 inherit residual;
        ALTER TABLE partition.residual_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_14 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_14 inherit residual;
        ALTER TABLE partition.residual_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_15 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_15 inherit residual;
        ALTER TABLE partition.residual_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_16 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_16 inherit residual;
        ALTER TABLE partition.residual_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_17 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_17 inherit residual;
        ALTER TABLE partition.residual_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_18 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_18 inherit residual;
        ALTER TABLE partition.residual_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_19 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_19 inherit residual;
        ALTER TABLE partition.residual_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_20 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_20 inherit residual;
        ALTER TABLE partition.residual_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_21 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_21 inherit residual;
        ALTER TABLE partition.residual_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_22 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_22 inherit residual;
        ALTER TABLE partition.residual_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_23 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_23 inherit residual;
        ALTER TABLE partition.residual_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_24 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_24 inherit residual;
        ALTER TABLE partition.residual_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_25 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_25 inherit residual;
        ALTER TABLE partition.residual_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_26 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_26 inherit residual;
        ALTER TABLE partition.residual_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_27 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_27 inherit residual;
        ALTER TABLE partition.residual_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_28 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_28 inherit residual;
        ALTER TABLE partition.residual_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_29 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_29 inherit residual;
        ALTER TABLE partition.residual_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_30 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_30 inherit residual;
        ALTER TABLE partition.residual_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_31 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_31 inherit residual;
        ALTER TABLE partition.residual_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_32 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_32 inherit residual;
        ALTER TABLE partition.residual_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_33 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_33 inherit residual;
        ALTER TABLE partition.residual_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_34 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_34 inherit residual;
        ALTER TABLE partition.residual_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_35 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_35 inherit residual;
        ALTER TABLE partition.residual_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_36 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_36 inherit residual;
        ALTER TABLE partition.residual_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_37 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_37 inherit residual;
        ALTER TABLE partition.residual_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_38 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_38 inherit residual;
        ALTER TABLE partition.residual_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_39 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_39 inherit residual;
        ALTER TABLE partition.residual_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_40 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_40 inherit residual;
        ALTER TABLE partition.residual_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_41 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_41 inherit residual;
        ALTER TABLE partition.residual_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_42 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_42 inherit residual;
        ALTER TABLE partition.residual_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_43 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_43 inherit residual;
        ALTER TABLE partition.residual_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_44 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_44 inherit residual;
        ALTER TABLE partition.residual_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.residual_bis_45 ( LIKE residual including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.residual_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.residual_bis_45 inherit residual;
        ALTER TABLE partition.residual_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.residual_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.residual_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            residual_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.residual_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.residual_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.residual_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.residual_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.residual_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.residual_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.residual_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.residual_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.residual_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.residual_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.residual_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.residual_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.residual_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.residual_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.residual_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.residual_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.residual_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.residual_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.residual_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.residual_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.residual_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.residual_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.residual_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.residual_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.residual_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.residual_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.residual_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.residual_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.residual_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.residual_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.residual_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.residual_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.residual_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.residual_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.residual_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.residual_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.residual_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.residual_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.residual_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.residual_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.residual_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.residual_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.residual_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.residual_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.residual_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY residual WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_residual    
            AFTER INSERT ON residual
            FOR EACH ROW EXECUTE PROCEDURE residual_insert_trigger();   
        MAC LABEL ON FUNCTION residual_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.signal_bis_1 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_1 inherit signal;
        ALTER TABLE partition.signal_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_2 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_2 inherit signal;
        ALTER TABLE partition.signal_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_3 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_3 inherit signal;
        ALTER TABLE partition.signal_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_4 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_4 inherit signal;
        ALTER TABLE partition.signal_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_5 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_5 inherit signal;
        ALTER TABLE partition.signal_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_6 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_6 inherit signal;
        ALTER TABLE partition.signal_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_7 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_7 inherit signal;
        ALTER TABLE partition.signal_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_8 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_8 inherit signal;
        ALTER TABLE partition.signal_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_9 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_9 inherit signal;
        ALTER TABLE partition.signal_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_10 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_10 inherit signal;
        ALTER TABLE partition.signal_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_11 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_11 inherit signal;
        ALTER TABLE partition.signal_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_12 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_12 inherit signal;
        ALTER TABLE partition.signal_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_13 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_13 inherit signal;
        ALTER TABLE partition.signal_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_14 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_14 inherit signal;
        ALTER TABLE partition.signal_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_15 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_15 inherit signal;
        ALTER TABLE partition.signal_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_16 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_16 inherit signal;
        ALTER TABLE partition.signal_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_17 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_17 inherit signal;
        ALTER TABLE partition.signal_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_18 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_18 inherit signal;
        ALTER TABLE partition.signal_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_19 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_19 inherit signal;
        ALTER TABLE partition.signal_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_20 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_20 inherit signal;
        ALTER TABLE partition.signal_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_21 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_21 inherit signal;
        ALTER TABLE partition.signal_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_22 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_22 inherit signal;
        ALTER TABLE partition.signal_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_23 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_23 inherit signal;
        ALTER TABLE partition.signal_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_24 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_24 inherit signal;
        ALTER TABLE partition.signal_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_25 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_25 inherit signal;
        ALTER TABLE partition.signal_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_26 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_26 inherit signal;
        ALTER TABLE partition.signal_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_27 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_27 inherit signal;
        ALTER TABLE partition.signal_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_28 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_28 inherit signal;
        ALTER TABLE partition.signal_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_29 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_29 inherit signal;
        ALTER TABLE partition.signal_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_30 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_30 inherit signal;
        ALTER TABLE partition.signal_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_31 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_31 inherit signal;
        ALTER TABLE partition.signal_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_32 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_32 inherit signal;
        ALTER TABLE partition.signal_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_33 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_33 inherit signal;
        ALTER TABLE partition.signal_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_34 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_34 inherit signal;
        ALTER TABLE partition.signal_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_35 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_35 inherit signal;
        ALTER TABLE partition.signal_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_36 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_36 inherit signal;
        ALTER TABLE partition.signal_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_37 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_37 inherit signal;
        ALTER TABLE partition.signal_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_38 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_38 inherit signal;
        ALTER TABLE partition.signal_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_39 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_39 inherit signal;
        ALTER TABLE partition.signal_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_40 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_40 inherit signal;
        ALTER TABLE partition.signal_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_41 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_41 inherit signal;
        ALTER TABLE partition.signal_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_42 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_42 inherit signal;
        ALTER TABLE partition.signal_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_43 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_43 inherit signal;
        ALTER TABLE partition.signal_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_44 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_44 inherit signal;
        ALTER TABLE partition.signal_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.signal_bis_45 ( LIKE signal including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.signal_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.signal_bis_45 inherit signal;
        ALTER TABLE partition.signal_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.signal_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.signal_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            signal_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.signal_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.signal_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.signal_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.signal_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.signal_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.signal_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.signal_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.signal_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.signal_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.signal_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.signal_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.signal_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.signal_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.signal_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.signal_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.signal_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.signal_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.signal_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.signal_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.signal_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.signal_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.signal_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.signal_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.signal_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.signal_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.signal_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.signal_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.signal_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.signal_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.signal_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.signal_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.signal_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.signal_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.signal_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.signal_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.signal_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.signal_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.signal_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.signal_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.signal_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.signal_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.signal_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.signal_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.signal_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.signal_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY signal WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_signal    
            AFTER INSERT ON signal
            FOR EACH ROW EXECUTE PROCEDURE signal_insert_trigger();   
        MAC LABEL ON FUNCTION signal_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.control_bis_1 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_1 inherit control;
        ALTER TABLE partition.control_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_2 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_2 inherit control;
        ALTER TABLE partition.control_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_3 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_3 inherit control;
        ALTER TABLE partition.control_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_4 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_4 inherit control;
        ALTER TABLE partition.control_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_5 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_5 inherit control;
        ALTER TABLE partition.control_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_6 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_6 inherit control;
        ALTER TABLE partition.control_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_7 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_7 inherit control;
        ALTER TABLE partition.control_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_8 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_8 inherit control;
        ALTER TABLE partition.control_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_9 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_9 inherit control;
        ALTER TABLE partition.control_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_10 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_10 inherit control;
        ALTER TABLE partition.control_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_11 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_11 inherit control;
        ALTER TABLE partition.control_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_12 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_12 inherit control;
        ALTER TABLE partition.control_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_13 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_13 inherit control;
        ALTER TABLE partition.control_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_14 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_14 inherit control;
        ALTER TABLE partition.control_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_15 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_15 inherit control;
        ALTER TABLE partition.control_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_16 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_16 inherit control;
        ALTER TABLE partition.control_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_17 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_17 inherit control;
        ALTER TABLE partition.control_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_18 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_18 inherit control;
        ALTER TABLE partition.control_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_19 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_19 inherit control;
        ALTER TABLE partition.control_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_20 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_20 inherit control;
        ALTER TABLE partition.control_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_21 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_21 inherit control;
        ALTER TABLE partition.control_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_22 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_22 inherit control;
        ALTER TABLE partition.control_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_23 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_23 inherit control;
        ALTER TABLE partition.control_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_24 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_24 inherit control;
        ALTER TABLE partition.control_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_25 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_25 inherit control;
        ALTER TABLE partition.control_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_26 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_26 inherit control;
        ALTER TABLE partition.control_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_27 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_27 inherit control;
        ALTER TABLE partition.control_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_28 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_28 inherit control;
        ALTER TABLE partition.control_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_29 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_29 inherit control;
        ALTER TABLE partition.control_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_30 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_30 inherit control;
        ALTER TABLE partition.control_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_31 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_31 inherit control;
        ALTER TABLE partition.control_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_32 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_32 inherit control;
        ALTER TABLE partition.control_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_33 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_33 inherit control;
        ALTER TABLE partition.control_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_34 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_34 inherit control;
        ALTER TABLE partition.control_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_35 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_35 inherit control;
        ALTER TABLE partition.control_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_36 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_36 inherit control;
        ALTER TABLE partition.control_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_37 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_37 inherit control;
        ALTER TABLE partition.control_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_38 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_38 inherit control;
        ALTER TABLE partition.control_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_39 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_39 inherit control;
        ALTER TABLE partition.control_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_40 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_40 inherit control;
        ALTER TABLE partition.control_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_41 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_41 inherit control;
        ALTER TABLE partition.control_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_42 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_42 inherit control;
        ALTER TABLE partition.control_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_43 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_43 inherit control;
        ALTER TABLE partition.control_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_44 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_44 inherit control;
        ALTER TABLE partition.control_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.control_bis_45 ( LIKE control including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.control_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.control_bis_45 inherit control;
        ALTER TABLE partition.control_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.control_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.control_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            control_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.control_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.control_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.control_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.control_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.control_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.control_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.control_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.control_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.control_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.control_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.control_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.control_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.control_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.control_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.control_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.control_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.control_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.control_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.control_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.control_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.control_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.control_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.control_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.control_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.control_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.control_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.control_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.control_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.control_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.control_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.control_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.control_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.control_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.control_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.control_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.control_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.control_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.control_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.control_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.control_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.control_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.control_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.control_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.control_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.control_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY control WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_control    
            AFTER INSERT ON control
            FOR EACH ROW EXECUTE PROCEDURE control_insert_trigger();   
        MAC LABEL ON FUNCTION control_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_1 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_1 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_2 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_2 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_3 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_3 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_4 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_4 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_5 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_5 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_6 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_6 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_7 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_7 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_8 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_8 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_9 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_9 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_10 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_10 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_11 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_11 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_12 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_12 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_13 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_13 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_14 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_14 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_15 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_15 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_16 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_16 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_17 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_17 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_18 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_18 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_19 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_19 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_20 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_20 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_21 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_21 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_22 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_22 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_23 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_23 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_24 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_24 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_25 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_25 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_26 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_26 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_27 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_27 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_28 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_28 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_29 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_29 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_30 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_30 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_31 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_31 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_32 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_32 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_33 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_33 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_34 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_34 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_35 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_35 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_36 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_36 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_37 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_37 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_38 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_38 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_39 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_39 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_40 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_40 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_41 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_41 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_42 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_42 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_43 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_43 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_44 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_44 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.navsolution_bis_45 ( LIKE navsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.navsolution_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.navsolution_bis_45 inherit navsolution;
        ALTER TABLE partition.navsolution_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.navsolution_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.navsolution_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            navsolution_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.navsolution_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.navsolution_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.navsolution_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.navsolution_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.navsolution_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.navsolution_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.navsolution_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.navsolution_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.navsolution_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.navsolution_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.navsolution_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.navsolution_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.navsolution_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.navsolution_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.navsolution_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.navsolution_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.navsolution_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.navsolution_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.navsolution_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.navsolution_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.navsolution_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.navsolution_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.navsolution_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.navsolution_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.navsolution_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.navsolution_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.navsolution_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.navsolution_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.navsolution_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.navsolution_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.navsolution_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.navsolution_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.navsolution_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.navsolution_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.navsolution_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.navsolution_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.navsolution_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.navsolution_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.navsolution_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.navsolution_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.navsolution_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.navsolution_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.navsolution_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.navsolution_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.navsolution_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY navsolution WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_navsolution    
            AFTER INSERT ON navsolution
            FOR EACH ROW EXECUTE PROCEDURE navsolution_insert_trigger();   
        MAC LABEL ON FUNCTION navsolution_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.packet_bis_1 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_1 inherit packet;
        ALTER TABLE partition.packet_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_2 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_2 inherit packet;
        ALTER TABLE partition.packet_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_3 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_3 inherit packet;
        ALTER TABLE partition.packet_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_4 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_4 inherit packet;
        ALTER TABLE partition.packet_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_5 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_5 inherit packet;
        ALTER TABLE partition.packet_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_6 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_6 inherit packet;
        ALTER TABLE partition.packet_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_7 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_7 inherit packet;
        ALTER TABLE partition.packet_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_8 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_8 inherit packet;
        ALTER TABLE partition.packet_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_9 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_9 inherit packet;
        ALTER TABLE partition.packet_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_10 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_10 inherit packet;
        ALTER TABLE partition.packet_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_11 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_11 inherit packet;
        ALTER TABLE partition.packet_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_12 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_12 inherit packet;
        ALTER TABLE partition.packet_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_13 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_13 inherit packet;
        ALTER TABLE partition.packet_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_14 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_14 inherit packet;
        ALTER TABLE partition.packet_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_15 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_15 inherit packet;
        ALTER TABLE partition.packet_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_16 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_16 inherit packet;
        ALTER TABLE partition.packet_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_17 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_17 inherit packet;
        ALTER TABLE partition.packet_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_18 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_18 inherit packet;
        ALTER TABLE partition.packet_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_19 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_19 inherit packet;
        ALTER TABLE partition.packet_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_20 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_20 inherit packet;
        ALTER TABLE partition.packet_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_21 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_21 inherit packet;
        ALTER TABLE partition.packet_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_22 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_22 inherit packet;
        ALTER TABLE partition.packet_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_23 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_23 inherit packet;
        ALTER TABLE partition.packet_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_24 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_24 inherit packet;
        ALTER TABLE partition.packet_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_25 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_25 inherit packet;
        ALTER TABLE partition.packet_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_26 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_26 inherit packet;
        ALTER TABLE partition.packet_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_27 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_27 inherit packet;
        ALTER TABLE partition.packet_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_28 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_28 inherit packet;
        ALTER TABLE partition.packet_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_29 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_29 inherit packet;
        ALTER TABLE partition.packet_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_30 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_30 inherit packet;
        ALTER TABLE partition.packet_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_31 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_31 inherit packet;
        ALTER TABLE partition.packet_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_32 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_32 inherit packet;
        ALTER TABLE partition.packet_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_33 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_33 inherit packet;
        ALTER TABLE partition.packet_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_34 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_34 inherit packet;
        ALTER TABLE partition.packet_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_35 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_35 inherit packet;
        ALTER TABLE partition.packet_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_36 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_36 inherit packet;
        ALTER TABLE partition.packet_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_37 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_37 inherit packet;
        ALTER TABLE partition.packet_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_38 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_38 inherit packet;
        ALTER TABLE partition.packet_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_39 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_39 inherit packet;
        ALTER TABLE partition.packet_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_40 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_40 inherit packet;
        ALTER TABLE partition.packet_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_41 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_41 inherit packet;
        ALTER TABLE partition.packet_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_42 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_42 inherit packet;
        ALTER TABLE partition.packet_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_43 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_43 inherit packet;
        ALTER TABLE partition.packet_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_44 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_44 inherit packet;
        ALTER TABLE partition.packet_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.packet_bis_45 ( LIKE packet including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.packet_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.packet_bis_45 inherit packet;
        ALTER TABLE partition.packet_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.packet_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.packet_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            packet_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.packet_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.packet_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.packet_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.packet_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.packet_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.packet_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.packet_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.packet_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.packet_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.packet_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.packet_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.packet_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.packet_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.packet_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.packet_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.packet_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.packet_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.packet_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.packet_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.packet_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.packet_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.packet_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.packet_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.packet_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.packet_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.packet_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.packet_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.packet_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.packet_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.packet_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.packet_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.packet_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.packet_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.packet_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.packet_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.packet_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.packet_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.packet_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.packet_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.packet_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.packet_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.packet_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.packet_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.packet_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.packet_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY packet WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_packet    
            AFTER INSERT ON packet
            FOR EACH ROW EXECUTE PROCEDURE packet_insert_trigger();   
        MAC LABEL ON FUNCTION packet_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_1 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_1 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_2 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_2 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_3 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_3 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_4 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_4 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_5 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_5 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_6 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_6 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_7 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_7 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_8 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_8 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_9 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_9 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_10 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_10 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_11 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_11 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_12 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_12 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_13 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_13 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_14 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_14 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_15 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_15 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_16 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_16 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_17 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_17 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_18 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_18 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_19 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_19 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_20 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_20 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_21 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_21 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_22 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_22 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_23 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_23 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_24 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_24 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_25 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_25 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_26 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_26 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_27 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_27 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_28 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_28 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_29 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_29 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_30 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_30 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_31 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_31 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_32 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_32 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_33 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_33 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_34 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_34 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_35 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_35 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_36 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_36 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_37 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_37 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_38 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_38 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_39 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_39 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_40 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_40 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_41 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_41 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_42 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_42 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_43 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_43 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_44 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_44 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpnavsolution_bis_45 ( LIKE knpnavsolution including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpnavsolution_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpnavsolution_bis_45 inherit knpnavsolution;
        ALTER TABLE partition.knpnavsolution_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpnavsolution_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.knpnavsolution_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            knpnavsolution_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.knpnavsolution_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.knpnavsolution_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.knpnavsolution_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.knpnavsolution_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.knpnavsolution_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.knpnavsolution_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.knpnavsolution_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.knpnavsolution_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.knpnavsolution_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.knpnavsolution_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.knpnavsolution_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.knpnavsolution_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.knpnavsolution_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.knpnavsolution_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.knpnavsolution_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.knpnavsolution_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.knpnavsolution_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.knpnavsolution_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.knpnavsolution_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.knpnavsolution_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.knpnavsolution_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.knpnavsolution_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.knpnavsolution_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.knpnavsolution_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.knpnavsolution_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.knpnavsolution_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.knpnavsolution_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.knpnavsolution_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.knpnavsolution_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.knpnavsolution_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.knpnavsolution_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.knpnavsolution_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.knpnavsolution_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.knpnavsolution_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.knpnavsolution_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.knpnavsolution_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.knpnavsolution_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.knpnavsolution_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.knpnavsolution_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.knpnavsolution_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.knpnavsolution_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.knpnavsolution_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.knpnavsolution_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.knpnavsolution_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.knpnavsolution_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY knpnavsolution WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_knpnavsolution    
            AFTER INSERT ON knpnavsolution
            FOR EACH ROW EXECUTE PROCEDURE knpnavsolution_insert_trigger();   
        MAC LABEL ON FUNCTION knpnavsolution_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_1 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_1 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_2 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_2 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_3 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_3 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_4 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_4 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_5 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_5 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_6 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_6 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_7 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_7 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_8 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_8 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_9 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_9 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_10 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_10 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_11 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_11 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_12 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_12 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_13 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_13 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_14 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_14 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_15 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_15 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_16 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_16 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_17 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_17 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_18 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_18 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_19 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_19 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_20 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_20 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_21 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_21 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_22 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_22 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_23 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_23 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_24 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_24 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_25 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_25 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_26 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_26 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_27 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_27 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_28 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_28 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_29 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_29 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_30 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_30 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_31 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_31 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_32 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_32 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_33 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_33 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_34 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_34 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_35 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_35 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_36 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_36 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_37 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_37 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_38 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_38 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_39 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_39 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_40 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_40 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_41 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_41 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_42 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_42 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_43 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_43 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_44 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_44 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopmessage_bis_45 ( LIKE knpopmessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopmessage_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopmessage_bis_45 inherit knpopmessage;
        ALTER TABLE partition.knpopmessage_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopmessage_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopmessage_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            knpopmessage_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.knpopmessage_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.knpopmessage_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.knpopmessage_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.knpopmessage_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.knpopmessage_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.knpopmessage_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.knpopmessage_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.knpopmessage_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.knpopmessage_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.knpopmessage_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.knpopmessage_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.knpopmessage_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.knpopmessage_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.knpopmessage_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.knpopmessage_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.knpopmessage_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.knpopmessage_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.knpopmessage_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.knpopmessage_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.knpopmessage_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.knpopmessage_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.knpopmessage_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.knpopmessage_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.knpopmessage_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.knpopmessage_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.knpopmessage_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.knpopmessage_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.knpopmessage_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.knpopmessage_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.knpopmessage_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.knpopmessage_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.knpopmessage_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.knpopmessage_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.knpopmessage_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.knpopmessage_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.knpopmessage_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.knpopmessage_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.knpopmessage_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.knpopmessage_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.knpopmessage_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.knpopmessage_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.knpopmessage_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.knpopmessage_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.knpopmessage_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.knpopmessage_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY knpopmessage WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_knpopmessage    
            AFTER INSERT ON knpopmessage
            FOR EACH ROW EXECUTE PROCEDURE knpopmessage_insert_trigger();   
        MAC LABEL ON FUNCTION knpopmessage_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_1 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_1 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_2 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_2 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_3 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_3 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_4 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_4 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_5 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_5 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_6 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_6 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_7 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_7 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_8 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_8 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_9 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_9 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_10 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_10 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_11 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_11 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_12 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_12 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_13 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_13 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_14 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_14 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_15 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_15 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_16 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_16 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_17 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_17 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_18 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_18 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_19 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_19 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_20 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_20 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_21 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_21 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_22 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_22 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_23 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_23 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_24 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_24 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_25 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_25 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_26 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_26 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_27 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_27 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_28 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_28 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_29 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_29 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_30 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_30 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_31 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_31 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_32 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_32 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_33 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_33 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_34 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_34 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_35 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_35 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_36 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_36 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_37 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_37 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_38 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_38 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_39 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_39 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_40 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_40 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_41 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_41 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_42 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_42 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_43 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_43 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_44 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_44 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.meteoparameters_bis_45 ( LIKE meteoparameters including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.meteoparameters_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.meteoparameters_bis_45 inherit meteoparameters;
        ALTER TABLE partition.meteoparameters_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.meteoparameters_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.meteoparameters_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            meteoparameters_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.meteoparameters_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.meteoparameters_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.meteoparameters_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.meteoparameters_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.meteoparameters_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.meteoparameters_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.meteoparameters_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.meteoparameters_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.meteoparameters_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.meteoparameters_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.meteoparameters_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.meteoparameters_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.meteoparameters_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.meteoparameters_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.meteoparameters_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.meteoparameters_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.meteoparameters_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.meteoparameters_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.meteoparameters_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.meteoparameters_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.meteoparameters_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.meteoparameters_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.meteoparameters_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.meteoparameters_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.meteoparameters_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.meteoparameters_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.meteoparameters_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.meteoparameters_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.meteoparameters_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.meteoparameters_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.meteoparameters_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.meteoparameters_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.meteoparameters_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.meteoparameters_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.meteoparameters_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.meteoparameters_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.meteoparameters_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.meteoparameters_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.meteoparameters_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.meteoparameters_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.meteoparameters_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.meteoparameters_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.meteoparameters_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.meteoparameters_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.meteoparameters_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY meteoparameters WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_meteoparameters    
            AFTER INSERT ON meteoparameters
            FOR EACH ROW EXECUTE PROCEDURE meteoparameters_insert_trigger();   
        MAC LABEL ON FUNCTION meteoparameters_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_1 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_1 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_2 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_2 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_3 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_3 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_4 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_4 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_5 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_5 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_6 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_6 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_7 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_7 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_8 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_8 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_9 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_9 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_10 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_10 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_11 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_11 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_12 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_12 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_13 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_13 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_14 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_14 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_15 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_15 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_16 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_16 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_17 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_17 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_18 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_18 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_19 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_19 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_20 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_20 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_21 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_21 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_22 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_22 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_23 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_23 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_24 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_24 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_25 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_25 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_26 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_26 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_27 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_27 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_28 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_28 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_29 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_29 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_30 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_30 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_31 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_31 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_32 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_32 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_33 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_33 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_34 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_34 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_35 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_35 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_36 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_36 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_37 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_37 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_38 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_38 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_39 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_39 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_40 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_40 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_41 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_41 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_42 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_42 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_43 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_43 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_44 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_44 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.alarmcases_bis_45 ( LIKE alarmcases including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.alarmcases_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.alarmcases_bis_45 inherit alarmcases;
        ALTER TABLE partition.alarmcases_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.alarmcases_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.alarmcases_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            alarmcases_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.alarmcases_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.alarmcases_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.alarmcases_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.alarmcases_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.alarmcases_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.alarmcases_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.alarmcases_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.alarmcases_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.alarmcases_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.alarmcases_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.alarmcases_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.alarmcases_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.alarmcases_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.alarmcases_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.alarmcases_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.alarmcases_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.alarmcases_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.alarmcases_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.alarmcases_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.alarmcases_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.alarmcases_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.alarmcases_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.alarmcases_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.alarmcases_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.alarmcases_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.alarmcases_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.alarmcases_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.alarmcases_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.alarmcases_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.alarmcases_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.alarmcases_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.alarmcases_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.alarmcases_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.alarmcases_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.alarmcases_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.alarmcases_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.alarmcases_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.alarmcases_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.alarmcases_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.alarmcases_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.alarmcases_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.alarmcases_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.alarmcases_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.alarmcases_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.alarmcases_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY alarmcases WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_alarmcases    
            AFTER INSERT ON alarmcases
            FOR EACH ROW EXECUTE PROCEDURE alarmcases_insert_trigger();   
        MAC LABEL ON FUNCTION alarmcases_insert_trigger() IS '{1,0}';
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_1 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_1 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_1 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_1 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_1 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_1 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_2 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_2 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_2 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_2 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_2 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_2 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_3 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_3 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_3 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_3 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_3 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_3 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_4 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_4 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_4 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_4 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_4 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_4 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_5 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_5 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_5 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_5 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_5 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_5 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_6 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_6 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_6 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_6 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_6 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_6 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_7 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_7 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_7 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_7 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_7 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_7 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_8 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_8 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_8 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_8 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_8 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_8 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_9 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_9 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_9 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_9 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_9 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_9 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_10 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_10 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_10 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_10 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_10 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_10 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_11 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_11 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_11 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_11 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_11 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_11 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_12 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_12 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_12 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_12 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_12 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_12 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_13 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_13 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_13 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_13 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_13 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_13 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_14 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_14 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_14 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_14 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_14 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_14 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_15 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_15 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_15 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_15 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_15 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_15 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_16 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_16 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_16 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_16 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_16 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_16 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_17 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_17 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_17 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_17 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_17 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_17 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_18 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_18 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_18 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_18 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_18 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_18 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_19 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_19 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_19 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_19 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_19 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_19 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_20 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_20 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_20 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_20 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_20 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_20 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_21 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_21 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_21 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_21 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_21 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_21 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_22 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_22 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_22 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_22 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_22 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_22 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_23 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_23 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_23 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_23 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_23 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_23 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_24 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_24 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_24 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_24 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_24 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_24 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_25 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_25 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_25 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_25 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_25 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_25 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_26 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_26 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_26 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_26 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_26 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_26 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_27 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_27 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_27 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_27 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_27 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_27 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_28 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_28 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_28 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_28 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_28 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_28 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_29 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_29 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_29 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_29 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_29 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_29 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_30 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_30 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_30 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_30 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_30 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_30 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_31 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_31 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_31 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_31 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_31 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_31 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_32 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_32 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_32 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_32 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_32 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_32 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_33 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_33 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_33 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_33 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_33 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_33 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_34 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_34 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_34 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_34 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_34 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_34 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_35 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_35 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_35 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_35 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_35 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_35 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_36 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_36 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_36 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_36 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_36 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_36 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_37 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_37 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_37 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_37 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_37 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_37 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_38 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_38 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_38 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_38 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_38 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_38 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_39 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_39 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_39 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_39 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_39 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_39 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_40 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_40 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_40 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_40 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_40 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_40 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_41 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_41 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_41 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_41 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_41 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_41 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_42 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_42 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_42 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_42 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_42 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_42 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_43 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_43 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_43 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_43 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_43 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_43 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_44 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_44 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_44 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_44 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_44 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_44 IS OFF;
           
        CREATE TABLE IF NOT EXISTS partition.knpopsummessage_bis_45 ( LIKE knpopsummessage including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.knpopsummessage_bis_45 ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.knpopsummessage_bis_45 inherit knpopsummessage;
        ALTER TABLE partition.knpopsummessage_bis_45 OWNER TO knp;
        
        MAC LABEL ON TABLE partition.knpopsummessage_bis_45 IS '{1,0}';
        MAC CCR ON TABLE partition.knpopsummessage_bis_45 IS OFF;
           
            CREATE OR REPLACE FUNCTION     
            knpopsummessage_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.knpopsummessage_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 2) THEN
                INSERT INTO partition.knpopsummessage_bis_2 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 3) THEN
                INSERT INTO partition.knpopsummessage_bis_3 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 4) THEN
                INSERT INTO partition.knpopsummessage_bis_4 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 5) THEN
                INSERT INTO partition.knpopsummessage_bis_5 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 6) THEN
                INSERT INTO partition.knpopsummessage_bis_6 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 7) THEN
                INSERT INTO partition.knpopsummessage_bis_7 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 8) THEN
                INSERT INTO partition.knpopsummessage_bis_8 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 9) THEN
                INSERT INTO partition.knpopsummessage_bis_9 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 10) THEN
                INSERT INTO partition.knpopsummessage_bis_10 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 11) THEN
                INSERT INTO partition.knpopsummessage_bis_11 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 12) THEN
                INSERT INTO partition.knpopsummessage_bis_12 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 13) THEN
                INSERT INTO partition.knpopsummessage_bis_13 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 14) THEN
                INSERT INTO partition.knpopsummessage_bis_14 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 15) THEN
                INSERT INTO partition.knpopsummessage_bis_15 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 16) THEN
                INSERT INTO partition.knpopsummessage_bis_16 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 17) THEN
                INSERT INTO partition.knpopsummessage_bis_17 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 18) THEN
                INSERT INTO partition.knpopsummessage_bis_18 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 19) THEN
                INSERT INTO partition.knpopsummessage_bis_19 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 20) THEN
                INSERT INTO partition.knpopsummessage_bis_20 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 21) THEN
                INSERT INTO partition.knpopsummessage_bis_21 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 22) THEN
                INSERT INTO partition.knpopsummessage_bis_22 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 23) THEN
                INSERT INTO partition.knpopsummessage_bis_23 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 24) THEN
                INSERT INTO partition.knpopsummessage_bis_24 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 25) THEN
                INSERT INTO partition.knpopsummessage_bis_25 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 26) THEN
                INSERT INTO partition.knpopsummessage_bis_26 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 27) THEN
                INSERT INTO partition.knpopsummessage_bis_27 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 28) THEN
                INSERT INTO partition.knpopsummessage_bis_28 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 29) THEN
                INSERT INTO partition.knpopsummessage_bis_29 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 30) THEN
                INSERT INTO partition.knpopsummessage_bis_30 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 31) THEN
                INSERT INTO partition.knpopsummessage_bis_31 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 32) THEN
                INSERT INTO partition.knpopsummessage_bis_32 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 33) THEN
                INSERT INTO partition.knpopsummessage_bis_33 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 34) THEN
                INSERT INTO partition.knpopsummessage_bis_34 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 35) THEN
                INSERT INTO partition.knpopsummessage_bis_35 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 36) THEN
                INSERT INTO partition.knpopsummessage_bis_36 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 37) THEN
                INSERT INTO partition.knpopsummessage_bis_37 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 38) THEN
                INSERT INTO partition.knpopsummessage_bis_38 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 39) THEN
                INSERT INTO partition.knpopsummessage_bis_39 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 40) THEN
                INSERT INTO partition.knpopsummessage_bis_40 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 41) THEN
                INSERT INTO partition.knpopsummessage_bis_41 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 42) THEN
                INSERT INTO partition.knpopsummessage_bis_42 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 43) THEN
                INSERT INTO partition.knpopsummessage_bis_43 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSEIF (NEW.bis_id = 44) THEN
                INSERT INTO partition.knpopsummessage_bis_44 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            ELSE 
                INSERT INTO partition.knpopsummessage_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY knpopsummessage WHERE id = NEW.id;
                        
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            
            
            CREATE TRIGGER insert_knpopsummessage    
            AFTER INSERT ON knpopsummessage
            FOR EACH ROW EXECUTE PROCEDURE knpopsummessage_insert_trigger();   
        MAC LABEL ON FUNCTION knpopsummessage_insert_trigger() IS '{1,0}';