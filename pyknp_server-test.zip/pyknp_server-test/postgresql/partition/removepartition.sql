
        DROP TABLE partition.l1offrame_bis_1 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_2 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_3 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_4 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_5 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_6 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_7 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_8 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_9 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_10 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_11 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_12 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_13 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_14 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_15 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_16 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_17 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_18 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_19 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_20 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_21 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_22 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_23 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_24 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_25 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_26 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_27 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_28 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_29 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_30 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_31 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_32 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_33 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_34 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_35 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_36 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_37 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_38 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_39 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_40 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_41 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_42 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_43 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_44 CASCADE;
        
        DROP TABLE partition.l1offrame_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1offrame ON l1offrame;
        
        DROP TABLE partition.l2offrame_bis_1 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_2 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_3 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_4 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_5 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_6 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_7 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_8 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_9 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_10 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_11 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_12 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_13 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_14 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_15 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_16 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_17 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_18 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_19 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_20 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_21 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_22 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_23 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_24 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_25 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_26 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_27 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_28 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_29 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_30 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_31 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_32 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_33 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_34 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_35 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_36 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_37 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_38 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_39 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_40 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_41 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_42 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_43 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_44 CASCADE;
        
        DROP TABLE partition.l2offrame_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l2offrame ON l2offrame;
        
        DROP TABLE partition.l1sfframe_bis_1 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_2 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_3 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_4 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_5 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_6 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_7 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_8 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_9 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_10 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_11 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_12 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_13 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_14 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_15 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_16 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_17 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_18 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_19 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_20 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_21 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_22 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_23 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_24 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_25 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_26 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_27 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_28 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_29 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_30 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_31 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_32 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_33 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_34 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_35 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_36 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_37 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_38 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_39 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_40 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_41 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_42 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_43 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_44 CASCADE;
        
        DROP TABLE partition.l1sfframe_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1sfframe ON l1sfframe;
        
        DROP TABLE partition.l1ocstring_bis_1 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_2 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_3 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_4 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_5 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_6 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_7 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_8 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_9 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_10 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_11 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_12 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_13 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_14 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_15 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_16 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_17 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_18 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_19 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_20 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_21 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_22 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_23 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_24 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_25 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_26 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_27 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_28 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_29 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_30 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_31 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_32 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_33 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_34 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_35 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_36 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_37 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_38 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_39 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_40 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_41 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_42 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_43 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_44 CASCADE;
        
        DROP TABLE partition.l1ocstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1ocstring ON l1ocstring;
        
        DROP TABLE partition.l3ocstring_bis_1 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_2 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_3 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_4 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_5 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_6 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_7 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_8 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_9 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_10 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_11 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_12 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_13 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_14 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_15 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_16 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_17 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_18 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_19 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_20 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_21 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_22 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_23 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_24 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_25 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_26 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_27 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_28 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_29 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_30 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_31 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_32 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_33 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_34 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_35 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_36 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_37 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_38 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_39 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_40 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_41 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_42 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_43 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_44 CASCADE;
        
        DROP TABLE partition.l3ocstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l3ocstring ON l3ocstring;
        
        DROP TABLE partition.l1scstring_bis_1 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_2 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_3 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_4 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_5 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_6 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_7 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_8 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_9 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_10 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_11 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_12 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_13 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_14 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_15 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_16 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_17 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_18 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_19 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_20 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_21 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_22 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_23 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_24 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_25 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_26 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_27 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_28 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_29 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_30 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_31 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_32 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_33 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_34 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_35 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_36 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_37 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_38 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_39 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_40 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_41 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_42 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_43 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_44 CASCADE;
        
        DROP TABLE partition.l1scstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1scstring ON l1scstring;
        
        DROP TABLE partition.l2scstring_bis_1 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_2 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_3 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_4 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_5 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_6 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_7 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_8 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_9 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_10 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_11 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_12 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_13 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_14 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_15 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_16 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_17 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_18 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_19 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_20 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_21 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_22 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_23 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_24 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_25 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_26 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_27 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_28 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_29 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_30 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_31 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_32 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_33 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_34 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_35 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_36 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_37 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_38 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_39 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_40 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_41 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_42 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_43 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_44 CASCADE;
        
        DROP TABLE partition.l2scstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l2scstring ON l2scstring;
        
        DROP TABLE partition.l1ocframe_bis_1 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_2 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_3 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_4 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_5 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_6 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_7 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_8 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_9 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_10 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_11 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_12 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_13 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_14 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_15 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_16 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_17 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_18 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_19 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_20 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_21 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_22 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_23 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_24 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_25 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_26 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_27 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_28 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_29 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_30 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_31 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_32 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_33 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_34 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_35 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_36 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_37 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_38 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_39 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_40 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_41 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_42 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_43 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_44 CASCADE;
        
        DROP TABLE partition.l1ocframe_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1ocframe ON l1ocframe;
        
        DROP TABLE partition.l3ocframe_bis_1 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_2 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_3 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_4 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_5 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_6 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_7 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_8 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_9 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_10 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_11 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_12 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_13 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_14 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_15 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_16 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_17 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_18 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_19 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_20 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_21 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_22 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_23 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_24 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_25 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_26 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_27 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_28 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_29 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_30 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_31 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_32 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_33 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_34 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_35 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_36 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_37 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_38 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_39 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_40 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_41 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_42 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_43 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_44 CASCADE;
        
        DROP TABLE partition.l3ocframe_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l3ocframe ON l3ocframe;
        
        DROP TABLE partition.l1scframe_bis_1 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_2 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_3 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_4 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_5 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_6 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_7 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_8 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_9 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_10 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_11 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_12 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_13 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_14 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_15 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_16 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_17 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_18 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_19 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_20 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_21 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_22 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_23 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_24 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_25 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_26 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_27 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_28 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_29 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_30 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_31 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_32 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_33 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_34 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_35 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_36 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_37 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_38 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_39 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_40 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_41 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_42 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_43 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_44 CASCADE;
        
        DROP TABLE partition.l1scframe_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1scframe ON l1scframe;
        
        DROP TABLE partition.l2scframe_bis_1 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_2 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_3 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_4 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_5 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_6 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_7 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_8 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_9 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_10 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_11 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_12 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_13 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_14 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_15 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_16 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_17 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_18 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_19 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_20 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_21 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_22 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_23 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_24 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_25 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_26 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_27 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_28 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_29 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_30 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_31 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_32 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_33 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_34 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_35 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_36 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_37 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_38 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_39 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_40 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_41 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_42 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_43 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_44 CASCADE;
        
        DROP TABLE partition.l2scframe_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l2scframe ON l2scframe;
        
        DROP TABLE partition.l1ofstring_bis_1 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_2 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_3 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_4 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_5 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_6 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_7 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_8 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_9 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_10 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_11 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_12 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_13 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_14 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_15 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_16 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_17 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_18 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_19 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_20 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_21 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_22 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_23 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_24 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_25 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_26 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_27 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_28 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_29 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_30 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_31 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_32 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_33 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_34 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_35 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_36 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_37 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_38 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_39 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_40 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_41 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_42 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_43 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_44 CASCADE;
        
        DROP TABLE partition.l1ofstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1ofstring ON l1ofstring;
        
        DROP TABLE partition.l2ofstring_bis_1 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_2 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_3 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_4 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_5 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_6 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_7 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_8 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_9 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_10 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_11 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_12 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_13 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_14 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_15 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_16 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_17 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_18 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_19 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_20 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_21 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_22 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_23 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_24 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_25 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_26 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_27 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_28 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_29 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_30 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_31 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_32 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_33 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_34 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_35 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_36 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_37 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_38 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_39 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_40 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_41 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_42 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_43 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_44 CASCADE;
        
        DROP TABLE partition.l2ofstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l2ofstring ON l2ofstring;
        
        DROP TABLE partition.l1sfstring_bis_1 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_2 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_3 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_4 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_5 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_6 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_7 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_8 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_9 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_10 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_11 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_12 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_13 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_14 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_15 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_16 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_17 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_18 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_19 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_20 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_21 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_22 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_23 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_24 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_25 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_26 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_27 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_28 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_29 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_30 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_31 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_32 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_33 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_34 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_35 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_36 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_37 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_38 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_39 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_40 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_41 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_42 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_43 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_44 CASCADE;
        
        DROP TABLE partition.l1sfstring_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_l1sfstring ON l1sfstring;
        
        DROP TABLE partition.opmessage_bis_1 CASCADE;
        
        DROP TABLE partition.opmessage_bis_2 CASCADE;
        
        DROP TABLE partition.opmessage_bis_3 CASCADE;
        
        DROP TABLE partition.opmessage_bis_4 CASCADE;
        
        DROP TABLE partition.opmessage_bis_5 CASCADE;
        
        DROP TABLE partition.opmessage_bis_6 CASCADE;
        
        DROP TABLE partition.opmessage_bis_7 CASCADE;
        
        DROP TABLE partition.opmessage_bis_8 CASCADE;
        
        DROP TABLE partition.opmessage_bis_9 CASCADE;
        
        DROP TABLE partition.opmessage_bis_10 CASCADE;
        
        DROP TABLE partition.opmessage_bis_11 CASCADE;
        
        DROP TABLE partition.opmessage_bis_12 CASCADE;
        
        DROP TABLE partition.opmessage_bis_13 CASCADE;
        
        DROP TABLE partition.opmessage_bis_14 CASCADE;
        
        DROP TABLE partition.opmessage_bis_15 CASCADE;
        
        DROP TABLE partition.opmessage_bis_16 CASCADE;
        
        DROP TABLE partition.opmessage_bis_17 CASCADE;
        
        DROP TABLE partition.opmessage_bis_18 CASCADE;
        
        DROP TABLE partition.opmessage_bis_19 CASCADE;
        
        DROP TABLE partition.opmessage_bis_20 CASCADE;
        
        DROP TABLE partition.opmessage_bis_21 CASCADE;
        
        DROP TABLE partition.opmessage_bis_22 CASCADE;
        
        DROP TABLE partition.opmessage_bis_23 CASCADE;
        
        DROP TABLE partition.opmessage_bis_24 CASCADE;
        
        DROP TABLE partition.opmessage_bis_25 CASCADE;
        
        DROP TABLE partition.opmessage_bis_26 CASCADE;
        
        DROP TABLE partition.opmessage_bis_27 CASCADE;
        
        DROP TABLE partition.opmessage_bis_28 CASCADE;
        
        DROP TABLE partition.opmessage_bis_29 CASCADE;
        
        DROP TABLE partition.opmessage_bis_30 CASCADE;
        
        DROP TABLE partition.opmessage_bis_31 CASCADE;
        
        DROP TABLE partition.opmessage_bis_32 CASCADE;
        
        DROP TABLE partition.opmessage_bis_33 CASCADE;
        
        DROP TABLE partition.opmessage_bis_34 CASCADE;
        
        DROP TABLE partition.opmessage_bis_35 CASCADE;
        
        DROP TABLE partition.opmessage_bis_36 CASCADE;
        
        DROP TABLE partition.opmessage_bis_37 CASCADE;
        
        DROP TABLE partition.opmessage_bis_38 CASCADE;
        
        DROP TABLE partition.opmessage_bis_39 CASCADE;
        
        DROP TABLE partition.opmessage_bis_40 CASCADE;
        
        DROP TABLE partition.opmessage_bis_41 CASCADE;
        
        DROP TABLE partition.opmessage_bis_42 CASCADE;
        
        DROP TABLE partition.opmessage_bis_43 CASCADE;
        
        DROP TABLE partition.opmessage_bis_44 CASCADE;
        
        DROP TABLE partition.opmessage_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_opmessage ON opmessage;
        
        DROP TABLE partition.residual_bis_1 CASCADE;
        
        DROP TABLE partition.residual_bis_2 CASCADE;
        
        DROP TABLE partition.residual_bis_3 CASCADE;
        
        DROP TABLE partition.residual_bis_4 CASCADE;
        
        DROP TABLE partition.residual_bis_5 CASCADE;
        
        DROP TABLE partition.residual_bis_6 CASCADE;
        
        DROP TABLE partition.residual_bis_7 CASCADE;
        
        DROP TABLE partition.residual_bis_8 CASCADE;
        
        DROP TABLE partition.residual_bis_9 CASCADE;
        
        DROP TABLE partition.residual_bis_10 CASCADE;
        
        DROP TABLE partition.residual_bis_11 CASCADE;
        
        DROP TABLE partition.residual_bis_12 CASCADE;
        
        DROP TABLE partition.residual_bis_13 CASCADE;
        
        DROP TABLE partition.residual_bis_14 CASCADE;
        
        DROP TABLE partition.residual_bis_15 CASCADE;
        
        DROP TABLE partition.residual_bis_16 CASCADE;
        
        DROP TABLE partition.residual_bis_17 CASCADE;
        
        DROP TABLE partition.residual_bis_18 CASCADE;
        
        DROP TABLE partition.residual_bis_19 CASCADE;
        
        DROP TABLE partition.residual_bis_20 CASCADE;
        
        DROP TABLE partition.residual_bis_21 CASCADE;
        
        DROP TABLE partition.residual_bis_22 CASCADE;
        
        DROP TABLE partition.residual_bis_23 CASCADE;
        
        DROP TABLE partition.residual_bis_24 CASCADE;
        
        DROP TABLE partition.residual_bis_25 CASCADE;
        
        DROP TABLE partition.residual_bis_26 CASCADE;
        
        DROP TABLE partition.residual_bis_27 CASCADE;
        
        DROP TABLE partition.residual_bis_28 CASCADE;
        
        DROP TABLE partition.residual_bis_29 CASCADE;
        
        DROP TABLE partition.residual_bis_30 CASCADE;
        
        DROP TABLE partition.residual_bis_31 CASCADE;
        
        DROP TABLE partition.residual_bis_32 CASCADE;
        
        DROP TABLE partition.residual_bis_33 CASCADE;
        
        DROP TABLE partition.residual_bis_34 CASCADE;
        
        DROP TABLE partition.residual_bis_35 CASCADE;
        
        DROP TABLE partition.residual_bis_36 CASCADE;
        
        DROP TABLE partition.residual_bis_37 CASCADE;
        
        DROP TABLE partition.residual_bis_38 CASCADE;
        
        DROP TABLE partition.residual_bis_39 CASCADE;
        
        DROP TABLE partition.residual_bis_40 CASCADE;
        
        DROP TABLE partition.residual_bis_41 CASCADE;
        
        DROP TABLE partition.residual_bis_42 CASCADE;
        
        DROP TABLE partition.residual_bis_43 CASCADE;
        
        DROP TABLE partition.residual_bis_44 CASCADE;
        
        DROP TABLE partition.residual_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_residual ON residual;
        
        DROP TABLE partition.signal_bis_1 CASCADE;
        
        DROP TABLE partition.signal_bis_2 CASCADE;
        
        DROP TABLE partition.signal_bis_3 CASCADE;
        
        DROP TABLE partition.signal_bis_4 CASCADE;
        
        DROP TABLE partition.signal_bis_5 CASCADE;
        
        DROP TABLE partition.signal_bis_6 CASCADE;
        
        DROP TABLE partition.signal_bis_7 CASCADE;
        
        DROP TABLE partition.signal_bis_8 CASCADE;
        
        DROP TABLE partition.signal_bis_9 CASCADE;
        
        DROP TABLE partition.signal_bis_10 CASCADE;
        
        DROP TABLE partition.signal_bis_11 CASCADE;
        
        DROP TABLE partition.signal_bis_12 CASCADE;
        
        DROP TABLE partition.signal_bis_13 CASCADE;
        
        DROP TABLE partition.signal_bis_14 CASCADE;
        
        DROP TABLE partition.signal_bis_15 CASCADE;
        
        DROP TABLE partition.signal_bis_16 CASCADE;
        
        DROP TABLE partition.signal_bis_17 CASCADE;
        
        DROP TABLE partition.signal_bis_18 CASCADE;
        
        DROP TABLE partition.signal_bis_19 CASCADE;
        
        DROP TABLE partition.signal_bis_20 CASCADE;
        
        DROP TABLE partition.signal_bis_21 CASCADE;
        
        DROP TABLE partition.signal_bis_22 CASCADE;
        
        DROP TABLE partition.signal_bis_23 CASCADE;
        
        DROP TABLE partition.signal_bis_24 CASCADE;
        
        DROP TABLE partition.signal_bis_25 CASCADE;
        
        DROP TABLE partition.signal_bis_26 CASCADE;
        
        DROP TABLE partition.signal_bis_27 CASCADE;
        
        DROP TABLE partition.signal_bis_28 CASCADE;
        
        DROP TABLE partition.signal_bis_29 CASCADE;
        
        DROP TABLE partition.signal_bis_30 CASCADE;
        
        DROP TABLE partition.signal_bis_31 CASCADE;
        
        DROP TABLE partition.signal_bis_32 CASCADE;
        
        DROP TABLE partition.signal_bis_33 CASCADE;
        
        DROP TABLE partition.signal_bis_34 CASCADE;
        
        DROP TABLE partition.signal_bis_35 CASCADE;
        
        DROP TABLE partition.signal_bis_36 CASCADE;
        
        DROP TABLE partition.signal_bis_37 CASCADE;
        
        DROP TABLE partition.signal_bis_38 CASCADE;
        
        DROP TABLE partition.signal_bis_39 CASCADE;
        
        DROP TABLE partition.signal_bis_40 CASCADE;
        
        DROP TABLE partition.signal_bis_41 CASCADE;
        
        DROP TABLE partition.signal_bis_42 CASCADE;
        
        DROP TABLE partition.signal_bis_43 CASCADE;
        
        DROP TABLE partition.signal_bis_44 CASCADE;
        
        DROP TABLE partition.signal_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_signal ON signal;
        
        DROP TABLE partition.control_bis_1 CASCADE;
        
        DROP TABLE partition.control_bis_2 CASCADE;
        
        DROP TABLE partition.control_bis_3 CASCADE;
        
        DROP TABLE partition.control_bis_4 CASCADE;
        
        DROP TABLE partition.control_bis_5 CASCADE;
        
        DROP TABLE partition.control_bis_6 CASCADE;
        
        DROP TABLE partition.control_bis_7 CASCADE;
        
        DROP TABLE partition.control_bis_8 CASCADE;
        
        DROP TABLE partition.control_bis_9 CASCADE;
        
        DROP TABLE partition.control_bis_10 CASCADE;
        
        DROP TABLE partition.control_bis_11 CASCADE;
        
        DROP TABLE partition.control_bis_12 CASCADE;
        
        DROP TABLE partition.control_bis_13 CASCADE;
        
        DROP TABLE partition.control_bis_14 CASCADE;
        
        DROP TABLE partition.control_bis_15 CASCADE;
        
        DROP TABLE partition.control_bis_16 CASCADE;
        
        DROP TABLE partition.control_bis_17 CASCADE;
        
        DROP TABLE partition.control_bis_18 CASCADE;
        
        DROP TABLE partition.control_bis_19 CASCADE;
        
        DROP TABLE partition.control_bis_20 CASCADE;
        
        DROP TABLE partition.control_bis_21 CASCADE;
        
        DROP TABLE partition.control_bis_22 CASCADE;
        
        DROP TABLE partition.control_bis_23 CASCADE;
        
        DROP TABLE partition.control_bis_24 CASCADE;
        
        DROP TABLE partition.control_bis_25 CASCADE;
        
        DROP TABLE partition.control_bis_26 CASCADE;
        
        DROP TABLE partition.control_bis_27 CASCADE;
        
        DROP TABLE partition.control_bis_28 CASCADE;
        
        DROP TABLE partition.control_bis_29 CASCADE;
        
        DROP TABLE partition.control_bis_30 CASCADE;
        
        DROP TABLE partition.control_bis_31 CASCADE;
        
        DROP TABLE partition.control_bis_32 CASCADE;
        
        DROP TABLE partition.control_bis_33 CASCADE;
        
        DROP TABLE partition.control_bis_34 CASCADE;
        
        DROP TABLE partition.control_bis_35 CASCADE;
        
        DROP TABLE partition.control_bis_36 CASCADE;
        
        DROP TABLE partition.control_bis_37 CASCADE;
        
        DROP TABLE partition.control_bis_38 CASCADE;
        
        DROP TABLE partition.control_bis_39 CASCADE;
        
        DROP TABLE partition.control_bis_40 CASCADE;
        
        DROP TABLE partition.control_bis_41 CASCADE;
        
        DROP TABLE partition.control_bis_42 CASCADE;
        
        DROP TABLE partition.control_bis_43 CASCADE;
        
        DROP TABLE partition.control_bis_44 CASCADE;
        
        DROP TABLE partition.control_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_control ON control;
        
        DROP TABLE partition.navsolution_bis_1 CASCADE;
        
        DROP TABLE partition.navsolution_bis_2 CASCADE;
        
        DROP TABLE partition.navsolution_bis_3 CASCADE;
        
        DROP TABLE partition.navsolution_bis_4 CASCADE;
        
        DROP TABLE partition.navsolution_bis_5 CASCADE;
        
        DROP TABLE partition.navsolution_bis_6 CASCADE;
        
        DROP TABLE partition.navsolution_bis_7 CASCADE;
        
        DROP TABLE partition.navsolution_bis_8 CASCADE;
        
        DROP TABLE partition.navsolution_bis_9 CASCADE;
        
        DROP TABLE partition.navsolution_bis_10 CASCADE;
        
        DROP TABLE partition.navsolution_bis_11 CASCADE;
        
        DROP TABLE partition.navsolution_bis_12 CASCADE;
        
        DROP TABLE partition.navsolution_bis_13 CASCADE;
        
        DROP TABLE partition.navsolution_bis_14 CASCADE;
        
        DROP TABLE partition.navsolution_bis_15 CASCADE;
        
        DROP TABLE partition.navsolution_bis_16 CASCADE;
        
        DROP TABLE partition.navsolution_bis_17 CASCADE;
        
        DROP TABLE partition.navsolution_bis_18 CASCADE;
        
        DROP TABLE partition.navsolution_bis_19 CASCADE;
        
        DROP TABLE partition.navsolution_bis_20 CASCADE;
        
        DROP TABLE partition.navsolution_bis_21 CASCADE;
        
        DROP TABLE partition.navsolution_bis_22 CASCADE;
        
        DROP TABLE partition.navsolution_bis_23 CASCADE;
        
        DROP TABLE partition.navsolution_bis_24 CASCADE;
        
        DROP TABLE partition.navsolution_bis_25 CASCADE;
        
        DROP TABLE partition.navsolution_bis_26 CASCADE;
        
        DROP TABLE partition.navsolution_bis_27 CASCADE;
        
        DROP TABLE partition.navsolution_bis_28 CASCADE;
        
        DROP TABLE partition.navsolution_bis_29 CASCADE;
        
        DROP TABLE partition.navsolution_bis_30 CASCADE;
        
        DROP TABLE partition.navsolution_bis_31 CASCADE;
        
        DROP TABLE partition.navsolution_bis_32 CASCADE;
        
        DROP TABLE partition.navsolution_bis_33 CASCADE;
        
        DROP TABLE partition.navsolution_bis_34 CASCADE;
        
        DROP TABLE partition.navsolution_bis_35 CASCADE;
        
        DROP TABLE partition.navsolution_bis_36 CASCADE;
        
        DROP TABLE partition.navsolution_bis_37 CASCADE;
        
        DROP TABLE partition.navsolution_bis_38 CASCADE;
        
        DROP TABLE partition.navsolution_bis_39 CASCADE;
        
        DROP TABLE partition.navsolution_bis_40 CASCADE;
        
        DROP TABLE partition.navsolution_bis_41 CASCADE;
        
        DROP TABLE partition.navsolution_bis_42 CASCADE;
        
        DROP TABLE partition.navsolution_bis_43 CASCADE;
        
        DROP TABLE partition.navsolution_bis_44 CASCADE;
        
        DROP TABLE partition.navsolution_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_navsolution ON navsolution;
        
        DROP TABLE partition.packet_bis_1 CASCADE;
        
        DROP TABLE partition.packet_bis_2 CASCADE;
        
        DROP TABLE partition.packet_bis_3 CASCADE;
        
        DROP TABLE partition.packet_bis_4 CASCADE;
        
        DROP TABLE partition.packet_bis_5 CASCADE;
        
        DROP TABLE partition.packet_bis_6 CASCADE;
        
        DROP TABLE partition.packet_bis_7 CASCADE;
        
        DROP TABLE partition.packet_bis_8 CASCADE;
        
        DROP TABLE partition.packet_bis_9 CASCADE;
        
        DROP TABLE partition.packet_bis_10 CASCADE;
        
        DROP TABLE partition.packet_bis_11 CASCADE;
        
        DROP TABLE partition.packet_bis_12 CASCADE;
        
        DROP TABLE partition.packet_bis_13 CASCADE;
        
        DROP TABLE partition.packet_bis_14 CASCADE;
        
        DROP TABLE partition.packet_bis_15 CASCADE;
        
        DROP TABLE partition.packet_bis_16 CASCADE;
        
        DROP TABLE partition.packet_bis_17 CASCADE;
        
        DROP TABLE partition.packet_bis_18 CASCADE;
        
        DROP TABLE partition.packet_bis_19 CASCADE;
        
        DROP TABLE partition.packet_bis_20 CASCADE;
        
        DROP TABLE partition.packet_bis_21 CASCADE;
        
        DROP TABLE partition.packet_bis_22 CASCADE;
        
        DROP TABLE partition.packet_bis_23 CASCADE;
        
        DROP TABLE partition.packet_bis_24 CASCADE;
        
        DROP TABLE partition.packet_bis_25 CASCADE;
        
        DROP TABLE partition.packet_bis_26 CASCADE;
        
        DROP TABLE partition.packet_bis_27 CASCADE;
        
        DROP TABLE partition.packet_bis_28 CASCADE;
        
        DROP TABLE partition.packet_bis_29 CASCADE;
        
        DROP TABLE partition.packet_bis_30 CASCADE;
        
        DROP TABLE partition.packet_bis_31 CASCADE;
        
        DROP TABLE partition.packet_bis_32 CASCADE;
        
        DROP TABLE partition.packet_bis_33 CASCADE;
        
        DROP TABLE partition.packet_bis_34 CASCADE;
        
        DROP TABLE partition.packet_bis_35 CASCADE;
        
        DROP TABLE partition.packet_bis_36 CASCADE;
        
        DROP TABLE partition.packet_bis_37 CASCADE;
        
        DROP TABLE partition.packet_bis_38 CASCADE;
        
        DROP TABLE partition.packet_bis_39 CASCADE;
        
        DROP TABLE partition.packet_bis_40 CASCADE;
        
        DROP TABLE partition.packet_bis_41 CASCADE;
        
        DROP TABLE partition.packet_bis_42 CASCADE;
        
        DROP TABLE partition.packet_bis_43 CASCADE;
        
        DROP TABLE partition.packet_bis_44 CASCADE;
        
        DROP TABLE partition.packet_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_packet ON packet;
        
        DROP TABLE partition.knpnavsolution_bis_1 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_2 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_3 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_4 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_5 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_6 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_7 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_8 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_9 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_10 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_11 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_12 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_13 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_14 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_15 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_16 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_17 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_18 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_19 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_20 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_21 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_22 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_23 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_24 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_25 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_26 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_27 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_28 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_29 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_30 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_31 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_32 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_33 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_34 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_35 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_36 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_37 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_38 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_39 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_40 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_41 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_42 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_43 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_44 CASCADE;
        
        DROP TABLE partition.knpnavsolution_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_knpnavsolution ON knpnavsolution;
        
        DROP TABLE partition.knpopmessage_bis_1 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_2 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_3 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_4 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_5 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_6 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_7 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_8 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_9 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_10 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_11 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_12 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_13 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_14 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_15 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_16 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_17 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_18 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_19 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_20 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_21 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_22 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_23 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_24 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_25 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_26 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_27 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_28 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_29 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_30 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_31 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_32 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_33 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_34 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_35 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_36 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_37 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_38 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_39 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_40 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_41 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_42 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_43 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_44 CASCADE;
        
        DROP TABLE partition.knpopmessage_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_knpopmessage ON knpopmessage;
        
        DROP TABLE partition.meteoparameters_bis_1 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_2 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_3 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_4 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_5 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_6 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_7 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_8 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_9 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_10 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_11 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_12 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_13 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_14 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_15 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_16 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_17 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_18 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_19 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_20 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_21 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_22 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_23 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_24 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_25 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_26 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_27 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_28 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_29 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_30 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_31 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_32 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_33 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_34 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_35 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_36 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_37 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_38 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_39 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_40 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_41 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_42 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_43 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_44 CASCADE;
        
        DROP TABLE partition.meteoparameters_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_meteoparameters ON meteoparameters;
        
        DROP TABLE partition.alarmcases_bis_1 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_2 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_3 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_4 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_5 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_6 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_7 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_8 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_9 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_10 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_11 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_12 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_13 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_14 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_15 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_16 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_17 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_18 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_19 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_20 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_21 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_22 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_23 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_24 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_25 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_26 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_27 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_28 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_29 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_30 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_31 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_32 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_33 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_34 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_35 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_36 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_37 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_38 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_39 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_40 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_41 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_42 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_43 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_44 CASCADE;
        
        DROP TABLE partition.alarmcases_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_alarmcases ON alarmcases;
        
        DROP TABLE partition.knpopsummessage_bis_1 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_2 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_3 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_4 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_5 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_6 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_7 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_8 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_9 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_10 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_11 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_12 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_13 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_14 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_15 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_16 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_17 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_18 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_19 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_20 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_21 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_22 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_23 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_24 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_25 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_26 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_27 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_28 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_29 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_30 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_31 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_32 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_33 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_34 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_35 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_36 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_37 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_38 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_39 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_40 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_41 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_42 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_43 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_44 CASCADE;
        
        DROP TABLE partition.knpopsummessage_bis_45 CASCADE;
        
        DROP TRIGGER IF EXISTS insert_knpopsummessage ON knpopsummessage;
        