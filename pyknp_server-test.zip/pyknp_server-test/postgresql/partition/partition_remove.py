SAVE_FILENAME = "removepartition.sql"

with open(SAVE_FILENAME, 'w') as f: f.write('')


def write_to_file(filename: str, text: str):
    with open(filename, 'a') as f:
        f.write(text)


tablenames = ['l1offrame', 'l2offrame', 'l1sfframe', 'l1ocstring',
              'l3ocstring', 'l1scstring', 'l2scstring', 'l1ocframe',
              'l3ocframe', 'l1scframe', 'l2scframe', 'l1ofstring',
              'l2ofstring', 'l1sfstring', 'opmessage', 'residual',
              'signal', 'control', 'navsolution', 'packet', 'knpnavsolution',
              'knpopmessage', 'meteoparameters', 'knpopsummessage']

for tablename in tablenames:
    for i in range(1, 46):
        sql_statement = f"""
        DROP TABLE partition.{tablename}_bis_{i} CASCADE;
        """

        write_to_file(SAVE_FILENAME, sql_statement)
    sql_statement = f"""
        DROP TRIGGER IF EXISTS insert_{tablename} ON {tablename};
        """
    write_to_file(SAVE_FILENAME, sql_statement)
