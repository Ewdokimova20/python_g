MAC = False

if MAC:
    SAVE_FILENAME = "createpartition_maclabel1.sql"
else:
    SAVE_FILENAME = "createpartition_maclabel0.sql"

with open(SAVE_FILENAME, 'w') as f: f.write('')


def write_to_file(filename: str, text: str):
    with open(filename, 'a') as f:
        f.write(text)


tablenames = ['l1offrame', 'l2offrame', 'l1sfframe', 'l1ocstring',
              'l3ocstring', 'l1scstring', 'l2scstring', 'l1ocframe',
              'l3ocframe', 'l1scframe', 'l2scframe', 'l1ofstring',
              'l2ofstring', 'l1sfstring', 'opmessage', 'residual',
              'signal', 'control', 'navsolution', 'packet', 'knpnavsolution',
              'knpopmessage', 'meteoparameters', 'knpopsummessage']

sql_create_shema = """CREATE SCHEMA IF NOT EXISTS partition AUTHORIZATION knp;"""

if MAC:
    sql_create_shema += f"""
        MAC LABEL ON SCHEMA partition IS '{{1,0}}';
        MAC CCR ON SCHEMA partition IS OFF;        
        """

write_to_file(SAVE_FILENAME, sql_create_shema)

# TODO add MAC label

for tablename in tablenames:
    sql_insert_function = (f"""
            CREATE OR REPLACE FUNCTION     
            {tablename}_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
            """)

    sql_insert_function += f"""
            IF (NEW.bis_id = 1) THEN
                INSERT INTO partition.{tablename}_bis_1 VALUES (NEW.*);
                DELETE FROM ONLY {tablename} WHERE id = NEW.id;
                        """

    for i in range(2, 45):
        sql_insert_function += f"""
            ELSEIF (NEW.bis_id = {i}) THEN
                INSERT INTO partition.{tablename}_bis_{i} VALUES (NEW.*);
                DELETE FROM ONLY {tablename} WHERE id = NEW.id;
                        """
    sql_insert_function += f"""
            ELSE 
                INSERT INTO partition.{tablename}_bis_45 VALUES (NEW.*);
                DELETE FROM ONLY {tablename} WHERE id = NEW.id;
                        """
    sql_insert_function += """
            END IF;
            RETURN NEW;
            END;
            $$
            LANGUAGE plpgsql;
            """
    sql_insert_trigger = f"""
            
            CREATE TRIGGER insert_{tablename}    
            AFTER INSERT ON {tablename}
            FOR EACH ROW EXECUTE PROCEDURE {tablename}_insert_trigger();   
        """
    if MAC: sql_insert_trigger += f"""MAC LABEL ON FUNCTION {tablename}_insert_trigger() IS '{{1,0}}';"""

    for i in range(1, 46):
        sql_statement = f"""
        CREATE TABLE IF NOT EXISTS partition.{tablename}_bis_{i} ( LIKE {tablename} including all ) WITH (MACS=FALSE);
        ALTER TABLE partition.{tablename}_bis_{i} ALTER COLUMN id DROP DEFAULT;
        ALTER TABLE partition.{tablename}_bis_{i} inherit {tablename};
        ALTER TABLE partition.{tablename}_bis_{i} OWNER TO knp;
        """

        if MAC:
            sql_statement += f"""
        MAC LABEL ON TABLE partition.{tablename}_bis_{i} IS '{{1,0}}';
        MAC CCR ON TABLE partition.{tablename}_bis_{i} IS OFF;
           """

        write_to_file(SAVE_FILENAME, sql_statement)

    write_to_file(SAVE_FILENAME, sql_insert_function)
    write_to_file(SAVE_FILENAME, sql_insert_trigger)
