#!/usr/bin/env bash

# Определение базового имени проекта
PROJECT_NAME_BASE="knp-tlbd-l"
# Определение директории для сборки
BUILD_DIR="build/"
# Удаление старых .deb файлов
rm -f $BUILD_DIR/*.deb

# Цикл для создания пакетов с разными метками (0 и 1)
for label_name in "0" "1" ; do
  # Формирование полного имени проекта
  PROJECT_NAME="$PROJECT_NAME_BASE$label_name"
  # Определение рабочей директории
  WORKING_DIR="/tmp/${PROJECT_NAME}"

  # Очистка рабочей директории
  rm -rf "${WORKING_DIR}"

  # Создание необходимых директорий
  mkdir -p "${WORKING_DIR}"
  mkdir -p "${BUILD_DIR}"

  # Копирование исходных файлов
  rsync -a postgresql/builder/src/ "${WORKING_DIR}"

  # Копирование основного SQL файла
  rsync -a postgresql/createtables_maclabel1.sql "${WORKING_DIR}/var/local/tlbd/tlbd/public.sql"

  # Копирование дополнительных SQL файлов
  mkdir -p "${WORKING_DIR}/var/local/tlbd/tlbd/knp_scripts"
  rsync -a postgresql/tldb_scripts/*.sql "${WORKING_DIR}/var/local/tlbd/tlbd/knp_scripts/"

  # Модификация файла control
  VERSION=$( date +%Y.%m.%d.%H.%M )
  sed -i "${WORKING_DIR}/DEBIAN/control"  \
      -e "s/%VERSION%/${VERSION}/g" \
      -e "s/Package: .*/Package: $PROJECT_NAME/g"

  # Удаление MAC-меток для пакета с меткой 0
  if [ "_$label_name" == "_0" ] ; then
    # Удаление MAC-меток из public.sql
    sed -i -e's/^MAC.*//' "${WORKING_DIR}/var/local/tlbd/tlbd/public.sql"

    # Удаление MAC-меток из всех файлов в knp_scripts
    find "${WORKING_DIR}/var/local/tlbd/tlbd/knp_scripts" -type f -name "*.sql" -print0 | xargs -0 sed -i -e's/^MAC.*//'
  fi

  # Установка флага IS_MAC_NEEDED в postinst скрипте
  sed -i "${WORKING_DIR}/DEBIAN/postinst" -e "s/^IS_MAC_NEEDED=.*/IS_MAC_NEEDED=$label_name/g"

  # Установка прав доступа
  chmod 775 -R ${WORKING_DIR}/

  # Сборка .deb пакета
  echo "${WORKING_DIR}/" "${BUILD_DIR}"
  dpkg-deb --build "${WORKING_DIR}/" "${BUILD_DIR}"

  # Очистка рабочей директории после сборки
  rm -rf "${WORKING_DIR}"
done
