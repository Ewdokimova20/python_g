#!/usr/bin/env bash

DB_NAME="tlbd"
DUMP_PATH="$(dirname "${0}")"

echo "  Creating ${DB_NAME}"
createdb ${DB_NAME}

for SCHEMA in public
do
    DUMP="${DUMP_PATH}/${SCHEMA}.sql"
    echo "    Creating ${SCHEMA} using ${DUMP}"
    psql --quiet ${DB_NAME} < ${DUMP}
done
