#!/usr/bin/env bash

set -e

# Выполнение команды без "мусора" в stderr
function exec_no_junk()
{
    local MESSAGE=$(${1} 2>&1)
    if [[ $? -ne 0 ]]; then
         echo ${MESSAGE}
         exit $?
    fi
}

exec_no_junk "dropdb --if-exists tlbd"