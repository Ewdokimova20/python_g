#!/usr/bin/env bash

make
sudo dpkg -i build/*
