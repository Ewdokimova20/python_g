#!/usr/bin/env python3
__version__ = '1.0.0'

if __name__ == '__main__':
    print(__version__)
