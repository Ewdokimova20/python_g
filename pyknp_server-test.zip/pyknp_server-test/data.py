"""Модуль хранения данных приложения

Модуль хранения данных приложения в ЛБД в памяти. Содержит
данные от сети БИС и из других источников и результаты расчета.

Написан на peewee
"""
from __future__ import annotations

import datetime
import json
import logging
from abc import abstractmethod
from collections import defaultdict
from math import sqrt, pi, ceil
from typing import Dict, Union, Optional, List, Any, TYPE_CHECKING

import peewee
from peewee import IntegerField, CharField, DateTimeField, ForeignKeyField, FloatField, \
    TextField, BooleanField, DoesNotExist, AutoField
from playhouse.hybrid import hybrid_property
from pymatrix import Matrix, MatrixError
from typing_extensions import Literal

import utils.signals.CD.L1OC
import utils.signals.CD.L1SC_L2SC
from global_data import appdata
from global_data.appdata import L1_FREQ_SIGNAL_TYPES, L2_FREQ_SIGNAL_TYPES, L1_CODE_SIGNAL_TYPES, \
    L2_CODE_SIGNAL_TYPES, L3_CODE_SIGNAL_TYPES, SPEED_OF_LIGHT, max_steps, BIS_NKA_DCB
from global_data.config_schema import config
from models.base import BaseModel, OperativeStorageModel
from models.bis import Bis
from models.di_string.l1oc_string import L1OCString
from models.di_string.l1of_string import L1OFString
from models.di_string.l1sf_string import L1SFString
from models.di_string.l2ksi_string import L2KSIString
from models.di_string.l2of_string import L2OFString
from models.di_string.l3oc_string import L3OCString
from models.di_string.sc_string import L2SCString, L1SCString
from models.immediateinfo import LFImmediateInfo, LCImmediateInfo
from models.knp_nav_solution import NavSolutionForClient
from models.meteoparams import Meteoparameters
from models.nka import Nka
from models.residual import ResidualForClient
from models.signal_type import SignalType
from models.station import Station
from scripts.process_registry import get_current_visibility
from utils.EI_consistency.EI_consistency import check_EI_with_neighbor_frame
from utils.SI.compare_si_to_di.manual_comparison_to_si.manual_comparison_to_si import manual_compare_to_si
from utils.SI.compare_si_to_di.types import TimeData
from utils.astro import current_celestial_state
from utils.coordinates.coordinates import Coordinates, CoordinatesENU
from utils.coordinates.nka_coordinates_calculation import nka_coordinates
from utils.immediate_info.get_immediate_info_cache import get_immediate_info
from utils.lib.exceptions import CompareDItoSIError, ResidualCalcError, LFImmediateInfoError, \
    LCImmediateInfoError, BisCacheError, MissingParamError
from utils.meteo_data.tropospheric_delay import tropospheric_delay
from utils.signals import FD, FD, CD
from utils.signals.FD.L1SF import L1SF_strings_pattern
from utils.visibility.current_visibility import get_nka_visibility
from utils.visibility.types import VisibilityStatus

if TYPE_CHECKING:
    from models.di_string.base_di_string import BaseDIString

__all__ = ['Nka',
           'Station',
           'Bis',
           'Signal',
           'Control',
           'CDSignalFrame',
           'L1OFString',
           'L2OFString',
           'L1SFString',
           'LFImmediateInfo',
           'LCImmediateInfo',
           'LCStableData',
           'Almanac',
           'NavSolution',
           'Residual',
           'Packet',
           'KNPNavSolution',
           'L1OFFrame',
           'L2OFFrame',
           'L1SFFrame',
           'L1OCString',
           'L3OCString',
           'L1SCString',
           'L2SCString',
           'L1OCFrame',
           'L3OCFrame',
           'L1SCFrame',
           'L2SCFrame',
           'lbd_tables_list',
           'OperativeStorageModel',
           'L2KSIString',
           'stable_data_cache',
           'SummarizedFramesInfo',
           'SummarizedFrameComparison',
           'CDSignalFrame',
           'BaseDIFrame'
           ]

logger = logging.getLogger('ldb_models')

ELEVATION_USE_THRESHOLD = datetime.timedelta(seconds=120)


class Signal(OperativeStorageModel):
    """Сигнал НКА.

    Сигнал, принятый БИС от НКА ГЛОНАСС. Должен содержать данные, передаваемые
    БИС в пакете односекундных измерений в соответствии с 14Ц181.4000-0 Д3.
    """
    id: int = peewee.AutoField(primary_key=True)
    """Идентификатор"""
    signal_type: SignalType = ForeignKeyField(
        SignalType, backref='signals', on_delete='CASCADE')
    """Тип сигнала"""
    nka: Nka = ForeignKeyField(Nka, backref='signals', on_delete='CASCADE')
    """НКА, от которого принят сигнал"""
    bis: Bis = ForeignKeyField(Bis, backref='signals', on_delete='CASCADE')
    """БИС, который принял сигнал"""
    timestamp: datetime.datetime = DateTimeField()
    """Время в секундах с 01.01.1970 с точностью до микросекунды"""
    nanoseconds: int = IntegerField(default=0)
    """Наносекунды для timestamp"""
    letter: int = IntegerField()
    """Литера"""
    snr: float = FloatField()
    """Отношение сигнал/шум, дБ"""
    pseudorange: float = FloatField()
    """Полная псевдодальность кодовых измерений, м"""
    pseudospeed: float = FloatField()
    """Псевдоскорость, м/с"""
    carrier_shift: float = FloatField()
    """Доплеровский сдвиг несущей частоты, Гц"""
    carrier_phase: float = FloatField()
    """Интегральная фаза несущей частоты, целая часть, циклы"""

    def __str__(self):
        return f"{str(self.signal_type)} {str(self.letter)} {str(self.nka)} {str(self.timestamp)} {str(self.pseudorange)}"

    def carrier_frequency(self) -> float:
        """Возвращает номинальную частоту сигнала в Гц"""
        if self.signal_type.signal_type_id in L1_FREQ_SIGNAL_TYPES:
            return 1602000000 + self.letter * 562500
        elif self.signal_type.signal_type_id in L2_FREQ_SIGNAL_TYPES:
            return 1246000000 + self.letter * 437500
        elif self.signal_type.signal_type_id in L1_CODE_SIGNAL_TYPES:
            return 1600995000
        elif self.signal_type.signal_type_id in L2_CODE_SIGNAL_TYPES:
            return 1248060000
        elif self.signal_type.signal_type_id in L3_CODE_SIGNAL_TYPES:
            return 1202025000
        else:
            raise ValueError("Неизвестный тип сигнала")

    def ionosphere_free_combination(self, other: Signal) -> float:
        gamma = (self.carrier_frequency() / other.carrier_frequency()) ** 2
        try:
            return (other.pseudorange - BIS_NKA_DCB[other.bis_id][other.nka_id][other.signal_type] -
                    gamma * (self.pseudorange - BIS_NKA_DCB[self.bis_id][self.nka_id][self.signal_type])) / (1 - gamma)
        except ZeroDivisionError:
            raise ValueError

    def phase_pseudorange(self):
        return self.carrier_phase * SPEED_OF_LIGHT / self.carrier_frequency()

    def pseudospeed_precise(self) -> float:
        """Возвращает псевдоскорость, расчитанную на основе доплеровского сдвига частоты"""
        return self.carrier_shift * (SPEED_OF_LIGHT / self.carrier_frequency())


class Control(OperativeStorageModel):
    """Результаты контроля НКА.

    Результаты контроля НКА со тороны БИС. Должен содержать данные, передаваемые
    БИС в пакете "Результаты контроля" в соответствии с 14Ц181.4000-0 Д3.
    """

    signal_type: SignalType = ForeignKeyField(
        SignalType, backref='controls', on_delete='CASCADE')
    """Тип сигнала"""
    nka: Nka = ForeignKeyField(Nka, backref='controls', on_delete='CASCADE')
    """Контролируемый НКА"""
    bis: Bis = ForeignKeyField(Bis, backref='controls', on_delete='CASCADE')
    """Контролирующий БИС"""
    timestamp: datetime.datetime = DateTimeField()
    """Время в секундах с 01.01.1970 с точностью до секунды"""
    letter: int = IntegerField()
    """Литера"""
    snr: int = FloatField()
    """Отношение сигнал/шум, дБ"""
    nka_status: int = IntegerField()
    """Состояние НКА"""
    nka_elevation: float = FloatField()
    """Угол места НКА, градус"""
    nka_azimuth: float = FloatField()
    """Азимут НКА, градус"""

    @hybrid_property
    def is_in_sigth(self) -> bool:
        """НКА в ЗРВ

        Флаг нахождения НКА в зоне радиовидимости по данным БИС. Определяется
        по слову Состояние НКА (nka_status)
        """
        return not bool((self.nka_status & 0b00000001))

    class Meta:
        indexes = (
            (('nka', 'bis'), False),
        )


class JSONStringIdListField(TextField):
    """Класс для записи структур в формате JSON в поля таблиц БД"""

    def db_value(self, value):
        """Преобразование списка строк в список Id строк и запись структуры в формат JSON"""
        id_list = []
        if value:
            for string in value:
                id_list.append(string.id)
        return value if value is None else json.dumps(id_list)

    def python_value(self, value):
        """Преобразование записи из поля в базе в структуру списка id строк"""
        return value if value is None else json.loads(value)


class BaseDIFrame(OperativeStorageModel):
    """Кадр ЦИ"""

    signal_type = None
    """Тип сигнала"""

    @abstractmethod
    def get_timebind(self, frame_data) -> TimeData:
        pass

    @abstractmethod
    def get_tb(self):
        """Возвращает tb из оперативной информации для сравнения ЭИ в ЦИ на соседних интервалах"""
        pass

    @abstractmethod
    def control_tk(self):
        """Контроль соответствия значений оцифровки метки времени в принятой ЦИ текущему времени"""
        pass

    @abstractmethod
    def control_tb(self):
        """Контроль соответствия значений tk текущему tb,
        для сравнения только по времени год, месяц и дата устанавливаются в 1"""
        pass

    def get_param_from_string_or_none(self, string_num: int, key: str) -> Optional[Any]:
        """
        Безопасно получить значение параметра key из содержимого строки с номером string_num. Если что-то не вышло, вернут None
        Например, string_num=10 соответствует атрибуту self.string10.
        """
        string_attr = f'string{string_num}'
        string_obj: Optional[BaseDIString] = getattr(self, string_attr, None)

        if string_obj is None:
            return None
        return string_obj.get_param_or_none(key)

    def get_param_from_string(self, string_num: int, key: str) -> Any:
        """
        Получить значение параметра key из строки string_num. Кидает исключение, если строка/параметр отсутствует.
        """
        string_attr = f'string{string_num}'
        string_obj: Optional[BaseDIString] = getattr(self, string_attr, None)
        if string_obj is None:
            raise MissingParamError(f"Строка '{string_attr}' отсутствует в кадре {self.__class__.__name__} (id: {self.id})")
        return string_obj.get_param(key)  # Это вызовет исключение, если параметр не найден

    @abstractmethod
    def tb_to_datetime(self, tb: int, N: int, N4: int) -> Optional[datetime]:
        """Преобразовать параметры N4, N, tb в datetime."""
        pass

    @abstractmethod
    def _extract_time_params(self) -> tuple[Optional[int], Optional[int], Optional[int]]:
        """Вернуть (N4, Nt, tb). Любое может быть None, если нет данных."""
        pass

    def datetime_from_tb(self) -> Optional[datetime]:
        """Получить привязку кадра в формате дата-время по его параметрам"""
        tb, Nt, N4 = self._extract_time_params()
        if tb is not None:
            return self.tb_to_datetime(tb=tb, N=Nt, N4=N4)
        return None

    def parse_frame(self) -> Dict[str, Dict[str | int, str | int | dict]]:
        """Функция для получения данных из кадра в форме словаря и времени кадра."""
        frame_data: Dict[str, Dict[Union[str, int], Union[str, int, dict]]] = {}
        try:
            frame_data = self.as_long_dict()
        except Exception:
            pass
        if not frame_data:
            raise CompareDItoSIError(f'Не определены данные в формате словаря для кадра {str(self)}.')
        return frame_data

    def compare_to_SI(self) -> Optional[Dict[str, dict]]:
        """Сравнить данные из кадра с данными из СИ"""
        is_cd_frame = True if isinstance(self, CDSignalFrame) else False
        return manual_compare_to_si(self, is_cd_frame)

    def get_coords_on_tb_border(self, delta) -> dict:
        """Возвращает координаты, скорость и ускорение из эфемерид"""

        def coordinates_from_frame() -> Coordinates:
            """Возвращает координаты, скорость и ускорение из эфемерид"""
            frame_data = self.as_long_dict()
            xyz = Coordinates.XYZ(
                x=frame_data['x']['val'], y=frame_data['y']['val'], z=frame_data['z']['val'])
            vel = Coordinates.Vxyz(
                Vx=frame_data['Vx']['val'], Vy=frame_data['Vy']['val'], Vz=frame_data['Vz']['val'])
            acc = Coordinates.Axyz(
                Ax=frame_data['Ax']['val'], Ay=frame_data['Ay']['val'], Az=frame_data['Az']['val'])
            return Coordinates(xyz=xyz, vel=vel, acc=acc)

        coords = coordinates_from_frame()
        frame_timestamp = self.datetime_from_tb()
        coords_on_border = nka_coordinates(self.nka.nka_sys_number,
                                           coords, frame_timestamp, frame_timestamp + delta)

        return dict(
            x=coords_on_border.xyz.x,
            y=coords_on_border.xyz.y,
            z=coords_on_border.xyz.z,
            Vx=coords_on_border.vel.Vx,
            Vy=coords_on_border.vel.Vy,
            Vz=coords_on_border.vel.Vz,
            Ax=coords_on_border.acc.Ax,
            Ay=coords_on_border.acc.Ay,
            Az=coords_on_border.acc.Az,
            tb=self.datetime_from_tb()
        )

    def get_ephemeris_info(self):
        """Выделить эфемериды из кадра"""
        ephemeris = {}
        difital_info = self.as_long_dict()
        ephemeris_keys = ['x', 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az']
        for k, v in difital_info.items():
            if k in ephemeris_keys:
                ephemeris[k] = v['val']

        return ephemeris

    def get_frame_time(self):
        """Получить tk(time) кадра"""
        tk = self.tk if hasattr(self, 'tk') else getattr(self, 'time', None)
        return tk

    def check_EI_with_neighbor(self, neighbor_type: Literal['previous', 'next']):
        """Проверить согласованность ЭИ на соседних tk"""

        return check_EI_with_neighbor_frame(self, neighbor_type)

    def __str__(self):
        return f'{self.__class__.__name__}, сигнал: {self.signal_type},  id: {self.id}, НКА: {self.nka_id}, БИС: {self.bis_id}, timestamp: {self.timestamp}'


class CDSignalFrame(BaseDIFrame):
    """Кадры ЦИ с кодовым разделением"""

    string_type = None
    """Класс типа строки, для которого описан кадр. Необходим для запроса строк соответствующего типа"""

    nka: Nka = ForeignKeyField(Nka, on_delete='CASCADE')
    """НКА, для которого собран кадр"""
    bis: Bis = ForeignKeyField(Bis, on_delete='CASCADE', null=True)
    """БИС, который собрал кадр"""
    seq: int = IntegerField()
    """Порядковый номер кадра в сутках (0 если значение не определено)"""
    time: int = IntegerField()
    """Время начала кадра в секундах с начала суток"""
    is_complete: bool = BooleanField(default=True)
    """Все ли строки псевдокадра присутствуют (независимо от их целостности)"""
    timestamp: datetime.datetime = DateTimeField()
    """Номинальное время излучения первой строки кадра"""

    # поле не для сохранения в ТЛБД (необходимо для оценки полноты кадра)
    pseudoframe_length: int = 0

    @property
    @abstractmethod
    def immediate_strings(self):
        """Список строк с оперативной информацией, которые открывают псевдокадр. Для переопределения
        Ожидается List[self.string_type]"""
        raise NotImplementedError

    @property
    @abstractmethod
    def nonimmediate_strings(self):
        """Остальные типы строк. Для переопределения
        Ожидается List[self.string_type]"""
        raise NotImplementedError

    @property
    def is_immediate_complete(self):
        """Полная ли оперативная информация"""
        return bool(self.string10 and self.string11 and self.string12)

    @property
    def is_immediate_valid(self):
        """Проверка, что все строки из оперативной информации присутствуют и не содержат ошибок"""
        try:
            return all(s is not None and not s.error_in_string for s in self.immediate_strings)
        except AttributeError:
            # Если у какой-то строки нет свойства error_in_string или immediate_strings нет
            return False

    def meta_as_dict(self):
        tb = self.get_tb()
        return {'frame_id': self.id,
                'bis_id': self.bis_id,
                'sources': None,
                'station_id': getattr(self.bis, 'station_id', None),
                'nka': self.nka_id,
                'tk': self.time,
                'seq': self.seq,
                'is_complete': self.is_complete,
                'timestamp': self.timestamp,
                'db_timestamp': self.db_timestamp,
                'tk_time_format': self.timestamp.strftime("%H:%M:%S"),
                'tb_time_format': CD.common.tb_to_datetime(tb).strftime("%H:%M:%S") if tb is not None else None}

    def get_strings_from_ldb(self, di_string: list):
        """Метод для обработки списков идентификаторов строк в список строк из ЛБД"""
        strings_list = []
        for string_id in di_string:  # для каждого идентификатора запрашиваем строку
            if string_id:
                string = self.string_type.get_or_none(
                    self.string_type.id == string_id)
                if string:
                    strings_list.append(string)
        return strings_list

    def get_all_strings(self):
        """Метод для получения списка всех строк"""
        strings_oi = self.immediate_strings
        strings_id = self.nonimmediate_strings

        # если есть int, то превращаем в list и удаляем None
        strings_id = [[id] if isinstance(
            id, int) else id for id in strings_id if id is not None]
        strings_id_list = []
        # объединяем nested list в list
        [strings_id_list.extend(sublst) for sublst in strings_id if sublst]
        strings_list = self.get_strings_from_ldb(strings_id_list)
        all_strings = strings_oi + strings_list
        return all_strings

    def as_dict(self):
        """Представление содержимого псевдокадра в виде набора значений параметров из его строк"""

        all_strings = self.get_all_strings()
        strings = []
        string_errors: dict = {}
        for i, string in enumerate(all_strings):
            if string:
                if hasattr(string, 'as_dict'):
                    string_dict = string.as_dict()
                    if string_dict:
                        strings.append(string_dict)
                        string_errors[len(strings) - 1] = string.error_in_string

        return {'meta': {**self.meta_as_dict(),
                         'string_errors': string_errors
                         },
                'content': strings}

    def as_long_dict(self):
        """Представление содержимого псевдокадра в виде набора значений параметров, который включает альманаха"""

        all_strings = self.get_all_strings()
        result = {}
        alm = {}
        alm_string_num = 20  # строка в которой передается альманах
        for string in reversed(all_strings):
            if string:
                if string.string_num != alm_string_num:
                    if hasattr(string, 'as_dict'):
                        string = string.as_dict()
                        if string:
                            for par_name, par_val in string.items():
                                result[par_name] = par_val
                else:  # заполняем параметры альманаха
                    if hasattr(string, 'as_dict'):
                        string = string.as_dict()
                        nka_num = string.get('ja', {}).get('val', None)
                        if string and nka_num:
                            alm[nka_num] = {}
                            for par_name, par_val in string.items():
                                alm[nka_num][par_name] = par_val
        result['alm'] = alm
        return result

    def get_timebind(self, frame_data) -> TimeData:
        Na = {nka_num.get('Na', {}).get('val', None)
              for nka_num in frame_data.get('alm', {}).values()}
        time = TimeData(timestamp=self.timestamp,
                        tb=frame_data.get('tb', {}).get('val', None),
                        N=frame_data.get('Nt', {}).get('val', None),
                        Na=Na,
                        tb_timestamp=self.datetime_from_tb(),
                        N4=frame_data.get('N4', {}).get('val'),
                        tk=frame_data.get('OMB', {}).get('val'))
        if isinstance(time.tb, (int, float)):
            # перевод из секунд в 15-минутные интервалы
            time.tb = ceil(time.tb // (60 * 15))
        return time

    def get_tb(self):
        """Возвращает tb из оперативной информации для сравнения ЭИ в ЦИ на соседних интервалах"""
        try:
            tb = self.string10.content[0]['tb']
        except (AttributeError, KeyError, IndexError, DoesNotExist) as e:
            logger.debug(f'Ошибка при обращении к tb в 10 строке кадра {self.__str__()}: {str(e)}')
            return None
        return tb

    def tb_to_datetime(self, tb: int, N: int, N4: int) -> Optional[datetime]:
        """Преобразовать параметры N4, N, tb в datetime."""
        try:
            return CD.common.tb_to_datetime(N4=N4, N=N, tb=tb)
        except Exception:
            return None

    def _extract_time_params(self):
        N4 = self.get_param_from_string_or_none(10, 'N4')
        Nt = self.get_param_from_string_or_none(10, 'Nt')
        tb = self.get_param_from_string_or_none(10, 'tb')
        return tb, Nt, N4

    def control_tk(self):
        """Контроль соответствия значений оцифровки метки времени в принятой ЦИ текущему времени"""
        try:
            error_in_string_with_tk = self.string10.error_in_string
        except AttributeError:
            pass
        else:
            if not error_in_string_with_tk:
                time_now = datetime.datetime.now()
                if abs(time_now - self.timestamp) > datetime.timedelta(seconds=config['di_control']['tk_difference']):
                    return int((self.timestamp).timestamp())
        return 0

    def control_tb(self):
        """Контроль соответствия значений tk текущему tb"""
        try:
            error_in_string_with_tb_tk = self.string10.error_in_string
        except AttributeError:
            pass
        else:
            if not error_in_string_with_tb_tk:
                tb = self.get_tb()
                if tb is not None:
                    # для сравнения без учета даты, для tk и tb установлена одинаковая дата 01.01.2000
                    tb_time_format = ((CD.common.tb_to_datetime(tb)).replace(
                        year=2000, month=1, day=1, microsecond=0))
                    tk_time_format = self.timestamp.replace(
                        year=2000, month=1, day=1, microsecond=0)
                    time_delta = datetime.timedelta(minutes=15)
                    if tb_time_format is not None:
                        if not (tb_time_format - time_delta <= tk_time_format <= tb_time_format + time_delta):
                            return tb
        return 0


class L1OCFrame(CDSignalFrame):
    """Кадр ЦИ L1OC"""

    signal_type = appdata.SIGNALS_NAME["L1OCd"]
    """Тип сигнала"""

    string_type = L1OCString
    """Класс строки кадра"""

    string10: L1OCString = ForeignKeyField(
        L1OCString, backref='l1oc_frames10', on_delete='CASCADE', null=True)
    string11: L1OCString = ForeignKeyField(
        L1OCString, backref='l1oc_frames11', on_delete='CASCADE', null=True)
    string12: L1OCString = ForeignKeyField(
        L1OCString, backref='l1oc_frames12', on_delete='CASCADE', null=True)
    string13: L1OCString = None
    string20: L1OCString = JSONStringIdListField(L1OCString)
    string25: L1OCString = JSONStringIdListField(L1OCString)
    string16: L1OCString = JSONStringIdListField(L1OCString)
    string31: L1OCString = JSONStringIdListField(L1OCString)
    string32: L1OCString = JSONStringIdListField(L1OCString)
    string50: L1OCString = JSONStringIdListField(L1OCString)
    string60: L1OCString = JSONStringIdListField(L1OCString)
    string0: L1OCString = JSONStringIdListField(L1OCString)
    # string1: L1OCString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    # string2: L1OCString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other: L1OCString = JSONStringIdListField(L1OCString)

    @property
    def immediate_strings(self):
        """Список строк с оперативной информацией, которые открывают псевдокадр"""
        return [self.string10, self.string11, self.string12]

    @property
    def nonimmediate_strings(self):
        """Остальные типы строк"""
        return [self.string20, self.string25, self.string16,
                self.string31, self.string32, self.string50, self.string60,
                self.string0, self.string_other,
                # self.string1, self.string2 # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
                ]


class L3OCFrame(CDSignalFrame):
    """Кадр ЦИ L3OC"""

    signal_type = appdata.SIGNALS_NAME["L3OCd"]
    """Тип сигнала"""

    string_type = L3OCString
    """Класс строки кадра"""

    string10: L3OCString = ForeignKeyField(
        L3OCString, backref='l3oc_frames10', on_delete='CASCADE', null=True)
    string11: L3OCString = ForeignKeyField(
        L3OCString, backref='l3oc_frames11', on_delete='CASCADE', null=True)
    string12: L3OCString = ForeignKeyField(
        L3OCString, backref='l3oc_frames12', on_delete='CASCADE', null=True)
    string13: L3OCString = None
    string20: L3OCString = JSONStringIdListField(L3OCString)
    string25: L3OCString = JSONStringIdListField(L3OCString)
    string16: L3OCString = JSONStringIdListField(L3OCString)
    string31: L3OCString = JSONStringIdListField(L3OCString)
    string32: L3OCString = JSONStringIdListField(L3OCString)
    string60: L3OCString = JSONStringIdListField(L3OCString)
    string0: L3OCString = JSONStringIdListField(L3OCString)
    # string1: L3OCString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    # string2: L3OCString = None  # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
    string_other: L3OCString = JSONStringIdListField(L3OCString)

    @property
    def immediate_strings(self):
        """Список строк с оперативной информацией, которые открывают псевдокадр"""
        return [self.string10, self.string11, self.string12]

    @property
    def nonimmediate_strings(self):
        """Остальные типы строк"""
        return [self.string20, self.string25, self.string16,
                self.string31, self.string32, self.string60,
                self.string0, self.string_other,
                # self.string1, self.string2 # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
                ]


def create_scframe_child(string_class, name='', signal_type_id: int = 0):
    """Ф-я возврата типа данных строк с кодовым разделением (типогенератор)"""

    class CDSignalFrameChild(CDSignalFrame):
        """Кадр ЦИ сигнала с кодовым разделением с санкционированным доступом"""

        signal_type = signal_type_id
        """Тип сигнала"""

        string_type = string_class
        """Класс строки кадра"""

        string10: string_class = ForeignKeyField(string_class, backref=f'{name.lower()}_frames10',
                                                 on_delete='CASCADE', null=True)
        string11: string_class = ForeignKeyField(string_class, backref=f'{name.lower()}_frames11',
                                                 on_delete='CASCADE', null=True)
        string12: string_class = ForeignKeyField(string_class, backref=f'{name.lower()}_frames12',
                                                 on_delete='CASCADE', null=True)
        string13: string_class = ForeignKeyField(string_class, backref=f'{name.lower()}_frames13',
                                                 on_delete='CASCADE', null=True)
        string20: string_class = JSONStringIdListField(string_class)
        string25: string_class = JSONStringIdListField(string_class)
        string16: string_class = JSONStringIdListField(string_class)
        string31: string_class = JSONStringIdListField(string_class)
        string32: string_class = JSONStringIdListField(string_class)
        string60: string_class = JSONStringIdListField(string_class)
        string0: string_class = JSONStringIdListField(string_class)
        string_other: string_class = JSONStringIdListField(string_class)

        class Meta:
            table_name = name

        @property
        def immediate_strings(self):
            """Список строк с оперативной информацией, которые открывают псевдокадр"""
            return [self.string10, self.string11, self.string12, self.string13]

        @property
        def nonimmediate_strings(self):
            """Остальные типы строк"""
            return [self.string20, self.string25, self.string16,
                    self.string31, self.string32, self.string60,
                    self.string0, self.string_other,
                    # self.string1, self.string2 # TODO скорректировать после реализации для всех видов пакетов кодограмм обработки аномальных строк
                    ]

        @property
        def is_immediate_valid(self):
            """Проверка, что все строки 10, 11 и 12 (без 13) из оперативной информации присутствуют и не содержат ошибок"""
            try:
                return all(s is not None and not s.error_in_string for s in [self.string10, self.string11, self.string12])
            except AttributeError:
                # Если у какой-то строки нет свойства error_in_string
                return False

    return CDSignalFrameChild


L1SCFrame = create_scframe_child(
    L1SCString, 'l1scframe', appdata.SIGNALS_NAME["L1SCd"])
L2SCFrame = create_scframe_child(
    L2SCString, 'l2scframe', appdata.SIGNALS_NAME["L2SCd"])


# deprecated
class Ephemeris(OperativeStorageModel):
    """Рассчитанные эфемериды НКА"""
    nka: Nka = ForeignKeyField(Nka, backref='ephemerides', on_delete='CASCADE')
    """НКА, для которого собраны эфемериды"""
    x: float = FloatField()
    """X-координата НКА в системе координат ПЗ-90.02 на момент времени t, м"""
    y: float = FloatField()
    """Y-координата НКА в системе координат ПЗ-90.02 на момент времени t, м"""
    z: float = FloatField()
    """Z-координата НКА в системе координат ПЗ-90.02 на момент времени t, м"""
    Vx: float = FloatField()
    """X-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени t, м/с"""
    Vy: float = FloatField()
    """Y-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени t, м/с"""
    Vz: float = FloatField()
    """Z-составляющая вектора скорости НКА в системе координат ПЗ-90.02 на момент времени t, м/с"""
    Ax: float = FloatField()
    """X-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени t, м/с^2"""
    Ay: float = FloatField()
    """Y-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени t, м/с^2"""
    Az: float = FloatField()
    """Z-составляющая вектора ускорения НКА в системе координат ПЗ-90.02 на момент времени t, м/с^2"""
    t: datetime.datetime = DateTimeField()
    """Время, на которое даны эфемериды"""


class Almanac(OperativeStorageModel):
    nka: int = IntegerField()
    """НКА, положение которого описывается данным слотом альманаха"""
    source_nka: int = IntegerField()
    """НКА-источник поступления содержимого слота альманаха"""
    source_signal: int = IntegerField()
    """Сигнал-источник поступления содержимого слота альманаха"""
    N_A: int = IntegerField()
    """Календарный номер суток внутри четырехлетнего периода, начиная с високосного года, к которым относятся поправка 
    tau_s и данные альманаха системы (альманах орбит и альманах фаз)"""
    N4: int = IntegerField()
    """Номер четырехлетнего периода, первый год первого четырехлетия соответствует 1996 году"""
    approve_count: int = IntegerField()
    """Счетчик подтверждения содержимого данного слота с различных НКА"""

    # время прохождения восходящего узла, ближайшее к началу суток, полуцикл
    Tlambda_A: float = FloatField()
    # отклонение периода от номинала 40544, с (для кодовых пересчитывается из 43200)
    deltaT_A: float = FloatField()
    # отклонение наклонения от номинала 64.8 градуса (для кодовых пересчитывается 63)
    deltaI_A: float = FloatField()
    deltaTdot: float = FloatField()  # скорость изменения периода, б/р
    e_A: float = FloatField()  # эксцентриситет, б/р
    omega_A: float = FloatField()  # аргумент перигея, полуциклы
    lambda_A: float = FloatField()  # долгота восходящего узла, полуциклы

    def as_dict(self):
        return {'slot_nka': self.nka,
                'source_nka': self.source_nka,
                'source_signal': self.source_signal,
                'N_A': self.N_A,
                'N4': self.N4,
                'approve_count': self.approve_count,
                'Tlambda_A_hc': self.Tlambda_A,
                'deltaT_A': self.deltaT_A,
                'deltaTdot': self.deltaTdot,
                'e_A': self.e_A,
                'omega_A_hc': self.omega_A,
                'lambda_A_hc': self.lambda_A}

    class Meta:
        indexes = (
            (('nka', 'N_A', 'N4',), True),
        )


class LCStableData(BaseModel):
    """Чрезвычайно редко изменяющиеся данные кодовых сигналов."""

    nka: Nka = ForeignKeyField(
        Nka, backref='lcstabledata', on_delete='CASCADE')
    """НКА, для которого собраны эфемериды"""
    signal_type_id: int = IntegerField()
    """Код сигнала"""
    r: float = FloatField()
    """от центра Земли до ЦМ КА, м"""
    b: float = FloatField()
    """правая тройка к двум другим, м"""
    n: float = FloatField()
    """на Солнце, м"""
    dt: float = FloatField()
    """Задержка между сигналами, привязанная и интерпретируемая в зависимости от конкретного сигнала, с"""
    db_timestamp: datetime.datetime = DateTimeField(
        default=datetime.datetime.now)
    """Время записи в БД"""

    class Meta:
        indexes = (
            (('nka', 'signal_type_id'), True),
        )


stable_data_cache = defaultdict(dict)
"""Двухуровневый словарь с перечнем стабильных характеристик НКА
Первый уровень - номер НКА, второй - идентификатор сигнала"""


def get_stable_data(nka, signal_id: int) -> LCStableData:
    nka_id = nka.nka_sys_number
    # Указываем альтернативные источники получения стабильных данных
    signal_id = 0x16 if signal_id == 0x56 else signal_id  # заменяем L3OCp на L3OCd
    signal_id = 0x06 if signal_id == 0x46 else signal_id  # заменяем L1OCp на L1OCd
    signal_id = 0x26 if signal_id == 0x66 else signal_id  # заменяем L1SCp на L1SCd
    signal_id = 0x2E if signal_id == 0x6E else signal_id  # заменяем L2SCp на L2SCd
    # заменяем L2OCp на L3OCd т.к. он скорее будет
    signal_id = 0x16 if signal_id == 0x4E else signal_id
    # заменяем L2КСИ на L3OCd т.к. он скорее будет
    signal_id = 0x16 if signal_id == 0x0E else signal_id
    # Проверяем, есть ли данные для данного nka в кэше
    if signal_id in stable_data_cache[nka_id]:
        return stable_data_cache[nka_id][signal_id]
    else:
        # Если данных нет в кэше, делаем запрос к БД и сохраняем результат в кэше
        stable_data = LCStableData.select().where(
            (LCStableData.nka == nka) & (LCStableData.signal_type_id == signal_id)) \
            .order_by(LCStableData.id.desc()).get()
        stable_data_cache[nka_id][signal_id] = stable_data
        return stable_data


class Residual(OperativeStorageModel):
    """Модель невязки"""

    id = AutoField()
    """id Невязки (соответствует столбцу id)"""
    bis: Bis = ForeignKeyField(Bis, backref='residuals', on_delete='CASCADE')
    """БИС, для которого посчитаны невязки"""
    nka: Nka = ForeignKeyField(Nka, backref='residuals', on_delete='CASCADE')
    """НКА, для которого посчитаны невязки"""
    signal_1: int = IntegerField(default=None, null=True)
    """Первый тип сигнала"""
    signal_2: int = IntegerField(default=None, null=True)
    """Второй тип сигнала"""
    residual: float = FloatField()
    """Величина невязки по паре сигналов"""
    residual1: float = FloatField()
    """Величина невязки по первому сигналу из пары"""
    residual2: float = FloatField()
    """Величина невязки по второму сигналу из пары"""
    speed_residual: float = FloatField()
    """Величина невязки псевдоскорости, м/с"""
    average: float = FloatField(default=None, null=True)
    """Среднее по 'хорошим' невязкам"""
    delta: float = FloatField(default=None, null=True)
    """Отклонение от среднего"""
    delta1: float = FloatField(default=None, null=True)
    """Отклонение от среднего неязки по первому сигналу из пары"""
    delta2: float = FloatField(default=None, null=True)
    """Отклонение от среднего невязки по второму сигналу из пары"""
    status: bool = BooleanField(default=False)
    """Статус признания 'хорошей' невязкой по критерию разницы со средней"""
    y_comb_1: float = FloatField(null=True, default=None)
    """Y-комбинация по сигналу 1"""
    y_comb_2: float = FloatField(null=True, default=None)
    """Y-комбинация по сигналу 2"""
    distance: float = FloatField()
    """Рассчетная дальность от БИС до НКА"""
    ionosphere_free_combination: float = FloatField(null=True, default=None)
    """Безионосферная комбинация"""
    tropo_delay: float = FloatField()
    """Тропосферная задержка"""
    time_freq_correction: float = FloatField()
    """Частотно-временная поправка (?)"""
    signal1_pseudorange: float = FloatField()
    """Псевдодальность по сигналу 1"""
    signal2_pseudorange: float = FloatField(null=True, default=None)
    """Псевдодальность по сигналу 2"""
    nka_x: float = FloatField(default=0)
    """x-координата НКА"""
    nka_y: float = FloatField(default=0)
    """y-координата НКА"""
    nka_z: float = FloatField(default=0)
    """z-координата НКА"""
    nka_elevation: float = FloatField(default=0)
    """Угол места НКА на момент получения сигнала, градусы"""
    nka_in_guaranteed_elevation: bool = BooleanField(default=True)
    """НКА находится на угле места гарантированного приема"""
    signal_is_untrusted: bool = BooleanField(default=True)
    """В сигнале выставлен признак недостоверности навигационного сигнала или навигационного кадра"""
    rejected_due_to_deviation: bool = BooleanField(default=False)
    """Невязка отбракована согласно раздела 6 ГОСТ 8.736-2011"""
    timestamp: datetime.datetime = DateTimeField()
    """Время, на которое рассчитана невязка"""

    @classmethod
    def from_signals(cls, signal1: Union[Signal, None] = None, signal2: Union[Signal, None] = None) -> Residual:
        """Рассчитывает и записывает в ЛБД невязки по переданным сигнала
        Возвращает id невязки в lbd"""

        # Если НКА излучает L2КСИ, L2OCp, L2SCd, L2SCp, но не излучает парные им сигналы в диапазоне L1
        # то считаем невязку по второму сигналу, но записываем несуществующий первый как основной
        if not signal1:
            if signal2 and signal2.signal_type.signal_type_id in [0x0E, 0x4E, 0x2E, 0x6E]:
                # меняем местами (вернем назад перед записью) и считаем как одночастотый
                signal2, signal1 = signal1, signal2
            else:
                raise ResidualCalcError

        try:
            if signal2 and (signal1.nka.nka_sys_number != signal2.nka.nka_sys_number or
                            signal1.bis.id != signal2.bis.id):
                raise ResidualCalcError("Нельзя посчитать невязку для разных НКА и/или БИС")
            nka = signal1.nka
            bis = signal1.bis
            bis_coordinates = bis.coordinates

            immediate = get_immediate_info(nka.nka_sys_number, signal1.signal_type.signal_type_id)

            timestamp = signal1.timestamp

            if signal2:
                ionosphere_free_combination = signal1.ionosphere_free_combination(signal2)
                pseudorange = ionosphere_free_combination
            else:
                ionosphere_free_combination = None
                pseudorange = signal1.pseudorange

            try:
                nka_coordinates_lf, nka_coordinates_lc = appdata.NKA_coordinates[signal1.bis.id][
                    signal1.nka.nka_sys_number]
            except KeyError as e:
                raise ResidualCalcError(
                    f'Координаты НКА {signal1.nka.nka_sys_number} отсутствуют в кэше невязок. '
                    f'Пропускаем расчет невязки: {str(e)}')

            # явно маркируем проблемные (нулевые) координаты как отсутствующие/недостоверные
            if nka_coordinates_lf and (nka_coordinates_lf.xyz.x == 0) and (nka_coordinates_lf.xyz.y == 0) and (
                    nka_coordinates_lf.xyz.z == 0):
                nka_coordinates_lf = None
            if nka_coordinates_lc and (nka_coordinates_lc.xyz.x == 0) and (nka_coordinates_lc.xyz.y == 0) and (
                    nka_coordinates_lc.xyz.z == 0):
                nka_coordinates_lc = None

            nka_coordinates = None
            # выбираем ОИ надлежащего источника для определение точки излучения
            if nka_coordinates_lf and (signal1.signal_type.signal_type_id in appdata.FREQ_SIGNAL_TYPES):
                nka_coordinates = nka_coordinates_lf
            if nka_coordinates_lc and (signal1.signal_type.signal_type_id not in appdata.FREQ_SIGNAL_TYPES):
                # получаем данные для учета смещения ФЦА
                signal_data = get_stable_data(nka, signal1.signal_type.signal_type_id)
                # определяем с учетом положения Солнца  где ФЦА относительно ЦМ
                nka_xyz = current_celestial_state.get_emmit_point(nka_mass_center=nka_coordinates_lc.xyz,
                                                                  fca_offset=Coordinates.XYZ(x=signal_data.r,
                                                                                             y=signal_data.b,
                                                                                             z=signal_data.n))
                # заменяем положение ЦМ на положение ФЦА
                nka_coordinates = Coordinates(xyz=nka_xyz, vel=nka_coordinates_lc.vel, acc=nka_coordinates_lc.acc)

            if nka_coordinates is None:
                raise ValueError

            distance = bis_coordinates.distance(nka_coordinates)
            tdelta = datetime.timedelta(microseconds=distance * 1000000 / SPEED_OF_LIGHT)
            time_freq_correction = immediate.time_freq_correction(current_time=timestamp - tdelta)

            # Угол места берем из существующих расчётов. Если там нет угла места, то считаем заново
            current_visibility = get_current_visibility()
            try:
                _, elevation_angle_grad, _ = current_visibility.angles[bis.station][nka.nka_sys_number]
            except (AttributeError, KeyError, ValueError):
                try:
                    elevation_angle_grad = bis.coordinates.elevation_grad(nka_coordinates.xyz)
                except ZeroDivisionError:
                    elevation_angle_grad = 0

            """Определение гарантированности видимости КА по порогу угла места"""
            visibility_status = current_visibility.get_status(bis.station.station_number, nka.nka_sys_number)
            if visibility_status == VisibilityStatus.UNDEFINED:
                nka_in_guaranteed_elevation = get_nka_visibility(bis.station.station_number,
                                                                 elevation_angle_grad) >= VisibilityStatus.GUARANTEED
            else:
                nka_in_guaranteed_elevation = visibility_status >= VisibilityStatus.GUARANTEED

            """Расчет тропосферной задержки, [м], по текущей модели"""
            tropo_delay = tropospheric_delay(bis.id, elevation_angle_grad / 180 * pi, timestamp) \
                if config['bis_control']['use_troposphere_model'] else 0.0

            """Расчет невязки для основного сигнала без учета ШВ БИС"""
            residual = distance - (pseudorange - tropo_delay - time_freq_correction)

            # вычисляем проекцию скорости НКА на линию, соединяющую ФЦА БИС-НКА
            # Вычисляем матрицу преобразования в соответствии с п.11 р.3 МВРЕ.00042-01 13 01-1
            # объявляем вектор-строку коэффициентов-ортов
            a1 = (bis_coordinates.xyz.x - nka_coordinates.xyz.x) / distance
            a2 = (bis_coordinates.xyz.y - nka_coordinates.xyz.y) / distance
            a3 = (bis_coordinates.xyz.z - nka_coordinates.xyz.z) / distance
            # ... а вектор-столбец скоростей берем непосредственно из результата размножения эфемерид КА
            speed_calculated = (a1 * nka_coordinates.vel.Vx) + (a2 * nka_coordinates.vel.Vy) + (
                    a3 * nka_coordinates.vel.Vz)
            # Расчет невязки пседоскорости (согласно файлу Расчет_невязок_псевдоскорости.docx)
            # Для справки: предельный вклад гамма-компонента на границе ОДЗ: 0,279 м/с, типовой: 0,003 м/с
            speed_residual = speed_calculated - signal1.pseudospeed_precise() + (immediate.gamma * SPEED_OF_LIGHT)

            if signal2:
                signal1_c_f = signal1.carrier_frequency()
                signal2_c_f = signal2.carrier_frequency()
                sqr_signal2_c_f = signal2_c_f * signal2_c_f
                signal1_ph_psr = signal1.phase_pseudorange()
                signal2_ph_psr = signal2.phase_pseudorange()

                y_add = (signal2_ph_psr - signal1_ph_psr) * 2 * sqr_signal2_c_f / (
                        signal1_c_f * signal1_c_f - sqr_signal2_c_f)

                y_comb_1 = signal1.pseudorange - signal1_ph_psr + y_add
                y_comb_2 = signal2.pseudorange - signal2_ph_psr + y_add
            else:
                y_comb_1, y_comb_2 = (None, None)

            s2_pseudorange = None
            signal2_type = None
            signal1_type = signal1.signal_type.signal_type_id
            if signal2:
                s2_pseudorange = signal2.pseudorange
                signal2_type = signal2.signal_type.signal_type_id
                residual_signal1 = distance - (signal1.pseudorange - tropo_delay - time_freq_correction)
                residual_signal2 = distance - (s2_pseudorange - tropo_delay - time_freq_correction)
            else:
                residual_signal1 = residual
                residual_signal2 = None

            residual = cls(bis=bis,
                           nka=nka,
                           signal_1=signal1_type,
                           signal_2=signal2_type,
                           residual=residual,
                           residual1=residual_signal1,
                           residual2=residual_signal2,
                           speed_residual=speed_residual,
                           y_comb_1=y_comb_1,
                           y_comb_2=y_comb_2,
                           distance=distance,
                           ionosphere_free_combination=ionosphere_free_combination,
                           tropo_delay=tropo_delay,
                           time_freq_correction=time_freq_correction,
                           signal1_pseudorange=signal1.pseudorange,
                           signal2_pseudorange=s2_pseudorange,
                           nka_x=nka_coordinates.xyz.x,
                           nka_y=nka_coordinates.xyz.y,
                           nka_z=nka_coordinates.xyz.z,
                           nka_elevation=elevation_angle_grad,
                           nka_in_guaranteed_elevation=nka_in_guaranteed_elevation,
                           signal_is_untrusted=immediate.ln1 or immediate.ln3,
                           rejected_due_to_deviation=False,
                           timestamp=timestamp)
            return residual
        except (peewee.DoesNotExist, ValueError, ResidualCalcError) as e:
            logger.debug(f"Ошибка при расчёте невязок: {str(e)}")
            raise ResidualCalcError
        except (LFImmediateInfoError, LCImmediateInfoError, BisCacheError) as e:
            logger.debug(f"Ошибка при расчёте невязок: {str(e)}")
            raise ResidualCalcError

    def as_small_dict(self) -> 'ResidualForClient':
        status_speed_residual = abs(self.speed_residual) < config['bis_control']['speed_residual_inaccuracy_threshold']
        return {'timestamp': self.timestamp,
                'residual': self.residual,
                'speed_residual': self.speed_residual,
                'nka': self.nka.nka_sys_number,
                'signal1': self.signal_1,
                'signal2': self.signal_2,
                'bis': self.bis.id,
                'nka_elevation': self.nka_elevation,
                'status': self.status,
                'delta': self.delta,
                'delta1': self.delta1,
                'delta2': self.delta2,
                'average': self.average,
                'status_speed_residual': status_speed_residual}

    def as_dict(self) -> Dict[str, Any]:
        return {
            'bis': self.bis,
            'nka': self.nka,
            'signal_1': self.signal_1,
            'signal_2': self.signal_2,
            'residual': self.residual,
            'residual1': self.residual1,
            'residual2': self.residual2,
            'speed_residual': self.speed_residual,
            'average': self.average,
            'delta': self.delta,
            'delta1': self.delta1,
            'delta2': self.delta2,
            'status': self.status,
            'y_comb_1': self.y_comb_1,
            'y_comb_2': self.y_comb_2,
            'distance': self.distance,
            'ionosphere_free_combination': self.ionosphere_free_combination,
            'tropo_delay': self.tropo_delay,
            'time_freq_correction': self.time_freq_correction,
            'signal1_pseudorange': self.signal1_pseudorange,
            'signal2_pseudorange': self.signal2_pseudorange,
            'nka_x': self.nka_x,
            'nka_y': self.nka_y,
            'nka_z': self.nka_z,
            'nka_elevation': self.nka_elevation,
            'nka_in_guaranteed_elevation': self.nka_in_guaranteed_elevation,
            'signal_is_untrusted': self.signal_is_untrusted,
            'rejected_due_to_deviation': self.rejected_due_to_deviation,
            'timestamp': self.timestamp,
        }

    def __str__(self):
        return (f"НКА: {str(self.nka.nka_sys_number)}, "
                f"сигнал: {str(self.signal_1)}, "
                f"невязка: {str(self.residual)}, "
                f"время: {str(self.timestamp)}, "
                f"станция/бис: {str(self.bis.station.station_number)}/{str(self.bis.bis_number)}")

    class Meta:
        indexes = (
            (('nka', 'bis', 'timestamp', 'signal_1'), True),
            # non-unique index, for request rejected
            (('rejected_due_to_deviation', 'timestamp', 'signal_1'), False),
        )


class NavSolution(OperativeStorageModel):
    """Модель результатов решения навигационной задачи"""

    bis: Bis = ForeignKeyField(Bis, backref='navsolution', on_delete='CASCADE')
    """БИС, для которого получено решение"""
    timestamp: datetime.datetime = DateTimeField()
    """Время, на которое получено решение"""
    latitude: float = FloatField()
    """Широта, градусы"""
    longitude: float = FloatField()
    """Долгота, градусы"""
    height: float = FloatField()
    """Высота, метры"""
    latitude_error: float = FloatField()
    """Оценка точности по широте в метрах"""
    longitude_error: float = FloatField()
    """Оценка точности по долготе в метрах"""
    height_error: float = FloatField()
    """Оценка точности по высоте в метрах"""
    latitude_velocity: float = FloatField()
    """Скорость по широте (единица измерений неизвестна)"""
    longitude_velocity: float = FloatField()
    """Скорость по долготе (единица измерений неизвестна)"""
    height_velocity: float = FloatField()
    """Скорость по широте (единица измерений неизвестна)"""
    HDOP: float = FloatField()
    """HDOP"""
    VDOP: float = FloatField()
    """VDOP"""


class KNPNavSolution(OperativeStorageModel):
    """Решение навигационной задачи силами КНП"""

    bis: Bis = ForeignKeyField(Bis, backref='knpnavsolution')
    """БИС, для которого получено решение"""
    signal_id: int = IntegerField()
    """Основной сигнал, по невязкам которого считается НВЗ"""
    timestamp: datetime.datetime = DateTimeField()
    """Время, на которое получено решение"""
    latitude: float = FloatField()
    """Широта, градусы"""
    longitude: float = FloatField()
    """Долгота, градусы"""
    height: float = FloatField()
    """Высота, метры"""
    x: float = FloatField()
    """x-координата, метры"""
    y: float = FloatField()
    """y-координата, метры"""
    z: float = FloatField()
    """z-координата, метры"""
    E: float = FloatField()
    """E-координата (восток), метры"""
    N: float = FloatField()
    """отклонение по y-координате от опорного значения, метры"""
    U: float = FloatField()
    """U-координата (верх), метры"""
    dt: float = FloatField()
    """Смещение шкалы времени БИС от шкалы ГЛОНАСС в метрах"""
    distance: float = FloatField()
    """расстояние от опорной точки, метры"""
    GDOP: float = FloatField(default=0)
    """Geometric dilution of precision"""
    threshold_exceeded: bool = BooleanField(default=0)
    """Флаг превышения порога расстояния решения от опорных координат БИС"""
    nka_list: str = CharField(max_length=64)
    """Список НКА, по невязкам которых решена задача"""
    user_solution: bool = BooleanField(default=False)
    """Признак решения НВЗ с параметрами пользователя"""
    best_solution: bool = BooleanField(default=False)
    """Признак решения НВЗ с параметрами пользователя которое было признано лучшим при исключении "плохого" НКА"""

    @classmethod
    def calculate(cls, residuals: List[Residual], signal_id: int = 0x01,
                  user_solution: bool = False, best_solution: bool = False) -> KNPNavSolution:
        """
        Функция расчёта навигационной задачи КНП

        Args:
            residuals (List[Residual]): список невязок
            signal_id (int): тип сигнала id
            user_solution (bool): пользовательской решение задачи
            best_solution (bool): лучшее решение задачи

        Raises:
            ValueError: ошибка значения

        Returns:
            KNPNavSolution: объект KNPNavSolution
        """

        if len(residuals) < 4:
            raise ValueError("Невозможно решить навигационную задачу по менее чем четырем сигналам от разных НКА")

        step = 0
        nka_lists = []
        # первая невязка (для получения БИС и timestamp)
        first_residual = residuals[0]
        bis, timestamp = first_residual.bis, first_residual.timestamp
        bis_coordinates = bis.coordinates
        # начальное приближение - опорные координаты БИС
        p0 = bis_coordinates.xyz
        p0_prev = Coordinates.XYZ(x=0, y=0, z=0)
        # чтобы PyCharm не ругался
        matrix_x = Matrix(rows=4, cols=1)
        matrix_a = Matrix(rows=1, cols=4)
        try:
            while p0.distance(p0_prev) > 0.05 and step < 2 * max_steps:
                g_lists = []
                y_lists = []
                step += 1
                # готовим "списки" значений матриц G и Y
                for r in residuals:
                    residual_distance = r.distance
                    y_lists.append([r.residual])
                    g_string = [(p0.x - r.nka_x) / residual_distance,
                                (p0.y - r.nka_y) / residual_distance,
                                (p0.z - r.nka_z) / residual_distance,
                                1]
                    g_lists.append(g_string)
                    if step == 1:
                        nka_lists.append(r.nka.nka_sys_number)
                matrix_g = Matrix.from_list(g_lists)
                matrix_y = Matrix.from_list(y_lists)
                matrix_x = ((matrix_g.trans() * matrix_g).inv()) * matrix_g.trans() * matrix_y
                if step == 1:
                    matrix_a = matrix_g.copy()
                p0_prev = p0
                p0 = Coordinates.XYZ(x=matrix_x[0][0] + bis_coordinates.xyz.x,
                                     y=matrix_x[1][0] + bis_coordinates.xyz.y,
                                     z=matrix_x[2][0] + bis_coordinates.xyz.z)

            result = Coordinates(xyz=p0)
            result_enu = CoordinatesENU(coord=result, coord0=bis_coordinates)
            distance = p0.distance(bis_coordinates.xyz)
            threshold_exceeded = False
            if distance > bis.station.solution_distance_threshold:
                threshold_exceeded = True
            # считаем GDOP
            matrix_q = (matrix_a.trans() * matrix_a).inv()
            GDOP = sqrt(matrix_q[0][0] + matrix_q[1][1] + matrix_q[2][2] + matrix_q[3][3])
            nka_list = sorted(nka_lists)
        except MatrixError:
            logger.exception("Возникли проблемы с матричными вычислениями")
            raise ValueError

        solution = cls(bis=bis,
                       signal_id=signal_id,
                       timestamp=timestamp,
                       latitude=result.blh.b * 180 / pi,
                       longitude=result.blh.l * 180 / pi,
                       height=result.blh.h,
                       x=result.xyz.x,
                       y=result.xyz.y,
                       z=result.xyz.z,
                       E=result_enu.enu.e,
                       N=result_enu.enu.n,
                       U=result_enu.enu.u,
                       dt=matrix_x[3][0],
                       distance=p0.distance(bis_coordinates.xyz),
                       GDOP=GDOP,
                       threshold_exceeded=threshold_exceeded,
                       nka_list=str(nka_list),
                       user_solution=user_solution,
                       best_solution=best_solution)
        return solution

    def as_dict(self) -> NavSolutionForClient:
        try:
            bis_coordinates = self.bis.coordinates
            dx = self.x - bis_coordinates.xyz.x
            dy = self.y - bis_coordinates.xyz.y
            dz = self.z - bis_coordinates.xyz.z
            is_x_valid = True if abs(
                dx) < config['bis_control']['nvz_solution_inaccuracy_threshold'] else False
            is_y_valid = True if abs(
                dy) < config['bis_control']['nvz_solution_inaccuracy_threshold'] else False
            is_z_valid = True if abs(
                dz) < config['bis_control']['nvz_solution_inaccuracy_threshold'] else False
            nka_list = json.loads(self.nka_list)
        except Exception as e:
            logging.debug(f'Не удалось посчитать dx, dy, dz: {str(e)}')
            dx = None
            dy = None
            dz = None
            is_x_valid = None
            is_y_valid = None
            is_z_valid = None
            nka_list = []
        return {'timestamp': self.timestamp,
                'id': self.id,
                'bis_id': self.bis_id,
                'signal': self.signal_id,
                'latitude': self.latitude,
                'longitude': self.longitude,
                'height': self.height,
                'x': self.x,
                'y': self.y,
                'z': self.z,
                'dx': dx,
                'dy': dy,
                'dz': dz,
                'is_x_valid': is_x_valid,
                'is_y_valid': is_y_valid,
                'is_z_valid': is_z_valid,
                'E': self.E,
                'N': self.N,
                'U': self.U,
                'dt': self.dt,
                'distance': self.distance,
                'GDOP': self.GDOP,
                'nka_list': nka_list,
                'user_solution': self.user_solution,
                'best_solution': self.best_solution}


class Packet(OperativeStorageModel):
    """Модель времени получения и времени из заголовка пакета"""

    packet_identi: int = IntegerField()
    """ID пакета"""
    packet_gen_timestamp_s: float = FloatField()
    """Время формирования пакета в секундах"""
    db_timestamp_s: float = FloatField()
    """Время записи пакета в БД в секундах"""
    ders: float = FloatField()
    """Разница между db_timestamp_s и packet_gen_timestamp_s"""
    packet_gen_timestamp: datetime.datetime = DateTimeField()
    """Время формирования пакета в секундах"""
    dropped: bool = BooleanField()
    """Флаг отброса пакетов"""


class OFSignalFrame(BaseDIFrame):
    """Кадры ЦИ с частотным разделением"""

    @property
    def is_immediate_complete(self):
        """Полная ли оперативная информация"""
        return bool(self.string1 and self.string2 and self.string3 and self.string4 and self.string5)

    @property
    def is_immediate_valid(self):
        """Без ошибок ли оперативная информация"""

        is_valid = False
        try:
            is_valid = not bool(self.string1.error_in_string and
                                self.string2.error_in_string and
                                self.string3.error_in_string and
                                self.string4.error_in_string and
                                self.string5.error_in_string)
        except KeyError:
            pass
        return is_valid

    def meta_as_dict(self):
        tb = self.get_tb()
        return {'frame_id': self.id,
                'bis_id': self.bis_id,
                'sources': None,
                'station_id': getattr(self.bis, 'station_id', None),
                'nka': self.nka_id,
                'tk': self.tk,
                'seq': self.seq,
                'num': self.num,
                'is_complete': self.is_complete,
                'is_fifth': self.is_fifth,
                'timestamp': self.timestamp,
                'db_timestamp': self.db_timestamp,
                'tk_time_format': self.timestamp.strftime("%H:%M:%S"),
                'tb_time_format': FD.common.tb_to_datetime(tb).strftime("%H:%M:%S") if tb is not None else None}

    def as_dict(self):
        content = {}
        string_errors: dict = {}
        meta = self.meta_as_dict()
        string_arr = [self.string1, self.string2, self.string3, self.string4, self.string5,
                      self.string6, self.string7, self.string8, self.string9, self.string10,
                      self.string11, self.string12, self.string13, self.string14, self.string15]

        for i, string in enumerate(string_arr):
            if string:
                if i + 1 >= 14:
                    content[i + 1] = string_arr[i].as_dict(is_fifth=self.is_fifth)
                else:
                    content[i + 1] = string_arr[i].as_dict()

                string_errors[i + 1] = string.error_in_string

            else:
                string_errors[i + 1] = None
                content[i + 1] = None

        return {'meta': {**meta,
                         'string_errors': string_errors},
                'content': content}

    def as_long_dict(self):
        result = {}
        alm = {}
        # заполняем параметры из первых 5 строк
        for string_num in range(1, 6):
            try:
                string_content = self.as_dict()['content'][string_num]
                if string_content:
                    # объединяем все строки в одно
                    result = {**result, **string_content}
            except KeyError:
                pass
        # заполняем параметры альманаха для каждого из 5 КА
        alm_string_numbers = [6, 8, 10, 12,
                              14] if not self.is_fifth else [6, 8, 10, 12]
        for string_num in alm_string_numbers:
            alm_string_1 = self.as_dict()['content'][string_num]
            alm_string_2 = self.as_dict()['content'][string_num + 1]
            if alm_string_1:
                sys_num = alm_string_1['n_a']['val']
                alm[sys_num] = {}
                alm[sys_num] = {**alm[sys_num], **alm_string_1}
                if alm_string_2:
                    alm[sys_num] = {**alm[sys_num], **alm_string_2}
        result['alm'] = alm
        if self.is_fifth:
            try:
                string_14_content = self.as_dict()['content'][14]
                string_15_content = self.as_dict()['content'][15]
                if string_14_content:
                    result = {**result, **string_14_content}
                if string_15_content:
                    result = {**result, **string_15_content}
            except KeyError:
                pass
        return result

    def get_timebind(self, frame_data) -> TimeData:

        time = TimeData(timestamp=self.timestamp,
                        tb=frame_data.get('tb', {}).get('val', None),
                        N=frame_data.get('Nt', {}).get('val', None),
                        Na={frame_data.get('Na', {}).get('val', None)},
                        tb_timestamp=self.datetime_from_tb(),
                        N4=frame_data.get('N4', {}).get('val'),
                        tk=frame_data.get('tk', {}).get('val'))
        return time

    def get_tb(self):
        """Возвращает tb из оперативной информации для сравнения ЭИ в ЦИ на соседних интервалах"""
        try:
            tb = self.string2.content[0]['tb']
        except (AttributeError, KeyError, IndexError):
            return None
        return tb

    def tb_to_datetime(self, tb: int, N: int, N4: int) -> Optional[datetime]:
        """Преобразовать параметры N4, N, tb в datetime."""
        try:
            return FD.common.tb_to_datetime(N4=N4, N=N, tb=tb)
        except Exception:
            return None

    def _extract_time_params(self):
        N4 = self.get_param_from_string_or_none(5, 'N4')
        Nt = self.get_param_from_string_or_none(4, 'Nt')
        tb = self.get_param_from_string_or_none(2, 'tb')
        return tb, Nt, N4

    def get_p4(self) -> Optional[int]:
        """
        Возвращает слово P4 из кадра.
        Р4 – признак того, что на текущем интервале времени tb средствами
            ПКУ на НКА заложена (1) или не заложена (0) обновленная эфемеридная или
            частотно-временная информация.
        """
        try:
            P4 = self.string4.content[0]['P4']
        except (AttributeError, KeyError, IndexError, TypeError):
            P4 = None
        return P4

    def control_tk(self):
        """Контроль соответствия значений оцифровки метки времени в принятой ЦИ текущему времени"""
        try:
            # tk, NT и N4 нужны для определения timestamp
            error_in_string_with_tk = self.string1.error_in_string
            error_in_string_with_NT = self.string4.error_in_string
            error_in_string_with_N4 = self.string5.error_in_string
        except AttributeError:
            pass
        else:
            if not (error_in_string_with_tk or error_in_string_with_NT or error_in_string_with_N4):
                time_now = datetime.datetime.now()
                if abs(time_now - self.timestamp) > datetime.timedelta(seconds=config['di_control']['tk_difference']):
                    return int((self.timestamp).timestamp())
        return 0

    def control_tb(self):
        """Контроль соответствия значений tk текущему tb"""
        try:
            error_in_string_with_tb = self.string2.error_in_string
            error_in_string_with_tk = self.string1.error_in_string
        except AttributeError:
            pass
        else:
            if not (error_in_string_with_tb or error_in_string_with_tk):
                tb = self.get_tb()
                if tb is not None:
                    # для сравнения без учета даты, для tk и tb установлена одинаковая дата 01.01.2000
                    tb_time_format = ((FD.common.tb_to_datetime(tb)).replace(
                        year=2000, month=1, day=1, microsecond=0))
                    tk_time_format = self.timestamp.replace(
                        year=2000, month=1, day=1, microsecond=0)
                    time_delta = datetime.timedelta(minutes=15)
                    if tb_time_format is not None:
                        if not (tb_time_format - time_delta <= tk_time_format <= tb_time_format + time_delta):
                            return tb
        return 0


class L1OFFrame(OFSignalFrame):
    """Кадр ЦИ L1OF"""
    nka: Nka = ForeignKeyField(Nka, backref='l1of_frames', on_delete='CASCADE')
    """НКА, для которого собран кадр"""
    bis: Bis = ForeignKeyField(
        Bis, backref='l1of_frames', on_delete='CASCADE', null=True)
    """БИС, который собрал кадр"""
    tk: int = IntegerField()
    """Время начала кадра в формате tk по ИКД"""
    seq: int = IntegerField()
    """Порядковый номер кадра в сутках"""
    num: int = IntegerField()
    """Номер кадра в суперкадре"""
    time: int = IntegerField()
    """Время начала кадра в секундах с начала суток"""
    string1: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames1', on_delete='CASCADE', null=True)
    """Первая строка кадра"""
    string2: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames2', on_delete='CASCADE', null=True)
    """Вторая строка кадра"""
    string3: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames3', on_delete='CASCADE', null=True)
    """Третья строка кадра"""
    string4: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames4', on_delete='CASCADE', null=True)
    """Четвертая строка кадра"""
    string5: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames5', on_delete='CASCADE', null=True)
    """Пятая строка кадра"""
    string6: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames6', on_delete='CASCADE', null=True)
    """Шестая строка кадра"""
    string7: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames7', on_delete='CASCADE', null=True)
    """Седьмая строка кадра"""
    string8: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames8', on_delete='CASCADE', null=True)
    """Восьмая строка кадра"""
    string9: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames9', on_delete='CASCADE', null=True)
    """Девятая строка кадра"""
    string10: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames10', on_delete='CASCADE', null=True)
    """Десятая строка кадра"""
    string11: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames11', on_delete='CASCADE', null=True)
    """Одиннадцатая строка кадра"""
    string12: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames12', on_delete='CASCADE', null=True)
    """Двенадцатая строка кадра"""
    string13: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames13', on_delete='CASCADE', null=True)
    """Тринадцатая строка кадра"""
    string14: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames14', on_delete='CASCADE', null=True)
    """Четырнадцатая строка кадра"""
    string15: L1OFString = ForeignKeyField(
        L1OFString, backref='l1of_frames15', on_delete='CASCADE', null=True)
    """Пятнадцатая строка кадра"""
    is_fifth: bool = BooleanField(default=False)
    """Является ли кадр пятым в суперкадре"""
    is_complete: bool = BooleanField(default=True)
    """Полный ли кадр в части простого наличия всех строк (независимо от их целостности)"""
    timestamp: datetime.datetime = DateTimeField()
    """Номинальное время излучения первой строки кадра"""
    signal_type = appdata.SIGNALS_NAME["L1OF"]
    """Тип сигнала"""
    string_type = L1OFString
    """Класс строки кадра"""


class L2OFFrame(OFSignalFrame):
    """Кадр ЦИ L2OF"""
    nka: Nka = ForeignKeyField(Nka, backref='l2of_frames', on_delete='CASCADE')
    """НКА, для которого собран кадр"""
    bis: Bis = ForeignKeyField(
        Bis, backref='l2of_frames', on_delete='CASCADE', null=True)
    """БИС, который собрал кадр"""
    tk: int = IntegerField()
    """Время начала кадра в формате tk по ИКД"""
    seq: int = IntegerField()
    """Порядковый номер кадра в сутках"""
    num: int = IntegerField()
    """Номер кадра в суперкадре"""
    time: int = IntegerField()
    """Время начала кадра в секундах с начала суток"""
    string1: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames1', on_delete='CASCADE', null=True)
    """Первая строка кадра"""
    string2: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames2', on_delete='CASCADE', null=True)
    """Вторая строка кадра"""
    string3: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames3', on_delete='CASCADE', null=True)
    """Третья строка кадра"""
    string4: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames4', on_delete='CASCADE', null=True)
    """Четвертая строка кадра"""
    string5: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames5', on_delete='CASCADE', null=True)
    """Пятая строка кадра"""
    string6: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames6', on_delete='CASCADE', null=True)
    """Шестая строка кадра"""
    string7: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames7', on_delete='CASCADE', null=True)
    """Седьмая строка кадра"""
    string8: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames8', on_delete='CASCADE', null=True)
    """Восьмая строка кадра"""
    string9: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames9', on_delete='CASCADE', null=True)
    """Девятая строка кадра"""
    string10: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames10', on_delete='CASCADE', null=True)
    """Десятая строка кадра"""
    string11: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames11', on_delete='CASCADE', null=True)
    """Одиннадцатая строка кадра"""
    string12: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames12', on_delete='CASCADE', null=True)
    """Двенадцатая строка кадра"""
    string13: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames13', on_delete='CASCADE', null=True)
    """Тринадцатая строка кадра"""
    string14: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames14', on_delete='CASCADE', null=True)
    """Четырнадцатая строка кадра"""
    string15: L2OFString = ForeignKeyField(
        L2OFString, backref='l2of_frames15', on_delete='CASCADE', null=True)
    """Пятнадцатая строка кадра"""
    is_fifth: bool = BooleanField(default=False)
    """Является ли кадр пятым в суперкадре"""
    is_complete: bool = BooleanField(default=True)
    """Полный ли кадр в части простого наличия всех строк (независимо от их целостности)"""
    timestamp: datetime.datetime = DateTimeField()
    """Номинальное время излучения первой строки кадра"""
    signal_type = appdata.SIGNALS_NAME["L2OF"]
    """Тип сигнала"""
    string_type = L2OFString
    """Класс строки кадра"""


class L1SFFrame(OFSignalFrame):
    """Кадр ЦИ L1SF"""
    nka: Nka = ForeignKeyField(Nka, backref='l1sf_frames', on_delete='CASCADE')
    """НКА, для которого собран кадр"""
    bis: Bis = ForeignKeyField(
        Bis, backref='l1sf_frames', on_delete='CASCADE', null=True)
    """БИС, который собрал кадр"""
    tk: int = IntegerField()
    """Время начала кадра в формате tk по ИКД"""
    seq: int = IntegerField()
    """Порядковый номер кадра в сутках"""
    num: int = IntegerField()
    """Номер кадра в суперкадре"""
    time: int = IntegerField()
    """Время начала кадра в секундах с начала суток"""
    string1: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames1', on_delete='CASCADE', null=True)
    """Первая строка кадра"""
    string2: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames2', on_delete='CASCADE', null=True)
    """Вторая строка кадра"""
    string3: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames3', on_delete='CASCADE', null=True)
    """Третья строка кадра"""
    string4: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames4', on_delete='CASCADE', null=True)
    """Четвертая строка кадра"""
    string5: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames5', on_delete='CASCADE', null=True)
    """Пятая строка кадра"""
    string6: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames6', on_delete='CASCADE', null=True)
    """Шестая строка кадра"""
    string7: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames7', on_delete='CASCADE', null=True)
    """Седьмая строка кадра"""
    string8: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames8', on_delete='CASCADE', null=True)
    """Восьмая строка кадра"""
    string9: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames9', on_delete='CASCADE', null=True)
    """Девятая строка кадра"""
    string10: L1SFString = ForeignKeyField(
        L1SFString, backref='l1sf_frames10', on_delete='CASCADE', null=True)
    """Десятая строка кадра"""
    is_complete: bool = BooleanField(default=True)
    """Полный ли кадр в части простого наличия всех строк (независимо от их целостности)"""
    timestamp: datetime.datetime = DateTimeField()
    """Номинальное время излучения первой строки кадра"""
    signal_type = appdata.SIGNALS_NAME["L1SF"]
    """Тип сигнала"""
    string_type = L1SFString
    """Класс строки кадра"""

    def meta_as_dict(self):
        tb = self.get_tb()
        return {'frame_id': self.id,
                'bis_id': self.bis_id,
                'sources': None,
                'station_id': getattr(self.bis, 'station_id', None),
                'nka': self.nka_id,
                'tk': self.tk,
                'seq': self.seq,
                'num': self.num,
                'is_complete': self.is_complete,
                'timestamp': self.timestamp,
                'db_timestamp': self.db_timestamp,
                'tk_time_format': self.timestamp.strftime("%H:%M:%S"),
                'tb_time_format': FD.common.tb_to_datetime(tb).strftime("%H:%M:%S") if tb is not None else None,
                'num_in_segment': utils.signals.FD.L1SF.frame_num_from_segment(self.tk)}

    def as_dict(self):
        meta = self.meta_as_dict()
        num_in_segment = meta.get('num_in_segment', 1)

        content = {}
        string_errors: dict = {}
        meta = self.meta_as_dict()
        string_arr = [self.string1, self.string2, self.string3, self.string4, self.string5,
                      self.string6, self.string7, self.string8, self.string9, self.string10]

        for i, string in enumerate(string_arr):
            if string:
                string_errors[i + 1] = string.error_in_string
                content[i + 1] = string_arr[i].as_dict(num_in_segment)
            else:
                string_errors[i + 1] = None
                content[i + 1] = None

        return {'meta': {**meta,
                         'string_errors': string_errors},
                'content': content}

    @property
    def is_immediate_complete(self):
        """Полная ли оперативная информация"""
        return bool(
            self.string1 and self.string2 and self.string3 and self.string4 and self.string5)  # FIXME сколько строк в оперативке

    @property
    def is_immediate_valid(self):
        """Без ошибок ли оперативная информация"""

        is_valid = False
        try:
            is_valid = not bool(self.string1.error_in_string and
                                self.string2.error_in_string and
                                self.string3.error_in_string and
                                self.string4.error_in_string and
                                self.string5.error_in_string)
        except KeyError:
            pass
        return is_valid

    def as_long_dict(self):

        def write_single_param_in_dict(target_dict: dict, name: string, value):
            """Записать параметр в целевой словарь в вид dict, содержащий имя параметра,
            его значение и двоичное представление"""

            target_dict[name] = value
            target_dict[name]['name'] = name

        def get_frames(meta, offsets):
            frames = []
            for offset in offsets:
                try:
                    frame = L1SFFrame.select().where((L1SFFrame.nka_id == meta['nka'])
                                                     & (L1SFFrame.bis_id == meta['bis_id'])
                                                     & (L1SFFrame.timestamp == (
                            meta['timestamp'] + datetime.timedelta(seconds=offset)))).get()
                    frames.append(frame)
                except DoesNotExist:
                    frames.append(None)
            return frames

        result = {}
        alm = {}
        # заполняем параметры из первых 10 строк
        for string_num in [1, 2, 3, 4, 5, 6, 7]:
            string = self.as_dict()['content'][string_num]
            if string:
                for par_name, par_val in string.items():
                    write_single_param_in_dict(
                        target_dict=result, name=par_name, value=par_val)
        alm_string_numbers = [8, 9, 10]

        one_segment = []
        meta = self.meta_as_dict()
        if meta['num_in_segment'] == 1:
            offsets = [10, 20]
            frames = get_frames(meta, offsets)
            one_segment = [self, frames[0], frames[1]]
        elif meta['num_in_segment'] == 2:
            offsets = [-10, 10]
            frames = get_frames(meta, offsets)
            one_segment = [frames[0], self, frames[1]]
        elif meta['num_in_segment'] == 3:
            offsets = [-20, -10]
            frames = get_frames(meta, offsets)
            one_segment = [frames[0], frames[1], self]
        try:
            sys_num = one_segment[0].as_dict()['content'][8]['n_a']['val']
        except (AttributeError, KeyError, TypeError):
            pass
        else:
            alm[sys_num] = {}
            if one_segment and type(one_segment) is list:
                for frame in one_segment:
                    if frame is not None:
                        for string_num in alm_string_numbers:
                            alm_string = frame.as_dict()['content'][string_num]
                            if alm_string:
                                for par_name, par_val in alm_string.items():
                                    write_single_param_in_dict(
                                        target_dict=alm[sys_num], name=par_name, value=par_val)
        result['alm'] = alm
        return result

    def _extract_time_params(self):
        # FIXME откуда брать Nt И N4  в каком кадре из сегмента
        N4 = self.get_param_from_string_or_none(10, 'N4')
        Nt = self.get_param_from_string_or_none(10, 'Nt')
        tb = self.get_param_from_string_or_none(5, 'tb')
        return tb, Nt, N4

    def get_tb(self):
        """Возвращает tb из оперативной информации для сравнения ЭИ в ЦИ на соседних интервалах"""
        try:
            tb = self.string5.content[0]['tb']
        except (AttributeError, KeyError, IndexError):
            return None
        return tb

    def get_timebind(self, frame_data) -> TimeData:
        Nt, Na = None, None
        try:
            Nt = self.string10.content[0]['Nt']
        except (AttributeError, KeyError):
            pass
        if frame_data.get('alm', {}).keys():
            number_alm_nka = list(frame_data.get('alm', {}).keys())[0]
            Na = {(frame_data.get('alm', {})).get(number_alm_nka, {}).get('Na', {}).get('val', Nt)}

        time = TimeData(timestamp=self.timestamp,
                        tb=frame_data.get('tb', {}).get('val', None),
                        N=Nt,
                        # FIXME откуда взять Na, если нет 3 кадра в сегменте, пока по умолчанию берём Nt,
                        #  чтобы вывести хоть какую то часть алманаха
                        Na=Na,
                        tb_timestamp=self.datetime_from_tb(),
                        N4=frame_data.get('N4', {}).get('val'),
                        tk=frame_data.get('tk', {}).get('val'))
        return time

    def control_tk(self):
        """Контроль соответствия значений оцифровки метки времени в принятой ЦИ текущему времени"""
        try:
            # tk, NT и N4 нужны для определения timestamp
            error_in_string_with_tk = self.string1.error_in_string
            error_in_string_with_NT_N4 = self.string10.error_in_string
        except AttributeError:
            pass
        else:
            if not (error_in_string_with_tk or error_in_string_with_NT_N4):
                time_now = datetime.datetime.now()
                if abs(time_now - self.timestamp) > datetime.timedelta(seconds=config['di_control']['tk_difference']):
                    return int((self.timestamp).timestamp())
        return 0

    def control_tb(self):
        """Контроль соответствия значений tk текущему tb"""
        try:
            error_in_string_with_tb = self.string5.error_in_string
            error_in_string_with_tk = self.string1.error_in_string
        except AttributeError:
            pass
        else:
            if not (error_in_string_with_tb or error_in_string_with_tk):
                tb = self.get_tb()
                if tb is not None:
                    # для сравнения без учета даты, для tk и tb установлена одинаковая дата 01.01.2000
                    tb_time_format = ((FD.common.tb_to_datetime(tb)).replace(
                        year=2000, month=1, day=1, microsecond=0))
                    tk_time_format = self.timestamp.replace(
                        year=2000, month=1, day=1, microsecond=0)
                    time_delta = datetime.timedelta(minutes=15)
                    if tb_time_format is not None:
                        if not (tb_time_format - time_delta <= tk_time_format <= tb_time_format + time_delta):
                            return tb
        return 0


class JSONSourcesField(TextField):
    """Класс для записи структур в формате JSON в поле sources таблицы БД SummarizedFramesInfo"""

    def db_value(self, value):
        """Преобразование сета источников в список источников и запись структуры в формат JSON"""
        sources = []
        if value:
            for source in value:
                sources.append(source)
        return value if value is None else json.dumps(sources)

    def python_value(self, value):
        """Преобразование записи из поля в базе в структуру списка id строк"""
        return value if value is None else json.loads(value)


class SummarizedFramesInfo(OperativeStorageModel):
    """Таблица для сохранения источников, каждого обобщенного кадра"""
    id: int = IntegerField(primary_key=True)
    """id обобщенного кадра в списке всех обобщенных кадров."""
    frame_id: int = IntegerField()
    """id обобщенного кадра, соответствует id под которым кадр храниться в таблице своего типа сигнала."""
    signal_type: int = IntegerField()
    """Тип сигнала"""
    nka: Nka = ForeignKeyField(Nka)
    """НКА, для которого собран кадр"""
    timestamp: datetime.datetime = DateTimeField()
    """Номинальное время излучения первой строки кадра"""
    sources: str = JSONSourcesField()
    """Источники обобщенного кадра"""

    class Meta:
        indexes = ((('frame_id', 'signal_type'), True),)
        table_name = "summarized_frames_info"


class SummarizedFrameComparison(OperativeStorageModel):
    """Таблица для сохранения результатов сравнения обобщенного кадра с СИ."""
    frame_info_id: int = ForeignKeyField(SummarizedFramesInfo, field='id')
    """id обобщенного кадра, соответствует id под которым кадр храниться в таблице всех обобщенных кадров."""
    almanac_sys_num = IntegerField()
    """Номер НКА для которого приведены параметры альманаха"""
    name = TextField()
    """Название параметра, для сравнения."""
    param_value = TextField()
    """Значение параметра."""
    is_valid = IntegerField(null=True)
    """Результат сравнения обобщенного кадра с СИ ( True (1) - параметр в пределах пороговых значений, False (0))"""
    si_value = FloatField(null=True)
    """Значение данного параметра в СИ."""
    si_timestamp: datetime.datetime = DateTimeField()
    """Дата и время завершения закладки СИ МДВ."""
    si_phrase_tb = IntegerField(null=True)
    """tb фразы СИ, с которой было сравнение ЦИ из кадра."""

    class Meta:
        table_name = "summarized_frame_comparison"


lbd_tables_list = [Signal, Nka, Station, Bis, SignalType, Control, L1OFString, L2OFString,
                   L1SFString, L1OCString, L3OCString, L1SCString, L2SCString, LFImmediateInfo, NavSolution,
                   Residual, Packet, KNPNavSolution,
                   L1OFFrame, L2OFFrame, L1SFFrame, L1OCFrame, L3OCFrame, L1SCFrame, L2SCFrame, L2KSIString,
                   LCImmediateInfo, LCStableData, Almanac, SummarizedFramesInfo, SummarizedFrameComparison,
                   Meteoparameters]
"""Перечень таблиц, создаваемых в технологической ЛБД"""
