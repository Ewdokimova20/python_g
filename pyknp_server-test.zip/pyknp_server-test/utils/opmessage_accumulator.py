# DEPRECATED

"""Operative message accumulator

Объект хранения, дедупликации и учета показа оперативных сообщений оператору.
Включает:
  Хранилище сигнальных признаков
  Перечень фильтров для клиента
  Перечень активных клиентов

Определения
ОС -- оперативные сообщения, получаемые извне от СПО сети БИС или формируемые СПО КНП на основании поступающих ИТНП/ЦИ
СП --- набор значений полей в ОС, описывающих выявленную проблему в ГНСС (далее предполагается для простоты что одно ОС содержит один СП)
Комбинация -- ОС, описываемое конкретными значениями полей КА/событие/сигнал/БИС/источник
Ситуация -- выявление комбинации на интервале времени с явным указанием причины окончания поступления

Описание общей логики:
Для потребителей интересны не отдельные ОС, а информация о состоянии признаков.
Аккумулятор хранит для комбинации статус оповещения.
Ситуации пишутся в ТЛБД периодически, по завершению, при удалении

Потребители должны информироваться только о новых ситуациях.
Ситуация считается новой, если в аккумуляторе отсутствуют незавершенные ситуации  (оперативные сообщения) с такой же комбинацией
Если же ситуация считалась завершенной, но СП поступил повторно, то:
0. Завершенная ситуация записывается в ТЛБД и удаляется автоматически
1. Новая ситуация замещает завершенную, но не показывается как новая.

# """
# import datetime
# import logging
# from collections import defaultdict
# from enum import IntEnum
# from typing import List, Optional
#
# import psycopg2
# from peewee import EXCLUDED
# from psycopg2.extras import execute_values
# from typing_extensions import TypedDict
#
# from db.db_connection import db, connection_params
# from global_data.appdata import allowed_hide_intervals, ServerStatusCode, L1_FREQ_SIGNAL_TYPES, \
#     L2_FREQ_SIGNAL_TYPES, L1_CODE_SIGNAL_TYPES, L3_CODE_SIGNAL_TYPES, L2_CODE_SIGNAL_TYPES, NKA_SIGNALS
# from global_data.config_schema import config
# from models.op_message import KNPOpMessage, KNPOpSumMessage, OpMessage
# from utils.signals import FD, CD
# from utils.signals.common import format_ground_call_control_raw_value
#
# DATE_PERMANENT_FILTER = datetime.datetime(year=2100, month=1, day=1)
# logger = logging.getLogger('opmessage')
#
#
# class SignalFlagUpdate(TypedDict):
#     """Словарь для обновления сигнального признака"""
#     combination_id: int
#     first_appear_timestamp: datetime.datetime
#     last_appear_timestamp: datetime.datetime
#     appear_count: int
#
#
# class SourceId(IntEnum):
#     """Кем сформировано ОС"""
#     undefined = 0,  # сигнальный признак был выявлен сетью БИС
#     BIS = 1,  # сигнальный признак был выявлен сетью БИС
#     KNP = 2,  # сигнальный признак был выявлен СПО КНП
#     KNPSum = 3  # сигнальный признак был выявлен СПО КНП по обобщенной ЦИ
#
#
# class AlarmId(IntEnum):  # недопустимо использование идентификаторов меньших или равных нулю
#     """Числовой представления выявленного СП"""
#     ground_control_call = 1,  # Выявлен сигнал Вызов НКУ
#     unreliable_frame = 2,  # Недостоверность навигационного кадра
#     unreliable_signal = 3,  # Негодность НС
#     unreliable_digital_info = 4,  # Негодность ЦИ
#     absent_signal = 5,  # Отсутствет сигнал НКА, ожидаемый в ЗРВ и излучаемый согласно ЦБД
#     tk_inconsistency = 6,  # Несоответствие значений оцифровки метки времени в принятой ЦИ текущему времени
#     tb_inconsistency = 7,  # Несоответствие значения tb значению tk
#     EI_inconsistency = 8,  # Несоответствие параметров ЭИ в обобщенной ЦИ с заложенными СИ
#     clock_inconsistency = 9,  # Несоответствие параметров ЧВП в обобщенной ЦИ с заложенными СИ
#     almanac_inconsistency = 10,  # Несоответствие параметров альманаха в обобщенной ЦИ с заложенными СИ
#     generalized_DI = 11,  # Результат обобщения признаков 6-10 нужно для интерфейса
#     generalized_signals_validity = 12,  # годность навигационных сигналов в таблице обобщенных признаков нужно для интерфейса
#     generalized_receive_status = 13,  # статусы приёма сигналов НКА в таблице обобщенных признаков нужно для интерфейса
#
#
# class FinalizeCode(IntEnum):
#     """Код причины завершения конкретного СП. Используется для отражения причины завершения ситуации."""
#     in_progress = 0,  # ситуация не завершена и должна быть загружена из ТЛБД при запуске
#     value_changed = 1,  # значение СП изменилось (на штатное или иное нештатное)
#     became_emitted = 2,  # отсутствусющий сигнал стал излучаться (описывает ОГ глобально, не для единичного БИС)
#     out_of_sight = 3,  # НКА вышел из ЗРВ соответствующего ПЭ (на основании прогноза по альманаху)
#     timeout = 4  # СП не приходил в течение заданного времени
#     user_deleted = 9,  # ситуация завершена пользователем и удалена из аккумулятора (только для БД, в хранилище СПО КНП не встречается)
#
#
# class EventStatus(IntEnum):
#     """Статус актуальности ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
#     finalized = 0,  # ЕМВ: подразумевает отсутствие событий по всем источникам/бис входящим в данное обобщенное событие.
#     active = 1,  # ЕМВ: подразумевает наличие событий хотя бы по одному источнику/бис, входящими в данное обобщенное событие.
#
#
# class NotificationStatus(IntEnum):
#     """Статус подтверждения ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
#     approved = 0,  # Сообщение не выделено жирным шрифтом
#     new = 1,  # Сообщение выделено жирным шрифтом
#
#
# class SoundAlarmStatus(IntEnum):
#     """Заглушена или нет звуковая сигнализация события"""
#     undefined = 0,  # неопределенное значение, соответствующее незаполненному состоянию
#     unmuted = 1,  # звуковая сигнализация включена для события
#     muted = 2,  # звуковая сигнализация отключена для события
#
#
# MINIMAL_COMBINATION_ID_VALUE = 9999  # минимальное допустимое значение комбинации
# MAXIMAL_COMBINATION_ID_VALUE = 99999999999  # максимальное допустимое значение комбинации
# MAXIMAL_BIS_ID = MINIMAL_COMBINATION_ID_VALUE
# UNDEFINED_BIS_ID = MINIMAL_COMBINATION_ID_VALUE
# bis_id_cache = {MAXIMAL_BIS_ID: [99, 99]}  # кэш сопоставляющий идентификаторы БИС и их описание для оператора
#
#
# class SignalFlagDescriptor:
#     """Описание сигнального признака, хранимого в аккумуляторе
#
#     Отражает первичные данные, выявленные сетью БИС или СПО КНП
#     Служит для агрегированного хранения экстренных признаков, которые доставляются до оператора"""
#
#     def __init__(self):
#         self.value = None  # значение выявленного признака (актуальнее всего для вызова НКУ, не обновляется в процессе работы)
#         self.first_appear_timestamp = datetime.datetime.now()  # момент первого выявления данной комбинации (не обновляется в процессе работы)
#         self.last_appear_timestamp = None  # момент позднейшего выявления сигнального признака данной комбинации
#         self.appear_count = 0  # количество выявленых признаков за описанный интервал времени
#         self.combination_id = 0  # идентификатор комбинации для того, чтобы не перерасчитывать его каждый раз (отражает ключ)
#         self.finalize_code = FinalizeCode.in_progress  # создаваемая, новая ситуация всегда считается незавершенной
#
#     def finalize(self, finalize_code: FinalizeCode) -> bool:
#         """Ф-я финализации СП по дескриптору. Возвращает False если реальных действий не было предпринято."""
#
#         if self.last_appear_timestamp is None:  # блокируем ситуацию работы с незполненным дескриптором
#             return False
#
#         # проверяем ситуацию двойной финализации (за исключением удаления ситуации)
#         # если ситуация уже была финализирована, то первопричина более релевантна
#         # также данный подход позволяет избегать избыточных обращений к ТЛБД
#         # Пример: попытка финализации ситуации ВНКУ по причине выхода из ЗРВ, хотя она была финализирована по причине зануления ВНКУ
#         if (finalize_code != FinalizeCode.user_deleted) \
#                 and (self.finalize_code != FinalizeCode.in_progress):
#             return False
#         self.finalize_code = finalize_code
#         # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
#         AlarmCases.update(finalize_reason=finalize_code). \
#             where((AlarmCases.combination == self.combination_id) &
#                   (AlarmCases.first_appear_timestamp == self.first_appear_timestamp)).execute()
#         return True
#
#     def approve(self) -> bool:
#         """Ф-я отключение сигнализации СП по дескриптору. Возвращает False если реальных действий не было предпринято."""
#
#         if self.last_appear_timestamp is None:  # блокируем ситуацию работы с незаполненным дескриптором
#             logger.info(
#                 f'Попытка отключить сигнализацию для ситуации с незаполненным дескриптором last_appear_timestamp: {self.combination_id}')
#             return False
#
#         # если ситуация финализирована, то перестаем её обновлять.
#         # Единственное развитие --- её удаление, но тогда запись будет выполнена в рамках finalize
#         if self.finalize_code == FinalizeCode.in_progress:
#             # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
#             AlarmCases.update(mute_timestamp=datetime.datetime.now()). \
#                 where((AlarmCases.combination == self.combination_id) &
#                       (AlarmCases.first_appear_timestamp == self.first_appear_timestamp) &
#                       (AlarmCases.mute_timestamp == None)
#                       # фиксируем первое скрытие т.к. только оно будет значимо в разборе полетов
#                       ).execute()
#         return True
#
#     def prepare_update(self) -> Optional[SignalFlagUpdate]:
#         """Ф-я обновления ситуации в ТЛБД по дескриптору. Возвращает False если реальных действий не было предпринято."""
#
#         if self.last_appear_timestamp is None:  # блокируем ситуацию работы с незполненным дескриптором
#             return None
#
#         update = {
#             'combination_id': self.combination_id,
#             'first_appear_timestamp': self.first_appear_timestamp,
#             'last_appear_timestamp': self.last_appear_timestamp,
#             'appear_count': self.appear_count
#         }
#         return update
#
#
# class SignalFlagGroup:
#     """Описание группы сигнальных признаков, хранимого в аккумуляторе и имеющих общие параметры индикации
#
#     Служит для хранение группы сигнальных признаков в зависимости от БИС или типа источника и необходимости их отображения"""
#
#     def __init__(self):
#         self.signal_flags = defaultdict(
#             lambda: defaultdict(SignalFlagDescriptor))  # ключ: БИС/источник выявсения СП (см. SourceId)
#         self.event_status = EventStatus.active  # при заполнении по умолчаю автоматически выставляется правильное значение
#         self.notification_status = NotificationStatus.new  # при заполнении по умолчаю автоматически выставляется правильное значение
#         self.sound_alarm_status = SoundAlarmStatus.undefined
#         self.is_explicit_finalize = False  # допустимо ли финализировать ситуацию по периоду неактивности
#
#     def finalize(self, bis_id: int, finalize_code: FinalizeCode) -> bool:
#         """Ф-я финализации группы СП по дескриптору. Возвращает False если реальных действий не было предпринято."""
#
#         # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
#         result = False
#         for signal_descriptor in self.signal_flags[bis_id].values():
#             result |= signal_descriptor.finalize(finalize_code)
#         self.event_status = EventStatus.finalized
#         return result
#
#     def approve(self) -> bool:
#         """Ф-я отключение сигнализации СП по дескриптору. Возвращает False если реальных действий не было предпринято.
#
#         Соответствует команде 'Ознакомлен' от клиента"""
#
#         self.notification_status = NotificationStatus.approved
#         # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
#         result = False
#         for bis_signal_flags in self.signal_flags.values():
#             for signal_descriptor in bis_signal_flags.values():
#                 result |= signal_descriptor.approve()
#         return result
#
#     def prepare_updates_for_group(self, current_time: datetime.datetime) -> List[SignalFlagUpdate]:
#         """Ф-я обновления ситуации в ТЛБД по дескриптору. Возвращает [] если реальных действий не было предпринято."""
#
#         updates = []
#
#         for bis_signal_flags in self.signal_flags.values():
#             for signal_descriptor in bis_signal_flags.values():
#                 single_desciptor_update = signal_descriptor.prepare_update()
#                 if single_desciptor_update:
#                     updates.append(single_desciptor_update)
#         return updates
#
#
# def encode_combination_id(nka_id: int, alarm_id: int, signal_id: int, bis_id: int, source_id: int) -> int:
#     """Ф-я взаимододнозначного пересета вектора идентификаторов в идентификатор комбинации
#
#     Ограничения:
#     Число НКА --- не регулируется, может быть любым
#     Идентификаторы сигнальным признаков --- не более 19 штук (сейчас двукратный запас)
#     Идентификаторы сигналов --- не более 1000 (сейчас четырехкратный запас)
#     Идентификаторы БИС --- не более 10 000 штук (более чем десятикратный запас)
#     Идентификатор источника --- не более 9 (сейчас восьмикратный запас)
#     """
#     return (((nka_id * 100 + alarm_id) * 1000 + signal_id) * 10000 + bis_id) * 10 + source_id
#
#
# def get_sourceless_range(nka_id: int, alarm_id: int, signal_id: int) -> (int, int):  # FIXME НИГДЕ НЕ ИСПОЛЬЗУЕТСЯ
#     """Ф-я получения пары значений, между которыми будут находиться идентификаторы комбинаций независимо от источника"""
#     range_begin = encode_combination_id(nka_id, alarm_id, signal_id, 0, 0)
#     return range_begin, range_begin + (MAXIMAL_BIS_ID * 10) + 9  # младшие 5 дес.разрядов имеют максимальное значение
#
#
# def decode_combination_id(combination_id: int) -> list:
#     """Преобразование идентификатора комбинации в перечень идентификаторов составляющих
#
#     См. описание encode_combination_id в части ограничений"""
#     source_id = combination_id % 10
#     combination_id //= 10
#     bis_id = combination_id % 10000
#     combination_id //= 10000
#     signal_id = combination_id % 1000
#     combination_id //= 1000
#     alarm_id = combination_id % 100
#     return [combination_id // 100, alarm_id, signal_id, bis_id, source_id]
#
#
# class SignalFlagStorage:
#     """Класс хранения сигнальных признаков в денормализованном виде
#
#     Ключи: КА/событие/сигнал"""
#     signal_flags = defaultdict(lambda: defaultdict(lambda: defaultdict(SignalFlagGroup)))
#
#     def __init__(self):
#         self.flags_to_insert_to_db = []
#         """Список сигнальных флагов, готовых к вставке в ТЛБД"""
#         self.flags_to_update_in_db = []
#         """Список сигнальных флагов, готовых к обновлению в ТЛБД"""
#         self.last_flush_to_db = datetime.datetime.min
#         """Время последнего обновления сигнальных флагов в ТЛБД"""
#
#     def add_single_signal_flag(self, nka_id: int, alarm_id: int, signal_id: int, bis_id: int, source_id: int,
#                                alarm_value: int, alarm_timestamp: datetime.datetime):
#         """Ф-я добавления одиночного сигнального признака, используемая как во внешних, так и во внутренних вызовах"""
#
#         # получаем дескриптор с соответствующей группой СП (если она отсутствовала, будет создан чистый)
#         current_signal_group = self.signal_flags[nka_id][alarm_id][signal_id]
#         current_signal_group.is_explicit_finalize = alarm_id == AlarmId.absent_signal
#         # если заполняем новый дескриптор, то инициализируем значение фильтрации (признак явного заполнения)
#         if current_signal_group.sound_alarm_status == SoundAlarmStatus.undefined:
#             current_signal_group.sound_alarm_status = SoundAlarmStatus.unmuted
#         # получаем дескриптор с соответствующей конкретной комбинацией СП (если она отсутствовала, будет создан чистый)
#         current_signal_descriptor = current_signal_group.signal_flags[bis_id][source_id]
#
#         # особая обработка ВНКУ по потребностям эксплуатанта (новое значение ВНКУ --- новое событие, о котором надо уведомлять)
#         if (alarm_id == AlarmId.ground_control_call) \
#                 and (current_signal_descriptor.value is not None) \
#                 and (current_signal_descriptor.value != alarm_value):  # проверяем несовпадение значений
#             current_signal_descriptor.finalize(FinalizeCode.value_changed)  # конкретный СП будет пересоздан
#             current_signal_group.event_status = EventStatus.active  # выставляем признак для информирования
#             current_signal_group.notification_status = NotificationStatus.new  # звуковое информирование
#
#         current_signal_group.event_status = EventStatus.active
#
#         # ситуация повторяется, обновляем дескриптор, но пользователя не информируем дополнительно
#         # у новой ситуации будет признак нефинализированности
#         if current_signal_descriptor.finalize_code != FinalizeCode.in_progress:
#             # сохранять содержимое старого дескриптора в ТЛБД нет необходимости т.к. это было сделано при финализации
#             # создаем новый дескриптор для заполнения с чистого листа
#             current_signal_descriptor = SignalFlagDescriptor()
#             current_signal_group.signal_flags[bis_id][source_id] = current_signal_descriptor
#             current_signal_group.notification_status = NotificationStatus.new
#
#         current_signal_descriptor.value = alarm_value
#
#         """Предполагаем, что дублирование пакетов от СПО сети БИС не будет встречатья.
#         Несоблюдение этого условия приведет к неверному подсчету количества сигнальных признаков на интервале"""
#         current_signal_descriptor.appear_count += 1
#         current_signal_descriptor.combination_id = encode_combination_id(nka_id, alarm_id, signal_id, bis_id, source_id)
#
#         """В начальном состоянии время в структуру не заполнено, присваиваем текущее для исключения сбоев при
#         последущем выборе максимального времени"""
#         if current_signal_descriptor.last_appear_timestamp is None:
#             current_signal_descriptor.last_appear_timestamp = alarm_timestamp
#             alarm_case_dict = {
#                 'nka': nka_id,
#                 'alarm': alarm_id,
#                 'alarm_value': alarm_value,
#                 'signal': signal_id,
#                 'bis_id': bis_id,
#                 'source': source_id,
#                 'combination': current_signal_descriptor.combination_id,
#                 'first_appear_timestamp': current_signal_descriptor.first_appear_timestamp,
#                 'last_appear_timestamp': current_signal_descriptor.last_appear_timestamp,
#                 'appear_count': 1,
#                 'finalize_reason': FinalizeCode.in_progress
#             }
#             self.flags_to_insert_to_db.append(alarm_case_dict)
#
#         """Защищаемся от ситуации неупорядоченного поступления пакетов, реализуя храповик меток времени"""
#         current_signal_descriptor.last_appear_timestamp = \
#             max(current_signal_descriptor.last_appear_timestamp, alarm_timestamp)
#
#     def finalize_case(self, nka_id: int, alarm_id: int, signal_id: int, bis_id: int,
#                       finalize_code: FinalizeCode) -> bool:
#         """Ф-я финализации ситуации. Если ситуация уже была финализирована и не запрошено удаление, то не делает ничего
#         При запросе пользователя на удаление он будет доведен до конца для сущестующей ситуации.
#         Возвращает False, если финализируемая ситуация не существует, иначе True"""
#
#         # проверяем, что обощенное событие, соответствующее финализируемой записи существует (иначе игнорируем некорректный запрос)
#         if signal_id not in self.signal_flags[nka_id][alarm_id]:
#             return False
#
#         current_signal_group = self.signal_flags[nka_id][alarm_id][signal_id]
#         # если идентификатор БИС равен 0, то ничего не финализируется. Поэтому при удалении далее будет финализациявсех БИС
#         current_signal_group.finalize(bis_id, finalize_code)
#
#         # удалем всю информацию о ситуации по запросу пользователя. При повторе она станет новой
#         if finalize_code == FinalizeCode.user_deleted:
#             # завершаем принудительно все события при удалении
#             for bis_id in current_signal_group.signal_flags.keys():
#                 current_signal_group.finalize(bis_id, finalize_code)
#             self.signal_flags[nka_id][alarm_id].pop(signal_id)
#         return True
#
#     def finalize_combination(self, combination_id: int, finalize_code: FinalizeCode) -> bool:
#         nka_id, alarm_id, signal_id, bis_id, _ = decode_combination_id(combination_id)
#         return self.finalize_case(nka_id, alarm_id, signal_id, bis_id, finalize_code)
#
#     def finalize_out_of_sight(self, nka_id: int, bis_id: int):
#         for alarm_id, alarm_val in self.signal_flags[nka_id].items():  # НКА вышел из ЗРВ - финализация касается всех СП
#             for signal_id, signal_val in alarm_val.items():  # ...и всех сигналов НКА
#                 signal_val.finalize(bis_id, FinalizeCode.out_of_sight)  # но конкретного БИС
#
#     def finalize_emitted(self, nka_id: int, signal_id: int):  # ставший излучаться сигнал затрагивает только один вид СП
#         self.signal_flags[nka_id][AlarmId.absent_signal][signal_id].finalize(UNDEFINED_BIS_ID,
#                                                                              FinalizeCode.out_of_sight)
#
#     def finalize_timeout(self) -> None:
#         """Функция для финализирования группы сигнальных признаков, в которой не появлялись свежие СП в течение заданного времени.
#             Проверяем время у каждого СП в SignalFlagGroup,
#             если в SignalFlagGroup нет ни одного свежего СП(SignalFlagDescriptor), то финализизируем всю группу СП.
#         """
#         timeout_threshold = datetime.timedelta(seconds=config['opmessage']['auto_finalize_timeout'])
#         time_now = datetime.datetime.now()
#         for nka_id, alarms in self.signal_flags.items():  # SignalFlagStorage
#             for alarm_id, alarm_val in alarms.items():
#                 for signal_id, current_signal_group in alarm_val.items():  # SignalFlagGroup
#                     should_finalize = False
#                     if current_signal_group.event_status == EventStatus.finalized:
#                         continue
#                     for bis_id, signal_descriptor_group in current_signal_group.signal_flags.items():  # SignalFlagDescriptor
#                         if not signal_descriptor_group:
#                             continue
#                         should_finalize = True  # если СП не приходило ни с одного источника в течение заданного времени, то finalized
#                         for source_id, signal_descriptor in signal_descriptor_group.items():
#                             if signal_descriptor.last_appear_timestamp is not None \
#                                     and (abs(time_now - signal_descriptor.last_appear_timestamp) < timeout_threshold):
#                                 should_finalize = False
#                                 break  # Выходим из цикла, если нашли свежий СП в SignalFlagGroup
#                         if not should_finalize:
#                             break
#                     if should_finalize:  # Финализируем СП для всех БИС, так как ни по одному из БИС нет такого свежего СП
#                         for bis_id, _ in current_signal_group.signal_flags.items():  # SignalFlagDescriptor
#                             current_signal_group.finalize(bis_id, FinalizeCode.timeout)  # в этом случае update в базу
#
#     def change_notification_status(self, nka_id: int) -> None:
#         """Функция для изменения статуса подтверждения СП (красная цветовая рамка вокруг СП)
#             При выходе НКА из зоны видимости через заданное время изменяем статус на approved.
#         """
#         timeout_threshold = datetime.timedelta(seconds=config['opmessage']['auto_approve_timeout'])
#         time_now = datetime.datetime.now()
#         for alarm_id, alarm_val in self.signal_flags.get(nka_id, {}).items():  # SignalFlagStorage
#             for signal_id, current_signal_group in alarm_val.items():  # SignalFlagGroup
#                 if not current_signal_group:
#                     continue
#                 if current_signal_group.event_status == EventStatus.active:
#                     continue
#                 should_change_status = False
#                 for bis_id, bis_signal_flags in current_signal_group.signal_flags.items():  # SignalFlagDescriptor
#                     if bis_signal_flags:
#                         should_change_status = True
#                         if SourceId.KNP in bis_signal_flags.keys():
#                             # Проверяем, превышен ли таймаут для всех сигнальных признаков
#                             should_change_status = all(
#                                 abs(time_now - signal_descriptor.last_appear_timestamp) > timeout_threshold
#                                 for signal_descriptor in bis_signal_flags.values()
#                             )
#                             if not should_change_status:
#                                 break
#                 if should_change_status:
#                     current_signal_group.notification_status = NotificationStatus.approved
#
#     def approve_combination(self, combination_id: int) -> bool:
#         nka_id, alarm_id, signal_id, _, _ = decode_combination_id(combination_id)
#         # проверяем, что финализируемая запись существует (иначе игнорируем некорректный запрос)
#         if signal_id not in self.signal_flags[nka_id][alarm_id]:
#             logger.info(f'Попытка отключить сигнализацию для несуществующей ситуации {combination_id}')
#             return False
#
#         return self.signal_flags[nka_id][alarm_id][signal_id].approve()
#
#     def add_operative_message(self, stored_message: 'OpMessage'):
#         """Декодируем струтктуру оперативного сообщения с выделением необходимых полей и охранением в аккумуляторе"""
#
#         """Определяем источник на основе типа данных"""
#         source_id = SourceId.BIS
#         if type(stored_message) is KNPOpMessage:
#             source_id = SourceId.KNP
#         if type(stored_message) is KNPOpSumMessage:
#             source_id = SourceId.KNPSum
#
#         """Выделям набор сигнальных признаков для сохранения каждого"""
#         message_signal_flags = {}
#         if source_id == SourceId.BIS or source_id == SourceId.KNP:
#             if stored_message.ground_control_call:
#                 message_signal_flags[AlarmId.ground_control_call] = stored_message.ground_control_call
#             if stored_message.unreliable_frame:
#                 message_signal_flags[AlarmId.unreliable_frame] = stored_message.unreliable_frame
#             if stored_message.unreliable_signal:
#                 message_signal_flags[AlarmId.unreliable_signal] = stored_message.unreliable_signal
#             if stored_message.unreliable_digital_info:
#                 message_signal_flags[AlarmId.unreliable_digital_info] = stored_message.unreliable_digital_info
#             if stored_message.not_in_sight:
#                 message_signal_flags[AlarmId.absent_signal] = 1
#             if stored_message.tk_inconsistency:
#                 message_signal_flags[AlarmId.tk_inconsistency] = stored_message.tk_inconsistency
#             if stored_message.tb_inconsistency:
#                 message_signal_flags[AlarmId.tb_inconsistency] = stored_message.tb_inconsistency
#         if source_id == SourceId.KNPSum:
#             if stored_message.EI_inconsistency:
#                 message_signal_flags[AlarmId.EI_inconsistency] = stored_message.tk
#             if stored_message.clock_inconsistency:
#                 message_signal_flags[AlarmId.clock_inconsistency] = stored_message.tk
#             if stored_message.almanac_inconsistency:
#                 message_signal_flags[AlarmId.almanac_inconsistency] = stored_message.tk
#
#         # если актуально, заполняем кэш идентификаторов БИС для снижения накладных расходов на их декодирование
#         if len(message_signal_flags):
#             if stored_message.bis_id not in bis_id_cache:
#                 if stored_message.bis_id == MAXIMAL_BIS_ID:  # сигнальный признак выделен в результате обощения и не привязан к БИС
#                     bis_id_cache[stored_message.bis_id] = [99, 99]
#                 else:
#                     bis_id_cache[stored_message.bis_id] = [stored_message.bis.station.station_number,
#                                                            stored_message.bis.bis_number]
#
#         """Сохраняем каждый сигнальный признак в хранилище с атрибуцией"""
#         for current_alarm_id, message_value in message_signal_flags.items():
#             self.add_single_signal_flag(nka_id=stored_message.nka_id,
#                                         alarm_id=current_alarm_id,
#                                         signal_id=stored_message.signal_type,
#                                         bis_id=stored_message.bis_id,
#                                         source_id=source_id,
#                                         alarm_value=message_value,
#                                         alarm_timestamp=stored_message.timestamp)
#
#     def delete_client_representation(self, approved_combinations: list):
#         """Ф-я подтверждения ознакомлениф клиента с конкретными сигнальными признаками с удалением из аккумулятора"""
#
#         # если оператор не указал конкретные просмотренные комбинации, то считаем что ознакомление было со всеми
#         if len(approved_combinations) == 0:
#             for satellite_id, satellite_val in self.signal_flags.items():
#                 for alarm_id, alarm_val in satellite_val.items():
#                     for signal_flag_group in alarm_val.values():
#                         for bis_id in signal_flag_group.signal_flags.keys():
#                             signal_flag_group.finalize(bis_id, FinalizeCode.user_deleted)
#             self.signal_flags.clear()
#
#         for combination_id in approved_combinations:
#             finalize_result = self.finalize_combination(combination_id, FinalizeCode.user_deleted)
#             if not finalize_result:
#                 raise KeyError('Попыка удалить несуществующую комбинацию')
#
#     def approve_client_representation(self, approved_combinations: list):
#         """Ф-я подтверждения ознакомлениф клиента с конкретными сигнальными признаками"""
#
#         # если оператор не указал конкретные просмотренные комбинации, то считаем что ознакомление было со всеми
#         if len(approved_combinations) == 0:
#             for satellite_id, satellite_val in self.signal_flags.items():
#                 for alarm_id, alarm_val in satellite_val.items():
#                     for signal_flag_group in alarm_val.values():
#                         signal_flag_group.approve()
#
#         for combination_id in approved_combinations:
#             finalize_result = self.approve_combination(combination_id)
#             if not finalize_result:
#                 raise KeyError('При подтверждении событий возникли ошибки. Подробности указаны в журналах логов')
#
#     def prepare_updates_for_all_flags(self, nka_id: int, current_time: datetime.datetime):
#         """Собирает все уникальные обновления сигнальных признаков для НКА, находящихся в зоне гарантрованного приема"""
#         # Создаем словарь из существующих данных
#         existing_updates = {
#             (item['combination_id'], item['first_appear_timestamp']): item
#             for item in self.flags_to_update_in_db
#         }
#
#         # Обрабатываем новые обновления
#         for alarm_id, alarm_val in self.signal_flags[nka_id].items():
#             for signal_id, signal_val in alarm_val.items():
#                 single_signal_flag_group_updates = signal_val.prepare_updates_for_group(current_time)
#
#                 for update in single_signal_flag_group_updates:
#                     key = (update['combination_id'], update['first_appear_timestamp'])
#
#                     if key in existing_updates:
#                         existing = existing_updates[key]
#                         # Обновляем, если новая запись имеет больший appear_count или более позднее last_appear_timestamp
#                         if (update['appear_count'] > existing['appear_count'] or
#                                 update['last_appear_timestamp'] > existing['last_appear_timestamp']):
#                             existing_updates[key] = update
#                     else:
#                         existing_updates[key] = update
#
#         # Обновляем self.flags_to_update_in_db новым списком уникальных обновлений
#         self.flags_to_update_in_db = list(existing_updates.values())
#
#     def get_status(self) -> str:
#         """Признак наличия ситуация, о которых необходимо сигнализировать и уведомлять оператора"""
#         for satellite_id, satellite_val in self.signal_flags.items():
#             for alarm_id, alarm_val in satellite_val.items():
#                 for signal_flag_group in alarm_val.values():
#                     if signal_flag_group.notification_status == NotificationStatus.new:
#                         return 'Present'
#         return 'Absent'
#
#     def insert_flags_to_db(self, current_time=datetime.datetime.now()):
#         """
#         Вставка сигнальных признаков в БД пачкой
#         """
#         if self.flags_to_insert_to_db:
#             try:
#                 with db.atomic():
#                     (AlarmCases
#                      .insert_many(self.flags_to_insert_to_db)
#                      .on_conflict(
#                         conflict_target=[AlarmCases.combination, AlarmCases.first_appear_timestamp],
#                         update={
#                             AlarmCases.appear_count: 1,
#                             AlarmCases.last_appear_timestamp: EXCLUDED.last_appear_timestamp,
#                             AlarmCases.finalize_reason: FinalizeCode.in_progress
#                         }
#                     )
#                      .execute())
#             except Exception as e:
#                 logger.warning(f'Ошибка при групповом обновлении сигнальных признаков в ТЛБД: {str(e)}')
#
#             #  очищаем буфер для вставки сигнальных признаков
#             self.flags_to_insert_to_db = []
#
#     def update_flags_in_db(self):
#         """
#         Обновление  сигнальных признаков в БД пачкой
#         """
#         if self.flags_to_update_in_db:
#             # Подготовка данных для SQL-запроса
#             update_data = [(item['last_appear_timestamp'], item['appear_count'],
#                             item['combination_id'], item['first_appear_timestamp'])
#                            for item in self.flags_to_update_in_db]
#
#             # SQL-запрос для массового обновления
#             sql = """
#                 UPDATE alarmcases
#                 SET last_appear_timestamp = data.last_appear_timestamp,
#                     appear_count = data.appear_count
#                 FROM (VALUES %s) AS data(last_appear_timestamp, appear_count, combination_id, first_appear_timestamp)
#                 WHERE alarmcases.combination = data.combination_id
#                   AND alarmcases.first_appear_timestamp = data.first_appear_timestamp
#                 """
#
#             try:
#                 # conn = psycopg2.connect(**connection_params)
#                 with psycopg2.connect(**connection_params) as conn:
#                     with conn.cursor() as cursor:
#                         execute_values(cursor, sql, update_data)
#                         logger.debug(f'Обновлено признаков в таблице AlarmCases: {cursor.rowcount}')
#             except psycopg2.OperationalError as e:
#                 logger.warning(f'Не удалось подключиться к БД для группового обновления признаков в ТЛБД: {str(e)}')
#             except Exception as e:
#                 logger.warning(f'Ошибка при групповом обновлении сигнальных признаков в ТЛБД: {str(e)}')
#
#             # Очищаем буфер для обновления сигнальных признаков
#             self.flags_to_update_in_db = []
#
#     def flush_to_db(self, current_time: datetime):
#         """
#         Запись и обновление всех сигнальных признаков в БД
#         """
#         if abs(self.last_flush_to_db - current_time).total_seconds() > 5:
#             self.insert_flags_to_db()
#             self.update_flags_in_db()
#             self.last_flush_to_db = datetime.datetime.now()
#
#
# class SignalFlagFilter:
#     """Стуруктура описания параметров фильтрации"""
#
#     def __init__(self):
#         self.filtered_bises: dict = {}  # ключ: идентификатор БИС, значение: время сброса фильтра
#         self.filtered_satellites: dict = {}  # ключ: идентификатор БИС, значение: время сброса фильтра
#         self.filtered_combination: dict = {}  # ключ: время сброса фильтра
#
#     def __str__(self):
#         return f"filter content:\nnka:{str(self.filtered_satellites)}\nbis:{str(self.filtered_bises)}\ncombination:{str(self.filtered_combination)}"
#
#
# class SignalFlagAccumulator:
#     storage: SignalFlagStorage
#     filters = defaultdict(SignalFlagFilter)  # ключи: идентификатор клиента / МВ окончания применения
#     ground_control_call_lists: list = []
#     """Список оперативных сообщений: Вызов НКУ."""
#
#     def get_actual_filters(self) -> SignalFlagFilter:
#         """Получаем сосвокупное состяоние фильтров дял конкретного клиента"""
#
#         result = SignalFlagFilter()  # Пустая структура, используемая как контейнер для сохранения результатов
#         time_now = datetime.datetime.now()  # Однократно получаем текущее время для проверки устаревания фильтров
#         # удаляем устаревшие записи (т.к. количество фильтров оценивается для клиента менее 25, то копирование быстро)
#         client_filters = {key: val for key, val in self.filters.items() if key > time_now}
#         self.filters = client_filters
#
#         # Проходим по всем фильтрам для клиента
#         for actual_border, current_filter in client_filters.items():
#             # мало проверок корректности данных не бывает
#             if actual_border < time_now:
#                 continue
#
#             # Собираем воедино фильтры, заданные в разные времена для совокупной картины
#             for bis_id in current_filter.filtered_bises.keys():
#                 result.filtered_bises[bis_id] = actual_border
#             for nka_id in current_filter.filtered_satellites.keys():
#                 result.filtered_satellites[nka_id] = actual_border
#             for combination_id in current_filter.filtered_combination.keys():
#                 # возвращаем идентификатор без БИС и типа источника, т.к. фильтрация не зависит от них
#                 result.filtered_combination[(combination_id // 100000) * 100000] = actual_border
#         return result
#
#     def add_operative_message(self, stored_message: 'OpMessage'):  # Ф-я обертка
#         self.storage.add_operative_message(stored_message)
#
#     def as_dict_for_client(self) -> list:
#         """Формируем сигнальные признаки для конкретного клиента с целью отображения"""
#
#         actual_filters = self.get_actual_filters()  # определяем фильтры для исключения лишнего
#
#         # хранилище результата с возможностью создания конечного элемента
#         result = []
#         self.ground_control_call_lists = []  # список вызовов НКУ
#         for satellite_id, satellite_val in self.storage.signal_flags.items():
#             if satellite_id not in NKA_SIGNALS.keys():
#                 continue
#             satellite_muted = False  # признак отключения сигнализации для НКА --- всегда надеемся на лучшее для начала
#             if satellite_id in actual_filters.filtered_satellites:  # отключаем сигнализацию у фильтруемого НКА
#                 satellite_muted = True
#             for alarm_id, alarm_val in satellite_val.items():
#                 for signal_id, alarm_group in alarm_val.items():
#                     alarm_muted = satellite_muted  # если сигнализация скрыта для целого НКА, то она скрыта для всех БИС-источников
#                     if (len(alarm_group.signal_flags) == 0) \
#                             or (alarm_group.sound_alarm_status == SoundAlarmStatus.undefined):
#                         continue
#
#                     # отключаем сигнализацию у записи при нахождении их в перечне комбинаций
#                     sourcless_combination_id = encode_combination_id(satellite_id, alarm_id, signal_id, 0, 0)
#                     if sourcless_combination_id in actual_filters.filtered_combination:
#                         alarm_muted = True
#                     alarm_group.sound_alarm_status = SoundAlarmStatus.muted if alarm_muted else SoundAlarmStatus.unmuted
#                     # добавляем не сразу т.к. необходимо сформировать обощенные данные
#                     summarized_alarm_state = {
#                         'nka': satellite_id,
#                         'signal_type': signal_id,
#                         'message': {'type': int(alarm_id), 'value': None},
#                         'sources': [],  # будет заполняться в цикле далее
#                         'count': 0,  # будет заполняться в цикле далее
#                         'first_at': datetime.datetime.now(),  # будет заполняться в цикле далее
#                         'last_at': datetime.datetime.fromtimestamp(timestamp=0),  # будет заполняться в цикле далее
#                         'combination': sourcless_combination_id,
#                         'event_status': int(alarm_group.event_status),
#                         'notification_status': int(alarm_group.notification_status),
#                         'sound_status': int(alarm_group.sound_alarm_status),
#                     }
#                     # дозаполняем обощенную структуру
#                     for bis_id, bis_val in alarm_group.signal_flags.items():
#                         if bis_id not in bis_id_cache:
#                             continue
#                         bis_name = bis_id_cache[bis_id]
#                         for source_id, alarm_descriptor in bis_val.items():  # обрабатываем каждый источник в составе записи о БИС
#                             if alarm_id == 1:
#                                 alarm_param_value = format_ground_call_control_raw_value(signal_id,
#                                                                                          alarm_descriptor.value)
#                             elif alarm_id == 6:  # перевод tk в формат 'd.%m.%Y %H:%M:%S'
#                                 alarm_param_value = (datetime.datetime.fromtimestamp(alarm_descriptor.value)) \
#                                     .strftime("%d.%m.%Y %H:%M:%S")
#                             elif alarm_id == 7:  # перевод tb в формат '%H:%M:%S'
#                                 if (signal_id in L1_FREQ_SIGNAL_TYPES) or (signal_id in L2_FREQ_SIGNAL_TYPES):
#                                     tb_time_format = FD.common.tb_to_datetime(alarm_descriptor.value) \
#                                         .strftime("%H:%M:%S")
#                                     alarm_param_value = tb_time_format
#                                 elif (signal_id in L1_CODE_SIGNAL_TYPES) \
#                                         or (signal_id in L2_CODE_SIGNAL_TYPES) \
#                                         or (signal_id in L3_CODE_SIGNAL_TYPES):
#                                     tb_time_format = CD.common.tb_to_datetime(alarm_descriptor.value) \
#                                         .strftime("%H:%M:%S")
#                                     alarm_param_value = tb_time_format
#                             else:
#                                 alarm_param_value = alarm_descriptor.value
#                             # реализуем приоритет заполнения значения: в первую очередь заполняем значениями от КНП
#                             if source_id == SourceId.KNP:
#                                 summarized_alarm_state['message']['value'] = alarm_param_value
#                             # для всех СП, кроме ВНКУ: если значение пустое, то используем значение от БИС
#                             if (alarm_id != AlarmId.ground_control_call) and (
#                                     summarized_alarm_state['message']['value'] is None):
#                                 summarized_alarm_state['message']['value'] = alarm_param_value
#                             # обощаем временные показатели
#                             summarized_alarm_state['first_at'] = min(summarized_alarm_state['first_at'],
#                                                                      alarm_descriptor.first_appear_timestamp)
#                             summarized_alarm_state['last_at'] = max(summarized_alarm_state['last_at'],
#                                                                     alarm_descriptor.last_appear_timestamp)
#                             # подсчитываем совокупное число появлений
#                             summarized_alarm_state['count'] += alarm_descriptor.appear_count
#                             # заполняем для обеспечения доступа клиента к первичным, необобщенным данных
#                             summarized_alarm_state['sources'].append({
#                                 'bis': bis_name[1],
#                                 'station': bis_name[0],
#                                 'bis_id': bis_id,
#                                 'source': int(source_id),
#                                 'message': {'type': int(alarm_id), 'value': alarm_param_value},
#                                 'count': alarm_descriptor.appear_count,
#                                 'first_at': alarm_descriptor.first_appear_timestamp,
#                                 'last_at': alarm_descriptor.last_appear_timestamp,
#                                 'combination': alarm_descriptor.combination_id,
#                                 'finalize_code': alarm_descriptor.finalize_code,
#                             })
#
#                     result.append(summarized_alarm_state)
#                     if alarm_id == AlarmId.ground_control_call:
#                         self.ground_control_call_lists.append(summarized_alarm_state)
#
#         return result
#
#     def delete_combinations(self, approved_combinations: list):  # Ф-я обертка
#         self.storage.delete_client_representation(approved_combinations)
#
#     def approve_combinations(self, approved_combinations: list):  # Ф-я обертка
#         self.storage.approve_client_representation(approved_combinations)
#
#     def finalize_out_of_sight(self, nka_id: int, bis_id: int):  # Ф-я обертка
#         self.storage.finalize_out_of_sight(nka_id, bis_id)
#
#     def finalize_emitted(self, nka_id: int, signal_id: int):  # Ф-я обертка
#         self.storage.finalize_emitted(nka_id, signal_id)
#
#     def finalize_timeout(self):  # Ф-я обертка
#         self.storage.finalize_timeout()
#
#     def change_notification_status(self, nka_id: int):  # Ф-я обертка
#         self.storage.change_notification_status(nka_id)
#
#     def prepare_updates(self, nka_id: int, current_time: datetime.datetime):  # Ф-я обертка
#         self.storage.prepare_updates_for_all_flags(nka_id, current_time)
#
#     def get_status(self) -> str:  # Ф-я обертка
#         return self.storage.get_status()
#
#     def __init__(self):
#         self.storage = SignalFlagStorage()
#
#     def set_filter(self, filtered_nka: list, filtered_bises: list, filtered_combinations: list,
#                    cooldown_seconds=None) -> ServerStatusCode:
#         """Задаем фильтры с контролем времени скрытия данных"""
#
#         # проверить, что значение cooldown_seconds в ОДЗ
#         if cooldown_seconds and cooldown_seconds not in allowed_hide_intervals:
#             return ServerStatusCode.BAD_DATA
#
#         # Расссчитываем время, когда фильтр должен прекращаться использоваться
#         # Если это фильтр без времени, то устанавливаем его время далеко вперед
#         if cooldown_seconds:
#             filter_actual_time = datetime.datetime.now() + datetime.timedelta(seconds=cooldown_seconds)
#             # Пакуем фильтры в структуру и сохраняем в хранилище с ключом времени актуальности
#             filter_parameters = SignalFlagFilter()
#             filter_parameters.filtered_bises = {key: 0 for key in filtered_bises if key}
#             filter_parameters.filtered_satellites = {key: 0 for key in filtered_nka if key}
#             filter_parameters.filtered_combination = {key: 0 for key in filtered_combinations if key}
#             self.filters[filter_actual_time] = filter_parameters
#
#         else:
#             if DATE_PERMANENT_FILTER not in self.filters:
#                 self.filters[DATE_PERMANENT_FILTER] = SignalFlagFilter()
#             filter_permanent = self.filters[DATE_PERMANENT_FILTER]
#             for key in filtered_bises:
#                 if key:
#                     filter_permanent.filtered_bises[key] = 0
#             for key in filtered_nka:
#                 if key:
#                     filter_permanent.filtered_satellites[key] = 0
#             for key in filtered_combinations:
#                 if key:
#                     filter_permanent.filtered_combination[key] = 0
#         return ServerStatusCode.OK
#
#     def filters_as_dict(self) -> dict:
#         """Представляем информацию о фильтрах клиента"""
#
#         actual_filters = self.get_actual_filters()
#
#         # Пакуем информацию о комбинациях
#         combination_list = {}
#         for combination_id, actual_time in actual_filters.filtered_combination.items():
#             nka_id, alarm_id, signal_id, bis_id, source_id = decode_combination_id(combination_id)
#             combination_list[combination_id] = {'nka': nka_id,
#                                                 'alarm': alarm_id,
#                                                 'signal': signal_id,
#                                                 'bis': bis_id,
#                                                 'source': source_id,
#                                                 'present': actual_time}
#
#         # Формируем структуру верхнего уровня описания
#         result = {'nka': {nka_id: actual_time for nka_id, actual_time in actual_filters.filtered_satellites.items()},
#                   'bis': {bis_id: actual_time for bis_id, actual_time in actual_filters.filtered_bises.items()},
#                   'combination': combination_list,
#                   'allowed_durations': [single_interval for single_interval in allowed_hide_intervals]}
#         return result
#
#     def kill_permanent_filter(self,
#                               not_filtered_nka: list,
#                               not_filtered_bises: list,
#                               not_filtered_combinations: list) -> ServerStatusCode:
#         """Удаление постоянных фильтров из списка"""
#         filter_permanent = self.filters[DATE_PERMANENT_FILTER]
#         try:
#             for key in not_filtered_bises:
#                 if key:
#                     del filter_permanent.filtered_bises[key]
#             for key in not_filtered_nka:
#                 if key:
#                     del filter_permanent.filtered_satellites[key]
#
#                     # Ищем в словаре фильтруемых комбинаций те, что относятся к данному НКА
#                     combinations_to_delete = []
#                     for combination in filter_permanent.filtered_combination.keys():
#                         if int(combination // 1e9) == int(key):
#                             combinations_to_delete.append(combination)
#
#                     #  И тоже их вычищаем
#                     for combination in combinations_to_delete:
#                         del filter_permanent.filtered_combination[combination]
#             for key in not_filtered_combinations:
#                 if key:
#                     del filter_permanent.filtered_combination[key]
#         except KeyError:
#             logger.info(f'Не удалось удалить сигнализацию для комбинации {key}')
#             pass
#
#         return ServerStatusCode.OK
#
#     def flush_to_db(self, current_time=datetime.datetime.now()):
#         self.storage.flush_to_db(current_time)
