import utils.PDOP.PDOPCalculator as PDOPCalculator  # набрал код почти наугад, возможно заработает
from threading import Thread
from queue import Queue
import time
import logging

logger = logging.getLogger('pdop_thread')

class PDOPThread():
    """
    класс для работы с потоком, реализующим только лишь функцию расчета среднего значения PDOP
    1) создание потока
    2) запрос статуса потока
    3) запрос результатов
    """
    thr = Thread()  # поток, в котором будет проводиться расчет
    q0 = Queue()  # очередь, в которой будет храниться процент расчета
    q0.maxsize = 1

    PDOPcalc: PDOPCalculator.PDOPcalculator = None
    result = []

    def __init__(self):
        self.zone = None
        self.PDOPcalc = PDOPCalculator.PDOPcalculator()

    def createthread(self, args1):
        """запуск потока

        аргументы в списке agrs1 - такие же как в функции get_pdop_for_date_grid_and_constellation
        """
        if self.thr.is_alive() == True:  # проверка того, запущен ли поток уже. Если запущен, закрываем его посредством установки значения переменной PDOPCalculator.StopPDOPcalc = True
            self.PDOPcalc.StopPDOPcalc = True
            # self.PDOPcalc.resultPDOP = {'PDOP0': -1, 'PDOP': -1, 'access': -1, 'partical_PDOP': -1}
            self.PDOPcalc.resultPDOP = {}
            time.sleep(0.5)
        # установка параметров класса, соответствующих запущенному расчету
        self.PDOPcalc.StopPDOPcalc = False
        self.PDOPcalc.status = PDOPCalculator.CalculationStatus.CALCULATING
        self.PDOPcalc.comment = ['calculating...']

        if (len(self.q0.queue) == 0):
            self.q0.put(0)
        else:
            self.q0.get(0)
        self.PDOPcalc.queueout = self.q0

        # запуск потоковой функции

        if (args1[6] == 0):  # аргумент - равномерность сетки. Зпауск функции для расчета PDOP.
            self.mode = 0
            self.thr = Thread(target=self.PDOPcalc.get_pdop_for_date_grid_and_constellation,
                              args=([args1[0], args1[1], args1[2], args1[3], args1[4], args1[6], args1[7]]))

        if (args1[6] == 1):  # Сетка - равномерная, запуск функции для расчета доступности.
            self.mode = 1
            self.thr = Thread(target=self.PDOPcalc.get_availability_for_date_grid_and_constellation,
                              args=([args1[0], args1[1], args1[2], args1[3], args1[4], args1[7]]))
        self.zone = args1[1]

        i = self.thr.start()

        if (args1[6] == 0):
            logger.info(
                f"Начат расчет PDOP. КА: {str(args1[0])}, территория: {str(args1[1])}, \
                день: {str(args1[2])}, месяц: {str(args1[3])}, \
                год: {str(args1[4])}, режим:{str(args1[6])}.")  # смысла выводить mode нет, так как он соответствует третьему слову
        if (args1[6] == 1):
            logger.info(f"Начат расчет доступности. \
                        КА: {str(args1[0])}, территория: {str(args1[1])}, \
                        день: {str(args1[2])}, месяц: {str(args1[3])}, \
                        год: {str(args1[4])}, режим: {str(args1[6])}.")

        return i

    def getthreadstatus(self):
        """"получение статуса потока"""
        return self.thr.is_alive()

    def getresult(self):
        """"возврат результатов расчета"""
        try:
            if (self.mode == 0): return self.PDOPcalc.result_PDOP
            if (self.mode == 1): return self.PDOPcalc.av
        except AttributeError:
            return self.PDOPcalc.result_PDOP

    def getstatepercentage(self):
        """возврат состояния расчета"""
        try:
            if (self.mode == 0):
                pass
            if (self.mode == 1):
                if self.PDOPcalc.calc_phase == 0: phase = 'Фаза рассчета PDOP.'
                if self.PDOPcalc.calc_phase == 1: phase = 'Фаза рассчета доступности.'
        except AttributeError:
            pass
        return self.PDOPcalc.CalcState2

    def stop(self):
        """принудительная остановка потока"""

        self.PDOPcalc.result_PDOP['PDOP0'] = None
        self.PDOPcalc.result_PDOP['PDOP'] = None
        self.PDOPcalc.result_PDOP['availability'] = None

        self.PDOPcalc.StopPDOPcalc = True
        return 0

    def getstatus(self):
        try:
            if (self.mode == 1) & (self.PDOPcalc.calc_phase == 0):
                self.PDOPcalc.status = PDOPCalculator.CalculationStatus.CALCULATING
        except AttributeError:
            return self.PDOPcalc.status

        return self.PDOPcalc.status

    def getcomment(self):
        return PDOPCalculator.state_dict[self.PDOPcalc.status]


PDOP_Thread: PDOPThread()
PDOP_Thread = PDOPThread()
PDOP_Thread.CalcState2 = 0
PDOP_Thread.result = - 1
from queue import Queue

q0 = Queue()
