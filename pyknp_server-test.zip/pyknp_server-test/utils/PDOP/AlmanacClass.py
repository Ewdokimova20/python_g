from data import L1OFString
from data import L1OFFrame
from math import *
from datetime import datetime
from typing import NamedTuple
from utils.lib.kepler_to_xyz import kepler_to_xyz
from global_data import appdata

r_earth = 6378.136e3  # радиус Земли

class NKA_almanac(NamedTuple):
    """ класс с описанием параметров движения для одного КА. """
    # нужно будет сделать конфигурационный файл, который будет содержать информацию о всех КА, которые летают (в ОГ + на ЛИ + вывыдены из системы)
    # в этом файле нужно будет установить (и периодически актуализировать) соответствие между номерами КА в НКУ, системными номерами и номерами системных точек
    # экземпляр этого класса - основа для сборки целого альманаха.
    nku_number: int # номер КА в НКУ
    #liter: int # литера
    system_number: int # системный номер
    system_point_number: int # номер системной точки

    N4: int # номер 4-хлетнего интрвала
    Na: int # номер суток внутри интервала
    tlambdaA: float # время прохождения восходящего узла, ближайшее к началу суток
    deltatA: float # отклонение периода от номинала
    deltaia: float # отклонение наклонения от номинала
    deltaTdot: float # скорост изменения периода
    ea: float # эксцентриситет
    omegala: float # аргумент перигея
    lambdaA: float # долгота восходящего узла
    divtype: int # 0  - частотное разделение, 1 - кодовое


def get_date_by_n4_na(n_four: int, n_day: int) -> list:
    """
    Функция получения даты (день, месяц, год) по значению
    номера четырехлетия от 1996 года и номера суток в
    текущем четырехлетии.

    :param n_four: номер четырехлетия от 1996 года
    :param n_day: номер суток в текущем четырехлетии
    :returns out: список - число, месяц, год
    """

    if (n_day >= 1) & (n_day <= 366):
        J = 1  # високосный год
    else:
        if (n_day >= 367) & (n_day <= 731):
            J = 2
            n_day = n_day - 366
        else:
            if (n_day >= 732) & (n_day <= 1096):
                J = 3
                n_day = n_day - 366 - 365
            else:
                if (n_day >= 1097) & (n_day <= 1461):
                    J = 4
                    n_day = n_day - 366 - 365 - 365

    year = 1996 + (n_four - 1) * 4 + J - 1  # 3.1.3 ИКД
    days_number_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]  # количество суток по месяцам в нормальном (невисокосном) году
    if (J == 1): days_number_in_month = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]  # количество суток по месяцам в високосном году
    days_integral = [31]
    for i in range(1, 12, 1): days_integral.append(days_integral[i-1] + days_number_in_month[i])
    Months = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сент', 'Окт', 'Нояб', 'Дек']
    days_integral2 = [1]
    for i in range(0, 12, 1): days_integral2.append(days_integral[i])
    day = n_day
    Mon = 0
    day = 0
    if (n_day >= 1) and (n_day <= 31):
        day = n_day
        Mon = 0
    if (n_day > 31) and (n_day <= 31 + days_number_in_month[1]):
        day = n_day - 31
        Mon = 1
    if (n_day > 31 + days_number_in_month[1]) and (n_day <= 62 + days_number_in_month[1]):
        day = n_day - 31 - days_number_in_month[1]
        Mon = 2
    if (n_day > 62 + days_number_in_month[1]) and (n_day <= 92 + days_number_in_month[1]):
        day = n_day - 62 - days_number_in_month[1]
        Mon = 3
    if (n_day > 92 + days_number_in_month[1]) and (n_day <= 123 + days_number_in_month[1]):
        day = n_day - 92 - days_number_in_month[1]
        Mon = 4
    if (n_day > 123 + days_number_in_month[1]) and (n_day <= 153 + days_number_in_month[1]):
        day = n_day - 123 - days_number_in_month[1]
        Mon = 5
    if (n_day > 153 + days_number_in_month[1]) and (n_day <= 184 + days_number_in_month[1]):
        day = n_day - 153 - days_number_in_month[1]
        Mon = 6
    if (n_day > 184 + days_number_in_month[1]) and (n_day <= 215 + days_number_in_month[1]):
        day = n_day - 184 - days_number_in_month[1]
        Mon = 7
    if (n_day > 215 + days_number_in_month[1]) and (n_day <= 245 + days_number_in_month[1]):
        day = n_day - 215 - days_number_in_month[1]
        Mon = 8
    if (n_day > 245 + days_number_in_month[1]) and (n_day <= 276 + days_number_in_month[1]):
        day = n_day - 245 - days_number_in_month[1]
        Mon = 9
    if (n_day > 276 + days_number_in_month[1]) and (n_day <= 306 + days_number_in_month[1]):
        day = n_day - 276 - days_number_in_month[1]
        Mon = 10
    if (n_day > 306 + days_number_in_month[1]) and (n_day <= 337 + days_number_in_month[1]):
        day = n_day - 306 - days_number_in_month[1]
        Mon = 11
    month = Mon + 1
    out = [day, month, year]
    return out

def get_n4_na_by_date(year: int, month: int, day: int) -> list:
    """
    Функция получения номера четырехлетия от 1996 года и номера суток в
    текущем четырехлетии по дате (день, месяц, год)
    :param year: год
    :param month: месяц
    :param day: день

    :returns out: список: [номер четырехлетия от 1996 года, номер суток в текущем четырехлетии]
    """
    out = []
    N4 = floor((year - 1996) / 4) + 1  # получили N4
    J = year - 1996 - (N4 - 1) * 4 + 1  # рассчитываем J. Если J = 1, год - високосный, иначе - нет.
    days_number_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    if (J == 1):days_number_in_month[1] = 29

    N2 = 0
    for i in range(0, month - 1, 1):
        N2 = N2 + days_number_in_month[i]

    if (J == 1):
        N2 = N2
    if (J == 2):
        N2 = N2 + 366
    if (J == 3):
        N2 = N2 + 366 + 365
    if (J == 4):
        N2 = N2 + 366 + 365*2

    Na = N2 + day
    out = [N4, Na, J]
    return out


class Almanac:
    """  описание класса для работы с альманахом. """

    almdict = {} # прочитанный альманах
    n4 = -1
    na = -1
    nka_num = -1

    def get_almanac_from_base(self, nka_num: int, N4: int, Na: int) -> list:
        """
        Функция для чтения альманаха системы из ЛБД СПО КНП.
        Доработанная версия. Альманах считывается сначала из ЦИ L1OF, а потом,
        для тех КА, которых не нашлось в ЦИ L1OF - из ЦИ сигналов с кодовым разделением.
        В качестве источника информации о перечне КА в ОГ (не только штатная ОГ, но и
        КА на ЛИ и выведенные из системы) используется ЛБД СПО КНП (таблица nka).
        Функция не используется в связи с использованием другой.

        :param nka_num: номер КА, из ЦИ которого берётся альманах
        :param N4: номер четырехления, на которое альманах актуален
        :param Na: номер суток внутри четырехлетия
        :returns out: считанный из ЛБД СПО КНП альманах
        """

        # сначала читаем таблицу nka и получаем перечень КА в ОГ
        #all_nkas = []#Nka.select() # запрос к новой ЦБД (все КА)

        # запрос к старой БД
        all_nkas2 =appdata.NKA_DATA.values() # Tka.select(Tka.nka, Tka.tochk, Tka.nameka).where(Tka.zapr == "+").where(Tka.tochk != "00")
        nka_list = []  # список всех КА
        for i in all_nkas2: nka_list.append(i['sys_num'])

        out = []  # инициализация переменной, возвращаемой функцией
        # поиск альманаха от заданного КА на заданный номер суток.
        # сначала ищется строка с номером 5, полученная от заданного КА по сигналу L1OF> потом из неё извлекается номер суток.
        # если номер суток совпадает с тем, который нужен, извлекаем данные из остальных строк и кадров из данного суперкадра.
        str5found = False  # признак того, что 5я строка для КА найдена в ЛБД
        almfound = False  # признак того, что альманах найден в ЛБД
        ntry = 0  # количество попыток
        str5 = L1OFString.select().where(L1OFString.nka == nka_num).where(L1OFString.string_num == 5)  # ищем строку в ЛБД
        nf = len(str5)  # число найденных строк от заданного КА с номером строки == 5
        nf_na = []  # номера строк из результата поиска str5, в которых na равен нужному
        for i in range(len(str5)):
            c = str5[i].as_dict()
            Na_found = c['Na']['val']
            N4_found = c['N4']['val']  # на номер четырехлетия пока не обращаем внимание
            if (Na_found == Na): nf_na.append(i)
        # теперь в массиве nf_na есть все номера элементов массива результата поиска, в котором номер КА и номер дня в 4-хлетии соответствуют заданным.
        for i in nf_na:
            sid0 = str5[i].id
            frame = L1OFFrame.select().where(L1OFFrame.string5_id == sid0)
            if (len(frame) == 0):
                pass
            else:
                frame_found = frame[0]
                super_frame_exists = [0, 0, 0, 0, 0]  # флаг наличия кадров в суперкадре
                frame_id_s = []
                for i2 in range(1, 6, 1):
                    iframeseq = frame_found.seq - frame_found.num + i2
                    super_frame_exists[i2 - 1] = len(
                        L1OFFrame.select().where(L1OFFrame.seq == iframeseq).where(L1OFFrame.nka_id == nka_num))
                    x = L1OFFrame.select().where(L1OFFrame.seq == iframeseq).where(L1OFFrame.nka_id == nka_num)
                    if len(x) != 0:
                        frame_id_s.append(x[0].id)
                if (super_frame_exists[0] != 0) & (super_frame_exists[1] != 0) & (super_frame_exists[2] != 0) & (
                        super_frame_exists[3] != 0) & (super_frame_exists[4] != 0):
                    # все кадры из суперкадра найдены. собираем альманах.
                    almfound = True
                    break

        if almfound == True:
            # начинаем собирать альманах. id кадров с первого по пятый находятся в переменной frame_id_s
            # сборка альманаха
            alman = {}
            for ids in frame_id_s:
                x = L1OFFrame.get_by_id(ids)
                smax = 16
                if (x.num == 5):
                    smax = 14
                for i in range(4, smax, 1):
                    y = x.as_dict()
                    s = y['content']
                    s2 = s[i]
                    if i == 5:
                        s1 = s2
                        N4_found = s1['N4']['val']
                        Na_found = s1['Na']['val']
                    if (i > 5):  # начался альманах. Если кадр с 1го по 4й - то альманах - в строках с 6 по 15 (5 НКА), если 5 й - с 6 по 13 (4 НКА)
                        if (i % 2 == 0):  # четные строки
                            nka_template = {'M_a': s2['M_a']['val'], 'n_a': s2['n_a']['val'], 'taua': s2['tau_a']['val'], 'lambda': s2['lambda_']['val'], 'deltai': s2['delta_i']['val'],
                                            'epsilon': s2['epsilon']['val']}# 'cn': s2['C']['val']} Key error 'C'
                        else:  # нечетные строки
                            nka_template['omega'] = s2['omega']['val']
                            nka_template['t_lambda'] = s2['t_lambda']['val']
                            nka_template['delta_T'] = s2['delta_T']['val']
                            nka_template['d_delta_T'] = s2['d_delta_T']['val']
                            nka_template2 = NKA_almanac(0, nka_template['n_a'], 0, N4_found, Na_found, nka_template['t_lambda'], nka_template['delta_T'], nka_template['deltai'], nka_template['d_delta_T'], nka_template['epsilon'], nka_template['omega'], nka_template['lambda'], 0) # 0 - ЧР
                            alman[nka_template['n_a']] =  nka_template2
                            nka_list.remove(nka_template['n_a'])

            #альманах считан в переменную alman.
            self.almdict = alman

            if len(nka_list) == 0: return 0 # если в альманахе из ЦИ сигналов с ЧР найдены все КА
            else:
                # если в альманахе из ЦИ сигналов с ЧР найдены не все КА, пытаемся найти оставшиеся КА в ЦИ сигналов с КР.
                # пока - заглушка, штатно тут должен производиться вызов функции (наверное лучше не функции, а просто кода),
                # читающей ЦИ сигналов с КР и дособирающей альманах, а также удаляющей найденные КА из списка nka_list
                # после - если список nka_list окажется пустым - значит КА были успешно найдены, возвращаем 0
                # МЕСТО ДЛЯ ЗАГЛУШКИ
                for i in nka_list:
                    # выбираем из ЛБД (таблица с альманахами) строки, отсортированные в порядке убывания сначала по N4, внутри N4 = const - по убывнию N_a
                    s = data.Almanac.select().order_by(data.Almanac.N4).order_by(data.Almanac.N_A)#.where(data.Almanac.approve_count>20)
                    # и выбираем строки для искомого КА, где число повторов > 20, где N4 и NA соответствуют искомым.
                    s2 = s.where(data.Almanac.nka == i).where(data.Almanac.approve_count > 20).where(data.Almanac.N4 == N4).where(data.Almanac.N_A == Na)
                    # теперь нужно выбрать единственную строку, с которой будет браться альманах. Пусть это будет первая по счету строка в базе.
                    if len(s2) > 0:
                        s2 = data.Almanac.select().where(data.Almanac.id == s2)
                        s3 = data.Almanac.get_by_id(s2)

                        nka_template = {'n_a': i, 'lambda': s3.lambda_A, 'deltai': s3.deltaI_A, 'epsilon': s3.e_A}
                        nka_template['omega'] = s3.omega_A
                        nka_template['t_lambda'] = s3.Tlambda_A
                        nka_template['delta_T'] = s3.deltaT_A
                        nka_template['d_delta_T'] = s3.deltaTdot

                        nka_template3 = NKA_almanac(0, nka_template['n_a'], 0, N4_found, Na_found,
                                                    nka_template['t_lambda'], nka_template['delta_T'],
                                                    nka_template['deltai'], nka_template['d_delta_T'],
                                                    nka_template['epsilon'], nka_template['omega'],
                                                    nka_template['lambda'], 0)  # 0 - ЧР
                        alman[nka_template['n_a']] = nka_template3
                        nka_list.remove(nka_template['n_a'])
                    else:
                        logging.warning(f"get_almanac_from_base: Для КА №{str(i)} в ТЛБД нет альманаха.")



                if len(nka_list) == 0: return 0
                # в самом плохом случае - возвращаем сообщение с ошибкой (как результат функции, но поле класса
                # "almdict" все-равно будет заполненным параметрами движения для КА, которые были найдены)
                return nka_list #('get_almanac_from_base: не найдены НКА с системными номерами: ' + str(nka_list)) #outalm
        else:
            return 'get_almanac_from_base: Альманах на заданные N4 и Na не найден (с ЧР)'


    def append_nka_to_almanac(self, nka_sys_num, nka_template: NKA_almanac):
        """функция добавления КА в альманах с заданным системным номером и параметрами движения"""
        self.almdict[nka_sys_num] = nka_template
        return 0

    def alman_to_xyz(self, time: datetime) -> list:  # расчет координат всех КА по альманаху на заданный момент времени
        """
        Функция расчета координат и вектора скорости всех КА альманаха на заданный момент времени.

        :param time: момент времени, на который необходимо расчитать координаты КА
        :param N: номер суток в четырехлетии, на который требуется рассчитать координаты
        :param division_type: вид разделения сигналов для сигнала, из ЦИ которого собран (альманах).Необходим для определения значений периода обращения и наклонения орбиты КА, к которым в кадрре ЦИ передаются поправки (ПОКА ЭТО НЕ РЕАЛИЗОВАНО)
        :returns out: список координат и скоростей всек КА из альманаха на заданный момент времени
        """
        out = {} #[]
        [N4, N, J] = get_n4_na_by_date(time.year, time.month, time.day)

        for nka_sys_num in self.almdict:
            try:
                nka_sys_num
                if self.almdict[nka_sys_num].divtype == 0:#self.almdict[nka_sys_num].divtype == 0:  # вид разделения сигналов для учета разных значений номинала периода обращения и наклонения
                    k = 1
                else:
                    k = 0
                out[nka_sys_num] = kepler_to_xyz(self.almdict[nka_sys_num].N4, self.almdict[nka_sys_num].Na,
                                                 self.almdict[nka_sys_num].tlambdaA,
                                                 self.almdict[nka_sys_num].deltatA + k * (43200 - 40544),
                                                 self.almdict[nka_sys_num].deltaia + k * (63 - 64.8) / 180,
                                                 self.almdict[nka_sys_num].deltaTdot, self.almdict[nka_sys_num].ea,
                                                 #self.almdict[nka_sys_num].deltatA, self.almdict[nka_sys_num].ea,
                                                 self.almdict[nka_sys_num].omegala, self.almdict[nka_sys_num].lambdaA,#N,
                                                  time)

            except KeyError:  # если КА был удален из альманаха то ничего не делаем, но прога не валится из за ошибки.
                pass
        return out

    def __init__(self, **kwargs):
        self.almdict = {}
        out = -2
        try:
            if len(kwargs) == 0:
                # нулевой набор аргументов
                out = 0
                pass
        except KeyError:
            out = -1
            pass
        try:
            if len(kwargs) == 3 and kwargs['n4'] and kwargs['na'] and kwargs['nnka']:
                # первый набор аргументов
                out = 1
                pass
        except KeyError:
            out = -1
            pass
        try:
            if len(kwargs) == 2 and kwargs['datetime'] and kwargs['nnka']:
                # третий набор аргументов
                out = 3
                pass
        except KeyError:
            out = -1
            pass
        try:
            if len(kwargs) == 4 and kwargs['dd'] and kwargs['mm'] and kwargs['yyyy']  and kwargs['nnka']:
                # второй набор аргументов
                out = 2
                pass
        except KeyError:
            out = -1
            pass

        if out == -1 :
            return 0 # завершение функции-конструктора
        if out == 0:
            # просто создается пустой альманах
            pass
        if out == 1: # создаем альманах по номеру 4-хлетия, суток в 4-х летии, номера КА
            self.n4 = kwargs['n4'] #  TO DO: нужно заполнять эти поля только в случае, если альманах был успешно считан из ЛБД
            self.na = kwargs['na']
            self.nka_num = kwargs['nnka']
            day, month, year = get_date_by_n4_na(kwargs['n4'],kwargs['na'])
            self.year = year
            self.month = month
            self.day = day
            self.get_almanac_from_base(kwargs['nnka'],kwargs['n4'],kwargs['na'])
            self.timestamp = datetime(self.year, self.month, self.day,0,0,0,0,None)

        if out == 2: # создаем альманах по дате и номеру КА
            self.n4, self.na, j =  get_n4_na_by_date(kwargs['yyyy'], kwargs['mm'],kwargs['dd'])
            self.year = kwargs['yyyy']
            self.month = kwargs['mm']
            self.day = kwargs['dd']
            self.nka_num = kwargs['nnka']
            self.get_almanac_from_base(kwargs['nnka'], self.n4, self.na)
            self.timestamp = datetime(self.year, self.month, self.day,0,0,0,0,None)

        if out == 3: # по datetime и номеру КА
            self.timestamp = kwargs['datetime']
            # ! требуется доработка

def get_elevation_angle(alm: Almanac, timemoment: int, point_xyz: list, nka_num: int) -> float:  # расчет угла места (1 точка, 1 КА, 1 момент времени)
    """
    Функция расчета угла места, под которым КА виден в точке.
    :param N: номер суток в четырехлетии
    :param point_xyz: список координат точки([Xp, Yp, Zp]).
    :param nka_num: номер КА, УМ которого нужно определить
    (для вызова функции нужно предварительно заполнить
    поле класса координатами КА, например, с помощью
     функции almantoxyz)

    :returns  out: угол места в градусах.
    """
    satellite_xyzs = alm.alman_to_xyz(timemoment)
    vkp = satellite_xyzs[nka_num - 1 * 0]
    xka = vkp[0]
    yka = vkp[1]
    zka = vkp[2]
    dka = ((xka - point_xyz[0]) ** 2 + (yka - point_xyz[1]) ** 2 + (zka - point_xyz[2]) ** 2) ** 0.5
    r_orbit = (xka ** 2 + yka ** 2 + zka ** 2) ** 0.5 # фактическое значение радиуса орбиты
    el = acos((dka ** 2 + r_earth ** 2 - r_orbit ** 2) / (2 * r_earth * dka)) * 180 / pi - 90
    return el

def get_elevation_angles(alm: Almanac, time_start: int, time_end: int, time_step: int, point_xyz_s: list,
                         nka_nums: list) -> list:  # углы места для нескольких точек по нескольким КА на интервале времени
    """
    Функция расчета углов места для нескольких КА
    в нескольких точках на интервал времени.
    Список рассчитанных углов места сохраняется в переменной объекта класса ElevationAngles
    Массив моментов времени также сохраняется в
    переменной типа time
    :param N: номер суток в четырехлетии, на который требуется определить УМ
    :param time_start: начальный момент времени, на который проводится расчет
    :param time_end: последний момент времени, на который проводится расчет
    :param time_step: шаг по времени
    :param point_xyz_s: список координат точек, относительно
    которых проводится расчет
    :param nka_nums: список номеров КА из альманаха, для
    которых проводится расчет
    :returns out: Список углов места list[list[list]]
    """
    out = []
    for t in range(time_start, time_end, time_step):
        tmp1 = []
        for xc, yc, zc in point_xyz_s:
            tmp2 = []
            satellite_xyz = alm.alman_to_xyz(t)
            for nka_num in nka_nums:
                tmp2.append(get_elevation_angle(alm, t, [xc, yc, zc], nka_num))
            tmp1.append(tmp2)
        out.append(tmp1)
    return out

def get_visibility_intervals(alm: Almanac, point_xyzs: list, nka_nums: list, elevation_cutoff: float, time_start: int, time_end: int, time_step: int) -> list:
    """
    !!!
    !!!  функция требует проверки функционирования
    !!!
    Функция расчета интервалов видимости по условию
    превышения улгом места заданного значения.
    Перед вызовом функции необходимо вызвать функцию
    getelevationangles или заполнить переменные класса
    time и elevation_angles.
    Функция также заполняет переменную типа visibility_intervals
     (массив пар моментов начала и конца ЗРВ) и переменную
     visibility (флаги видимости/невидимости).

    :param point_xyzs: список координат точек, для которых нужно расчитать интервалы радиовидимости
    :param nka_nums: номера КА из альманаха, для которых нужно расчитать интервлы радиовидимости
    :param elevation_cutoff: минимальный угол места КА, с которого считается, что КА в ЗРВ (градусы)
    :param time_start: момент времени начала расчета
    :param time_end: момент времени конца расчета
    :param time_step: шаг по времени

    :returns out: список интервалов (пар чисел начало-конец радиовидимости)
    """
    time = range(time_start, time_end, time_step)
    elevation_angles = get_elevation_angles(alm, time_start, time_end, time_step, point_xyzs,nka_nums)
    out = []
    for i in elevation_angles: # перебор массива с углами места для формирования флагов радиовидимости # по времени
        tmp1 = []
        for j in i:
            tmp2 = []
            for k in j:
                if k > elevation_cutoff:
                    tmp2.append(1)
                else:
                    tmp2.append(0)
            tmp1.append(tmp2)
        out.append(tmp1)
    visiblity = out  # состояние видимости (критерий - превышение углом места заданного порога)
    out = []
    out2 = []
    for j in range(0, len(visiblity[0]), 1): # цикл, в котором определяются моменты начал и концов ЗРВ
        tmp1 = []
        for k in range(0, len(visiblity[0][0]), 1):
            tmp2 = []
            start = 0
            end = 0
            if (visiblity[0][j][k] == 1): start = 0.1
            for i in range(0, len(visiblity), 1):
                if (visiblity[i - 1][j][k] != visiblity[i][j][k]):
                    if (visiblity[i][j][k] == 1):
                        # начало ЗРВ
                        start = time[i]
                        pass
                    if ((visiblity[i][j][k] == 0) & (start != 0)):
                        # конец ЗРВ
                        end = time[i]
                        if (start == 0.1): start = 0
                        tmp2.append([start, end])
                        end = 0
                        pass
            if (start != 0) & (end == 0):  #
                end = time[i]
                tmp2.append([start, end])
            tmp1.append(tmp2)
        out2.append(tmp1)
    return out2
