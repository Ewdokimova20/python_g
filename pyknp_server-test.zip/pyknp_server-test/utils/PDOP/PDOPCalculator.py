import queue
import traceback
from enum import IntEnum

from utils.PDOP.AlmanacClass import Almanac, get_n4_na_by_date, get_date_by_n4_na, NKA_almanac
from math import acos, sqrt, cos, pi, sin, asin
import logging
from datetime import date, datetime, timedelta
from utils.almanac.get_almanac_slot import get_almanac_slot
from global_data import appdata
from global_data.config_schema import config

logger = logging.getLogger('pdop_calc')

acos_table = []
for i in range(0, 2001, 1): acos_table.append(
    acos((i - 1000) / 1000))  # таблица значений арккосинуса для проверки возможности оптимизации

r_earth = 6378136  # радиус Земли
doubled_r_earth = 2 * r_earth  # удвоенный радиус Земли
r_orb_nom = r_earth + 19100e3  # номинальный радиус орбиты КА
help_const1 = r_earth ** 2 - r_orb_nom ** 2  # вспомогательная константа для расчета углов места
help_const2 = r_earth ** 2 + r_orb_nom ** 2  # вспомогательная константа 2 для расчета углов места


class CalculationStatus(IntEnum):
    NOT_STARTED = 0  # = 'расчет не начат'
    STOPPED = 1  # 'расчет остановлен'
    CALCULATING = 2  # 'расчет идет'
    FINISHED = 3  # 'расчет завершен'


class ZoneType(IntEnum):
    RUS = 0  # зона расчета PDOP - территория РФ
    GLOB = 1  # Глобально


class CalcMode(IntEnum):
    PDOP = 0  # зона расчета PDOP - территория РФ
    AVAILABILITY = 1  # Глобально


state_dict = {
    CalculationStatus.NOT_STARTED: 'NOT_STARTED',
    CalculationStatus.STOPPED: 'STOPPED',
    CalculationStatus.CALCULATING: 'CALCULATING',
    CalculationStatus.FINISHED: 'FINISHED'
}

RUS = 0  # зона расчета PDOP - территория РФ
GLOB = 1  # Глобально
DEBUG = 2  # для отладки с меньшим количеством точек
zone_dict = {RUS: 'russian', GLOB: 'global', DEBUG: 'debug'}

SECONDS_AMOUNT_IN_A_DAY = 86400  # число секунд в сутках

PDOP_TIME_STEP_PDOP = config['PDOP']['PDOP_time_step']  # шаг рассчета PDOP (по методике 230 = 2 минуты).1
PDOP_TIME_STEP_availability = config['PDOP'][
    'availability_time_step']  # шаг рассчета PDOP для методики 243 (доступность)
ELEVATION_MASK = config['PDOP']['nka_elevation_mask']  # минимальный угол места, с которого рассчитывается PDOP.

CALCULATION_HAS_BEEN_STOPPED = -2  # константа, возвращаемая в случае, если расчет был остановлен
ALM_NOT_FOUND = -3  # константа, возвращаемая в случае, если расчет не начат. Альманах не найден в базе.
NOT_ALL_NKA_IN_ALM = -4  # константа, которая возвращается в случае, если в считанном из базы альманазе нет всех КА, по которым было дано задание начать расчет.


def lat_lon_to_xyz(input: list) -> list:
    """
    Функция перевода координат точки на поверхности Земли
    из геодезических (широта и долгота) в геоцентрические (X, Y, Z).

    :param input: список геодезических координат точек
    :returns out: список геоцентрических координат
    """
    out = []
    e2 = 0.0066943662
    a = 6378136.0
    for lat, lon in input:
        B = lat * pi / 180
        H = 0
        L = lon * pi / 180
        N = a / sqrt(1 - e2 * sin(B) * sin(B))
        X = (N + H) * cos(B) * cos(L)
        Y = (N + H) * cos(B) * sin(L)
        Z = (N * (1 - e2) + H) * sin(B)
        out.append([X, Y, Z])
    return out


def arccos2(x: float):
    """
    Функция арккосинуса:
    Входные данные - значение косинуса (дискрет 0.001, с округлением)
    Выходные данные - значение угла из таблицы
    """
    x2 = round((x + 1) * 1000)
    return acos_table[x2]


class PDOPcalculator:
    """ Класс для расчета средних значений PDOP по территории РФ или глобальной зоне. """
    # класс с функциями расчета PDOP в точке/на сетке // на момент времени/интервал  для реализации методики
    almanac = Almanac()  # = [] # альманах, считанный из базы
    time_interval = []  # интервал времени, на который произведен расчет
    point_grid = []  # сетка точек, для которой произведен расчет (XYZ)
    BL = []  # широта и долгота для сетки точек
    sat_xyz_epoch = -8888  # индикатор наличия рассчитанных координат КА на данный момент времени
    sat_xyz = []  # координаты КА на момент времени, соответствующий последнему расчету
    # result_PDOP = {'PDOP0': -1, 'PDOP': -1, 'availability': -1} #, 'Partical PDOPs ': -1}
    result_PDOP = {}
    av = 0
    CalcState2 = 0
    status = 0
    queueout: queue.Queue

    def __init__(self):
        self.StopPDOPcalc = False
        self.NKA_mask = None  # маска - КА, участвующие в расчете.
        self.datestamp = None

    def get_point_grid(self, zone: int, mode: int) -> list:
        """
        Функция расчета сетки точек для территории РФ или для глобальной территории.
        Также функция заполняет значения параметров BL и pointgrid вызывающего объекта.

        :param zone: флаг, проводить расчет для РФ или мира (0 -  РФ , 1  - глобально)
        :param mode: признак, означающий,какой формировать сетку: равномерной или нет. Если да (mode = 1), то шаг по долготе всегда 1 градус, если нет (mode = 0) - 1/cos(широта)
        :returns out: список геоцентрических координат для заданной сетки
        """
        out = []
        lat_st = 0
        lat_end = 0
        lon_st = 0
        lon_end = 0
        if zone == 0:  # РФ
            lat_st = 40  # геодезические координаты - границы территории РФ в соответствии с методикой оценки
            lat_end = 80  # среднего значения PDOP на сутках (14К173.0000-0ПМ-230)
            lon_st = 20
            lon_end = 190
        if zone == 1:  # глобально
            lat_st = -90  # геодезические координаты, определяющие поверхность Земного шара
            lat_end = 90
            lon_st = 0
            lon_end = 360

        if zone == 2:  # для отладки - произвольная точка или сетка точек
            lat_st = -30
            lat_end = -20
            lon_st = -5
            lon_end = 5

        if ((zone != 0) & (zone != 1) & (zone != 2)): return [-1]  # некорректный аргумент
        lat_arr = list(range(lat_st, lat_end + 1, 1))
        pts = []
        for lat in range(len(lat_arr)):
            lon_step = mode + (1 - mode) * abs(1 / cos(pi / 180 * lat_arr[lat]))
            if ((lat_arr[lat] == 90) | (lat_arr[lat] == -90)) == True:
                pass
                n = (mode - 1) + mode * round((lon_end - lon_st) / lon_step)
            else:
                n = round((lon_end - lon_st) / lon_step)
            lon_arr = []
            for i in range(n + 1):
                lon_arr.append(lon_st + i * lon_step)
            for lon in range(len(lon_arr)):
                if lon_arr[lon] <= 360:
                    pts.append([lat_arr[lat], lon_arr[lon]])
        out = lat_lon_to_xyz(pts)
        self.point_grid = out
        self.BL = pts
        return out

    def get_pdop_for_point_and_moment(self, time_moment: datetime, xp: float, yp: float, zp: float,
                                      min_elevation: float, ln_cn_emitted: dict = []) -> float:
        """
        Функция расчета PDOP на один момент времени для одной точки

        :param time_moment: момент времени, для которого проводится расчет
        :param xp: координата X точки, для которой проводится расчет
        :param yp: координата Y точки, для которой проводится расчет
        :param zp: координата Z точки, для которой проводится расчет
        :param min_elevation: минимальный угол места, превышение которого означает наличие КА в зоне радиовидимости.
        :returns dict: значение PDOP в заданной точке на заданный момент времени
        """
        if self.StopPDOPcalc:  # проверка, был ли расчет остановлен принудительно
            self.status = CalculationStatus.STOPPED  # self.comment = ['расчет остановлен']
            return CALCULATION_HAS_BEEN_STOPPED
        else:
            if self.sat_xyz_epoch == time_moment:
                xyz_packed = self.satXYZ
            else:
                xyz_packed = self.almanac.alman_to_xyz(time_moment)
                self.sat_xyz_epoch = time_moment
                self.satXYZ = xyz_packed
            # FIXME думаю, учитывать излучаемые признаки ln и Cn нужно будет именно здесь. Можно удалять координаты соответствующего КА из xyz_packed.

        # тут - создание резервной копии xyz_packed, фильтрация по признакам Ln, Cn, а потом (после  расчета) - вернуть обратно.
        xyz_packed2 = xyz_packed.copy()
        bad_kas = []

        for i in ln_cn_emitted:
            for j in ln_cn_emitted[i]:
                st = j[0]
                en = j[1]
                time_start = datetime.fromisoformat(st)
                time_finish = datetime.fromisoformat(en)
                if ((time_moment >= time_start) and (time_moment <= time_finish)): bad_kas.append(i)
                pass

        # bad_kas - номера КА, которые на момент time_moment "были недостоверны"
        for i in bad_kas:
            try:
                del xyz_packed[int(i)]
            except KeyError:
                continue

        self.satXYZ = xyz_packed
        A = []  # матрица направляющих косинусов
        els = []
        const2 = (min_elevation + 90) / (180 / pi)
        for XYZ in xyz_packed:
            D = sqrt((xp - xyz_packed[XYZ][0]) ** 2 + (yp - xyz_packed[XYZ][1]) ** 2 + (zp - xyz_packed[XYZ][2]) ** 2)
            Rorb = sqrt(xyz_packed[XYZ][0] ** 2 + xyz_packed[XYZ][1] ** 2 + xyz_packed[XYZ][2] ** 2)
            z = (D ** 2 + r_earth ** 2 - Rorb ** 2) / (D * doubled_r_earth)
            els.append(acos((D ** 2 + r_earth ** 2 - Rorb ** 2) / (D * doubled_r_earth)) * 180 / pi - 90)
            if abs(z) <= 1:
                # следующая строчка кода и 2-е условие в последующей строчке не имеют смысла.
                is_signal_reliable = True  # если true, значит излучаемый КА в данный момент сигнал является достоверным.
                if (acos(z) * 180 / pi - 90 > min_elevation) and (
                        is_signal_reliable == True):  # проверить корректность логического "И"
                    A.append(
                        [(xp - xyz_packed[XYZ][0]) / D, (yp - xyz_packed[XYZ][1]) / D, (zp - xyz_packed[XYZ][2]) / D,
                         1])
            del D, Rorb, z
        if len(A) < 4:
            PDOP = 0 * 9999  # критерий, означающий, что из точки видно менее 4-х КА и РНВЗ невозможно
        else:
            c11 = 0
            c22 = 0
            c33 = 0
            c44 = len(A)  # n
            c12 = 0
            c13 = 0
            c14 = 0
            c23 = 0
            c24 = 0
            c34 = 0
            for i in range(
                    len(A)):  # перемножение матриц с учетом того, что это произведение матрицы на саму себя транспонированную
                c11 = c11 + (A[i][0]) ** 2  # cos^2(ax)
                c22 = c22 + (A[i][1]) ** 2  # cos^2(ay)
                c33 = c33 + (A[i][2]) ** 2  # cos^2(az)
                c12 = c12 + A[i][0] * A[i][1]  # cos x cos y
                c13 = c13 + A[i][0] * A[i][2]  # cos x cos z
                c14 = c14 + A[i][0]  # * A[i][3]  # cos x
                c23 = c23 + A[i][1] * A[i][2]  # cos y cos z
                c24 = c24 + A[i][1]  # * A[i][3]  # cos y
                c34 = c34 + A[i][2]  # * A[i][3]  # cos z
            del A
            a11 = c22 * c33 * c44 + c23 * c24 * c34 + c23 * c34 * c24 - c33 * c24 ** 2 - c22 * c34 ** 2 - c44 * c23 ** 2
            a12 = c12 * c33 * c44 + c23 * c14 * c34 + c13 * c34 * c24 - c14 * c33 * c24 - c12 * c34 ** 2 - c23 * c13 * c44
            a13 = c12 * c23 * c44 + c22 * c34 * c14 + c13 * c24 ** 2 - c14 * c23 * c24 - c12 * c34 * c24 - c13 * c22 * c44
            a14 = c12 * c23 * c34 + c14 * c33 * c22 + c23 * c13 * c24 - c14 * c23 ** 2 - c12 * c33 * c24 - c13 * c22 * c34
            detc = c11 * a11 - c12 * a12 + c13 * a13 - c14 * a14
            a22 = c11 * c33 * c44 + c13 * c34 * c14 * 2 - c33 * c14 ** 2 - c11 * c34 ** 2 - c44 * c13 ** 2
            a33 = c11 * c22 * c44 + c12 * c24 * c14 * 2 - c22 * c14 ** 2 - c11 * c24 ** 2 - c44 * c12 ** 2

            del c11, c22, c33, c12, c13, c14, c23, c24, c34, a12, a13, a14

            if detc != 0:
                var_val = (a11 + a22 + a33) / detc
            else:
                var_val = 0
            if (var_val >= 0):
                PDOP = sqrt(var_val)
            else:
                PDOP = -1
            del a11, a22, a33, detc
        xyz_packed = xyz_packed2
        self.satXYZ = xyz_packed
        return PDOP

    def get_pdop_for_point_and_time_interval(self, time_start: int, time_stop: int, time_step: int, point_xyz: list,
                                             min_elevation: float,
                                             ln_cn_emitted: dict = []) -> list:  # расчет значения PDOP для одной точки с заданными координатами по альманаху на заданный интервал времени
        """
        Функция расчета PDOP на один момент времени для одной точки.

        :param time_start: начальный момент времени, для которого проводится расчет
        :param time_stop: конечный момент времени, для которого проводится расчет
        :param time_step: шаг по времени
        :param point_xyz: координаты точки, для которой проводится расчет (список [Xp, Yp, Zp])
        :param min_elevation: минимальный угол места (градусы).

        :returns out: список значений PDOP
        """
        out = []
        for tmoment in range(time_start, time_stop + time_step, time_step):
            out.append(self.get_pdop_for_point_and_moment(self, tmoment, point_xyz[0], point_xyz[1], point_xyz[2],
                                                          min_elevation, ln_cn_emitted))
        return out

    def get_pdop_for_grid_and_moment(self, time_moment: datetime, min_elevation: float,
                                     ln_cn_emitted: dict = []) -> list:
        """
        Функция расчета PDOP на один момент времени для сетки точек.

        :param time_moment: момент времени, для которого проводится расчет
        :param grid_xyzs: список координат точек, для которых проводится расчет
        :param min_elevation: минимальный угол места.

        :returns out: список значений PDOP на один момент времени для сетки
        """
        out = []

        ln_cn_s = {1: [], 2: [], 3: [], 4: [], 5: [], 6: [],
                   7: [], 8: [], 9: [], 10: [], 11: [], 12: [],
                   # [datetime(year = 2023, month = 7, day = 24, hour = 0), datetime(year = 2023, month = 7, day = 24, hour = 1)] # [datetime(year = 2023, month = 7, day = 24, hour = 0), datetime(year = 2023, month = 7, day = 25, hour = 00, minute = 00, second = 00)]
                   13: [], 14: [], 15: [], 16: [], 17: [], 18: [],
                   19: [], 20: [], 21: [], 22: [], 23: [], 24: [],
                   }
        ln_cn_s = ln_cn_emitted
        for Xp, Yp, Zp in self.point_grid:
            if not self.StopPDOPcalc:
                try:
                    out.append(self.get_pdop_for_point_and_moment(time_moment, Xp, Yp, Zp, min_elevation, ln_cn_s))
                except(MemoryError):
                    logger.debug('Недостаточно оперативной памяти для расчета.')
            else:
                break
        return out

    def get_pdop_for_grid_and_time_interval(self, time_start: int, time_stop: int, time_step: int, min_elevation: float,
                                            ln_cn_emitted: dict) -> list:
        """
        Функция расчета PDOP на интервал времени для сетки точек.

        :param time_start: начальный момент времени, для которого проводится расчет
        :param time_stop: конечный момент времени, для которого проводится расчет
        :param time_step: шаг по времени
        :param grid_xyzs: список координат точек, для которых проводится расчет
        :param min_elevation: минимальный угол места.

        :returns out: Список значений PDOP.
        """
        self.CalcState2 = 0
        out = []
        self.CalcState2 = 0
        if (len(self.queueout.queue) == 0):
            self.queueout.put(self.CalcState2)

        if (len(self.queueout.queue) == 1):
            self.queueout.get(0)
            self.queueout.put(self.CalcState2)

        file_name = config['PDOP']['full_file_name_PDOP']  # 'utils\PDOP\PDOPS_0.txt' #'PDOPS_0.txt'

        try:
            file_object = open(file_name, 'w')
        except FileNotFoundError:
            logger.error('Нет файла с рассчитанными PDOP.')
            return -1

        k1 = 0
        k2 = 0
        n1 = 0
        n2 = 0

        self.time_points = [i for i in range(time_start, time_stop + time_step, time_step)]
        self.time_points_count = len(self.time_points)

        for tmoment in range(time_start, time_stop + time_step, time_step):
            instant_pdops_on_grid = self.get_pdop_for_grid_and_moment(tmoment, min_elevation)
            for partical_pdops in instant_pdops_on_grid:
                file_object.write(partical_pdops.__str__())
                file_object.write('\n')
                k1 = k1 + 1
                n1 = n1 + partical_pdops
                if partical_pdops <= 6:
                    k2 = k2 + 1
                    n2 = n2 + partical_pdops

            self.P1 = n2 / k2
            self.P2 = n1 / k1
            self.P3 = self.P1 / self.P2

            self.CalcState2 = round(((tmoment - time_start + time_step) / time_step) / len(
                range(time_start, time_stop + time_step, time_step)) * 1e4 * 100) / 1e4
            # обновление процента расчета в очереди
            if (len(self.queueout.queue) == 0):
                self.queueout.put(self.CalcState2)
            elif (
                    len(self.queueout.queue) == 1):  # тут всего 2 варианта (т.к. self.queue.maxsize = 1), эта конструкция исчерпывающая.
                self.queueout.get(0)
                self.queueout.put(self.CalcState2)

            self.status = CalculationStatus.CALCULATING
            if self.CalcState2 == 100.0:
                self.status = CalculationStatus.FINISHED

            if self.StopPDOPcalc:
                self.CalcState2 = round(((tmoment - time_start + time_step) / time_step) / len(
                    range(time_start, time_stop + time_step,
                          time_step)) * 1e4 * 100) / 1e4  # round(i2/i1*10000*100)/10000
                self.status = CalculationStatus.STOPPED
                return [CALCULATION_HAS_BEEN_STOPPED]
        file_object.close()
        return out

    def get_pdop_for_grid_and_time_interval2(self, time_start: datetime, time_stop: datetime, zoneid: int, mode: int,
                                             ln_cn_emitted: dict) -> list:
        """
        Функция расчета PDOP на интервал времени для сетки точек.

        :param time_start: начальный момент времени, для которого проводится расчет
        :param time_stop: конечный момент времени, для которого проводится расчет
        :param time_step: шаг по времени

        :returns out: Список значений PDOP.
        """
        self.get_point_grid(zoneid, mode)
        self.CalcState2 = 0
        out = []
        self.CalcState2 = 0
        if (len(self.queueout.queue) == 0):
            self.queueout.put(self.CalcState2)

        if (len(self.queueout.queue) == 1):
            self.queueout.get(0)
            self.queueout.put(self.CalcState2)

        file_name = config['PDOP']['full_file_name_PDOP']  # 'utils\PDOP\PDOPS_0.txt' #'PDOPS_0.txt'

        try:
            file_object = open(file_name, 'w')
        except FileNotFoundError:
            logger.error('Нет файла с рассчитанными PDOP.')
            return -1

        k1 = 0
        k2 = 0
        n1 = 0
        n2 = 0

        time_step = PDOP_TIME_STEP_availability * mode + PDOP_TIME_STEP_PDOP * (1 - mode)
        min_elevation = ELEVATION_MASK  #

        self.time_points = [
            time_start]  # [i for i in range(time_start, time_stop + timedelta(seconds = time_step), time_step)]
        current_time = time_start
        while current_time < time_stop:  # +timedelta(seconds= time_step):
            current_time = current_time + timedelta(seconds=time_step)
            self.time_points.append(current_time)

        self.time_points_count = len(self.time_points)

        current_point_number = 0
        for tmoment in self.time_points:  # range(time_start, time_stop + time_step, time_step):
            tmp_var1 = self.get_pdop_for_grid_and_moment(tmoment, min_elevation, ln_cn_emitted)
            for tmp_var2 in tmp_var1:
                file_object.write(tmp_var2.__str__())
                file_object.write('\n')
                k1 = k1 + 1
                n1 = n1 + tmp_var2
                if tmp_var2 <= 6:
                    k2 = k2 + 1
                    n2 = n2 + tmp_var2

            self.P1 = 0
            self.P2 = 0
            self.P3 = 0

            try:
                self.P1 = n2 / k2
                self.P2 = n1 / k1
                self.P3 = self.P1 / self.P2
            except ZeroDivisionError:
                pass

            current_point_number = current_point_number + 1
            self.CalcState2 = round(current_point_number / len(self.time_points) * 1e4 * 100) / 1e4

            # обновление процента расчета в очереди
            if (len(self.queueout.queue) == 0):
                self.queueout.put(self.CalcState2)
            elif (
                    len(self.queueout.queue) == 1):  # тут всего 2 варианта (т.к. self.queue.maxsize = 1), эта конструкция исчерпывающая.
                self.queueout.get(0)
                self.queueout.put(self.CalcState2)

            self.status = CalculationStatus.CALCULATING
            if self.CalcState2 == 100.0:
                self.status = CalculationStatus.FINISHED

            if self.StopPDOPcalc:
                self.CalcState2 = round(current_point_number / len(self.time_points) * 1e4 * 100) / 1e4
                self.status = CalculationStatus.STOPPED
                return [CALCULATION_HAS_BEEN_STOPPED]
        file_object.close()
        return out

    def verify_ability_of_calculation2(self, NKA_sys_nums: list, day: int, month: int, year: int, use_closest_alm: bool,
                                       n_tries: int) -> list:
        """функция для проверки возможности начала рассчета с заданными параметрами.
        Проверяется наличие альманаха для всех выбранных КА (дата не имеет значения - всегда берется
        самый свежий альманах). Используется функция get_almanac_slot.
        """
        absent_kas = []  # перечень КА, для которых не найден альманах
        alman = []

        self.almanac.almdict = {}
        self.almanac_shift = {}
        max_pdop_na_spread = config['PDOP']['max_pdop_na_spread']
        if use_closest_alm == True:
            [n4, na, J] = get_n4_na_by_date(year, month, day)
            outalm = {}
            for i in NKA_sys_nums:
                nka_template = get_almanac_slot(i, na, n4, max_pdop_na_spread, False)
                if (nka_template != None):
                    nka_template.divtype = 0
                    alman.append(nka_template)
                    outalm[i] = nka_template
                    self.almanac.almdict[i] = (
                        NKA_almanac('None', nka_template.nka, i, nka_template.N4, nka_template.N_A,
                                    nka_template.Tlambda_A, nka_template.deltaT_A, nka_template.deltaI_A,
                                    nka_template.deltaTdot,
                                    nka_template.e_A, nka_template.omega_A, nka_template.lambda_A, 'divtype' == 0))
                    self.almanac_shift[i] = -(nka_template.N_A - na)
                else:
                    absent_kas.append(i)
        if len(absent_kas) == 0:
            return []
        else:
            message = f"Невозможно начать расчёт. На {str(day)}.{str(month)}.{str(year)} нет альманахов для КА {str(absent_kas)}."
            logger.warning(message)
            return absent_kas

    def get_pdop_for_date_grid_and_constellation(self, NKA_sys_nums: list, zoneid: int, day: int, month: int, year: int,
                                                 mode: int, ln_cn_emitted: dict = []) -> dict:
        """Расчет PDOP для заданного состава ОГ на заданую дату в глобальной зоне или по РФ
        В конкретной версии функции расчет выполняется с шагом 5 минут (в методике - 2).
        Для расчета используются:
        1) альманах на заданную дату, прочитанный из ЛБД СПО КНП.
        2) сетка точек.

        :param zoneid: флаг зоны (0 - РФ, 1 - глобальная зона)
        :param day: день
        :param month: месяц
        :param year: год
        :param mode: режим расчета (0 - для неравномерной секти: средний PDOP, 1 - для равномерной сетки : доступность и перерыв навигации)

        'PDOP0' - среднее значение PDOP с ограничением индекса доступности (PDOP <= 6)
        'PDOP' - среднее значение PDOP без ограничения индекса доступности
        'Доступность' - отношение числа точек (с учетом времени), для которых PDOP <= 6 к общему числу точек
        'Частные PDOP' - список значений PDOP
        """
        try:
            self.result_PDOP = {}

            if self.StopPDOPcalc:
                self.status = CalculationStatus.STOPPED
                return {'result': CALCULATION_HAS_BEEN_STOPPED}

            self.NKA_mask = NKA_sys_nums  # маска - КА, участвующие в расчете.
            self.datestamp = datetime(year=year, month=month, day=day)
            self.CalcState2 = 0

            # удаление параметров альманаха для тех КА, по которым расчет проводить не нужно
            nkas_to_delete = []
            for nka in self.almanac.almdict:
                if (nka in NKA_sys_nums) == False: nkas_to_delete.append(nka)
            for nka in nkas_to_delete: del self.almanac.almdict[nka]
            # проверка, все ли КА, по которым нужно провести расчет, имеются в альманахе.
            absentnkas = []  # массив отсутствующих в альманахе КА
            for nka in NKA_sys_nums:
                if (nka in self.almanac.almdict) == False: absentnkas.append(nka)
            if len(absentnkas) != 0:
                self.status = 0
                logger.warning(
                    f'Расчет не может быть начат, так как в альманахе отсутствуют КА, по которым указано проводить расчет. Нет следующих КА: {str(absentnkas)}')
                return {'result': NOT_ALL_NKA_IN_ALM,
                        'error': f'Расчет не может быть начат, так как в альманахе отсутствуют КА, по которым указано проводить расчет. Нет следующих КА: {str(absentnkas)}'}
            out = self.get_pdop_for_grid_and_time_interval2(self.datestamp,
                                                            self.datestamp + timedelta(days=1),  # ! верифицировать
                                                            zoneid, mode, ln_cn_emitted)
            if out == -1:
                self.StopPDOPcalc = True

            if self.StopPDOPcalc:
                self.status = CalculationStatus.STOPPED
                return {'result': CALCULATION_HAS_BEEN_STOPPED - 1}

            total = 0
            total2 = 0
            PDOP_double_dash = 0
            PDOP_dash = 0
            for i in out:
                for j in i:
                    total = total + 1
                    PDOP_double_dash = PDOP_double_dash + j

                    if j <= 6:
                        PDOP_dash = PDOP_dash + j
                        total2 = total2 + 1
            P1 = -1  # константы, равные минус единице на выходе функции означают, что что-то пошло не так,
            P3 = -1  # в частности P1 == -1 и P3 == -1 означает, что список значений PDOP пуст.
            P2 = -1  # P2 == -1 означает, что в списке значений PDOP нет значений, меньших или равных 6.
            if (total != 0):
                P1 = PDOP_double_dash / total
                P3 = total2 / total

            if (total2 != 0):
                P2 = PDOP_dash / total2

            out2 = {'PDOP0': self.P1, 'PDOP': self.P2, 'avail': self.P3, 'day': day, 'month': month, 'year': year,
                    'zone': zone_dict[zoneid],
                    'zoneid': zoneid}  # не отображаются значения PDOP для каждой точки и момента времени
            logger.info('Расчет PDOP завершен.' + str(
                out2))  # FIXME в логе это выглядит не очень красиво, но это не главное. Потом можно будет доработать.

            self.particalpdops = out
            self.result_PDOP = out2
            self.status = CalculationStatus.FINISHED
            return {'out': out2}
        except Exception as err:
            logger.error(f'Ошибка при расчете PDOP: {str(err)}')
            logger.info(traceback.format_exc())
            self.StopPDOPcalc = True
            self.status = CalculationStatus.STOPPED

    def get_availability(self, zoneid, mode):  # функция расчета доступности на основе рассчитанных значений PDOP.
        # новая версия, позволяющая не занимать лишнюю ОЗУ
        file_name = config['PDOP']['full_file_name_PDOP']  # 'utils\PDOP\PDOPS_0.txt' #'PDOPS_0.txt'
        try:
            file_object = open(file_name, 'r')
        except FileNotFoundError:
            logger.error('Файл utils\PDOP\availability_sec_data_0.txt не сушествует.')

        self.point_grid = self.get_point_grid(zoneid, mode)
        self.points_count = len(self.point_grid)
        q = []
        last_state = []
        maxbreakk = 0
        max_point_break = []
        current_point_break = []

        p = 0
        p2 = 0

        num = 0
        denom = 0

        q1 = {'точка': 'тест', 'время': 'метка времени', 'доступность': '---'}
        q.append(q1)

        for i2 in range(0, self.points_count, 1):
            if self.StopPDOPcalc:
                self.status = CalculationStatus.STOPPED
                stopmsg = {}
                return stopmsg
            s = file_object.readline()
            denom = denom + cos(self.BL[i2][0] * pi / 180)
            if float(s) <= 6:
                p = p + 1
                last_state.append(1)  # значение мнговенной доступности на прошлый момент времени.
                max_point_break.append(0)
                current_point_break.append(0)
                num = num + cos(self.BL[i2][0] * pi / 180)
            else:
                p2 = p2 + 1
                last_state.append(0)
                max_point_break.append(1)
                current_point_break.append(1)
                maxbreakk = []

        for i1 in range(1, self.time_points_count, 1):
            self.CalcState2 = round(i1 / (self.time_points_count - 1) * 1e4) / 1e2
            for i2 in range(0, self.points_count, 1):
                if self.StopPDOPcalc:
                    self.status = CalculationStatus.STOPPED
                    return {'result': CALCULATION_HAS_BEEN_STOPPED - 1}
                denom = denom + cos(self.BL[i2][0] * pi / 180)
                s = file_object.readline()  # мнговенное значение PDOP.
                if float(s) <= 6:  # мгновенный индекс доступности
                    ai = 1
                    num = num + cos(self.BL[i2][0] * pi / 180)
                else:
                    ai = 0

                if ai == 0:
                    p = p + 1
                    q1 = {'точка': i2, 'время': i1,
                          'доступность': 0}  # q1 = {'точка': point_index, 'время': time_index, 'доступность': 0}
                    q.append(q1)
                    if last_state[i2] == 0:  # недоступно = > недоступно
                        current_point_break[i2] += 1
                    if last_state[i2] == 1:  # доступно = > недоступно
                        current_point_break[i2] = 0
                if ai == 1:
                    p2 = p2 + 1
                    if last_state[i2] == 0:  # недоступно = > доступно
                        if (max_point_break[i2] < current_point_break[i2]):
                            max_point_break[i2] = current_point_break[i2]
                            n = i2
                        current_point_break[i2] = 0
                    if last_state[i2] == 1:  # доступно = > доступно
                        current_point_break[i2] = 0
                last_state[i2] = ai
                if current_point_break[i2] >= max_point_break[i2]: max_point_break[i2] = current_point_break[i2]

        maxbreakk = 0
        nmax = 0
        for i in range(0, self.points_count, 1):
            if max_point_break[i] > maxbreakk:
                maxbreakk = max_point_break[i]
                nmax = i  # номер

        file_name = config['PDOP']['full_file_name_availability']  # 'Availability_sec_data.txt'
        file_object = open(file_name, 'w')
        un = 0
        for i in q:  # сохранение промежуточных данных в части доступности в файл
            un = un + 1
            file_object.write(f"Условный номер точки (место/время): {str(un)};{str(i['точка'])};{str(i['время'])}\n")
        file_object.close()

        self.availability = num / denom
        self.maxbreak = maxbreakk * PDOP_TIME_STEP_availability
        return {'avail': num / denom, 'nav_break': maxbreakk * PDOP_TIME_STEP_availability, 'Номер точки': nmax,
                'Широта': self.BL[nmax][0], 'Долгота': self.BL[nmax][1]}

    def read_PDOPS_from_file(self, file_name: str, points_count: int, time_count: int) -> int:
        """
        Функция для считывания значений PDOP из файла. Использовалась для отработки функции расчета доступности.
        В настоящий момент не используется.

        :param file_name: имя файла с записанными значениями PDOP.
        :param points_count: число точек в сетке
        :param time_count: число моментов времени
        """
        n = 0
        ns = points_count * time_count

        self.particalpdops = []

        with open(file_name, 'r') as file_object:
            for i in range(0, time_count, 1):
                p = []
                for j in range(0, points_count, 1):
                    pdopp = file_object.read(
                        13)  # при расчете во внимание принимаются только первые 3 знака после запятой
                    l = file_object.readline()
                    try:
                        p.append(float(pdopp))
                        if (float(pdopp) > 2000):
                            msg = f"Значение PDOP > 2000.({float(pdopp.__str__())}). Точка: {self.point_grid[j]}. Время: {(i * PDOP_TIME_STEP_availability).__str__()}."
                            logger.debug(msg)
                    except ValueError:
                        p.append(0)
                    n += 1
                self.particalpdops.append(p)
        return 0

    def save_PDOPs_to_file(self,
                           file_name: str):  # по-хорошему, нужно сохранять и загружать в файл метаданные - количество точек и моментов времени и их координаты, шаг по времени, а также некоторые промежуточные результаты расчета
        """
        Функция для сохранения значений PDOP в файл. В настоящее время не используется.

        :param file_name: имя файла, в который нужно сохранить рассчитанные значения PDOPю
        """
        with open(file_name, 'w') as file_object:
            for i in self.particalpdops:
                for j in i:
                    file_object.write(j.__str__())
                    file_object.write('\n')

    def get_availability_for_date_grid_and_constellation(self, NKA_sys_nums: list, zoneid: int, day: int, month: int,
                                                         year: int, ln_cn_emission_intervals: dict = []) -> dict:
        try:
            self.NKA_mask = NKA_sys_nums  # маска - КА, участвующие в расчете.
            if month < 10:
                s1 = '0'
            else:
                s1 = ''
            if day < 10:
                s2 = '0'
            else:
                s2 = ''

            self.datestamp = datetime.fromisoformat(
                year.__str__() + '-' + s1 + month.__str__() + '-' + s2 + day.__str__() + 'T00:00:00.000')
            self.av = {}
            self.calc_phase = 1  # рассчет PDOP
            logger.info('Фаза расчета PDOP.')
            self.get_pdop_for_date_grid_and_constellation(NKA_sys_nums, zoneid, day, month, year, 1,
                                                          ln_cn_emission_intervals)  # последний аргумент = 1 - равномерная сетка

            if self.StopPDOPcalc:
                logger.info('Расчет доступности остановлен')
                self.status = CalculationStatus.STOPPED  # была принудительная остановка расчета
                return {}

            self.status = CalculationStatus.CALCULATING  # так как рассчет ещё полностью не завершен, будут ещё следующие фазы.
            logger.info('Фаза расчета доступности.')
            self.calc_phase = 2  # после расчета PDOP начат рассчет доступности
            x = self.get_availability(zoneid, 1)

            if self.StopPDOPcalc:
                logger.info('Расчет доступности остановлен')
                self.status = CalculationStatus.STOPPED  # была принудительная остановка расчета
            if not self.StopPDOPcalc:
                self.status = CalculationStatus.FINISHED
                logger.info(
                    f"Расчет доступности завершен. Доступность: {str(x['avail'])}. Макс. перерыв: {str(x['nav_break'])}.")

            self.av = x
            return x
        except Exception as err:
            logger.error(f'Ошибка при расчете доступности: {str(err)}')
            logger.info(traceback.format_exc())
            self.StopPDOPcalc = True
            self.status = CalculationStatus.STOPPED
