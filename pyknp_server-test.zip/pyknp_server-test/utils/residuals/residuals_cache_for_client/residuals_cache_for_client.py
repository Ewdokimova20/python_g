from copy import deepcopy
from typing import Tuple, Dict

from models.residual import ResidualForClient


class ResidualsCacheForClient:
    """Кэш последних рассчитанных значений невязок для всех БИС, НКА и сигналов"""

    def __init__(self):
        self.data: Dict[int, Dict[str, Dict[str, ResidualForClient]]] = {}

    def load_data(self, bis_id: int, data: Dict[str, Dict[str, ResidualForClient]]) -> None:
        """Запись невязок в кэш"""
        self.data[bis_id] = data

    def get_latest_items(self) -> Tuple[Dict[int, Dict[str, Dict[str, ResidualForClient]]], bool]:
        """Метод для API, возвращающий последние записанные невязки"""

        data = deepcopy(
            self.data)  # копия сделана для того, чтоб параллельное изменение self.data не повлияло на выполнение этой функции
        is_data_present = any(
            any(any(residual_dict for residual_dict in signal_residuals.values()) for signal_residuals in bis_residuals.values())
            for bis_residuals in data.values())

        return data, is_data_present


residuals_cache_for_client = ResidualsCacheForClient()
