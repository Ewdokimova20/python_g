import logging
from collections import defaultdict
from datetime import datetime
from typing import DefaultDict, TYPE_CHECKING, List

from communication.types import ZMQTopic
from global_data.config_schema import config
from utils.fixed_list_ttl.fixed_list_ttl import FixedListManualTTL

if TYPE_CHECKING:
    from data import Residual

logger = logging.getLogger(__name__)

RESIDUAL_CACHE_TTL = config['general']['reject_cache_depth'] + 1  # время жизни записей в секундах
RESIDUAL_CACHE_DEPTH = config['general']['reject_cache_depth']  # максимальное количество записей для каждой комбинации
SEND_INTERVAL_SECONDS = 3  # интервал передачи текущего состояния кэша в секундах


class RecentResidualCache:
    """
    Кэш списков последних значений невязок для всех БИС, НКА и сигналов, накопленных за время RESIDUAL_CACHE_TTL.
    Кэш отправляет свое состояние главному процессу раз в SEND_INTERVAL_SECONDS.
    """

    def __init__(self):
        self._cache: DefaultDict[int, DefaultDict[int, DefaultDict[int, FixedListManualTTL[Residual]]]] = defaultdict(
            lambda: defaultdict(
                lambda: defaultdict(lambda: FixedListManualTTL(max_length=RESIDUAL_CACHE_DEPTH, hold_time=RESIDUAL_CACHE_TTL))))
        self._last_sent_at = datetime.min
        self._zmq_manager = None

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def append(self, residual: 'Residual') -> None:
        """Добавление новой невязки в кэш"""

        if residual.rejected_due_to_deviation:
            return
        self._cache[residual.bis.id][residual.signal_1][residual.nka_id].append(residual)

        # Проверяем необходимость персистентного сохранения
        if (datetime.now() - self._last_sent_at).seconds >= SEND_INTERVAL_SECONDS:
            self.send_cache_state()

    def expire(self, current_time: datetime) -> None:
        """Принудительное удаление устаревших записей из всех кэшей"""

        for bis_cache in self._cache.values():
            for cache_by_signal in bis_cache.values():
                for cache_by_nka in cache_by_signal.values():
                    cache_by_nka.expire(current_time)

    def send_cache_state(self) -> None:
        """Отправка текущего состояния кэша на сокет ZMQ галвного процесса"""

        for bis_id, bis_cache in self._cache.items():
            data_by_bis = {}

            for signal_type, cache_by_signal in bis_cache.items():
                data_by_bis[signal_type] = {}
                for nka, cache_by_nka in cache_by_signal.items():
                    residual = cache_by_nka.get_newest_item()
                    if residual:
                        data_by_bis[signal_type][nka] = residual.as_small_dict()

            is_data_present = any(any(data_by_signal) for data_by_signal in data_by_bis.values())

            if is_data_present:
                try:
                    logger.debug(f'Отправка состояния кэша мгновенных невязок для БИС {bis_id}')
                    self._zmq_manager.publish_data(ZMQTopic.RECENT_RESIDUALS_CACHE, bis_id=bis_id, data=data_by_bis)
                except Exception as e:
                    logger.warning(f'Ошибка при отправке состояния кэша мгновенных невязок для БИС {bis_id}: {e}')

        self._last_sent_at = datetime.now()

    def get_cache_item(self, bis_id: int, signal_type: int, nka: int) -> List['Residual']:
        """
        Получение кэша для конкретной комбинации BIS, сигнала и НКА
        """

        return self._cache[bis_id][signal_type][nka].get_all_items()
