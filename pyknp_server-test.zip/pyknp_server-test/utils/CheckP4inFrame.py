from datetime import timedelta

from peewee import OperationalError

from data import L1OFFrame, Nka
from global_data.appdata import NKA_DATA
from global_data.config_schema import config
from utils.SI.main import SI_FORMS


def find_frame_with_P4(nku_num, rec_id, form):
    """Ищет кадр L1OFFrame, в котором P4 = 1, и возвращает его tk"""
    nka_type = [nka['type_ka'] for nka in NKA_DATA.values() if nka['nku_num'] == nku_num]
    if nka_type:
        nka_type = nka_type[0]
        form = SI_FORMS[nka_type][form]
        try:
            record = form.get_record_from_cdb_by_id(nka=nku_num, vitok=0, id=rec_id)
        except OperationalError:
            return None
        if not record:
            return None
        if record.si_form in (895, 701, 921):
            return None
        frames = (L1OFFrame.select().join(Nka).where(
            (L1OFFrame.timestamp >= record.start_time) & (
                    L1OFFrame.timestamp <= record.start_time + timedelta(minutes=config['SI']['search_depth_P4'])) &
            (L1OFFrame.nka.nku_number == nku_num)).execute())
        for frame in frames:
            P4 = frame.get_p4()
            if P4:
                return frame
    return None
