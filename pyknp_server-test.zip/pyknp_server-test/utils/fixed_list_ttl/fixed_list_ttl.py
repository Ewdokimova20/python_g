"""Файл с классом списка фиксированной длины"""
from __future__ import annotations

from collections import deque
from datetime import datetime, timedelta
from typing import NamedTuple, Generic, TypeVar, Optional, List

__all__ = ['FixedListManualTTL']

T = TypeVar('T')


class FixedListManualTTL(Generic[T]):
    """Список заданной длины со временем жизни элементов.
    Запуск проверки времени жизни осуществляется вручную"""

    max_length: int = 0

    hold_time = timedelta(seconds=0)

    data = deque()

    class Element(NamedTuple):
        val: any = None
        datetime: datetime = None

    def __init__(self, max_length: int, hold_time: int):
        self.data = deque()
        self.max_length = max_length
        self.hold_time = timedelta(seconds=hold_time)

    def append(self, item):
        now = datetime.now()
        if len(self.data) >= self.max_length:
            self.data.popleft()
        self.data.append(self.Element(val=item, datetime=now))

    def clear(self):
        self.data.clear()

    def get_all_items(self) -> List[T]:
        items = []
        # FIXME Подумать, чтобы оптимизировать этот цикл
        for item in self.data:
            items.append(item.val)
        return items

    def get_newest_item(self) -> Optional[T]:
        """Получить самый новый элемент в списке (т.к. добавляем справа)"""
        if len(self.data):
            return self.data[-1].val  # оптимизированные вариант, предложенный ЕМВ
        else:
            return None

    def expire(self, now=None):
        """Очистить элементы, истекшие по времени"""
        if now is None:
            now = datetime.now()
        for item in self.data.copy():
            if now - item.datetime > self.hold_time:
                self.data.remove(item)

    def __len__(self):
        return len(self.data)

    def __repr__(self):
        return f"{str(self.data)} max_length = {self.max_length} hold_time = {self.hold_time}"

