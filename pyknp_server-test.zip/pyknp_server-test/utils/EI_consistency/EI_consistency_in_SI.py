import datetime
import logging

from typing_extensions import Literal

from data import Coordinates, Nka
from global_data.config_schema import comparison_si_threshold
from utils.SI.compare_si_to_di.types import TimeData
from utils.coordinates.nka_coordinates_calculation import nka_coordinates
from utils.lib.exceptions import BadEIException

MIN_TB_VALUE = 1
MAX_TB_VALUE = 48
MIN_N_VALUE = 1
MAX_N_VALUE = 1461


def coordinates_from_EI(data, param_name) -> Coordinates:
    """Возвращает координаты, скорость и ускорение из эфемерид"""
    xyz = Coordinates.XYZ(x=data[param_name['x']], y=data[param_name['y']], z=data[param_name['z']])
    vel = Coordinates.Vxyz(Vx=data[param_name['Vx']], Vy=data[param_name['Vy']], Vz=data[param_name['Vz']])
    acc = Coordinates.Axyz(Ax=data[param_name['Ax']], Ay=data[param_name['Ay']], Az=data[param_name['Az']])
    return Coordinates(xyz=xyz, vel=vel, acc=acc)


def get_coords_on_tb_border(EI: dict, nka: Nka, timestamp: datetime, delta) -> dict:
    """Возвращает координаты, скорость и ускорение из эфемерид"""

    param_name = {'x': 'x', 'y': 'y', 'z': 'z', 'Vx': 'Vx', 'Vy': 'Vy', 'Vz': 'Vz', 'Ax': 'Ax', 'Ay': 'Ay', 'Az': 'Az'}
    coords = coordinates_from_EI(EI, param_name)
    coords_on_border = nka_coordinates(nka.nka_sys_number, coords, timestamp, timestamp + delta)
    params_from_ephemeris = dict(
        x=coords_on_border.xyz.x,
        y=coords_on_border.xyz.y,
        z=coords_on_border.xyz.z,
        Vx=coords_on_border.vel.Vx,
        Vy=coords_on_border.vel.Vy,
        Vz=coords_on_border.vel.Vz,
        Ax=coords_on_border.acc.Ax,
        Ay=coords_on_border.acc.Ay,
        Az=coords_on_border.acc.Az
    )
    param_name_L3 = {'x': 'x_L3', 'y': 'y_L3', 'z': 'z_L3', 'Vx': 'Vx', 'Vy': 'Vy', 'Vz': 'Vz', 'Ax': 'Ax_L3',
                     'Ay': 'Ay_L3', 'Az': 'Az_L3'}
    if all(key in list(EI.keys()) for key in list(param_name_L3.values())):
        coords = coordinates_from_EI(EI, param_name_L3)
        coords_L3_on_border = nka_coordinates(nka.nka_sys_number, coords, timestamp, timestamp + delta)
        params_L3_from_ephemeris = dict(
            x_L3=coords_L3_on_border.xyz.x,
            y_L3=coords_L3_on_border.xyz.y,
            z_L3=coords_L3_on_border.xyz.z,
            Ax_L3=coords_L3_on_border.acc.Ax,
            Ay_L3=coords_L3_on_border.acc.Ay,
            Az_L3=coords_L3_on_border.acc.Az
        )
        params_from_ephemeris.update(params_L3_from_ephemeris)
    return params_from_ephemeris


def get_neighbor_tb(tb: int, N: int, neighbor_type: Literal['previous', 'next']):
    """Расчет tb и N для соседней фразы с учетом границ суток и четырехлетий"""

    tb_neighbor, N_neighbor = None, None
    if neighbor_type == 'previous':
        if tb == MIN_TB_VALUE:
            tb_neighbor = MAX_TB_VALUE
            if N == MIN_N_VALUE:
                N_neighbor = MAX_N_VALUE
            else:
                N_neighbor = N - 1
        else:
            tb_neighbor = tb - 1
            N_neighbor = N

    if neighbor_type == 'next':
        if tb == MAX_TB_VALUE:
            tb_neighbor = MIN_TB_VALUE
            if N == MAX_N_VALUE:
                N_neighbor = MIN_N_VALUE
            else:
                N_neighbor = N + 1
        else:
            tb_neighbor = tb + 1
            N_neighbor = N

    return tb_neighbor, N_neighbor


def check_EI_with_neighbor_SI(time_bind: TimeData,
                              form,
                              nka: int,
                              record,
                              neighbor_type: Literal['previous', 'next']):
    """
    Проверить согласованность СИ на соседних tb
    Сначала происходит поиск  текущей фразы (той, на которую нажал юзер) по заданным tb и N в заданной записи record.
    Затем из текущей записи достается ЭИ. После производится расчет tb и N соседней записи (тип соседства является
    параметром), и осуществляется поиск соседней фразы, откуда также достается ЭИ.
    Имея два набора ЭИ, каждый из них пересчитывается на общую границу интервалов tb (поскольку исходная ЭИ привязана
    к серединам интервалов) и формируется результат сравнения в виде словаря.
    """

    result = []
    tb_curr = time_bind.tb
    N_curr = time_bind.N
    MAX_TB_VALUE = 48  # Максимальное значение tb
    MIN_TB_VALUE = 1  # Минимальное значение tb

    # Поиск фразы в СИ с текущим tb
    curr_SI = form(nku_num=nka)  # экземпляр СИ с текущим tb
    curr_EI, _ = curr_SI.parse_form(record, time_bind=TimeData(tb=tb_curr, N=N_curr, mode='SI'))
    if not curr_SI.phrase:
        raise ValueError(f'Не найдена фраза в СИ с заданными tb = {tb_curr} и N = {N_curr}')

    # Поиск фразы в СИ с соседним tb
    tb_neighbor, N_neighbor = get_neighbor_tb(tb_curr, N_curr, neighbor_type)
    neighbor_SI = form(nku_num=nka)  # экземпляр СИ с соседним tb
    neighbor_EI, _ = neighbor_SI.parse_form(record, time_bind=TimeData(tb=tb_neighbor, N=N_neighbor, mode='SI'))
    if not neighbor_SI.phrase:
        logging.info(
            f'Сравнение ЭИ в СИ: Не найдена соседняя фраза с параметрами tb = {tb_neighbor} и N = {N_neighbor}')
        raise ValueError(f'Не найдена соседняя фраза с параметрами tb = {tb_neighbor} и N = {N_neighbor}')

    # Формирование словаря со сравнением параметров
    if not neighbor_EI:
        raise ValueError(
            f'Не удалось извлечь ЭИ из соседней фразы СИ с параметрами: tb = {tb_neighbor} и N = {N_neighbor}')
    param = {}
    try:
        #  пересчет ЭИ на границу tb
        if neighbor_type == 'next':
            delta = datetime.timedelta(minutes=-15)
        else:
            delta = datetime.timedelta(minutes=15)
        neighbor_EI_on_border = get_coords_on_tb_border(nka=neighbor_SI.curr_nka, EI=neighbor_EI,
                                                        timestamp=record.timestamp, delta=delta)
        curr_EI_on_border = get_coords_on_tb_border(nka=curr_SI.curr_nka, EI=curr_EI,
                                                    timestamp=record.timestamp, delta=-delta)
    except (ValueError,
            ZeroDivisionError):
        raise BadEIException('Ошибка пересчета ЭИ на границу интервала tb')
    else:
        for key, val in curr_EI.items():
            param[key] = {}
            param[key]['param'] = key
            param[key]['curr'] = val

            if key in curr_EI_on_border:
                param[key]['curr_border'] = curr_EI_on_border[key]
            if key in neighbor_EI:
                param[key]['neighbor'] = neighbor_EI[key]
                if key not in neighbor_EI_on_border:  # FIXME для параметров без пересчета (изначально для dX, dY, dZ на 14Ф160)
                    if key == 'phrase_tb' and (neighbor_EI[key] == MAX_TB_VALUE and param[key]['curr'] == MIN_TB_VALUE):
                        param[key]['diff'] = (param[key]['curr'] - neighbor_EI[key]) % MAX_TB_VALUE
                    elif key == 'phrase_tb' and (
                            param[key]['curr'] == MAX_TB_VALUE and neighbor_EI[key] == MIN_TB_VALUE):
                        param[key]['diff'] = (neighbor_EI[key] - param[key]['curr']) % MAX_TB_VALUE
                    else:
                        param[key]['diff'] = param[key]['curr'] - neighbor_EI[key]
                    param[key]['curr_border'] = param[key]['curr']
                    param[key]['neighbor_border'] = neighbor_EI[key]
            if key in neighbor_EI_on_border:
                param[key]['neighbor_border'] = neighbor_EI_on_border[key]
                if key in curr_EI_on_border:
                    param[key]['diff'] = curr_EI_on_border[key] - neighbor_EI_on_border[key]
            if key == 'phrase_tb':
                param[key]['diff'] = abs(param[key]['diff'])
                param[key]['threshold'] = MIN_TB_VALUE
            else:
                param[key]['threshold'] = comparison_si_threshold.get(key, 0)
            param[key]['is_valid'] = True if abs(param[key]['diff']) <= param[key]['threshold'] else False

        result = list(param.values())

    return dict(result=result,
                sys_num=curr_SI.curr_nka.nka_sys_number,
                nka_num=curr_SI.curr_nka.nku_number,
                time=dict(
                    timestamp=record.timestamp,
                    tb=tb_curr,
                    tb_timestamp=(datetime.datetime(year=2000, month=1, day=1) + datetime.timedelta(days=N_curr - 1,
                                                                                                    minutes=tb_curr * 30)).strftime(
                        '%d.%m %H:%M:%S'),
                    N=N_curr,
                    neighbor_tb=tb_neighbor if neighbor_EI else None,
                    neighbor_N=N_neighbor if neighbor_EI else None
                ))
