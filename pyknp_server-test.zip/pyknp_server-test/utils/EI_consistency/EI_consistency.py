import datetime
import logging

from typing_extensions import Literal

from data import DoesNotExist
from global_data.appdata import CODE_SIGNAL_TYPES
from global_data.config_schema import comparison_si_threshold
from utils.lib.exceptions import BadEIException, CompareEIinDIError


def set_response(is_tb_equal, result, curr_frame, neighbor_frame):
    curr_tk = curr_frame.get_frame_time()
    neighbor_tk = neighbor_frame.get_frame_time() if neighbor_frame else None
    sys_num = curr_frame.nka.nka_sys_number
    nka_num = curr_frame.nka.nku_number
    timestamp = curr_frame.timestamp

    return dict(is_tb_equal=is_tb_equal,
                result=result,
                sys_num=sys_num,
                nka_num=nka_num,
                time=dict(
                    timestamp=timestamp,
                    tk=curr_tk,
                    neighbor_tk=neighbor_tk,
                ))


def check_EI_with_neighbor_frame(curr_frame, neighbor_type: Literal['previous', 'next']):
    """Проверить согласованность ЭИ на соседних tk"""

    result = []
    is_tb_equal = None
    neighbor_frame = None
    tb_curr = curr_frame.get_tb()
    if tb_curr is None:
        raise CompareEIinDIError('Отсутствует tb в выбранном кадре ЦИ')

    #  если оперативка в кадре неполная или строки с ошибками
    if not curr_frame.is_immediate_complete or not curr_frame.is_immediate_valid:
        if curr_frame.signal_type in CODE_SIGNAL_TYPES:
            raise CompareEIinDIError(
                'Оперативная информация выбранного кадра ЦИ (строки 11, 12 и 13) неполная или содержит ошибки')
        else:
            raise CompareEIinDIError('Оперативная информация выбранного кадра ЦИ неполная или содержит ошибки')

    cls = type(curr_frame)
    neighbor_EI = None
    tb_neighbor = None
    curr_EI = curr_frame.get_ephemeris_info()
    curr_EI['tb'] = curr_frame.datetime_from_tb()
    try:
        if neighbor_type == 'previous':
            neighbor_frame = cls \
                .select() \
                .where(cls.nka == curr_frame.nka) \
                .where(cls.timestamp < curr_frame.timestamp) \
                .order_by(cls.timestamp.desc()) \
                .get()
        else:
            neighbor_frame = cls \
                .select() \
                .where(cls.nka == curr_frame.nka) \
                .where(cls.timestamp > curr_frame.timestamp) \
                .order_by(cls.timestamp.asc()) \
                .get()
    except DoesNotExist:
        logging.info(f'Не найдена ЭИ для tk: {curr_frame.get_frame_time()}')
        raise CompareEIinDIError('Соседний кадр ЦИ отсутствует')
    if not neighbor_frame.is_immediate_complete or not neighbor_frame.is_immediate_valid:
        if curr_frame.signal_type in CODE_SIGNAL_TYPES:
            raise CompareEIinDIError(
                'Оперативная информация соседнего кадра ЦИ (строки 11, 12 и 13) неполная или содержит ошибки')
        else:
            raise CompareEIinDIError('Оперативная информация соседнего кадра ЦИ неполная или содержит ошибки')
    tb_neighbor = neighbor_frame.get_tb()
    if tb_neighbor is None:
        raise CompareEIinDIError('Отсутствует tb в соседнем кадре ЦИ')
    neighbor_EI = neighbor_frame.get_ephemeris_info()

    if tb_neighbor and neighbor_EI:
        neighbor_EI['tb'] = neighbor_frame.datetime_from_tb()
        param = {}
        for key, val in curr_EI.items():
            param[key] = {}
            param[key]['param'] = key
            param[key]['curr'] = val
            param[key]['neighbor'] = neighbor_EI[key]
            if tb_curr == tb_neighbor:
                is_tb_equal = True
                if key in neighbor_EI:
                    param[key]['diff'] = val - neighbor_EI[key]
                    param[key]['threshold'] = comparison_si_threshold.get(key, 0)
                    param[key]['is_valid'] = True if abs(param[key]['diff']) <= param[key]['threshold'] else False
                    if key == 'tb':
                        param[key]['diff'] = str(abs(param[key]['diff']))

        if tb_curr != tb_neighbor:
            is_tb_equal = False
            neighbor_EI_on_border = None
            curr_EI_on_border = None
            try:
                #  пересчет ЭИ на границу tb
                if neighbor_type == 'next':
                    neighbor_EI_on_border = neighbor_frame.get_coords_on_tb_border(datetime.timedelta(minutes=-15))
                    curr_EI_on_border = curr_frame.get_coords_on_tb_border(datetime.timedelta(minutes=15))
                else:
                    neighbor_EI_on_border = neighbor_frame.get_coords_on_tb_border(datetime.timedelta(minutes=15))
                    curr_EI_on_border = curr_frame.get_coords_on_tb_border(datetime.timedelta(minutes=-15))

                for key, val in curr_EI.items():
                    if key in curr_EI_on_border:
                        param[key]['curr_border'] = curr_EI_on_border[key]
                    if key in neighbor_EI_on_border:
                        param[key]['neighbor_border'] = neighbor_EI_on_border[key]
                        if key in curr_EI_on_border:
                            param[key]['diff'] = curr_EI_on_border[key] - neighbor_EI_on_border[key]
                            param[key]['threshold'] = comparison_si_threshold.get(key, 0)
                            param[key]['is_valid'] = True if abs(param[key]['diff']) <= param[key][
                                'threshold'] else False
                            if key == 'tb':
                                param[key]['diff'] = str(abs(param[key]['diff']))
            except (ValueError, ZeroDivisionError, KeyError, AttributeError):
                pass
            finally:
                if neighbor_EI_on_border is None or curr_EI_on_border is None:
                    raise BadEIException(set_response(is_tb_equal, list(param.values()), curr_frame, neighbor_frame))
        result = list(param.values())

    return set_response(is_tb_equal, result, curr_frame, neighbor_frame)
