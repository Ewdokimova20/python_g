import datetime
from collections import deque
from typing import Optional, Deque, Dict

from global_data.config_schema import config


class AverageValue:
    """Класс для расчета среднего значения average residual за определенный промежуток времени."""

    def __init__(self, window_size: int):
        self.window_size: int = window_size  # за какой период усреднять значения, в секундах (берем из конфига)
        self.buffer: Dict[int, Deque[float]] = dict()
        self.buffer_times: Dict[int, Deque[datetime]] = dict()

    def add_average_value(self, value: float, bis_id: int) -> None:
        """Функция добавляет среднее значение корректных невязок в буфер

        Args:
            value (float): Среднее всех корректных невязок.
            bis_id (int): id Бис.

        Returns:
            None: Добавляет значение в буфер
        """

        # Инициализируем буфер для среднего для каждого биса, если он еще не существует
        if bis_id not in self.buffer:
            self.buffer[bis_id] = deque([value], maxlen=self.window_size)
            self.buffer_times[bis_id] = deque([datetime.datetime.now()], maxlen=self.window_size)
        else:
            # Оптимизация по обращению к переменным класса, чтобы не выполнять повторный поиск по словарю
            buffer_bis_id = self.buffer[bis_id]
            buffer_times_bis_id = self.buffer_times[bis_id]
            # Добавляем новое значение в буфер
            current_time = datetime.datetime.now()
            buffer_bis_id.append(value)
            buffer_times_bis_id.append(current_time)

            # Проверяем и удаляем все значения, которые старше window_size секунд от времени самого свежего значения
            while (
                    buffer_times_bis_id and abs(buffer_times_bis_id[0] - current_time)
                    > datetime.timedelta(seconds=self.window_size)
            ):
                buffer_bis_id.popleft()
                buffer_times_bis_id.popleft()

    def get_average_value(self, bis_id: Optional[int]) -> Optional[float]:
        """Функция расчитывает среднее значение всех невязок за определенный промежуток времени

        Args:
            bis_id (Optional[int]): id Бис или None.

        Returns:
            Optional[float]: Среднее значения всех невязок из буфера или None
        """

        if not bis_id:
            return None
        buffer_bis_id = self.buffer.get(bis_id)
        # Вычисляем среднее значение по данным в буфере
        if buffer_bis_id:
            return sum(buffer_bis_id) / len(buffer_bis_id)
        else:
            return None


# Создаем экземпляр класса
average_value = AverageValue(config['bis_control']['average_residual_averaging_interval'])
