from typing import Union

from global_data import appdata
from global_data.appdata import PILOT_CODE_SIGNALS, DIGITAL_SIGNALS_FOR_PILOT_SIGNALS
from models.immediateinfo import LFImmediateInfo, LCImmediateInfo
from utils.immediate_info import cache_immediate_lf, cache_immediate_lc
from utils.lib.exceptions import ResidualCalcError, LFImmediateInfoError, LCImmediateInfoError


def get_immediate_info(nka_id: int, signal_id: int) -> Union[
    LFImmediateInfo, LCImmediateInfo, LFImmediateInfoError, LCImmediateInfoError]:
    """Функция предоставления доступа к кэшу ОИ для различных сигналов
    Указание конкретного сигнала сделано для возможности различения дефектов при различной ОИ в сигналах

    Args:
        nka_id (int): Номер бис id.
        signal_id (int): Номер станции id.

    Returns:
        Объекты LFImmediateInfo / LCImmediateInfo, или ошибки LFImmediateInfoError / LCImmediateInfoError.
    """

    if signal_id in appdata.FREQ_SIGNAL_TYPES:
        # Проверяем, есть ли данные для данного nka в кэше
        immediate = cache_immediate_lf.get_item_by_key(nka_id, signal_id)
        if immediate is not None:
            return immediate
        else:
            raise LFImmediateInfoError(f"в базе данных LFImmediateInfo нет пары нка:{nka_id}, сигнала:{signal_id}")
    else:
        # Так как ОИ для пилотных компонентов кодовых сигналов нету, берем для информационной
        if signal_id in PILOT_CODE_SIGNALS:
            signal_id = DIGITAL_SIGNALS_FOR_PILOT_SIGNALS.get(signal_id, signal_id)
        # Так как ОИ для l2ksi нет
        if signal_id == appdata.SIGNALS_NAME["L2КСИ"]:
            if appdata.SIGNALS_NAME["L1OCd"] in appdata.NKA_SIGNALS.get(nka_id, []):
                signal_id = appdata.SIGNALS_NAME["L1OCd"]
            elif appdata.SIGNALS_NAME["L2SCd"] in appdata.NKA_SIGNALS.get(nka_id, []):
                signal_id = appdata.SIGNALS_NAME["L2SCd"]
            else:
                raise ResidualCalcError

        # Проверяем, есть ли данные для данного nka в кэше
        immediate = cache_immediate_lc.get_item_by_key(nka_id, signal_id)
        if immediate is not None:
            return immediate
        else:
            raise LCImmediateInfoError(f"в базе данных LCImmediateInfo нет пары нка:{nka_id}, сигнала:{signal_id}")
