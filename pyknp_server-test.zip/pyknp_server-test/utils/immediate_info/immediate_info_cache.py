from typing import Dict, Optional, Tuple, Type, Union

from models.immediateinfo import LCImmediateInfo, LFImmediateInfo
from utils.caches.base_model_cache import BaseCache


class ImmediateInfoCache(BaseCache):
    def __init__(self, model: Type[Union[LCImmediateInfo, LFImmediateInfo]]):
        self._cache: Dict[Tuple[int, int], Union[LCImmediateInfo, LFImmediateInfo]] = {}
        self.model = model
        self._update_cache_data_from_db()

    def add_data(self, nka_id: int, signal_id: int, immediate_info: Union[LCImmediateInfo, LFImmediateInfo]) -> None:
        """Добавление данных в кэш для модели

        Args:
            nka_id (int): id НКА.
            signal_id (int): id сигнала.
            immediate_info (Union[LCImmediateInfo, LFImmediateInfo]): модель оперативной информации.

        Returns:
            None
        """
        self._cache[(nka_id, signal_id)] = immediate_info

    def get_item_by_key(self, nka_id: int, signal_id: int) -> Optional[Union[LCImmediateInfo, LFImmediateInfo]]:
        """Получение данных из кэша для модели

        Args:
            nka_id (int): id НКА.
            signal_id (int): id сигнала.

        Returns:
            Optional[Union[LCImmediateInfo, LFImmediateInfo]]: модель оперативной информации или None.
        """
        return self._cache.get((nka_id, signal_id))

    def _update_cache_data_from_db(self) -> None:
        """Создание или обновление кэша из базы данных для модели

        Returns:
            None
        """
        list_immediate = (
            self.model
            .select()
            .distinct(self.model.nka, self.model.signal_id)
            .order_by(self.model.nka, self.model.signal_id, self.model.id.desc())
        )

        if list_immediate:
            for immediate in list_immediate:
                self.add_data(immediate.nka.nka_sys_number, immediate.signal_id, immediate)

    def __str__(self):
        return f"{self.__class__.__name__}: cache={self._cache}"


# Создание экземпляров кэша
cache_immediate_lc = ImmediateInfoCache(LCImmediateInfo)
"""Кэш для обобщенной оперативной информации по кодовым сигналам"""

cache_immediate_lf = ImmediateInfoCache(LFImmediateInfo)
"""Кэш для обобщенной оперативной информации по L1OF"""
