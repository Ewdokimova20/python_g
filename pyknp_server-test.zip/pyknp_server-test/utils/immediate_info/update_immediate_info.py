import logging
from typing import Union, List, Dict

from data import CDSignalFrame, LCStableData
from global_data.appdata import SIGNALS_NAME
from models.di_string.of_signal_string import OFSignalString
from models.immediateinfo import LCImmediateInfo, LFImmediateInfo
from models.nka import Nka
from utils.immediate_info import cache_immediate_lf, cache_immediate_lc
from utils.signals.FD.L1OF import seconds_from_tk as seconds_from_tk_L1OF
from utils.signals.FD.L1SF import seconds_from_tk as seconds_from_tk_L1SF

logger = logging.getLogger('update_immediate_info')


def update_immediate_info(string: Union[OFSignalString, CDSignalFrame],
                          immediate_buf: Union[List[Union[OFSignalString, CDSignalFrame]],
                                               Dict[int, Union[OFSignalString, CDSignalFrame]]]) -> None:
    """
    Обновление оперативной информации.

    *При этом проверяем код Хэмминга - если есть ошибка в строке, то оперативку по этому набору не собираем.
    Обёртка try...except сделана для тех редких случаев, когда сборщик кадра просигнализировал о наличии собранных строк ОИ, а на самом деле одной не хватает.
    Так иногда бывает, когда при нестабильном приёме или входе в зону какие-то строки задерживаются и их зачисляют не в свой кадр.*

    Args:
        string (Union[OFSignalString, CDSignalFrame]): модель SignalFrame.
        immediate_buf (Union[List, Dict]): список или словарь моделей SignalFrame.

    Raises:
        AttributeError: попытка получить доступ к атрибуту, который не существует у объекта.

    Returns:
        None
    """

    if string.signal_id is SIGNALS_NAME["L1OF"]:
        try:
            if all(not immediate_buf[i].error_in_string for i in range(1, 6)):
                update_immediate_info_lf(string.nka, immediate_buf, string.signal_id)
        except AttributeError:
            # TODO При подготовке к установке штатного ПО переделать на warning
            logger.info(f"Ошибка в строке при сборке оперативной информации.\n" + "\n".join(
                f"{immediate_buf.get(i, 'None')}" for i in range(1, 6)
            ))
    elif string.signal_id is SIGNALS_NAME["L1SF"]:
        try:
            if all(not immediate_buf[i].error_in_string for i in [1, 2, 3, 4, 5, 6, 7, 10]):
                update_immediate_info_lf(string.nka, immediate_buf, string.signal_id)
        except AttributeError:
            logger.info("Ошибка в строке при сборке оперативной информации.\n" + "\n".join(
                f"{immediate_buf.get(i, 'None')}" for i in [1, 2, 3, 4, 5, 6, 7, 10]
            ))
    elif string.signal_id in [SIGNALS_NAME["L1OCd"], SIGNALS_NAME["L3OCd"], SIGNALS_NAME["L1SCd"],
                              SIGNALS_NAME["L2SCd"]]:
        complete_frames = immediate_buf
        for frame in complete_frames:
            if frame.is_immediate_valid:
                update_immediate_info_lc(frame, string.signal_id)


def update_immediate_info_lf(nka: Nka, immediate_strings: dict, signal_id: int = 0x21) -> None:
    """Функция обновления обобщённой оперативной информации для сигналов с частотным разделением.

    Args:
        nka (Nka): модель НКА.
        immediate_strings (dict): список строк оперативной информации.
        signal_id (int): идентификатор сигнала, к которому принадлежит ОИ.

    Raises:
        IndexError: попытка доступа к элементу списка по индексу, который выходит за пределы диапазона.
        KeyError: попытка доступа к ключу в словаре, который не существует.
        AttributeError: попытка получить доступ к атрибуту, который не существует у объекта.

    Returns:
        None
    """

    try:
        # ============ собираем данные по строкам в единый словарь ============================
        immediate_info = {}
        for string_num, string_object in immediate_strings.items():
            # формируем совокупный словарь параметров из строк ЦИ
            # Параметры в рамках ОИ уникальны, они не перезапишут друг друга
            # Параметры альманаха не уникльны между слотами, но они здесь и не обрабатываются
            # В итоге если мы в некий словарь сведем все параметры кадра, то обращаяь по имени параметров ОИ мы их получим
            # Для каждой строки извлекаем словарь её параметров и добавляем/обновляем их значения в совокупном словаре
            immediate_info.update(string_object.content[0])  # FIXME не понимаю, как это работает
        frame_time = 0
        if signal_id == SIGNALS_NAME['L1SF']:
            frame_time = seconds_from_tk_L1SF(immediate_info['tk'])
        if signal_id == SIGNALS_NAME['L1OF']:
            frame_time = seconds_from_tk_L1OF(immediate_info['tk'])
        # ================== записываем оперативную информацию по КА в ЛБД ===========
        lf_immediate_info_cursor = (LFImmediateInfo
                                    .insert(nka=nka,
                                            signal_id=signal_id,
                                            N_T=immediate_info['Nt'],
                                            N4=immediate_info['N4'],
                                            t_k=immediate_info['tk'],
                                            P1=immediate_info['P1'],
                                            t_b=immediate_info['tb'],
                                            x=1000. * immediate_info['x'],
                                            Vx=1000. * immediate_info['Vx'],
                                            Ax=1000. * immediate_info['Ax'],
                                            y=1000. * immediate_info['y'],
                                            Vy=1000. * immediate_info['Vy'],
                                            Ay=1000. * immediate_info['Ay'],
                                            z=1000. * immediate_info['z'],
                                            Vz=1000. * immediate_info['Vz'],
                                            Az=1000. * immediate_info['Az'],
                                            gamma=immediate_info['gamma'],
                                            tau=immediate_info['tau'],
                                            ground_call=immediate_info['Bn'],
                                            is_in_time=0,  # по аналогии с L1OF
                                            frame_time=frame_time,
                                            ln1=immediate_info['ln1'],
                                            ln3=immediate_info['ln3'])
                                    .on_conflict_ignore()
                                    .returning(LFImmediateInfo)
                                    .execute())

        if lf_immediate_info_cursor:
            lf_immediate_info_model = lf_immediate_info_cursor[0]
            cache_immediate_lf.add_data(nka.nka_sys_number, signal_id, lf_immediate_info_model)

    except (IndexError, KeyError) as err:
        logger.warning(
            "Ошибка сборки оперативной информации сигналов с частотным разделением при доступе к параметру " + str(err))
    except AttributeError as e:
        logger.warning(f"Ошибка при сборке оперативной информации сигнала с кодом {str(signal_id)} ({str(e)})")


def update_immediate_info_lc(decoded_frame: CDSignalFrame, signal_id: int) -> None:
    """Функция обновления обобщённой оперативной информации для сигналов с кодовым разделением.

    Args:
        decoded_frame (CDSignalFrame): список строк оперативной информации.
        signal_id (int): идентификатор сигнала, к которому принадлежит ОИ.

    Raises:
        IndexError: попытка доступа к элементу списка по индексу, который выходит за пределы диапазона.
        KeyError: попытка доступа к ключу в словаре, который не существует.
        AttributeError: попытка получить доступ к атрибуту, который не существует у объекта.

    Returns:
        None
    """

    decoded_frame_string10 = decoded_frame.string10
    decoded_frame_string13 = decoded_frame.string13

    # обработке подлежат только полные кадры пока (иначе отбрасываем, хотя там могут быть 10-11-12 строки)
    if not decoded_frame.is_complete:
        return

    # дополнительная защита от отсутствия в кадре 10-й строки (вызывает сбой при обращении к service_fields)
    if not decoded_frame_string10:
        return

    try:
        # ============ собираем данные по строкам в единый словарь ============================
        service_fields = decoded_frame_string10.service_fields
        immediate_info = decoded_frame_string10.content[0]
        immediate_info.update(decoded_frame.string11.content[0])
        immediate_info.update(decoded_frame.string12.content[0])
        if decoded_frame_string13:  # для сигналов L*SC содержит координаты смещения ФЦА
            immediate_info.update(decoded_frame_string13.content[0])
        # ================== записываем оперативную информацию по КА в ЛБД ===========
        lc_immediate_info_cursor = (LCImmediateInfo
                                    .insert(nka=decoded_frame.nka,
                                            signal_id=signal_id,
                                            N_T=immediate_info['Nt'],
                                            N4=immediate_info['N4'],
                                            t_k=service_fields.omv,
                                            # ОМВ 10-й строки можно считать началом времени кадра
                                            P1=0,
                                            # что отражает факт нетипизированности времени обновления tb
                                            t_b=immediate_info['tb'],
                                            x=1000. * immediate_info['x'],
                                            Vx=1000. * immediate_info['Vx'],
                                            Ax=1000. * immediate_info['Ax'],
                                            y=1000. * immediate_info['y'],
                                            Vy=1000. * immediate_info['Vy'],
                                            Ay=1000. * immediate_info['Ay'],
                                            z=1000. * immediate_info['z'],
                                            Vz=1000. * immediate_info['Vz'],
                                            Az=1000. * immediate_info['Az'],
                                            gamma=immediate_info['gamma'], tau=immediate_info['tau'],
                                            beta=immediate_info['beta'],
                                            ground_call=service_fields.P1,
                                            is_in_time=0,  # по аналогии с LF -сигналами
                                            frame_time=service_fields.omv * decoded_frame_string10.string_duration,
                                            ln1=service_fields.gj,
                                            ln3=service_fields.lj)
                                    .on_conflict_ignore()
                                    .returning(LCImmediateInfo)
                                    .execute())
        if lc_immediate_info_cursor:
            lc_immediate_info_model = lc_immediate_info_cursor[0]
            cache_immediate_lc.add_data(decoded_frame.nka.nka_sys_number, signal_id, lc_immediate_info_model)

        # ================== записываем фиксированные/стабильные данные НКА в БД ===========
        # они, теоритически, можут быть записаны однократно для каждого НКА, но учитывая дальнейшую необходимость контроля
        # перезакладки и возможность изменения в процессе эксплуатации выполняем их периодическое обновление
        signal_dt = 0.0  # Важно! интерпретация параметра зависит от диентификатора сигнала!
        if 'delta_tau_L3' in immediate_info:  # Извлекаем смещение БШВ L3OCp относительно БШВ L3OCOCd
            signal_dt = immediate_info['delta_tau_L3']
        if 'delta_tau_l2' in immediate_info:  # Извлекаем смещение БШВ L2OCp относительно БШВ L1OCOCd
            signal_dt = immediate_info['delta_tau_l2']
        # сохранение проводим только если есть обязательные параметры (актуально для SC, где 13-я строка не в каждом кадре)
        if 'delta_x_fc' in immediate_info:
            (LCStableData.insert(nka=decoded_frame.nka,
                                 signal_type_id=signal_id,
                                 dt=signal_dt,
                                 r=immediate_info['delta_x_fc'],
                                 b=immediate_info['delta_y_fc'],
                                 n=immediate_info['delta_z_fc']
                                 ).on_conflict_ignore().execute())
    except (IndexError, KeyError) as err:
        logger.warning("Ошибка сборки неоперативной информации кодовых сигналов при доступе к параметру " + str(err))
    except AttributeError as e:
        logger.warning(f"Ошибка при сборке оперативной информации сигнала с кодом {str(signal_id)} ({str(e)})")
