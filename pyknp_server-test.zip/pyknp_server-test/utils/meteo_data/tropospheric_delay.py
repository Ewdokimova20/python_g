import datetime
from math import sin, cos
from typing import Union

from utils.caches import cache_bis
from utils.lib.exceptions import BisCacheError
from utils.meteo_data.meteo_data_cache import cache_meteoparameters


def tropospheric_delay(bis_id: int, elevation: float, timestamp: datetime.datetime) -> Union[float, BisCacheError]:
    """Расчет тропосферной задержки по Саастамойнену

    Args:
        bis_id (int): id БИС.
        elevation (float): Номер станции.
        timestamp (datetime.datetime): дата из сигнала.

    Raises:
        BisCacheError: bis_cache нету модели Bis

    Returns:
        Тропосферная задержка в метрах.
    """

    def delay_map(a: float, b: float, c: float, elev: float) -> float:
        numerator = 1 + a / (1 + b / (1 + c))
        denominator = sin(elev) + a / (sin(elev) + b / (sin(elev + b / (sin(elev) + c))))
        return numerator / denominator

    def md(elev: float, phis: float, ts: float, hs: float) -> float:
        """map function for dry delay

        Args:
            elev (float): Угол места НКА в радианах.
            phis (float): Широта пункта наблюдения.
            ts (float): Температура поверхности в пункте в градусах Цельсия.
            hs (float): Высота пункта.

        Returns:
            Delay dry.
        """

        T0 = 10  # какой-то поправочный коэффициент
        a = (1.2320 + 0.0130 * cos(phis) - 0.0209 * hs + 0.00215 * (ts - T0)) / 1000
        b = (3.1612 + 0.1600 * cos(phis) - 0.0331 * hs + 0.00206 * (ts - T0)) / 1000
        c = (71.244 + 4.2930 * cos(phis) - 0.1490 * hs + 0.00210 * (ts - T0)) / 1000
        return delay_map(a, b, c, elev)

    def mw(elev: float, phis: float, ts: float, hs: float) -> float:
        """map function for wet delay

        Args:
            elev (float): Угол места НКА в радианах.
            phis (float): Широта пункта наблюдения.
            ts (float): Температура поверхности в пункте в градусах Цельсия.
            hs (float): Высота пункта.

        Returns:
            Delay wet.
        """

        T0 = 10  # какой-то поправочный коэффициент
        a = (0.583 + 0.011 * cos(phis) - 0.052 * hs + 0.0014 * (ts - T0)) / 1000
        b = (1.402 + 0.102 * cos(phis) - 0.101 * hs + 0.0020 * (ts - T0)) / 1000
        c = (48.85 + 1.910 * cos(phis) - 1.290 * hs + 0.0150 * (ts - T0)) / 1000
        return delay_map(a, b, c, elev)

    # получаем параметры положения БИС для модели
    current_bis = cache_bis.get_item_by_id(bis_id)
    if current_bis is None:
        raise BisCacheError(f"В кэше отсутствует БИС с id: {bis_id}")
    current_bis_coordinates = current_bis.coordinates
    phi = current_bis_coordinates.blh.b  # широта в радианах
    h = current_bis_coordinates.blh.h / 1000.0  # высота в километрах

    # получаем текущие метеопараметры
    current_mete_data = cache_meteoparameters.get_item_by_key(bis_id, timestamp)

    if current_mete_data is None:
        return 0.0

    T = current_mete_data.t  # температура у поверхности в градусах цельсия

    # расчет задержки
    ZHD = 0.0022767 * current_mete_data.p / (1 - 0.00266 * cos(phi) - 0.28 * h * 1e-6)
    es = current_mete_data.h * 0.01 * 6.11 * pow(10, 7.5 * T / (237.3 + T))
    ZWD = 0.0022767 * (1255 / (T + 273.15) + 0.05) * es
    return ZHD * md(elevation, phi, T, h) + ZWD * mw(elevation, phi, T, h)
