import datetime
import logging
from typing import Dict, Optional

from global_data.config_schema import config
from models.meteoparams import Meteoparameters
from utils.caches import cache_bis
from utils.caches.base_model_cache import BaseCache


class MeteoparametersCache(BaseCache):
    METEODATA_ACTUAL_DURATION = config['bis_control']['meteodata_actual_duration']
    '''Cрок допустимости использования метеоданных'''
    logger = logging.getLogger('meteo_data')

    def __init__(self):
        self._cache: Dict[int, Meteoparameters] = {}
        self._fetch_from_db()

    def _fetch_from_db(self) -> Dict[int, Meteoparameters]:
        """Инициализирует кэш для БИСов из записей в БД

        Returns:
            Dict[int, Meteoparameters]: словарь (ключ bis_id, значение Meteoparameters) или пустой словарь
        """
        bis_list = cache_bis.get_bis_list()
        bis_ids = [bis.id for bis in bis_list]

        latest_data_from_db = (
            Meteoparameters
            .select()
            .distinct(Meteoparameters.bis)
            .where(
                (Meteoparameters.bis.in_(bis_ids)) &
                (Meteoparameters.is_incorrect == False)
            )
            .order_by(Meteoparameters.bis, Meteoparameters.id.desc())
        )

        latest_data = {meteoparametr.bis.id: meteoparametr for meteoparametr in latest_data_from_db}

        missing_id_bis = [model for model in bis_list if model.id not in latest_data]
        for model in missing_id_bis:
            self.logger.debug(
                f'В БД отсутствуют записи метеопараметров для '
                f'станции номер: {model.station.station_number} '
                f'и БИС номер: {model.bis_number}'
            )

        return latest_data

    def add_data(self, bis_id: int, meteoparameters: Meteoparameters) -> None:
        """Добавление данных в кэш для модели

        Args:
            bis_id (int): id Bis.
            meteoparameters (Meteoparameters): модель Meteoparameters.

        Returns:
            None
        """
        self._cache[bis_id] = meteoparameters

    def get_item_by_key(self, bis_id: int, timestamp: datetime.datetime) -> Optional[Meteoparameters]:
        """Получение данных из кэша для модели

        Args:
            bis_id (int): id Bis.
            timestamp (datetime.datetime): дата из сигнала.

        Returns:
            Optional[Meteoparameters]: модель Meteoparameters или None.
        """
        data = self._cache.get(bis_id)
        if data:
            border_timestamp_down = timestamp - datetime.timedelta(seconds=self.METEODATA_ACTUAL_DURATION)
            border_timestamp_top = timestamp + datetime.timedelta(seconds=self.METEODATA_ACTUAL_DURATION)
            meteo_timestamp = data.timestamp
            if border_timestamp_top >= meteo_timestamp >= border_timestamp_down:
                return data
        return None

    def __str__(self):
        return f"{self.__class__.__name__}: cache={self._cache}"


# Создание экземпляра кэша
cache_meteoparameters = MeteoparametersCache()
"""Кэш для Meteoparameters"""
