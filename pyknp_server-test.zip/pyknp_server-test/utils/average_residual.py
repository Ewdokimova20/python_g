import datetime
from collections import deque
from typing import Dict, Tuple, Union, Deque

from data import Residual
from global_data.config_schema import config


class AverageResidual:
    """Класс для расчета среднего значения каждой невязки за определенный промежуток времени residual_averaging_interval."""

    def __init__(self, window_size: int):
        self.window_size: int = window_size  # за какой период усреднять невязки, в секундах (берем из конфига)
        # self.buffer => key: (bis_id, nka_sys_number, signal_1, signal_2) value: deque([residual])
        self.buffer: Dict[Tuple[int, int, int, int], Deque[float]] = dict()
        self.last_update_times: Dict[Tuple[int, int, int, int], Deque[datetime]] = dict()

    def get_average_residual(self, residual: Residual) -> Union[float, int]:
        """Функция добавляет значение невязки в буфер и расчитывает среднее значение невязки за определенный промежуток времени

        Args:
            residual (Residual): Обьект невязки.

        Returns:
            Union[float, int]: Значение средней невязки.
        """

        residual_buffer_id = (residual.bis.id, residual.nka.nka_sys_number, residual.signal_1, residual.signal_2)
        timestamp = residual.timestamp
        residual_value = residual.residual

        # Инициализируем буфер для каждой невязки, если он еще не существует
        if residual_buffer_id not in self.buffer:
            self.buffer[residual_buffer_id] = deque([residual_value], maxlen=self.window_size)
            self.last_update_times[residual_buffer_id] = deque([timestamp], maxlen=self.window_size)
            # Оптимизация по обращению к переменной класса, чтобы не выполнять повторный поиск по словарю
            buffer = self.buffer[residual_buffer_id]
        else:
            # Оптимизация по обращению к переменным класса, чтобы не выполнять повторный поиск по словарю
            buffer = self.buffer[residual_buffer_id]
            last_update_times = self.last_update_times[residual_buffer_id]

            # Добавляем новое значение в буфер
            buffer.append(residual_value)
            last_update_times.append(timestamp)

            # Проверяем и удаляем все значения, которые старше window_size секунд от времени самой свежей невязки
            while (
                    last_update_times and abs(last_update_times[0] - timestamp)
                    > datetime.timedelta(seconds=self.window_size)
            ):
                buffer.popleft()
                last_update_times.popleft()

        # Проверяем, есть ли значения для расчета среднего
        if buffer:
            return sum(buffer) / len(buffer)
        else:
            return residual.residual


average_residual = AverageResidual(config['bis_control']['residual_averaging_interval'])
