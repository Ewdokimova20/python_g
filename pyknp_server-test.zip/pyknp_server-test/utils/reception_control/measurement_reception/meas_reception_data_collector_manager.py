from datetime import datetime
from typing import Dict

from models.bis import Bis
from utils.caches import cache_bis
from utils.reception_control.measurement_reception.meas_reception_data_collector import MeasReceptionDataCollector


class MeasReceptionDataManager:
    """
    Класс ведет учет данных о состоянии приема 1с измерений со всех НКА на всех БИС
    """

    def __init__(self):
        self.collectors: Dict[int, MeasReceptionDataCollector] = {}
        all_bis = cache_bis.get_bis_list()
        for bis in all_bis:
            self.collectors[bis.id] = MeasReceptionDataCollector(bis)

    def get_or_create_collector(self, bis: Bis) -> MeasReceptionDataCollector:
        """
        Создать инстанс класса сбора данных о состоянии приема 1с измерений для одного БИС
        """
        if bis.id not in self.collectors:
            self.collectors[bis.id] = MeasReceptionDataCollector(bis)
        return self.collectors[bis.id]

    def update_measurement(self, bis: Bis, nka: int, signal_type: int, timestamp: datetime, meas_id: int):
        """
        Сохранить информацию об 1с измерении
        """
        collector = self.get_or_create_collector(bis)
        collector.update_measurement(nka, signal_type, timestamp, meas_id)

    def check_and_flush_to_db(self):
        """
        Сбросить все данные в ТЛБД по всем БИС, если пора
        """
        for collector in self.collectors.values():
            collector.check_and_flush_to_db()


# Использование:
measurement_reception_manager = MeasReceptionDataManager()
