from peewee import ModelSelect, JOIN

from data import Signal
from models.bis import Bis
from models.current_angles import CurrentAngles
from models.meas_reception_data import MeasReceptionData
from utils.reception_control.common.base_reception_monitor import BaseReceptionMonitor
from utils.reception_control.common.reception_status import ReceptionStatus
from utils.reception_control.measurement_reception.meas_reception_types import MeasReceptDataForClient, \
    Measurement
from utils.visibility.types import VisibilityStatus


class MeasReceptionMonitor(BaseReceptionMonitor[MeasReceptDataForClient]):
    def __init__(self):
        super().__init__(data_class=MeasReceptDataForClient)

    def _get_db_query(self) -> ModelSelect:
        return (MeasReceptionData
                .select(MeasReceptionData, CurrentAngles.visibility_state, Signal.snr, Signal.pseudorange,
                        Signal.carrier_shift, Signal.carrier_phase, Signal.pseudospeed)
                .join(Bis)
                .switch(MeasReceptionData)
                .join(CurrentAngles, on=(MeasReceptionData.nka == CurrentAngles.nka_id) &
                                        (Bis.station_id == CurrentAngles.station_id))
                .switch(MeasReceptionData)
                .join(Signal,
                      on=((MeasReceptionData.measurement.is_null(False)) &
                          (MeasReceptionData.measurement == Signal.id)),
                      join_type=JOIN.LEFT_OUTER)
                .where(CurrentAngles.visibility_state > VisibilityStatus.OUT_OF_SIGHT))

    def _create_data_from_record(self, record: MeasReceptionData) -> MeasReceptDataForClient:
        measurement_data = Measurement()
        # не пишем измерение, если сигнал отсутствует и в зрв нет пакетов
        try:
            measurement = record.measurement
        except Signal.DoesNotExist:
            # FIXME короче peewee при left join выше c Signal когда MeasReceptionData.measurement_id == NULL
            # вместо того, чтобы поставить в record.measurement просто NULL фигачит в это свойство ошибку
            # я не смогла победить эту фигню, в sql все корректно отрабатывает
            pass
        else:
            if not (record.reception_status == ReceptionStatus.EXPECTED_VISIBLE_ABSENT and not record.zone_count):
                measurement_data = Measurement(
                    pseudorange=measurement.pseudorange,
                    pseudospeed=measurement.pseudospeed,
                    carrier_shift=measurement.carrier_shift,
                    carrier_phase=measurement.carrier_phase,
                    snr=measurement.snr,
                )

        # Если все проверки пройдены, обновляем данные
        return MeasReceptDataForClient(
            reception_status=record.reception_status,
            is_zone_count_sufficient=record.is_zone_count_sufficient,
            timestamp=record.timestamp,
            actual_count=record.actual_count,
            zone_count=record.zone_count,
            expected_zone_count=record.expected_zone_count,
            measurement=measurement_data,
            visibility=record.currentangles.visibility_state if hasattr(record, 'currentangles') else None,
            last_update=record.last_update,
        )


measurement_reception_monitor = MeasReceptionMonitor()
