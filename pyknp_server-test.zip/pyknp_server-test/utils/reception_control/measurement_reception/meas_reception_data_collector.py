import logging
from collections import defaultdict
from datetime import datetime, timedelta

from peewee import EXCLUDED

from global_data.appdata import NKA_SIGNALS
from models.bis import Bis
from models.meas_reception_data import MeasReceptionData
from utils.reception_control.common.base_reception_data_collector import BaseReceptionDataCollector
from utils.reception_control.measurement_reception.meas_reception_types import CollectedMeasReceptData

logger = logging.getLogger('meas_reception_data_collector')


class MeasReceptionDataCollector(BaseReceptionDataCollector[CollectedMeasReceptData]):
    """
    Класс сбора данных о состоянии приема 1с измерений со всех НКА у одного БИС
    """

    def __init__(self, bis: Bis):
        super().__init__(bis, data_class=CollectedMeasReceptData, db_model=MeasReceptionData)

    def _initialize_data_structure(self):
        """Инициализирует структуру данных для всех известных НКА и типов сигналов"""
        for nka in NKA_SIGNALS:
            self.data[nka] = defaultdict(lambda: self.data_class())
            self.changes[nka] = defaultdict(lambda: self.data_class())
            self.latest_item_time[nka] = defaultdict(lambda: datetime.min)
            self.last_processed_time[nka] = defaultdict(lambda: datetime.min)
            # несмотря на то чо дефолтдикт, все равно прописываем явно ожидаемые ключи, потому что они обязательные
            for signal_type in NKA_SIGNALS[nka]:
                self.data[nka][signal_type] = self.data_class()
                self.changes[nka][signal_type] = self.data_class()
                self.latest_item_time[nka][signal_type] = datetime.min
                self.last_processed_time[nka][signal_type] = datetime.min

        self.db_model.delete().execute()

    def _get_db_fields_to_update(self) -> dict:
        """
        Возвращает словарь полей для обновления в БД
        """
        return {
            self.db_model.reception_status: EXCLUDED.reception_status,
            self.db_model.is_zone_count_sufficient: EXCLUDED.is_zone_count_sufficient,
            self.db_model.zone_count: EXCLUDED.zone_count,
            self.db_model.last_update: EXCLUDED.last_update,
            self.db_model.expected_zone_count: EXCLUDED.expected_zone_count,
            self.db_model.timestamp: EXCLUDED.timestamp,
            self.db_model.measurement: EXCLUDED.measurement_id,
            self.db_model.actual_count: EXCLUDED.actual_count
        }

    def _update_expected_zone_count(self):
        """
        Обновляет для каждой комбинации БИС-НКА-Тип сигнала в self.data и self.changes ожидаемое количество
        1с измерений в текущей ЗРВ, а также флаг is_zone_count_sufficient
        """
        current_time = (datetime.now() + timedelta(seconds=1)).replace(microsecond=0)
        
        with self._lock:
            for nka, signal_data in self.changes.items():
                # определяем, сколько измерений должно быть получено с начала текущей зоны (требуемое кол-во)
                expected_zone_count, visibility_zone = self._get_seconds_since_zone_start(nka, current_time)
                if expected_zone_count is None:
                    continue

                if expected_zone_count is not None and expected_zone_count != 0:
                    for signal_type in NKA_SIGNALS[nka]:
                        # если для этой пары нка-сигнал что-то уже есть в changes, то только в этом случае пишем
                        if signal_data[signal_type].model_dump(exclude_unset=True):
                            self._update_expected_zone_count_for_signal(
                                nka, signal_type, expected_zone_count, visibility_zone)

    def update_measurement(self, nka: int, signal_type: int, timestamp: datetime, meas_id: int):
        """
        Обновляет данные об измерении в ТЛБД: время пакета, ПД, фактический счетчик измерений, счетчик измерений в ЗРВ
        """
        if nka not in NKA_SIGNALS:
            return

        update_data = CollectedMeasReceptData(timestamp=timestamp)

        with self._lock:
            current_actual_count = self.data[nka][signal_type].actual_count or 0
            update_data.actual_count = current_actual_count + 1
            update_data.measurement = meas_id
            update_data.zone_count = self.update_zone_count(nka, signal_type, timestamp)

            self.last_processed_time[nka][signal_type] = datetime.now()
            self.latest_item_time[nka][signal_type] = timestamp
            self._update_data_and_changes(nka, signal_type, update_data)

    def _clear_changes(self):
        """Очищает словарь изменений"""
        with self._lock:
            self.changes.clear()
            for nka in NKA_SIGNALS:
                self.changes[nka] = defaultdict(lambda: self.data_class())
                for signal_type in NKA_SIGNALS[nka]:
                    self.changes[nka][signal_type] = self.data_class()
