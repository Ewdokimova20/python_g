from typing import Optional

from pydantic import BaseModel, Field

from utils.reception_control.common.common_types import BaseCollectedReceptData
from utils.visibility.types import VisibilityStatus


class Measurement(BaseModel):
    """Модель данных измерений."""
    pseudorange: Optional[float] = Field(default=None, description="Значение псевдодальности")
    pseudospeed: Optional[float] = Field(default=None, description="Значение псевдоскорости")
    carrier_shift: Optional[float] = Field(default=None, description="Сдвиг несущей")
    carrier_phase: Optional[float] = Field(default=None, description="Фаза несущей")
    snr: Optional[float] = Field(default=None, description="Отношение сигнал/шум")


class CollectedMeasReceptData(BaseCollectedReceptData):
    """
    Модель данных состояния приема 1с измерений для одной комбинации БИС/НКА/Тип сигнала при сборе информации
    """
    measurement: Optional[int] = Field(default=None)
    """ID последнего  полученного измерения"""


class MeasReceptDataForClient(CollectedMeasReceptData):
    """
    Модель данных состояния приема 1с измерений для одной комбинации БИС/НКА/Тип сигнала при отдаче на клиент
    """
    visibility: Optional[VisibilityStatus] = Field(default=None)
    """Необязательное поле для хранения информации о видимости."""
    measurement: Optional[Measurement] = Field(default=None)
    """Данные последнего полученного 1с измерения"""
