from __future__ import annotations

from utils.reception_control.message_counters.base_message_counter import BaseMessageCounter
from utils.reception_control.message_counters.types import ZMQMessageCounters


class GeneralMessageCounter(BaseMessageCounter):
    """
    Класс счётчиков числа пакетов (сообщений) по всем БИС и времени поступления последнего сообщения для основного процесса (обобщающего).
    Собирает информацию от PartialMessageCounter из дочерних процессов в общие словари, а также взаимодействует с клиентом и обобщенными признаками
    """

    def __init__(self):
        super().__init__()

    def get_full_stations_counter(self):
        """Возвращает счётчики по станциям/бис (при запросе общей статистики по всем БИС (только общее число пакетов и дата последнего) (/summary))"""
        return self.general_counter

    def get_full_bises_counter(self):
        """Возвращает счётчики по станциям/бис c числом пакетов каждого вида (при запросе общей статистики по всем БИС с цифрами по видам пакетов (/packet_type))"""
        return self.bises_counter

    def get_fixed_bis_from_nkas_counter(self, station: int, bis: int):
        """Возвращает счётчики по НКА (при раскрытии одного БИС показать все НКА (/nka_message))"""
        if station in self.nkas_counter:
            if bis in self.nkas_counter[station]:
                return self.nkas_counter[station][bis]
        return None

    def get_fixed_nka_from_signals_counter(self, station: int, bis: int, nka: int):
        """Возвращает счётчики по сигналам (при раскрытии одного НКА для одного БИС показать все сигналы (/signals_message))"""
        if station in self.signals_counter:
            if bis in self.signals_counter[station]:
                if nka in self.signals_counter[station][bis]:
                    return self.signals_counter[station][bis][nka]
        return None

    def load_data(self, data: ZMQMessageCounters):
        """Загружает состояние счетчиков, пришедшие с сокета"""
        for station, station_data in data['general'].items():
            for bis_num, bis_data in station_data.items():
                self.general_counter[station][bis_num] = bis_data

                if station in data['bis_counter'] and bis_num in data['bis_counter'][station]:
                    self.bises_counter[station][bis_num] = data['bis_counter'][station][bis_num]

                if station in data['nka_counter'] and bis_num in data['nka_counter'][station]:
                    self.nkas_counter[station][bis_num] = data['nka_counter'][station][bis_num]

                if station in data['signal_counter'] and bis_num in data['signal_counter'][station]:
                    self.signals_counter[station][bis_num] = data['signal_counter'][station][bis_num]


general_message_counters = GeneralMessageCounter()
"""Счётчики поступающих сообщений и времени их поступления по всем БИС"""
