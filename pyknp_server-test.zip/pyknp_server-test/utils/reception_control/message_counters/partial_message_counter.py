"""Модуль содержит класс счётчика числа сообщений и времени поступления последнего сообщения"""
from __future__ import annotations

import copy
import logging
from collections import defaultdict
from datetime import datetime
from typing import List, TYPE_CHECKING

from communication.types import ZMQTopic
from global_data.appdata import SignalTypes, PacketID
from utils.caches import cache_bis
from utils.reception_control.message_counters.base_message_counter import BaseMessageCounter
from utils.reception_control.message_counters.types import ZMQMessageCounters, TimedCounterDict
from utils.signals.types import DIOrMeasPacketID

if TYPE_CHECKING:
    from models.bis import Bis

logger = logging.getLogger(__name__)


class PartialMessageCounter(BaseMessageCounter):
    """
    Класс счётчика числа сообщений и времени поступления последнего сообщения для процессов обработки (дочерних).
    Отправляет состояние счетчиков каждые SEND_INTERVAL_SECONDS секунд.
    Ожидается, что в процессе обработки будет обрабатываться несколько БИС (3-4), поэтому иерархия по БИС сохранена (не все БИС, поэтому Partial)
    """
    SEND_INTERVAL_SECONDS = 3  # интервал передачи текущего состояния в секундах

    def __init__(self, bis_list: List['Bis']):
        """Функция инициализирует пустые счётчики для всех БИС, которые есть в базе"""
        super().__init__(
            general_factory=lambda: defaultdict(TimedCounterDict),
            bises_factory=lambda: defaultdict(lambda: defaultdict(TimedCounterDict)),
            nkas_factory=lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(TimedCounterDict))),
            signals_factory=lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(TimedCounterDict))))
        )
        self._last_sent_at = datetime.min
        self._bis_list = bis_list
        self._init_bis_counters()
        self._zmq_manager = None

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def clear_all_counters(self):
        """Функция полной очистки всех счётчиков"""
        self.general_counter.clear()
        self.bises_counter.clear()
        self.nkas_counter.clear()
        self.signals_counter.clear()
        self._init_bis_counters()

    def increment_nka_counters(self, station: int, bis: int, nka: int, signal_type: 'SignalTypes', packet_type: DIOrMeasPacketID):
        """Функция увеличения счётчиков сообщений для нка/сигнала"""
        if (station is not None) and (bis is not None) and (packet_type is not None) and \
                (nka is not None) and (signal_type is not None):
            self.nkas_counter[station][bis][nka][packet_type].increment()
            self.signals_counter[station][bis][nka][signal_type][packet_type].increment()

    def increment_bis_counters(self, station: int, bis: int, packet: PacketID):
        """Функция увеличения счётчиков пакетов для станции/бис."""
        if (station is not None) and (bis is not None) and (packet is not None):
            # Пакеты "Контроль соединения" увеличиваются для всех БИС процесса, у потока от СПО сети которого идут эти пакеты
            if packet == PacketID.CONNECTION_CONTROL:
                for bis in cache_bis.get_bis_list():
                    self.general_counter[bis.station_id][bis.bis_number].increment()
                    self.bises_counter[bis.station_id][bis.bis_number][PacketID.CONNECTION_CONTROL].increment()
            else:
                self.general_counter[station][bis].increment()
                self.bises_counter[station][bis][packet].increment()

    def _init_bis_counters(self):
        all_bis = cache_bis.get_bis_list()
        for bis in all_bis:
            self.general_counter[bis.station_id][bis.bis_number]
            self.bises_counter[bis.station_id][bis.bis_number]

    def send_state(self):
        """Отправляет текущее состояние счетчиков через сокет на обобщение по всем БИС (раз в SEND_INTERVAL_SECONDS)"""
        if (datetime.now() - self._last_sent_at).seconds >= self.SEND_INTERVAL_SECONDS:
            data = ZMQMessageCounters(general=self.general_counter,
                                      bis_counter=self.bises_counter,
                                      nka_counter=self.nkas_counter,
                                      signal_counter=self.signals_counter)
            try:
                logger.debug(f'Отправка состояния счетчиков пакетов ')
                self._zmq_manager.publish_data(ZMQTopic.PACKET_COUNTERS, data=data)
            except Exception as e:
                logger.warning(f'Ошибка при отправке состояния счетчиков пакетов')

            self._last_sent_at = datetime.now()

    def create_snapshot(self) -> PartialMessageCounter:
        """Создает экземпляр счетчиков с текущим состоянием signals_counter"""
        snapshot = self.__class__(self._bis_list)
        snapshot.signals_counter = copy.deepcopy(self.signals_counter)
        return snapshot
