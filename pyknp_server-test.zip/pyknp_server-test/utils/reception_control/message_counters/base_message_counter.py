from __future__ import annotations

import copy
from collections import defaultdict
from datetime import datetime
from typing import DefaultDict, Optional, Dict, Callable, Any

from global_data.appdata import SignalTypes, PacketID
from utils.lib.types.type_aliases import StationNum, BisNum, NkaSysNum
from utils.reception_control.message_counters.types import TimedCounterDict
from utils.signals.types import DIOrMeasPacketID

# Общие типы для счетчиков
GeneralCounter = DefaultDict[StationNum, Dict[BisNum, TimedCounterDict]]
BisesCounter = DefaultDict[StationNum, Dict[BisNum, Dict[DIOrMeasPacketID, TimedCounterDict]]]
NkaCounter = DefaultDict[StationNum, Dict[BisNum, Dict[NkaSysNum, Dict[DIOrMeasPacketID, TimedCounterDict]]]]
SignalCounter = DefaultDict[
    StationNum, Dict[BisNum, Dict[NkaSysNum, Dict[SignalTypes, Dict[DIOrMeasPacketID, TimedCounterDict]]]]]


class BaseMessageCounter:
    """Базовый класс для хранения счетчиков числа пакетов (сообщений)"""

    def __init__(
            self,
            general_factory: Callable[[], Any] = defaultdict,
            bises_factory: Callable[[], Any] = defaultdict,
            nkas_factory: Callable[[], Any] = defaultdict,
            signals_factory: Callable[[], Any] = defaultdict
    ):
        """Инициализация счетчиков с использованием defaultdict для автоматического создания вложенных структур"""

        self.general_counter: GeneralCounter = defaultdict(general_factory)
        """Общий счётчик пакетов для станции/бис. Вложенный словарь: станция, БИС"""

        self.bises_counter: BisesCounter = defaultdict(bises_factory)
        """Попакетные счётчики для станции/бис. Вложенный словарь: станция, бис, тип пакета"""

        self.nkas_counter: NkaCounter = defaultdict(nkas_factory)
        """Счётчик сообщений по конкретному НКА. Вложенный словарь: станция, бис, нка, тип пакета"""

        self.signals_counter: SignalCounter = defaultdict(signals_factory)
        """Счётчик сообщений по конкретному сигналу. Вложенный словарь: станция, бис, нка, сигнал, тип пакета"""

    def get_latest_packet_time(self, station: int, bis: int) -> Optional[datetime]:
        """Возвращает время любого последнего пакета для указанного БИС"""
        try:
            return self.general_counter[station][bis]['t']
        except KeyError:
            return None

    def get_latest_packet_time_for_packet_type(self, station: int, bis: int, packet_id: PacketID) -> Optional[datetime]:
        """Возвращает время последнего пакета указанного типа для указанного БИС"""
        try:
            return self.bises_counter[station][bis][packet_id]['t']
        except KeyError:
            return None

    def get_counter(self, station: int, bis_number: int, nka: int, signal_type: SignalTypes, packet_type: DIOrMeasPacketID) -> \
            Optional[TimedCounterDict]:
        """Возвращает словарь счетчика (кол-во и время последнего сообщения) для заданной комбинации параметров"""
        try:
            return self.signals_counter[station][bis_number][nka][signal_type][packet_type]
        except KeyError:
            return None

    def create_snapshot(self) -> BaseMessageCounter:
        """Создает экземпляр счетчиков с текущим состоянием signals_counter"""
        snapshot = self.__class__()
        snapshot.signals_counter = copy.deepcopy(self.signals_counter)
        return snapshot
