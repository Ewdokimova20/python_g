from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict

from typing_extensions import TypedDict

from global_data.appdata import SignalTypes, PacketID
from utils.lib.types.type_aliases import BisNum, NkaSysNum
from utils.signals.types import DIOrMeasPacketID


@dataclass
class TimedCounterDict(dict):
    """Словарь для хранения счетчиков пакетов и времени их поступления"""

    def __init__(self, *args: Any, **kwargs: Any):
        # Если аргументы не переданы, используем значения по умолчанию
        if not args and not kwargs:
            super().__init__(c=0, t=datetime.now())
        else:
            # В противном случае инициализируем как обычный словарь
            super().__init__(*args, **kwargs)

    # Можно добавить дополнительные методы, если необходимо
    def increment(self):
        """Увеличивает счетчик на 1"""
        self['c'] = self.get('c', 0) + 1
        self['t'] = datetime.now()


class ZMQMessageCounters(TypedDict):
    """Словарь для передачи состояния счетчиков пакетов через сокет"""
    general: Dict[BisNum, TimedCounterDict]
    bis_counter: Dict[BisNum, Dict[PacketID, TimedCounterDict]]
    nka_counter: Dict[BisNum, Dict[NkaSysNum, Dict[DIOrMeasPacketID, TimedCounterDict]]]
    signal_counter: Dict[BisNum, Dict[NkaSysNum, Dict[SignalTypes, Dict[DIOrMeasPacketID, TimedCounterDict]]]]
