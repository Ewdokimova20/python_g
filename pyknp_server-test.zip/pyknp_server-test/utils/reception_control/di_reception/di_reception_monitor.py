from peewee import ModelSelect

from models.bis import Bis
from models.current_angles import CurrentAngles
from models.di_reception_data import DIReceptionData
from utils.reception_control.common.base_reception_monitor import BaseReceptionMonitor
from utils.reception_control.di_reception.di_reception_types import DIReceptDataForClient
from utils.visibility.types import VisibilityStatus


class DIReceptionMonitor(BaseReceptionMonitor[DIReceptDataForClient]):
    def __init__(self):
        super().__init__(data_class=DIReceptDataForClient)

    def _get_db_query(self) -> ModelSelect:
        return (DIReceptionData
                .select(DIReceptionData, CurrentAngles.visibility_state)
                .join(Bis)
                .switch(DIReceptionData)
                .join(CurrentAngles, on=(DIReceptionData.nka == CurrentAngles.nka_id) &
                                        (Bis.station_id == CurrentAngles.station_id))
                .switch(DIReceptionData)
                .where(CurrentAngles.visibility_state > VisibilityStatus.OUT_OF_SIGHT))

    def _create_data_from_record(self, record: DIReceptionData) -> DIReceptDataForClient:
        return DIReceptDataForClient(
            reception_status=record.reception_status,
            is_zone_count_sufficient=record.is_zone_count_sufficient,
            has_too_many_errors=record.has_too_many_errors,
            timestamp=record.timestamp,
            actual_count=record.actual_count,
            zone_count=record.zone_count,
            error_count=record.error_count,
            expected_zone_count=record.expected_zone_count,
            visibility=record.currentangles.visibility_state if hasattr(record, 'currentangles') else None,
            last_update=record.last_update,
        )


di_reception_monitor = DIReceptionMonitor()
