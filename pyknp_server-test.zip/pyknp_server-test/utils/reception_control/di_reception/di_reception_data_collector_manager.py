from typing import Dict, TYPE_CHECKING

from models.bis import Bis
from utils.caches import cache_bis
from utils.reception_control.di_reception.di_reception_data_collector import DIReceptionDataCollector

if TYPE_CHECKING:
    from data import BaseDIString


class DIReceptionDataManager:
    """
    Класс ведет учет данных о состоянии приема строк ЦИ со всех НКА на всех БИС
    """

    def __init__(self):
        self.collectors: Dict[int, DIReceptionDataCollector] = {}
        all_bis = cache_bis.get_bis_list()
        for bis in all_bis:
            self.collectors[bis.id] = DIReceptionDataCollector(bis)

    def get_or_create_collector(self, bis: Bis) -> DIReceptionDataCollector:
        """
        Создать инстанс класса сбора данных о состоянии приема строк ЦИ для одного БИС
        """
        if bis.id not in self.collectors:
            self.collectors[bis.id] = DIReceptionDataCollector(bis)
        return self.collectors[bis.id]

    def collect_string(self, string: 'BaseDIString'):
        """
        Создать инстанс класса сбора данных о состоянии приема строк ЦИ для одного БИС
        """
        collector = self.get_or_create_collector(string.bis)
        collector.collect_string(string)

    def check_and_flush_to_db(self):
        """
        Сбросить все данные в ТЛБД по всем БИС, если пора
        """
        for collector in self.collectors.values():
            collector.check_and_flush_to_db()


# Использование:
di_reception_manager = DIReceptionDataManager()
