import logging
from collections import defaultdict
from datetime import timedelta, datetime
from typing import Optional, TYPE_CHECKING

from peewee import EXCLUDED

from global_data.appdata import SignalTypes, NKA_SIGNALS, BIS_PROTOCOL_START_TIME
from global_data.config_schema import config
from models.bis import Bis
from models.di_reception_data import DIReceptionData
from scripts.process_registry import get_current_visibility
from utils.reception_control.common.base_reception_data_collector import BaseReceptionDataCollector
from utils.reception_control.di_reception.di_reception_types import CollectedDIReceptData
from utils.signals.common import DI_SIGNAL_TYPES, DI_STRING_DURATIONS
from utils.visibility.types import VisibilityStatus

if TYPE_CHECKING:
    from data import BaseDIString

logger = logging.getLogger('di_reception_data_collector')


class DIReceptionDataCollector(BaseReceptionDataCollector[CollectedDIReceptData]):
    """
    Класс сбора данных о состоянии приема строк ЦИ со всех НКА у одного БИС
    """
    ACCEPTABLE_ERROR_LEVEL = config['measurement_reception_control']['di_acceptable_error_level']

    def __init__(self, bis: Bis):
        super().__init__(bis, data_class=CollectedDIReceptData, db_model=DIReceptionData)

    def _initialize_data_structure(self):
        """
        Инициализирует всю структуру данных для всех известных НКА и типов сигналов
        """
        for nka in NKA_SIGNALS:
            self.data[nka] = defaultdict(lambda: self.data_class())
            self.changes[nka] = defaultdict(lambda: self.data_class())
            self.latest_item_time[nka] = defaultdict(lambda: datetime.min)
            self.last_processed_time[nka] = defaultdict(lambda: datetime.min)
            # несмотря на то чо дефолтдикт, все равно прописываем явно ожидаемые ключи, потому что они обязательные
            for signal_type in NKA_SIGNALS[nka]:
                if signal_type in DI_SIGNAL_TYPES:
                    self.data[nka][signal_type] = self.data_class()
                    self.changes[nka][signal_type] = self.data_class()
                    self.latest_item_time[nka][signal_type] = datetime.min
                    self.last_processed_time[nka][signal_type] = datetime.min

        self.db_model.delete().execute()

    def _get_db_fields_to_update(self) -> dict:
        """
        Возвращает словарь полей для обновления в БД
        """
        return {
            self.db_model.reception_status: EXCLUDED.reception_status,
            self.db_model.is_zone_count_sufficient: EXCLUDED.is_zone_count_sufficient,
            self.db_model.zone_count: EXCLUDED.zone_count,
            self.db_model.last_update: EXCLUDED.last_update,
            self.db_model.expected_zone_count: EXCLUDED.expected_zone_count,
            self.db_model.timestamp: EXCLUDED.timestamp,
            self.db_model.actual_count: EXCLUDED.actual_count,
            self.db_model.error_count: EXCLUDED.error_count,
            self.db_model.has_too_many_errors: EXCLUDED.has_too_many_errors
        }

    @staticmethod
    def _calc_expected_zone_count(seconds_since_start: int, signal_type: SignalTypes) -> Optional[int]:
        """Рассчитать, сколько строк ЦИ должно было прийти за интервал времени с начала текущей зоны"""
        string_duration = DI_STRING_DURATIONS.get(signal_type)
        return seconds_since_start // string_duration if string_duration else None

    def _update_expected_zone_count(self):
        """
        Обновляет для каждой комбинации БИС-НКА-Тип сигнала в self.data и self.changes ожидаемое количество
        строк ЦИ в текущей ЗРВ, а также флаг is_zone_count_sufficient
        """
        current_time = (datetime.now() + timedelta(seconds=1)).replace(microsecond=0)

        with self._lock:
            for nka, signal_data in self.changes.items():
                # определяем, сколько секунд прошло с начала текущей зоны (требуемое кол-во)
                seconds_since_start, visibility_zone = self._get_seconds_since_zone_start(nka, current_time)
                if seconds_since_start is None:
                    continue

                # считаем флаг соответствия доли полученных строк ЦИ от требуемого кол-ва пороговому значению
                for signal_type in NKA_SIGNALS[nka]:
                    if signal_type not in DI_SIGNAL_TYPES:
                        continue
                    # определяем, сколько строк ЦИ должно было быть получено с начала текущей зоны (требуемое кол-во)
                    expected_zone_count = self._calc_expected_zone_count(seconds_since_start, signal_type=signal_type)
                    if expected_zone_count is not None and expected_zone_count != 0:
                        # если для этой пары нка-сигнал что-то уже есть в changes, то только в этом случае пишем
                        if signal_data[signal_type].model_dump(exclude_unset=True):
                            self._update_expected_zone_count_for_signal(nka, signal_type, expected_zone_count,
                                                                        visibility_zone)

    def update_error_count(self, nka: int, signal_type: int, timestamp: datetime, has_error: bool) -> Optional[int]:
        """Обновляет счетчик данных в ЗРВ"""
        # прибавляем error_count только если время привязки позже времени запуска СПО КНП
        if timestamp > BIS_PROTOCOL_START_TIME:
            current_visibility = get_current_visibility()
            if current_visibility.get_status(self.station_id, nka) >= VisibilityStatus.GUARANTEED:
                zone = self.visibility_zones.get_zone(nka)
                # прибавляем error_count только если время измерения лежит в ЗРВ
                if zone and (zone.zone_start <= timestamp <= zone.zone_end):
                    current_error_count = self.data[nka][signal_type].error_count or 0
                    return current_error_count + 1 if has_error else current_error_count
        return None

    def collect_string(self, string: 'BaseDIString'):
        """
        Обновляет данные об измерении в ТЛБД: время пакета, ПД, фактический счетчик измерений, счетчик измерений в ЗРВ
        """
        nka = string.nka_id
        timestamp = string.timestamp
        signal_type = string.signal_id
        has_error = string.error_in_string

        if nka not in NKA_SIGNALS:
            return

        with self._lock:
            current_actual_count = self.data[nka][signal_type].actual_count or 0
            actual_count = current_actual_count + 1
            zone_count = self.update_zone_count(nka, signal_type, timestamp)
            error_count = self.update_error_count(nka, signal_type, timestamp, has_error)

            update_data = self.data_class(
                actual_count=actual_count,
                zone_count=zone_count,
                error_count=error_count,
                timestamp=timestamp
            )
            if zone_count and zone_count != 0:
                update_data.has_too_many_errors = error_count / zone_count > self.ACCEPTABLE_ERROR_LEVEL

            self._update_data_and_changes(nka, signal_type, update_data)
            self.last_processed_time[nka][signal_type] = datetime.now()
            self.latest_item_time[nka][signal_type] = timestamp

    def _clear_changes(self):
        """Очищает словарь изменений"""
        with self._lock:
            self.changes.clear()
            for nka in NKA_SIGNALS:
                self.changes[nka] = defaultdict(lambda: self.data_class())
                for signal_type in NKA_SIGNALS[nka]:
                    if signal_type in DI_SIGNAL_TYPES:
                        self.changes[nka][signal_type] = self.data_class()
