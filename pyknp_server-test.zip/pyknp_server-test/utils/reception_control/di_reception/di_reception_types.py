from typing import Optional

from pydantic import Field

from utils.reception_control.common.common_types import BaseCollectedReceptData
from utils.visibility.types import VisibilityStatus


class CollectedDIReceptData(BaseCollectedReceptData):
    """
    Модель данных для состояния приема строк ЦИ для одной комбинации БИС/НКА/Тип сигнала при сборе информации
    """
    error_count: Optional[int] = Field(default=None)
    """Счетчик строк ЦИ c ошибкой"""
    has_too_many_errors: Optional[bool] = Field(default=None)
    """Флаг показывает, превышает ли доля строк ЦИ с ошибками установленный порог."""


class DIReceptDataForClient(CollectedDIReceptData):
    """
    Модель данных для состояния приема строк ЦИ для одной комбинации БИС/НКА/Тип сигнала при отдаче на клиент
    """
    visibility: Optional[VisibilityStatus] = Field(default=None)
    """Необязательное поле для хранения информации о видимости."""
