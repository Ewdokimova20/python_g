import copy
import logging
import threading
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import TypeVar, Generic, Dict, Type, Optional, Any, List, Tuple

from peewee import Model

from db.db_connection import db
from global_data.appdata import NKA_SIGNALS, BIS_PROTOCOL_START_TIME, SignalTypes
from global_data.config_schema import config
from models.bis import Bis
from scripts.process_registry import get_current_visibility
from utils.reception_control.common.common_types import BaseCollectedReceptData
from utils.reception_control.common.reception_status import ReceptionStatus
from utils.visibility.current_visibility_zones import CurrentVisibilityZoneCache, CurrentVisibilityZone
from utils.visibility.types import VisibilityStatus

T = TypeVar('T', bound=BaseCollectedReceptData)

logger = logging.getLogger('reception_data_collector')


class BaseReceptionDataCollector(Generic[T], ABC):
    """
    Базовый класс для сбора данных о состоянии приема
    """

    EXPIRED_DATA_CHECK_RATE = 30
    """Периодичность проверки необходимости почистить данные с прошедших сеансов видимости, мин"""
    EXPIRED_DATA_CHECK_DEPTH = 30
    """Глубина по времени для очистки данных с прошедших сеансов видимости, мин"""
    TLDB_UPDATE_RATE = 10
    """Периодичность записи накопленных данных о состоянии приема 1с измерений в ТЛБД, с"""

    SUFFICIENT_RATE = config['measurement_reception_control']['sufficient_rate_for_zone_meas_count']
    ACCEPTABLE_DELAY = config['measurement_reception_control']['meas_acceptable_delay']
    ACCEPTABLE_ABSENCE = config['measurement_reception_control']['meas_acceptable_absence']

    def __init__(self, bis: Bis, data_class: Type[T], db_model: Type[Model]):
        self.bis = bis
        """Объект БИС, для которого собираются данные состояния приема 1с по всем НКА"""
        self.data_class = data_class
        """Класс модели данных состояния приема"""
        self.db_model = db_model
        """Класс модели таблицы состояния приема в ТЛБД"""

        self.station_id = bis.station_id
        """ID Станции, на которой расопложен БИС"""
        self.data: Dict[int, Dict[int, T]] = {}
        """Актуальное состояние приема 1с измерений"""
        self.changes: Dict[int, Dict[int, T]] = {}
        """Словарь изменений актуального состояния для записи в ТЛБД с последнего self.last_db_update"""
        self.last_db_update = datetime.min
        """Время последней записи актуального состояния приема в ТЛБД"""
        self.visibility_zones = CurrentVisibilityZoneCache(bis.id)
        """Кэш ЗРВ для всех НКА"""
        self.latest_item_time: Dict[int, Dict[int, datetime]] = {}
        """Словарь для хранения времени последнего обработанного значения для каждой комбинации НКА-тип сигнала"""
        self.last_processed_time: Dict[int, Dict[int, datetime]] = {}
        """Словарь для хранения времени последней обработки значений для каждой комбинации НКА-тип сигнала"""
        self.last_expired_sessions_data_clear = datetime.now()
        """Время последней чистки данных прошедших сеансов видимости"""

        self._lock = threading.RLock()

        self._initialize_data_structure()

    @abstractmethod
    def _initialize_data_structure(self):
        """
        Инициализирует всю структуру данных для всех известных НКА и типов сигналов
        """
        pass

    @abstractmethod
    def _update_expected_zone_count(self):
        """
        Обновляет для каждой комбинации БИС-НКА-Тип сигнала в self.data и self.changes ожидаемое количество
        1с измерений/строк ЦИ в текущей ЗРВ, а также флаг is_zone_count_sufficient
        """
        pass

    @abstractmethod
    def _get_db_fields_to_update(self) -> Dict[str, Any]:
        """Возвращает словарь полей для обновления в БД"""
        pass

    @abstractmethod
    def _clear_changes(self) -> None:
        """Очищает словарь изменений. Переопределяется в наследниках"""
        pass

    def _update_expected_zone_count_for_signal(self, nka: int, signal_type: SignalTypes, expected_zone_count: int,
                                               visibility_zone: Optional[CurrentVisibilityZone]):
        """
        Определить флаг соответствия доли полученных 1с измерений/строк ЦИ от требуемого кол-ва пороговому значению
        is_zone_count_sufficient и обновить флаг и ожидаемое число строк ЦИ в self.data и self.changes
        """
        update_data = self.data_class(expected_zone_count=expected_zone_count)
        zone_count = self.data[nka][signal_type].zone_count or 0

        # костыль для того, чтобы zone_count никогда не превышали expected_zone_count, и процент <=100%
        if zone_count > expected_zone_count:
            zone_count = expected_zone_count
            update_data.zone_count = zone_count
            logger.debug(
                f'Сбор данных состояния приема {self.__class__.__name__} : для {self.bis}, {nka} и {signal_type} zone_count превысила expected_zone_count: {zone_count} из {expected_zone_count}')
            if visibility_zone:
                logger.debug(
                    f'Текущая ЗРВ: начало: {visibility_zone.zone_start}, конец: {visibility_zone.zone_end}')

        update_data.is_zone_count_sufficient = zone_count / expected_zone_count > self.SUFFICIENT_RATE
        self._update_data_and_changes(nka, signal_type, update_data)

    def _update_data_and_changes(self, nka: int, signal_type: int, update_data: T):
        """Обновляет данные в self.data и self.changes"""
        with self._lock:
            self.data[nka][signal_type] = self.data[nka][signal_type].model_copy(
                update=update_data.model_dump(exclude_unset=True))
            self.changes[nka][signal_type] = self.changes[nka][signal_type].model_copy(
                update=update_data.model_dump(exclude_unset=True))

    def _clear_expired_sessions_data(self):
        """Очищает данные с прошедших сеансов видимости"""
        current_time = datetime.now()
        with self._lock:
            if current_time - self.last_expired_sessions_data_clear > timedelta(minutes=self.EXPIRED_DATA_CHECK_RATE):
                for nka, all_signals_last_processed_at in self.last_processed_time.items():
                    for signal_type, last_processed_at in all_signals_last_processed_at.items():
                        if (current_time - last_processed_at) > timedelta(minutes=self.EXPIRED_DATA_CHECK_DEPTH):
                            self.data[nka][signal_type] = self.data_class()
                            self.db_model.delete().where(
                                self.db_model.nka == nka,
                                self.db_model.bis_id == self.bis.id,
                                self.db_model.signal_type == signal_type
                            ).execute()
                self.last_expired_sessions_data_clear = current_time

    def _get_seconds_since_zone_start(self, nka: int, current_time: datetime) -> Tuple[
        Optional[int], Optional[CurrentVisibilityZone]]:
        """Вычисляет количество секунд с начала текущей зоны"""
        seconds_count = None
        visibility_zone = None

        current_visibility = get_current_visibility()
        if current_visibility.get_status(self.station_id, nka) >= VisibilityStatus.GUARANTEED:
            visibility_zone = self.visibility_zones.get_zone(nka)
            if visibility_zone:
                if BIS_PROTOCOL_START_TIME > visibility_zone.zone_start:
                    # если текущая зона началась раньше запуска КНП, считаем от времени запуска
                    seconds_count = int((current_time - BIS_PROTOCOL_START_TIME).total_seconds())
                else:
                    # если текущая зона началась позже запуска КНП, считаем от начала зоны
                    seconds_count = int((current_time - visibility_zone.zone_start).total_seconds())

        return seconds_count, visibility_zone

    def _update_reception_status(self):
        """Обновляет статусы приема для всех комбинаций НКА-тип сигнала с текущей зоной видимости"""
        with self._lock:
            changes_copy = {nka: signals.copy() for nka, signals in self.changes.items()}
            last_processed_copy = {nka: times.copy() for nka, times in self.last_processed_time.items()}
            latest_item_copy = {nka: times.copy() for nka, times in self.latest_item_time.items()}

        current_time = datetime.now()

        for nka, all_signals_data in changes_copy.items():
            for signal_type in all_signals_data.keys():
                update_data = self.data_class()
                reception_status: ReceptionStatus = ReceptionStatus.UNDEFINED

                if signal_type not in NKA_SIGNALS.get(nka, []):
                    reception_status = ReceptionStatus.NOT_EXPECTED
                else:
                    last_processed_time = last_processed_copy[nka][signal_type]
                    time_since_last_processing = (current_time - last_processed_time).total_seconds()
                    is_absent = time_since_last_processing > self.ACCEPTABLE_ABSENCE

                    current_visibility = get_current_visibility()
                    if current_visibility.get_status(self.station_id, nka) >= VisibilityStatus.GUARANTEED:
                        if not is_absent:
                            latest_time = latest_item_copy[nka][signal_type]
                            time_since_last = (current_time - latest_time).total_seconds()
                            has_delay = time_since_last > self.ACCEPTABLE_DELAY
                            reception_status = (ReceptionStatus.EXPECTED_VISIBLE_PRESENT_WITH_DELAY
                                                if has_delay
                                                else ReceptionStatus.EXPECTED_VISIBLE_PRESENT_WITHOUT_DELAY)
                        else:
                            reception_status = ReceptionStatus.EXPECTED_VISIBLE_ABSENT
                    elif not is_absent:
                        reception_status = ReceptionStatus.EXPECTED_NOT_VISIBLE_PRESENT

                if reception_status == ReceptionStatus.UNDEFINED:
                    update_data.timestamp = None

                update_data.reception_status = reception_status

                # Обновляем данные под блокировкой, чтобы избежать конфликтов с collect_string
                with self._lock:
                    self._update_data_and_changes(nka, signal_type, update_data)

    def update_zone_count(self, nka: int, signal_type: int, timestamp: datetime) -> Optional[int]:
        """Обновляет счетчик данных в ЗРВ"""
        # прибавляем zone_count только если время привязки позже времени запуска СПО КНП
        if timestamp > BIS_PROTOCOL_START_TIME:
            current_visibility = get_current_visibility()
            if current_visibility.get_status(self.station_id, nka) >= VisibilityStatus.GUARANTEED:
                zone = self.visibility_zones.get_zone(nka)
                # прибавляем zone_count только если время измерения лежит в ЗРВ
                if zone and (zone.zone_start <= timestamp <= zone.zone_end):
                    current_zone_count = self.data[nka][signal_type].zone_count or 0
                    return current_zone_count + 1
        return None

    def _update_db(self):
        """Записывает изменения в ТЛБД"""
        current_datetime = datetime.now()
        rows_to_insert: List[Dict[str, Optional[Any]]] = []

        with self._lock:
            # Глубокая копия, чтобы избежать изменений во время итерации
            changes_snapshot = copy.deepcopy(self.changes)

        for nka, signals in changes_snapshot.items():
            for signal_type, data in signals.items():
                update_data: Dict[str, Optional[Any]] = {}
                if data.model_dump(exclude_defaults=True):  # если что-то помимо значений по умолчанию мы записали
                    update_data = data.model_dump()  # отдаем полную структуру,
                    # а не только обновившиеся поля, нужно для корректной работы insert_many
                if update_data:
                    update_data.update({
                        'last_update': current_datetime,
                        'bis': self.bis,
                        'nka': nka,
                        'signal_type': signal_type
                    })
                    rows_to_insert.append(update_data)

        if rows_to_insert:
            with db.atomic():
                try:
                    self.db_model.insert_many(rows_to_insert).on_conflict(
                        conflict_target=[
                            self.db_model.bis,
                            self.db_model.nka,
                            self.db_model.signal_type
                        ],
                        update=self._get_db_fields_to_update()
                    ).execute()
                except Exception as e:
                    logger.info(f"Ошибка при insert_many данных состояния приема: {str(e)}")

        self._clear_changes()

    def check_and_flush_to_db(self):
        """Проверяет необходимость записи в БД и выполняет её при необходимости"""
        current_time = datetime.now()
        self.visibility_zones.update_all_from_db(current_time)
        if (current_time - self.last_db_update).total_seconds() >= self.TLDB_UPDATE_RATE:
            self._update_reception_status()
            self._update_expected_zone_count()
            self._update_db()
            self._clear_expired_sessions_data()
            self.last_db_update = current_time
