from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Generic, Type, Any

from peewee import ModelSelect

from utils.reception_control.common.reception_data import ReceptionData, T


class BaseReceptionMonitor(Generic[T], ABC):
    UPDATE_RATE_FROM_TLDB = 5
    """Частота загрузки данных состояния приема из ТЛБД"""

    def __init__(self, data_class: Type[T]):
        """
        :param data_class: Класс данных (DIReceptDataForClient или MeasReceptDataForClient)
        """
        self.data_class = data_class
        self.reception_data = ReceptionData(data_class=data_class)
        self.last_db_update = datetime.now()

    @abstractmethod
    def _get_db_query(self) -> ModelSelect:
        """Возвращает запрос к БД для получения данных"""
        pass

    def _create_empty_data(self) -> T:
        """Создает пустой объект данных"""
        return self.data_class()

    @abstractmethod
    def _create_data_from_record(self, record: Any) -> T:
        """
        Создает объект данных из записи БД
        :param record: Запись из БД
        :return: Объект данных соответствующего типа
        """
        pass

    def _load_data_from_db(self):
        """Загружает данные о состоянии приема из ТЛБД"""
        records = self._get_db_query()
        bis_nka_signal_combinations = set()

        # Заполняем данными, подгруженными из ТЛБД
        for record in records:
            self._update_monitoring_data(record)
            bis_nka_signal_combinations.add((
                record.bis_id,
                record.nka,
                record.signal_type
            ))

        # Инициализируем пустыми данными элементы словаря
        for bis_id in self.reception_data.root.keys():
            for nka in self.reception_data.root[bis_id].root.keys():
                for signal_type in self.reception_data.root[bis_id].root[nka].root.keys():
                    if (bis_id, nka, signal_type) not in bis_nka_signal_combinations:
                        self.reception_data.root[bis_id].root[nka].root[signal_type] = self._create_empty_data()

    def _update_monitoring_data(self, record: Any):
        """
        Обновляет данные мониторинга для конкретной записи
        :param record: Запись из БД
        """
        bis_id = record.bis_id
        nka = record.nka
        signal_type = record.signal_type

        # Проверяем, существуют ли переданные значения в нашей структуре
        if bis_id not in self.reception_data.root:
            return
        if nka not in self.reception_data.root[bis_id].root:
            return

        # Если все проверки пройдены, обновляем данные
        self.reception_data.root[bis_id].root[nka].root[signal_type] = self._create_data_from_record(record)

    def update_from_db(self, current_time: datetime):
        """Обновить словарь из ТЛБД"""
        if current_time - self.last_db_update >= timedelta(seconds=self.UPDATE_RATE_FROM_TLDB):
            self._load_data_from_db()
            self.last_db_update = current_time

    def get_single_bis_data(self, bis_id: int) -> str:
        """
        Получить данные состояния приема по одному БИС
        :param bis_id: ID БИС
        :return: JSON строка с данными
        """
        bis_data = self.reception_data.root.get(bis_id)
        if bis_data:
            return bis_data.model_dump_json(exclude_unset=True)
        return "{}"

    def get_all_bis_data(self) -> dict:
        """
        Получить данные состояния приема по всем БИС
        :return: JSON строка с данными
        """
        return self.reception_data.model_dump_filtered(include_fields={"reception_status",
                                                                       "is_zone_count_sufficient",
                                                                       "has_too_many_errors"})
