from enum import IntEnum


class ReceptionStatus(IntEnum):
    """Статус приема для строк ЦИ / 1с имзерений"""
    UNDEFINED = 0
    """Не определено"""
    EXPECTED_VISIBLE_ABSENT = 1
    """Ожидаемый сигнал, НКА в ЗРВ, измерения отсутствуют"""
    EXPECTED_VISIBLE_PRESENT_WITH_DELAY = 2
    """Ожидаемый сигнал, НКА в ЗРВ, измерения идут с задержкой"""
    EXPECTED_VISIBLE_PRESENT_WITHOUT_DELAY = 3
    """Ожидаемый сигнал, НКА в ЗРВ, измерения идут без задержки"""
    EXPECTED_NOT_VISIBLE_PRESENT = 4
    """Ожидаемый сигнал, НКА не в ЗРВ, измерения идут"""
    NOT_EXPECTED = 5
    """Неожидаемый сигнал"""
