from collections import defaultdict
from typing import TypeVar, Generic, Dict, Type, Optional

from pydantic import RootModel, BaseModel

from global_data.appdata import NKA_SIGNALS
from utils.caches import cache_bis
from utils.reception_control.di_reception.di_reception_types import DIReceptDataForClient
from utils.reception_control.measurement_reception.meas_reception_types import MeasReceptDataForClient

T = TypeVar('T', MeasReceptDataForClient, DIReceptDataForClient)


class NkaData(RootModel[Dict[int, T]], Generic[T]):
    """
    Модель данных о состоянии приема для одной комбинации БИС/НКА
    """

    def __init__(self, data_class: Type[T], **data):
        super().__init__(defaultdict(data_class))


# Обобщенная версия BisData
class BisData(RootModel[Dict[int, NkaData[T]]], Generic[T]):
    """
    Модель данных о состоянии приема для одного БИС
    """

    def __init__(self, data_class: Type[T], **data):
        super().__init__({})
        # Инициализируем данные для каждого НКА
        for nka in NKA_SIGNALS.keys():
            self.root[nka] = NkaData(data_class=data_class)


# Обобщенная версия ReceptionData
class ReceptionData(RootModel[Dict[int, BisData[T]]], Generic[T]):
    """
    Модель данных о состоянии приема
    """

    def __init__(self, data_class: Type[T], **data):
        super().__init__({})
        # Инициализируем данные для каждого БИС
        all_bis = cache_bis.get_bis_list()
        for bis in all_bis:
            self.root[bis.id] = BisData[T](data_class=data_class)

    def model_dump_filtered(self, include_fields: Optional[set] = None):
        """
        Метод для выборочного исключения полей и удаления пустых словарей.
        :param include_fields: Набор полей, которые нужно оставить.
        :return: Словарь с отфильтрованными данными без пустых словарей.
        """

        def filter_data(data: dict):
            """
            Фильтруем только указанные поля и сокращаем ключи по первым буквам слов.
            :param data: Словарь с данными для фильтрации.
            :return: Отфильтрованный и сокращенный словарь.
            """

            def reduce_key(key: str) -> str:
                # Разбиваем ключ по символу "_" и берем первые буквы каждого слова
                return ''.join(word[0] for word in key.split('_') if word)

            if not include_fields:
                # Если include_fields не задан, возвращаем данные как есть
                return {reduce_key(key): value for key, value in data.items()}

            # Фильтруем только указанные поля и сокращаем ключи
            return {reduce_key(key): value for key, value in data.items() if key in include_fields}

        # Рекурсивно обходим вложенные структуры
        def recursive_filter(data):
            if isinstance(data, dict):
                # Если это словарь, фильтруем его рекурсивно
                filtered = {k: recursive_filter(v) for k, v in data.items()}
                # Удаляем пустые словари
                return {k: v for k, v in filtered.items() if v not in (None, {}, [], set())}
            elif isinstance(data, RootModel):
                # Если это RootModel, обрабатываем его root
                return recursive_filter(data.root)
            elif isinstance(data, BaseModel):
                # Если это Pydantic модель, фильтруем ее поля
                return filter_data(data.model_dump(exclude_unset=True))
            elif isinstance(data, list):
                # Если это список, обрабатываем каждый элемент
                filtered_list = [recursive_filter(v) for v in data]
                # Удаляем пустые элементы списка
                return [v for v in filtered_list if v not in (None, {}, [], set())]
            else:
                # Если это примитивный тип, возвращаем его как есть
                return data

        # Применяем фильтрацию к корневым данным модели
        return recursive_filter(self.root)
