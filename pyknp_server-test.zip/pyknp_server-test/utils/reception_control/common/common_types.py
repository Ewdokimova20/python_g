from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from utils.reception_control.common.reception_status import ReceptionStatus


class BaseCollectedReceptData(BaseModel):
    """
    Базовый класс для моделей данных о состоянии приема 1с измерений и ЦИ
    """
    reception_status: Optional[ReceptionStatus] = Field(default=ReceptionStatus.UNDEFINED)
    """Состояние приема"""
    is_zone_count_sufficient: Optional[bool] = Field(default=None)
    """Флаг показывает, превышает ли процент строк ЦИ/измерений в ЗРВ от их общего количества установленный порог."""
    actual_count: Optional[int] = Field(default=None)
    """Счетчик фактически полученных 1с измерений / строк ЦИ"""
    zone_count: Optional[int] = Field(default=None)
    """Счетчик 1с измерений / строк ЦИ, полученных в гарантированной ЗРВ"""
    expected_zone_count: Optional[int] = Field(default=None)
    """Требуемое количество 1с измерений / строк ЦИ"""
    timestamp: Optional[datetime] = Field(default=None)
    """Время привязки последнего полученного 1с измерения / строки ЦИ"""
    last_update: Optional[datetime] = Field(default=None)
    """Время последнего обновления в БД"""
