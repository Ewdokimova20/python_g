import datetime
import logging
from collections import defaultdict
from typing import Union

import utils.signals.CD.L1OC
import utils.signals.CD.L1SC_L2SC
import utils.signals.CD.L3OC
import utils.signals.FD.L1SF
from data import L1OFFrame, L2OFFrame, L1SFFrame, L3OCFrame, CDSignalFrame, \
    L2SCFrame, L1SCFrame, L1OCFrame
from global_data.appdata import BAD_FRAME_TK, SIGNALS_NAME
from global_data.config_schema import config
from models.bis import Bis
from models.nka import Nka
from models.op_message import KNPOpMessage
from scripts.process_registry.registry_getters import get_signal_flags_aggregator
from utils.lib.get_date_from_N4_and_N import get_date_from_N4_and_N
from utils.signals.FD.L1OF import frame_seq_from_tk, frame_num_from_tk, seconds_from_tk

logger = logging.getLogger('composer')

FRAME_TIME_THRESHOLD = 1
"""Допустимый порог отличия времени строки от границ привязки кадра, с"""

MAX_INCOMPLETE_FRAMES = 3
"""Допустимое число незакрытых кадров в обработке"""

INCOMPLETE_FRAME_HOLD_TIME = 45
"""Длительность хранения незавершённых кадров относительно текущего времени пакета, в котором поступила строка, с"""


class IncompleteFrame:
    """Класс описывает незавершённый кадр/псевдокадр, в который собирают строки"""

    frame_time_start_s: float = None
    """Предполагаемое начало кадра в шкале поступающих пакетов.
    Или начало псевдокадра в шкале сигнала с кодовым разделением"""

    frame_time_end_s: float = None
    """Предполагаемый конец кадра в шкале поступающих пакетов.
    Или конец псевдокадра в шкале сигнала с кодовым разделением"""

    strings_count: int = None
    """"Число строк в буфере строк"""

    immediate_strings_count: int = None
    """Счётчик оперативных строк в буфере"""

    motherstring_n: int = None
    """Номер строки, породившей буфер"""

    motherstring_time_s: float = None
    """Время из пакета со строкой, породившей буфер.
    Или ОМВ строки, породившей буфер, для сигнала с кодовым разделением"""

    buffer = {}
    """Буфер строк. Если сигнал с частотным разделением, то в буфере для каждого номер лежит отдна строка.
    Если сигнал с кодовым разделением, то в буфере для типов строк с оперативной информацией лежит по одной строке,
    а для остальных типов строк - по списку"""

    def __init__(self):
        """"При инициализации буфер пуст, времена нулевые"""
        self.buffer = {}
        self.strings_count = 0
        self.immediate_strings_count = 0

    def append(self, string):
        """Функция добавляет строку для данного номера (типа) строки в буфере"""
        self.buffer[string.string_num] = string
        self.strings_count += 1

    def append_to_list(self, string):
        """Функция добавляет строку в список для данного номера (типа) строки в буфере"""
        if string.string_num in self.buffer:
            self.buffer[string.string_num].append(string)
        else:
            self.buffer[string.string_num] = [string]
        self.strings_count += 1

    def append_other_to_list(self, string):
        """Функция добавляет строку в список строк с номером, которого нет в ИКД"""
        if "other" in self.buffer:
            self.buffer["other"].append(string)
        else:
            self.buffer["other"] = [string]
        self.strings_count += 1

    def get_strings_buffer(self, strings_num_list: list):
        """Функция возвращает словарь с заданными номерами (типами) строк.
        На вход получает список номеров (типов) строк"""
        mini_buffer = {}
        for string_num in strings_num_list:
            mini_buffer[string_num] = self.buffer.get(string_num, None)
        return mini_buffer


def create_op_message_for_control_tk(bis: Bis, nka: Nka, signal_type, control_tk):
    """ Создать оперативное сообщение при несоответствии tk """
    if config['write_instance_to_ldb']['knpopmessage'] == 'yes':
        # Если в конфиге включена запись оперативных в ЛБД, то пишем
        new_op_message = KNPOpMessage.create(bis=bis,
                                             nka=nka,
                                             timestamp=datetime.datetime.now(),
                                             letter=-1,
                                             signal_type=signal_type,
                                             snr=0,
                                             not_in_sight=0,
                                             excess_of_residual=0,
                                             excess_of_pseudorange_difference=0,
                                             excess_of_navsolution_error=0,
                                             ground_control_call=0,
                                             unreliable_frame=0,
                                             unreliable_signal=0,
                                             unreliable_digital_info=0,
                                             tk_inconsistency=control_tk,
                                             tb_inconsistency=0)
    else:
        # Если нет, то создаем объект, но в ЛБД не пишем
        new_op_message = KNPOpMessage(bis=bis,
                                      nka=nka,
                                      timestamp=datetime.datetime.now(),
                                      letter=-1,
                                      signal_type=signal_type,
                                      snr=0,
                                      not_in_sight=0,
                                      excess_of_residual=0,
                                      excess_of_pseudorange_difference=0,
                                      excess_of_navsolution_error=0,
                                      ground_control_call=0,
                                      unreliable_frame=0,
                                      unreliable_signal=0,
                                      unreliable_digital_info=0,
                                      tk_inconsistency=control_tk,
                                      tb_inconsistency=0)
    signal_flags_aggregator = get_signal_flags_aggregator()
    signal_flags_aggregator.add_operative_message(new_op_message)


def create_op_message_for_control_tb(bis: Bis, nka: Nka, signal_type, control_tb):
    """ Создать оперативное сообщение при несоответствии tb """
    if config['write_instance_to_ldb']['knpopmessage'] == 'yes':
        # Если в конфиге включена запись оперативных в ЛБД, то пишем
        new_op_message = KNPOpMessage.create(bis=bis,
                                             nka=nka,
                                             timestamp=datetime.datetime.now(),
                                             letter=-1,
                                             signal_type=signal_type,
                                             snr=0,
                                             not_in_sight=0,
                                             excess_of_residual=0,
                                             excess_of_pseudorange_difference=0,
                                             excess_of_navsolution_error=0,
                                             ground_control_call=0,
                                             unreliable_frame=0,
                                             unreliable_signal=0,
                                             unreliable_digital_info=0,
                                             tk_inconsistency=0,
                                             tb_inconsistency=control_tb)
    else:
        # Если нет, то создаем объект, но в ЛБД не пишем
        new_op_message = KNPOpMessage(bis=bis,
                                      nka=nka,
                                      timestamp=datetime.datetime.now(),
                                      letter=-1,
                                      signal_type=signal_type,
                                      snr=0,
                                      not_in_sight=0,
                                      excess_of_residual=0,
                                      excess_of_pseudorange_difference=0,
                                      excess_of_navsolution_error=0,
                                      ground_control_call=0,
                                      unreliable_frame=0,
                                      unreliable_signal=0,
                                      unreliable_digital_info=0,
                                      tk_inconsistency=0,
                                      tb_inconsistency=control_tb)
    signal_flags_aggregator = get_signal_flags_aggregator()
    signal_flags_aggregator.add_operative_message(new_op_message)


class OneFDSignalFrameComposer:
    """Класс сборки кадра из поступающих строк для сигналов с частотным разделением.
     Обеспечивает проверку времени привязки строки по ШВ из пакета."""

    string_in_frame = None
    """"Количество строк в кадре"""

    string_duration = None
    """Продолжительность одной строки, с"""

    inc_frames = []
    """Список незавершённых (незакрытых) кадров"""

    immediate_strings = []
    """Список номеров строк с оперативной информацией.
    Заполняется в классе-наследнике"""

    immediate_strings_total = None
    """Общее нормативное число строк с оперативной информацией в кадре.
    Заполняется в классе-наследнике"""

    def __init__(self):
        """Конструктор инициализирует список незакрытых кадров"""
        self.inc_frames = []

    def append(self, string) -> (Union[None, dict], []):
        """При добавлении строки в незаврешённый кадр проверяется соответствие времени строки
        Если строка ничему не соответствует, то создаём для неё новый незавершённый кадр

        Возвращает словарь {номер_строки: строка} для собранного кадра
        """
        is_in_frame = False
        inc_frames_len = len(self.inc_frames)
        string_time_s = string.timestamp.timestamp()
        immediate_buf = None  # буфер строк с оперативной информацией
        complete_frames = []
        for i in range(inc_frames_len):
            # Проверяем, подходит ли строка в текущий буфер с учётом её номера. Если номер строки меньше номера строки,
            # породившей буфер, то проверяем интервал от начала буфера до времени породившей строки.
            # Если номер строки больше, то проверяем интервал до конца буфера. Такой подход позволяет исключить
            # попадание строк из конца и начала соседних кадров в буфер
            if ((string.string_num < self.inc_frames[i].motherstring_n) and
                (string_time_s >= self.inc_frames[i].frame_time_start_s - FRAME_TIME_THRESHOLD) and
                (string_time_s <= self.inc_frames[i].motherstring_time_s + FRAME_TIME_THRESHOLD)) or \
                    ((string.string_num > self.inc_frames[i].motherstring_n) and
                     (string_time_s >= self.inc_frames[i].motherstring_time_s - FRAME_TIME_THRESHOLD) and
                     (string_time_s <= self.inc_frames[i].frame_time_end_s + FRAME_TIME_THRESHOLD)):
                # Строка подошла по времени. Пристраиваем её в незавершённый кадр
                self.inc_frames[i].append(string)
                is_in_frame = True
                # TODO когда будет выполняться issue # 166, добавление оперативных строк надо делать в методе класса добавления строки
                if string.string_num in self.immediate_strings:
                    # Если строка относится к оперативным, то проверяем, есть ли все оперативные строки.
                    # Если все, то собираем их отдельно и отдаём для сборки оперативной информации
                    self.inc_frames[i].immediate_strings_count += 1
                    if self.inc_frames[i].immediate_strings_count >= self.immediate_strings_total:
                        # TODO стоит унифицировать со сборщиком кадрок кодовых сигналов и выдавать кадры
                        immediate_buf = self.inc_frames[i].get_strings_buffer(self.immediate_strings)

                if self.inc_frames[i].strings_count >= self.string_in_frame:
                    # Если число строк в открытом кадре соответствует требуемому, то пишем кадр в базу
                    frame = self.inc_frames.pop(i)
                    complete_frames.append(self._write_frame_to_db(frame))
                    # При записи нового кадра заодно проверяем, а не остались ли ещё у нас "старички", от которых
                    # следует избавиться
                    if len(self.inc_frames) > 0:
                        self.close_old_incomplete_frames(string_time_s)
                break

        # Если строку не пристроили, то создаём для неё новый незавершённый кадр.
        # Если таких кадров становится больше допустимого, то закрываем старый
        if not is_in_frame:
            if inc_frames_len >= MAX_INCOMPLETE_FRAMES:
                frame = self.inc_frames.pop(len(self.inc_frames) - 1)
                complete_frames.append(self._write_frame_to_db(frame))

            new_frame = IncompleteFrame()
            new_frame.append(string)
            new_frame.motherstring_n = string.string_num
            new_frame.motherstring_time_s = string_time_s
            new_frame.frame_time_start_s = string_time_s - (string.string_num - 1) * self.string_duration
            new_frame.frame_time_end_s = string_time_s + (self.string_in_frame - string.string_num + 1) * \
                                         self.string_duration
            # TODO когда будет выполняться issue # 166, добавление оперативных строк надо делать в методе класса добавления строки
            if string.string_num in self.immediate_strings:
                # Если строка относится к оперативным, то увеличиваем число оперативных строк в буфере
                new_frame.immediate_strings_count += 1
            self.inc_frames.insert(0, new_frame)
        return immediate_buf

    def close_old_incomplete_frames(self, cur_string_time_s: float):
        """Функция осуществляет закрытие существующих буферов, если они устарели по отношению ко времени текущей строки
        в шкале времени пакетов"""
        i = 0
        while i < len(self.inc_frames):
            if cur_string_time_s - self.inc_frames[i].frame_time_start_s > INCOMPLETE_FRAME_HOLD_TIME:
                frame = self.inc_frames.pop(i)
                self._write_frame_to_db(frame)
            i += 1

    def _write_frame_to_db(self, frame: IncompleteFrame) -> Union[L1OFFrame, L2OFFrame]:
        """Витруальная функция записи кадра в базу. Реализуют наследнички"""
        pass


class OneOFSignalFrameComposer(OneFDSignalFrameComposer):
    """Общий класс-предок сборки кадра строк L1OF и L2OF"""

    string_in_frame = 15
    """"Количество строк в кадре"""

    string_duration = 2
    """Продолжительность одной строки, с"""

    frame_type = None
    """"Класс типа кадра, для которого осуществляется сборка кадров"""

    immediate_strings = [1, 2, 3, 4, 5]
    """Список номеров строк с оперативной информацией."""

    immediate_strings_total = len(immediate_strings)

    def __init__(self, frame_type):
        super().__init__()
        self.frame_type = frame_type

    def _write_frame_to_db(self, frame: IncompleteFrame) -> Union[L1OFFrame, L2OFFrame]:
        """Функция записи строки в ЛБД"""
        # При наличии первой строки параметры берем из неё.
        # Если нет - то заполняем невозможными значениями и берём из существющих строк
        nka = None
        bis = None
        if (1 in frame.buffer) and (4 in frame.buffer) and (5 in frame.buffer):
            t_k = frame.buffer[1].content[0]['tk']
            seq = frame_seq_from_tk(t_k)
            num = frame_num_from_tk(t_k)
            time = seconds_from_tk(t_k)
            nka = frame.buffer[1].nka
            bis = frame.buffer[1].bis
            NT = frame.buffer[4].content[0]['Nt']
            N4 = frame.buffer[5].content[0]['N4']
            timestamp = get_date_from_N4_and_N(NT, N4) + datetime.timedelta(seconds=seconds_from_tk(t_k))
            is_fifth = True if frame_num_from_tk(t_k) == 5 else False
        else:
            t_k = BAD_FRAME_TK
            seq = 0
            num = 0
            time = 0
            is_fifth = False
            timestamp = datetime.datetime.fromtimestamp(frame.frame_time_start_s)
            # Вытаскиваем параметры из первой попавшейся строки в буфере
            for i in iter(frame.buffer):
                nka = frame.buffer[i].nka
                bis = frame.buffer[i].bis
                break

        is_complete = True if len(frame.buffer) == self.string_in_frame else False
        frame_written_to_ldb = self.frame_type.create(nka=nka,
                                                      bis=bis,
                                                      tk=t_k,
                                                      seq=seq,
                                                      num=num,
                                                      time=time,
                                                      is_fifth=is_fifth,
                                                      is_complete=is_complete,
                                                      string1=frame.buffer.get(1, None),
                                                      string2=frame.buffer.get(2, None),
                                                      string3=frame.buffer.get(3, None),
                                                      string4=frame.buffer.get(4, None),
                                                      string5=frame.buffer.get(5, None),
                                                      string6=frame.buffer.get(6, None),
                                                      string7=frame.buffer.get(7, None),
                                                      string8=frame.buffer.get(8, None),
                                                      string9=frame.buffer.get(9, None),
                                                      string10=frame.buffer.get(10, None),
                                                      string11=frame.buffer.get(11, None),
                                                      string12=frame.buffer.get(12, None),
                                                      string13=frame.buffer.get(13, None),
                                                      string14=frame.buffer.get(14, None),
                                                      string15=frame.buffer.get(15, None),
                                                      timestamp=timestamp)
        if frame_written_to_ldb.tk != BAD_FRAME_TK:
            if is_complete:
                control_tk = frame_written_to_ldb.control_tk()
                if control_tk:
                    create_op_message_for_control_tk(bis=bis, nka=nka, signal_type=frame_written_to_ldb.signal_type,
                                                     control_tk=control_tk)
                control_tb = frame_written_to_ldb.control_tb()
                if control_tb:
                    create_op_message_for_control_tb(bis=bis, nka=nka, signal_type=frame_written_to_ldb.signal_type,
                                                     control_tb=control_tb)
        return frame_written_to_ldb


class OneL1OFSignalFrameComposer(OneOFSignalFrameComposer):
    """Класс сборки кадров для сигналов L1OF
    Необходим, поскольку при создании массива сборщиков с defaultdict конструктор должен быть без параметров
    """

    def __init__(self):
        super().__init__(L1OFFrame)


class OneL2OFSignalFrameComposer(OneOFSignalFrameComposer):
    """Класс сборки кадров для сигналов L2OF
    Необходим, поскольку при создании массива сборщиков с defaultdict конструктор должен быть без параметров
    """

    def __init__(self):
        super().__init__(L2OFFrame)


class OneL1SFSignalFrameComposer(OneFDSignalFrameComposer):
    """Класс сборки кадра строк L1SF"""

    string_in_frame = 10
    """"Количество строк в кадре"""

    string_duration = 1
    """Продолжительность одной строки, с"""

    frame_type = L1SFFrame
    """"Класс типа кадра, для которого осуществляется сборка кадров"""

    immediate_strings = [1, 2, 3, 4, 5, 6, 7, 10]
    """Список номеров строк с оперативной информацией."""

    immediate_strings_total = len(immediate_strings)

    def __init__(self):
        super().__init__()

    def _write_frame_to_db(self, frame: IncompleteFrame) -> L1SFFrame:
        """Функция записи строки в ЛБД"""
        # При наличии первой строки параметры берем из неё.
        # Если нет - то заполняем невозможными значениями и берём из существующих строк
        nka = None
        bis = None
        if (1 in frame.buffer) and (10 in frame.buffer):
            t_k = frame.buffer[1].content[0]['tk']
            seq = utils.signals.FD.L1SF.frame_seq_from_tk(t_k)
            num = utils.signals.FD.L1SF.frame_num_from_tk(t_k)
            time = utils.signals.FD.L1SF.seconds_from_tk(t_k)
            nka = frame.buffer[1].nka
            bis = frame.buffer[1].bis
            NT = frame.buffer[10].content[0]['Nt']
            N4 = frame.buffer[10].content[0]['N4']
            timestamp = get_date_from_N4_and_N(NT, N4) + datetime.timedelta(seconds=utils.signals.FD.L1SF.seconds_from_tk(t_k))
        else:
            t_k = BAD_FRAME_TK
            seq = 0
            num = 0
            time = 0
            timestamp = datetime.datetime.fromtimestamp(frame.frame_time_start_s)
            # Вытаскиваем параметры из первой попавшейся строки в буфере
            for i in iter(frame.buffer):
                nka = frame.buffer[i].nka
                bis = frame.buffer[i].bis
                break

        is_complete = True if len(frame.buffer) == self.string_in_frame else False
        frame_written_to_ldb = self.frame_type.create(nka=nka,
                                                      bis=bis,
                                                      tk=t_k,
                                                      seq=seq,
                                                      num=num,
                                                      time=time,
                                                      is_complete=is_complete,
                                                      string1=frame.buffer.get(1, None),
                                                      string2=frame.buffer.get(2, None),
                                                      string3=frame.buffer.get(3, None),
                                                      string4=frame.buffer.get(4, None),
                                                      string5=frame.buffer.get(5, None),
                                                      string6=frame.buffer.get(6, None),
                                                      string7=frame.buffer.get(7, None),
                                                      string8=frame.buffer.get(8, None),
                                                      string9=frame.buffer.get(9, None),
                                                      string10=frame.buffer.get(10, None),
                                                      timestamp=timestamp)
        if frame_written_to_ldb.tk != BAD_FRAME_TK:
            if is_complete:
                control_tk = frame_written_to_ldb.control_tk()
                if control_tk:
                    create_op_message_for_control_tk(bis=bis, nka=nka, signal_type=frame_written_to_ldb.signal_type,
                                                     control_tk=control_tk)
                control_tb = frame_written_to_ldb.control_tb()
                if control_tb:
                    create_op_message_for_control_tb(bis=bis, nka=nka, signal_type=frame_written_to_ldb.signal_type,
                                                     control_tb=control_tb)
        return frame_written_to_ldb


class CDSignalPseudoframeComposer:
    """Класс сборки псевдокадра из поступающих строк для сигналов с кодовым разделением.
     Обеспечивает проверку времени привязки строки по ОМВ  из строки ЦИ."""

    string_duration = None
    """Продолжительность одной строки, с
    Должно быть определено значение по умолчанию в классе-наследнике"""

    pseudoframe_length = None
    """Количество строк в псевдокадре
    Должно быть определено значение по умолчанию в классе-наследнике"""

    pseudoframe_duration = None
    """Длительность псевдокадра, с
    Должно быть определено значение по умолчанию в классе-наследнике"""

    pseudoframe_type = None
    """Класс типа псевдокадра, для которого осуществляется сборка"""

    homeless_strings = []
    """Список строк, для которых не нашелся соответствующий псевдокадр"""

    open_pseudoframes = []
    """Список незавершённых (незакрытых) псевдокадров"""

    immediate_strings = None
    """Список строк с оперативной информацией, которые открывают псевдокадр.
    Должно быть определено значение по умолчанию в классе-наследнике"""

    nonimmediate_strings_in_ICD = None
    """Остальные типы строк, объявленные в ИКД.
    Должны быть определены в классе-наследнике"""

    def __init__(self):
        self.open_pseudoframes = []

    def append(self, string_cd) -> []:
        """Функция добавления строки в псевдокадр
        Возвращает набор кадров, для которых завершена сборка и нет надежды что-то добавить."""

        self.set_pseudoframe_length(string_cd)
        is_in_frame = False
        immediate_buf = []  # хранилище выдаваемых кадров
        for psfr in self.open_pseudoframes:
            """Проверяем, попадает ли строка в существующие открытые псевдокадры.
            Если псевдокадр с известным началом и концом, то всё проверяется просто.
            Если и начало не известно, то используем полдлины псевдокадра.
            Строки с оперативной информацией в неопознанные псевдокадры не записываем"""
            if psfr.frame_time_start_s and psfr.frame_time_end_s:
                if (string_cd.string_time >= psfr.frame_time_start_s) and \
                        (string_cd.string_time < psfr.frame_time_end_s):
                    # Если строка с оперативной информацией, пишем в буфер непосредственно.
                    # Если другой тип строки, то пишем в список для данного типа строки.
                    # Если данный тип строки ещё в буфер не добавлялся, то создаём список и добавляем в список.
                    if string_cd.string_num in self.immediate_strings:
                        psfr.append(string_cd)
                    elif string_cd.string_num in self.nonimmediate_strings_in_ICD:
                        psfr.append_to_list(string_cd)
                    else:
                        psfr.append_other_to_list(string_cd)
                    is_in_frame = True
            else:
                # Если буфер без времени начала и конца и строка не относится к оперативной информации,
                # то пишем её в буфер, если она подоходит по времени относительно строки, породившей буфер.
                if (string_cd.string_num not in self.immediate_strings) and \
                        ((string_cd.string_time <= psfr.motherstring_time_s + self.pseudoframe_duration // 2) or
                         (string_cd.string_time >= psfr.motherstring_time_s - self.pseudoframe_duration // 2)):
                    if string_cd.string_num in self.nonimmediate_strings_in_ICD:
                        psfr.append_to_list(string_cd)
                    else:
                        psfr.append_other_to_list(string_cd)
                    is_in_frame = True

            if is_in_frame:
                """Если строку пристроили, то проверяем, а вдруг буфер можно записать в базу"""
                if psfr.strings_count >= self.pseudoframe_length:
                    frame = self.open_pseudoframes.pop(self.open_pseudoframes.index(psfr))
                    """Раз кадр полон и записан в ЛБД, то выдаем его как готовый наружу для декодировки"""
                    current_frame = self._write_frame_to_db(frame)
                    if current_frame:
                        immediate_buf.append(current_frame)
                    # При записи нового кадра заодно проверяем, а не остались ли ещё у нас "старички", от которых
                    # следует избавиться
                    if len(self.open_pseudoframes) > 0:
                        self.close_old_incomplete_frames(string_cd.string_time)
                break

        # Если строку не пристроили, то создаём для неё новый незавершённый кадр.
        # Если таких кадров становится больше допустимого, то закрываем старый
        if not is_in_frame:
            if len(self.open_pseudoframes) >= MAX_INCOMPLETE_FRAMES:
                frame = self.open_pseudoframes.pop(len(self.open_pseudoframes) - 1)
                self._write_frame_to_db(frame)

            new_frame = IncompleteFrame()
            new_frame.motherstring_n = string_cd.string_num
            new_frame.motherstring_time_s = string_cd.string_time
            # Если строка оперативной информации, то можно заполнить время начала с концом
            if string_cd.string_num in self.immediate_strings:
                new_frame.append(string_cd)
                new_frame.frame_time_start_s = string_cd.string_time - \
                                               (string_cd.string_num - self.immediate_strings[0]) * self.string_duration
                new_frame.frame_time_end_s = new_frame.frame_time_start_s + self.pseudoframe_duration
                self._control_open_pseudoframes(new_frame)
            elif string_cd.string_num in self.nonimmediate_strings_in_ICD:
                new_frame.append_to_list(string_cd)
                new_frame.frame_time_start_s = None
                new_frame.frame_time_end_s = None
            else:
                new_frame.append_other_to_list(string_cd)
                new_frame.frame_time_start_s = None
                new_frame.frame_time_end_s = None
            self.open_pseudoframes.insert(0, new_frame)
        return immediate_buf

    def _create_model_instance(self, nka, bis, seq, time, is_complete, frame: IncompleteFrame,
                               timestamp) -> CDSignalFrame:
        """Витруальная функция записи кадра в базу. Реализуют наследнички"""
        pass

    def _write_frame_to_db(self, frame: IncompleteFrame) -> L3OCFrame:
        """Функция записи кадра в технологическую ЛБД."""

        # При наличии первой строки параметры берем из неё.
        # Если нет - то заполняем невозможными значениями и берём из существющих строк
        nka = None
        bis = None
        seq = 0
        timestamp = 0

        # Вытаскиваем параметры из первой попавшейся строки в буфере
        for _, buffer_item in frame.buffer.items():
            if isinstance(buffer_item, list):
                try:
                    string = buffer_item[0]
                except IndexError:
                    logger.warning("Ошибка содержимого буфера неполных кадров" + str(frame.buffer))
                    return None
            else:
                string = buffer_item
            nka = string.nka
            bis = string.bis
            timestamp = string.timestamp.replace(hour=0, minute=0, second=0, microsecond=0)
            break
        # во всех сигналах с навигационной информацией нужные параметры лежат в 10-й строке
        if 10 in frame.buffer:
            NT = frame.buffer[10].content[0]['Nt']
            N4 = frame.buffer[10].content[0]['N4']
            timestamp = get_date_from_N4_and_N(NT, N4)

        # Если есть временная привязка начала и конца (т.е. есть хоть одна строка оперативной информациии),
        # то по времени привязываемся относительно сохранённого времени начала. Иначе - относительно породившей строки
        if frame.frame_time_start_s and frame.frame_time_end_s:
            time = frame.frame_time_start_s
            timestamp = timestamp + datetime.timedelta(seconds=frame.frame_time_start_s)
            seq = frame.frame_time_start_s // self.pseudoframe_duration + 1
        else:
            time = frame.motherstring_time_s
            timestamp = timestamp + datetime.timedelta(seconds=frame.motherstring_time_s)

        # Считаем кадр полным, если число строк соответствует длине или даже чуть больше
        is_complete = True if frame.strings_count >= self.pseudoframe_length else False
        if frame.strings_count > self.pseudoframe_length:
            logger.warning(
                f"Число строк в псевдокадре {frame.strings_count} больше длины псевдокадра {self.pseudoframe_length}: {timestamp}")
        """Создаем объект и сохраняем его в переменную для возврата"""
        current_frame = self._create_model_instance(nka, bis, seq, time, is_complete, frame, timestamp)
        return current_frame

    def _control_open_pseudoframes(self, master_pseudoframe):
        """Функция проверяет содержимое псевдокадров без начальных строк с оперативной информации
        на возможность слития с псевдокадром с начальными строками"""
        for open_psfr in self.open_pseudoframes:
            if not open_psfr.frame_time_start_s and not open_psfr.frame_time_end_s:
                for _, string_list in open_psfr.buffer.items():
                    for string in string_list:
                        if (string.string_time >= master_pseudoframe.frame_time_start_s) and \
                                (string.string_time <= master_pseudoframe.frame_time_end_s):
                            master_pseudoframe.append_to_list(string)
                            string_list.remove(string)
                            open_psfr.strings_count -= 1
                if open_psfr.strings_count == 0:
                    self.open_pseudoframes.remove(open_psfr)

    def close_old_incomplete_frames(self, cur_string_time):
        """Функция осуществляет закрытие существующих буферов, если они устарели по отношению ко времени текущей строки
        в шкале времени пакетов"""
        i = 0
        while i < len(self.open_pseudoframes):
            close_frame = False
            if self.open_pseudoframes[i].frame_time_start_s:
                # Открытый псевдокадр храним не дольше, чем полторы длительности псевдокадра. Потом пишем в базу
                if cur_string_time - self.open_pseudoframes[i].frame_time_start_s > self.pseudoframe_duration * 1.5:
                    close_frame = True
            else:
                if cur_string_time - self.open_pseudoframes[i].motherstring_time_s > self.pseudoframe_duration * 1.5:
                    close_frame = True
            if close_frame:
                frame = self.open_pseudoframes.pop(i)
                self._write_frame_to_db(frame)
            i += 1

    def set_pseudoframe_length(self, string):
        """Функция устанавливает длину псевдокадра в сборщике"""
        pf_length = string.get_pseudoframe_length()
        if pf_length:
            if pf_length <= 0:
                logger.warning(
                    f"Некорректное значение РП в 10 строке {string.__class__.__name__}, id {string.id}")
            self.pseudoframe_length = pf_length
            self.pseudoframe_duration = pf_length * self.string_duration


class L1OCPseudoframeComposer(CDSignalPseudoframeComposer):
    """Класс сборки кадров сигнала L1C"""

    string_duration = utils.signals.CD.L1OC.L1OC_STRING_DURATION
    """Продолжительность одной строки, с"""

    pseudoframe_length = 15
    """Количество строк в псевдокадре"""

    pseudoframe_duration = string_duration * pseudoframe_length
    """Длительность псевдокадра, с"""

    immediate_strings = [10, 11, 12]
    """Список строк с оперативной информацией, которые открывают псевдокадр"""

    nonimmediate_strings_in_ICD = [0, 1, 2, 16, 20, 25, 31, 32, 50, 60]
    """Остальные типы строк, объявленные в ИКД"""

    def __init__(self):
        super().__init__()
        self.pseudoframe_type = L1OCFrame

    def _create_model_instance(self, nka, bis, seq, time, is_complete, frame, timestamp) -> L1OCFrame:
        """Создаем объект и сохраняем его в переменную для возврата"""
        current_frame = self.pseudoframe_type.create(nka=nka,
                                                     bis=bis,
                                                     seq=seq,
                                                     time=time,
                                                     is_complete=is_complete,
                                                     string10=frame.buffer.get(10, None),
                                                     string11=frame.buffer.get(11, None),
                                                     string12=frame.buffer.get(12, None),
                                                     string20=frame.buffer.get(20, None),
                                                     string25=frame.buffer.get(25, None),
                                                     string16=frame.buffer.get(16, None),
                                                     string31=frame.buffer.get(31, None),
                                                     string32=frame.buffer.get(32, None),
                                                     string50=frame.buffer.get(50, None),
                                                     string60=frame.buffer.get(60, None),
                                                     string0=frame.buffer.get(0, None),
                                                     # string1=frame.buffer.get(1, None),
                                                     # string2=frame.buffer.get(2, None),
                                                     string_other=frame.buffer.get("other", None),
                                                     timestamp=timestamp)
        current_frame.pseudoframe_length = self.pseudoframe_length
        if current_frame.seq != 0:
            if is_complete:
                control_tk = current_frame.control_tk()
                if control_tk:
                    create_op_message_for_control_tk(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tk=control_tk)
                control_tb = current_frame.control_tb()
                if control_tb:
                    create_op_message_for_control_tb(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tb=control_tb)
        return current_frame


class L3OCPseudoframeComposer(CDSignalPseudoframeComposer):
    """Класс сборки кадров сигнала L3OC"""

    string_duration = utils.signals.CD.L3OC.L3OC_STRING_DURATION
    """Продолжительность одной строки, с"""

    pseudoframe_length = 15
    """Количество строк в псевдокадре"""

    pseudoframe_duration = string_duration * pseudoframe_length
    """Длительность псевдокадра, с"""

    immediate_strings = [10, 11, 12]
    """Список строк с оперативной информацией, которые открывают псевдокадр"""

    nonimmediate_strings_in_ICD = [0, 1, 2, 16, 20, 25, 31, 32, 60]
    """Остальные типы строк, объявленные в ИКД"""

    def __init__(self):
        super().__init__()
        self.pseudoframe_type = L3OCFrame

    def _create_model_instance(self, nka, bis, seq, time, is_complete, frame, timestamp) -> L3OCFrame:
        """Создаем объект и сохраняем его в переменную для возврата"""
        current_frame = self.pseudoframe_type.create(nka=nka,
                                                     bis=bis,
                                                     seq=seq,
                                                     time=time,
                                                     is_complete=is_complete,
                                                     string10=frame.buffer.get(10, None),
                                                     string11=frame.buffer.get(11, None),
                                                     string12=frame.buffer.get(12, None),
                                                     string20=frame.buffer.get(20, None),
                                                     string25=frame.buffer.get(25, None),
                                                     string16=frame.buffer.get(16, None),
                                                     string31=frame.buffer.get(31, None),
                                                     string32=frame.buffer.get(32, None),
                                                     string60=frame.buffer.get(60, None),
                                                     string0=frame.buffer.get(0, None),
                                                     # string1=frame.buffer.get(1, None),
                                                     # string2=frame.buffer.get(2, None),
                                                     string_other=frame.buffer.get("other", None),
                                                     timestamp=timestamp)
        current_frame.pseudoframe_length = self.pseudoframe_length
        if current_frame.seq != 0:
            if is_complete:
                control_tk = current_frame.control_tk()
                if control_tk:
                    create_op_message_for_control_tk(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tk=control_tk)
                control_tb = current_frame.control_tb()
                if control_tb:
                    create_op_message_for_control_tb(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tb=control_tb)
        return current_frame


class SCPseudoframeComposer(CDSignalPseudoframeComposer):
    """Класс сборки кадров сигнала L1SC и L2SC"""

    string_duration = utils.signals.CD.L1SC_L2SC.SC_STRING_DURATION
    """Продолжительность одной строки, с"""

    pseudoframe_length = 15
    """Количество строк в псевдокадре"""

    pseudoframe_duration = string_duration * pseudoframe_length
    """Длительность псевдокадра, с"""

    immediate_strings = [10, 11, 12, 13]
    """Список строк с оперативной информацией, которые открывают псевдокадр"""

    nonimmediate_strings_in_ICD = [0, 1, 2, 16, 20, 25, 31, 32, 60]
    """Остальные типы строк, объявленные в ИКД"""

    def _create_model_instance(self, nka, bis, seq, time, is_complete, frame, timestamp) -> Union[L1SCFrame, L2SCFrame]:
        """Создаем объект и сохраняем его в переменную для возврата"""
        current_frame = self.pseudoframe_type.create(nka=nka,
                                                     bis=bis,
                                                     seq=seq,
                                                     time=time,
                                                     is_complete=is_complete,
                                                     string10=frame.buffer.get(10, None),
                                                     string11=frame.buffer.get(11, None),
                                                     string12=frame.buffer.get(12, None),
                                                     string13=frame.buffer.get(13, None),
                                                     string20=frame.buffer.get(20, None),
                                                     string25=frame.buffer.get(25, None),
                                                     string16=frame.buffer.get(16, None),
                                                     string31=frame.buffer.get(31, None),
                                                     string32=frame.buffer.get(32, None),
                                                     string60=frame.buffer.get(60, None),
                                                     string0=frame.buffer.get(0, None),
                                                     # string1=frame.buffer.get(1, None),
                                                     # string2=frame.buffer.get(2, None),
                                                     string_other=frame.buffer.get("other", None),
                                                     timestamp=timestamp)
        current_frame.pseudoframe_length = self.pseudoframe_length
        if current_frame.seq != 0:
            if is_complete:
                control_tk = current_frame.control_tk()
                if control_tk:
                    create_op_message_for_control_tk(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tk=control_tk)
                control_tb = current_frame.control_tb()
                if control_tb:
                    create_op_message_for_control_tb(bis=bis, nka=nka, signal_type=current_frame.signal_type,
                                                     control_tb=control_tb)
        return current_frame


class L1SCPseudoframeComposer(SCPseudoframeComposer):
    """Класс сборки кадров сигнала L1SC"""

    def __init__(self):
        super().__init__()
        self.pseudoframe_type = L1SCFrame


class L2SCPseudoframeComposer(SCPseudoframeComposer):
    """Класс сборки кадров сигнала L2SC"""

    def __init__(self):
        super().__init__()
        self.pseudoframe_type = L2SCFrame


class FrameComposer:
    composers: dict  # словарь всех сборщиков по типам сигналов

    def __init__(self):
        self.composers = {SIGNALS_NAME["L1OF"]: defaultdict(lambda: defaultdict(OneL1OFSignalFrameComposer)),
                          SIGNALS_NAME["L2OF"]: defaultdict(lambda: defaultdict(OneL2OFSignalFrameComposer)),
                          SIGNALS_NAME["L1SF"]: defaultdict(lambda: defaultdict(OneL1SFSignalFrameComposer)),
                          SIGNALS_NAME["L1SCd"]: defaultdict(lambda: defaultdict(L1SCPseudoframeComposer)),
                          SIGNALS_NAME["L2SCd"]: defaultdict(lambda: defaultdict(L2SCPseudoframeComposer)),
                          SIGNALS_NAME["L1OCd"]: defaultdict(lambda: defaultdict(L1OCPseudoframeComposer)),
                          SIGNALS_NAME["L3OCd"]: defaultdict(lambda: defaultdict(L3OCPseudoframeComposer))}

    def append(self, string):
        """Добавить строку в ее соответствующий сборщик"""
        return self.composers[string.signal_id][string.nka][string.bis].append(string)
