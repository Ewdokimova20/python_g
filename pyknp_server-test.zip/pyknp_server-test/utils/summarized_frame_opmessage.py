import logging

import peewee

from models.op_message import KNPOpSumMessage
from utils.SignalFlags import signal_flag_service

logger = logging.getLogger('op_message')


def add_summarized_knp_opmessage_to_accumulator(latest_update_time, time_now):
    """Функция для добавления оперативных сообщений созданных по обобщенным кадрам(AlarmId: 8, 9, 10)."""

    try:
        opmessages = KNPOpSumMessage.select().where(
            (KNPOpSumMessage.timestamp >= latest_update_time) & (KNPOpSumMessage.timestamp < time_now))
    except peewee.PeeweeException as err:
        logger.debug(f"Ошибка при загрузке оперативных сообщений о несоответствии ЦИ и СИ по обобщенным кадрам из ТЛБД:{err}.")
    else:
        if opmessages:
            for opmessage in opmessages:
                # Добавляем сообщение в аккумулятор
                signal_flag_service.add_operative_message(opmessage)  # fixme взаимодействие пока через базу
