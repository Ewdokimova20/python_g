from bitarray import bitarray
from bitarray.util import int2ba


class ServiceFields:
    """Виртуальный класс для наследования всех классов служебных полей"""
    pass



def check_cyclic_code_short(string: bytes) -> bool:
    """
    Проверка сигнала с длительностью строки ЦИ менее 300 бит на ошибки в строке

    В случае отсутствия ошибок в ЦК возвращается "False", иначе "True" - "есть ошибки в ЦК"
    """

    lfsr_string = int2ba(int.from_bytes(string, byteorder='big'), length=256)
    del lfsr_string[250:]

    shift_register = bitarray(lfsr_string[:16])
    shift_register.reverse()

    poly = [1, 5, 6, 8, 9, 10, 11, 13, 14]

    for left_bit in lfsr_string[16:]:
        copy_shift_register = shift_register[:]

        shift_register >>= 1
        shift_register[0] = left_bit ^ copy_shift_register[15]

        for num_poly in poly:
            shift_register[num_poly] = \
                copy_shift_register[num_poly - 1] ^ copy_shift_register[15]
    return any(shift_register)
