import datetime
import logging
from dataclasses import dataclass
from typing import Union, TYPE_CHECKING

import peewee
from cachetools import TTLCache

from utils.lib.get_date_from_N4_and_N import get_almanac_time_by_datetime

if TYPE_CHECKING:
    from data import Almanac

REQUIRED_APPROVE_COUNTS = 5

logger = logging.getLogger('almanac.get_almanac_slot')

cache_almanac = TTLCache(maxsize=64, ttl=3600)
"""Кэш для совокупного альманаха по частотным и кодовым сигналам"""


def get_almanac_slot(nka: int, NA_current: int = None, N4_current: int = None, request_depth: int = 30,
                     required_approves: int = REQUIRED_APPROVE_COUNTS, use_cache: bool = True) -> Union[None, 'Almanac']:
    """Ф-я предоставления доступа к кэшу альманаха для различных сигналов"""

    class AlmanacQuery:

        query_params = []

        """Описание границ запроса альманаха"""

        @dataclass
        class AlmanacQueryParameters:
            N4: int = 0
            Na_left_boundary: int = 0
            Na_right_boundary: int = 0

        @staticmethod
        def N4_Na_from_days_96(days_96: int):
            """Функция расчёта N4 и Na из числа дней от начала 96 года"""
            N4 = (days_96 - 1) // 1461 + 1
            Na = days_96 - (N4 - 1) * 1461
            return N4, Na

        @staticmethod
        def days_96_from_N4_Na(N4: int, Na: int) -> int:
            """Фугкция расчёт дней от начала 96 года по N4 и Na"""
            return (N4 - 1) * 1461 + Na

        def __init__(self, N4: int, Na: int, depth: int):
            self.query_params = [self.AlmanacQueryParameters(), None]
            self.query_params[0].N4 = N4
            self.query_params[0].Na_left_boundary = Na - depth
            self.query_params[0].Na_right_boundary = Na + depth
            # Считаем, не попали ли мы с диапазоном поиска на смену альманаха
            if self.query_params[0].Na_left_boundary < 1:
                self.query_params[0].Na_left_boundary = 1
                now_days_from_96 = self.days_96_from_N4_Na(N4, Na)
                boundary_from_96 = now_days_from_96 - request_depth
                tmp_N4, tmp_Na = self.N4_Na_from_days_96(boundary_from_96)
                self.query_params[1] = self.AlmanacQueryParameters(N4=tmp_N4,
                                                                   Na_left_boundary=tmp_Na,
                                                                   Na_right_boundary=1461
                                                                   )
            elif self.query_params[0].Na_right_boundary > 1461:
                self.query_params[0].Na_right_boundary = 1461
                now_days_from_96 = self.days_96_from_N4_Na(N4, Na)
                boundary_from_96 = now_days_from_96 + request_depth
                tmp_N4, tmp_Na = self.N4_Na_from_days_96(boundary_from_96)
                self.query_params[1] = self.AlmanacQueryParameters(N4=tmp_N4,
                                                                   Na_left_boundary=1,
                                                                   Na_right_boundary=tmp_Na
                                                                   )

    # при не заданной явно дате ищем данные на текущее время
    if (NA_current is None) or (NA_current == 0) or (N4_current is None) or (N4_current == 0):
        (N4_current, NA_current, _) = get_almanac_time_by_datetime(
            datetime.datetime.now())

    # Рассчитали, сколько дней прошло с момента отсчёта
    now_days_from_96 = AlmanacQuery.days_96_from_N4_Na(N4_current, NA_current)
    # Проверяем, есть ли данные для данного nka в кэше
    if use_cache == True:
        almanac_slot = cache_almanac.get(nka)
        if almanac_slot is not None:
            almanac_days_from_96 = AlmanacQuery.days_96_from_N4_Na(
                almanac_slot.N4, almanac_slot.N_A)
            if abs(now_days_from_96 - almanac_days_from_96) <= request_depth:
                return almanac_slot

    # Объекты для границ поиска в базе, если в кэше ничего нет или лежит не то, что нужно
    almanac_boundaries = AlmanacQuery(N4_current, NA_current, request_depth)

    from data import Almanac
    try:
        # доверяем если слот был собран более 15 раз одинаковым
        # берем запись с максимальным номером суток (не идентификатором, не позднейшую записанную)
        # четырехлетие должно совпадать
        # Возможны проблемы на границе четырехлетия при несогласованном изменении Na и N4
        # исходим из того, что альманах закладывается 4 раза в неделю. Т.е. либо через один, либо через два дня + день запаса
        # Возможные ситуации на границе четырехлетия: N4   NT   NA
        #                                              6  1460 1460 -- Ок, согласованное состояние
        #                                              6  1461 1460 -- Ок, согласованное состояние
        #                                              6  1461 1461 -- Ок, согласованное состояние
        #                                              6  1461    1 -- стоит пробовать запрашивать в предыдущем четырехлетии
        #                                              7     1 1461 -- стоит пробовать запрашивать в следующем четырехлетии
        #                                              7     1    1 -- Ок, согласованное состояние
        almanac_slot = Almanac.select().where((Almanac.nka == nka) &
                                              (Almanac.N4 == almanac_boundaries.query_params[0].N4) &
                                              (Almanac.N_A.between(almanac_boundaries.query_params[0].Na_left_boundary,
                                                                   almanac_boundaries.query_params[0].Na_right_boundary)) &
                                              (Almanac.approve_count > required_approves)).order_by(Almanac.N_A.desc()).get()
    except peewee.DoesNotExist:
        try:
            if almanac_boundaries.query_params[1]:
                almanac_slot = Almanac.select().where((Almanac.nka == nka) &
                                                      (Almanac.N4 == almanac_boundaries.query_params[1].N4) &
                                                      (Almanac.N_A.between(
                                                          almanac_boundaries.query_params[1].Na_left_boundary,
                                                          almanac_boundaries.query_params[1].Na_right_boundary)) &
                                                      (Almanac.approve_count > required_approves)).order_by(
                    Almanac.N_A.desc()).get()
            else:
                return None
        except peewee.DoesNotExist:
            return None
    except peewee.ProgrammingError as exc:
        logger.warning("Ошибка извлечения альманаха из ТЛБД:" + str(exc))
        return None
    if use_cache == True:
        cache_almanac[nka] = almanac_slot
    return almanac_slot
