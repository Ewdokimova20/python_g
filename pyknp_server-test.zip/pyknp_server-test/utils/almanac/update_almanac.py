from __future__ import annotations

import datetime
import logging
import math
from typing import Union, cast, TYPE_CHECKING

from peewee import DoesNotExist

from data import L1OFFrame, L1OFString, Almanac
from global_data.appdata import SignalTypes
from utils.caches.cache import cache_manager
from utils.lib.exceptions import MissingParamError
from utils.lib.get_date_from_N4_and_N import get_almanac_time_by_datetime

if TYPE_CHECKING:
    from data import L1OCFrame, L1SCFrame, L3OCFrame, L2SCFrame

APPROVE_COUNT_THRESHOLD = 15

logger = logging.getLogger('almanac.update_almanac')


def update_almanac_single_slot(N_A: int, N4: int, first_string: L1OFString, second_string: L1OFString):
    # не обновляем слоты если сбои в строках
    if not first_string or not second_string or first_string.error_in_string or second_string.error_in_string:
        return False

    try:
        update_almanac_slot_in_db(first_string.nka_id, first_string.signal_id, nka=first_string.get_param('n_a'), N_A=N_A, N4=N4,
                                  Tlambda_A=second_string.get_param('t_lambda'),
                                  # время прохождения восходящего узла, ближайшее к началу суток
                                  deltaT_A=second_string.get_param('delta_T'),
                                  # отклонение периода от номинала 40544, с (для кодовых пересчитывается из 43200)
                                  deltaI_A=first_string.get_param('delta_i'),
                                  # отклонение наклонения от номинала 64.8 градуса (для кодовых пересчитывается 63)
                                  deltaTdot=second_string.get_param('d_delta_T'),  # скорость изменения периода, б/р
                                  e_A=first_string.get_param('epsilon'),  # эксцентриситет, б/р
                                  omega_A=second_string.get_param('omega'),  # аргумент перигея, полуциклы
                                  lambda_A=first_string.get_param('lambda_'),  # долгота восходящего узла, полуциклы
                                  )
    except MissingParamError as err:
        logger.debug(f"Ошибка в строке при сборке альманаха {str(err)}.\n {str(first_string)} \n {str(second_string)}")
    except DoesNotExist:
        return False


def update_almanac_lf(frm: L1OFFrame):
    """Функция обновления обобщённой оперативной информации для сигналов открытого доступа с частотным разделением.
    Вход - список строк оперативной информации.
    Выход - структура с оперативной информацией."""

    # Проверяем наличие и корректность строки 5
    if not frm.string5 or frm.string5.error_in_string:
        return

    try:
        # Извлекаем значения N4 и Na из строки 5
        common_N4 = frm.get_param_from_string(5, 'N4')  # FIXME N_A и N4 меняются независимо,
        # что может привести к сбоям на границе четырехлетий
        common_NA = frm.get_param_from_string(5, 'Na')
    except MissingParamError as err:
        logger.info(
            f"Ошибка получения Na и N4 строки 5 кадра {frm.__class__.__name__} c id {frm.id}, '{getattr(err, 'args', [None])[0]}': {str(err)}")
        return

    try:  # защита на случай, если нужных строк всё же нет
        # Проверяем, что сигнал достоверный и строки без ошибок
        if frm.string6 and frm.string7 and not frm.string7.error_in_string \
                and not frm.string6.error_in_string and not frm.get_param_from_string(7, 'ln_a'):
            update_almanac_single_slot(common_NA, common_N4, frm.string6, frm.string7)

        if frm.string8 and frm.string9 and not frm.string9.error_in_string \
                and not frm.string8.error_in_string and not frm.get_param_from_string(9, 'ln_a'):
            update_almanac_single_slot(common_NA, common_N4, frm.string8, frm.string9)

        if frm.string10 and frm.string11 and not frm.string11.error_in_string \
                and not frm.string10.error_in_string and not frm.get_param_from_string(11, 'ln_a'):
            update_almanac_single_slot(common_NA, common_N4, frm.string10, frm.string11)

        if frm.string12 and frm.string13 and not frm.string13.error_in_string \
                and not frm.string12.error_in_string and not frm.get_param_from_string(13, 'ln_a'):
            update_almanac_single_slot(common_NA, common_N4, frm.string12, frm.string13)

            if not frm.is_fifth:
                if frm.string14 and frm.string15 and not frm.string15.error_in_string \
                        and not frm.string14.error_in_string and not frm.get_param_from_string(15, 'ln_a'):
                    update_almanac_single_slot(common_NA, common_N4, frm.string14, frm.string15)
    except MissingParamError as err:
        logger.debug(
            f"Ошибка обновления альманаха кадра {frm.__class__.__name__} c id {frm.id}, '{getattr(err, 'args', [None])[0]}': {str(err)}")


def update_almanac_lc(frm: Union['L1OCFrame', 'L1SCFrame', 'L2SCFrame', 'L3OCFrame']):
    """Функция обновления обобщённой оперативной информации для сигналов открытого доступа с частотным разделением.
    Вход - список строк оперативной информации.
    Выход - структура с оперативной информацией."""

    if frm.string10 is None or frm.string10.error_in_string:
        return

    N4 = frm.get_param_from_string_or_none(10, 'N4')  # FIXME N_A и N4 меняются независимо,
    # что может привести к сбоям на границе четырехлетий (ЛИА)
    if N4 is None:
        logger.debug(f"Ошибка доступа к N4 для {frm.__class__.__name__} c id {frm.id}")
        return

    if frm.string20 is None:
        return

    for string_20 in frm.string20:
        string_20 = cast(Union['L1OCString', 'L3OCString', 'L1SCString', 'L2SCString'], string_20)
        # при недоступности или сбоях строки не пытаемся обновить альманах
        if not string_20 or string_20.error_in_string:
            continue

        try:
            Lj = string_20.get_param('Lj')
            Gj = string_20.get_param('Gj')
            # Альманах обновляем только по достоверным сигналам. Это делается из-за возникновения ситуации борьбы между 26 с кучей сигналов и нескольких Глонасс-М с небольшим числом сигналов
            # Также проверяем и то, что проверочные символы сошлись
            # FIXME временный костыль, чтобы брался альманах с сигналов с кодовым разделением, сейчас они все недостоверные.
            if ((frm.signal_type == SignalTypes.L3OCd) or (not Lj and not Gj)) and not string_20.error_in_string:
                update_almanac_slot_in_db(
                    source_nka=string_20.nka_id,
                    source_signal=frm.signal_type,
                    nka=string_20.get_param('j'),
                    N_A=string_20.get_param('Na'),
                    N4=N4,
                    Tlambda_A=string_20.get_param('t_lambda'),  # время прохождения восходящего узла, ближайшее к началу суток
                    deltaT_A=string_20.get_param('delta_T') + (40544 - 43200),
                    # отклонение периода от номинала 40544, с (для кодовых пересчитывается из 43200)
                    deltaI_A=string_20.get_param('delta_i') + (64.8 - 63) / 180,
                    # отклонение наклонения от номинала 64.8 градуса (для кодовых пересчитывается 63)
                    deltaTdot=string_20.get_param('delta_dot_Ta'),  # скорость изменения периода, б/р
                    e_A=string_20.get_param('epsilon'),  # эксцентриситет, б/р
                    omega_A=string_20.get_param('omega'),  # аргумент перигея, полуциклы
                    lambda_A=string_20.get_param('lambda_'),  # долгота восходящего узла, полуциклы
                )
        except MissingParamError as err:
            logger.debug(
                f"Ошибка сборки альманаха, {frm.__class__.__name__}, id {frm.id}, {type(err).__name__} для  '{getattr(err, 'args', [None])[0]}': {str(err)}")
        except DoesNotExist:
            return False


def update_almanac_slot_in_db(source_nka: int, source_signal: int, nka: int, N_A: int, N4: int, Tlambda_A: float,
                              deltaT_A: float, deltaI_A: float, deltaTdot: float, e_A: float, omega_A: float,
                              lambda_A: float):
    # исправляем некорректеное значение N4
    # Возможны проблемы на границе четырехлетия при несогласованном изменении NA и N4
    # исходим из того, что альманах закладывается 4 раза в неделю. Т.е. либо через один, либо через два дня + день запаса
    # Возможные ситуации на границе четырехлетия: N4   NT   NA
    #                                              6  1460 1460 -- Ок, согласованное состояние
    #                                              6  1461 1460 -- Ок, согласованное состояние
    #                                              6  1461 1461 -- Ок, согласованное состояние
    #                                              6  1461    1 -- истинное N4 для альманаха на единицу больше
    #                                              7     1 1461 -- истинное N4 для альманаха на единицу меньше
    #                                              7     1    1 -- Ок, согласованное состояние
    # Т.о. особыми граничными случаями будут когда NA имеет значения [1459,3]

    if (N_A >= 1459) or (N_A <= 3):
        N4_current, NT_current, _ = get_almanac_time_by_datetime(
            datetime.datetime.now())  # значения ОИ привязаны к реальному МДВ
        # если NT и NA по разные границы четырехлетия, то N4 характеризует NT и некорректно описывает NA
        if (N4 == N4_current) and (NT_current >= 1459) and (N_A <= 3):
            N4 += 1
        if (N4 == N4_current) and (NT_current <= 3) and (N_A >= 1459):
            N4 -= 1

    # Пытаемся получить слот альманаха с идентификаторами текущего слота НКА
    try:
        almanac_slot = Almanac.select().where((Almanac.nka == nka) &
                                              (Almanac.N4 == N4) &
                                              (Almanac.N_A == N_A)).get()  # не указываем сортировку т.к.
        # запрашиваем по первичному ключу
    except DoesNotExist:
        # добавляем слот в состоянии отсутствия подтверждения
        source_nka = cache_manager.get_nka(source_nka)
        (Almanac.insert(source_nka=source_nka, source_signal=source_signal,
                        # сохраняем источник слота для расследований
                        nka=nka, N_A=N_A, N4=N4, approve_count=0,
                        Tlambda_A=Tlambda_A,  # время прохождения восходящего узла, ближайшее к началу суток
                        deltaT_A=deltaT_A,
                        # отклонение периода от номинала 40544, с (для кодовых пересчитывается из 43200)
                        deltaI_A=deltaI_A,
                        # отклонение наклонения от номинала 64.8 градуса (для кодовых пересчитывается 63)
                        deltaTdot=deltaTdot,  # скорость изменения периода, б/р
                        e_A=e_A,  # эксцентриситет, б/р
                        omega_A=omega_A,  # аргумент перигея, полуциклы
                        lambda_A=lambda_A,  # долгота восходящего узла, полуциклы
                        ).on_conflict_ignore().execute())
        return
    # если мы дошли до сюда, значит в БД есть слот с аналогичной идентификацией. Сравниваем с аргументами
    # голосование для слота конкретного НКА ведется по всем сигналам с ЦИ от всех НКА
    if math.isclose(almanac_slot.Tlambda_A, Tlambda_A, rel_tol=1e-3) and \
            math.isclose(almanac_slot.deltaT_A, deltaT_A, rel_tol=1e-3) and \
            math.isclose(almanac_slot.deltaI_A, deltaI_A, rel_tol=1e-3) and \
            math.isclose(almanac_slot.deltaTdot, deltaTdot, rel_tol=1e-3) and \
            math.isclose(almanac_slot.e_A, e_A, rel_tol=1e-3) and \
            math.isclose(almanac_slot.omega_A, omega_A, rel_tol=1e-3) and \
            math.isclose(almanac_slot.lambda_A, lambda_A,
                         rel_tol=1e-3):  # слоты совпадают, увеличиваем меру подтверждения
        if almanac_slot.approve_count < APPROVE_COUNT_THRESHOLD:  # ограничиваем значением, которое не даст единичным сбойным строкам исказить слот
            (Almanac.update(approve_count=almanac_slot.approve_count + 1).where((Almanac.nka == nka) &
                                                                                (Almanac.N4 == N4) &
                                                                                (Almanac.N_A == N_A)).execute())
    elif almanac_slot.approve_count > 1:  # слот из прошлого не совпадает с тем, что приходит сейчас --- снижаем достоверность
        (Almanac.update(approve_count=almanac_slot.approve_count - 1).where((Almanac.nka == nka) &
                                                                            (Almanac.N4 == N4) &
                                                                            (Almanac.N_A == N_A)).execute())
    else:
        (Almanac.delete().where((Almanac.nka == nka) &
                                (Almanac.N4 == N4) &
                                (Almanac.N_A == N_A)).execute())
        source_nka = cache_manager.get_nka(source_nka)
        (Almanac.insert(source_nka=source_nka, source_signal=source_signal,
                        # сохраняем источник слота для расследований
                        nka=nka, N_A=N_A, N4=N4, approve_count=0,
                        Tlambda_A=Tlambda_A,  # время прохождения восходящего узла, ближайшее к началу суток
                        deltaT_A=deltaT_A,
                        # отклонение периода от номинала 40544, с (для кодовых пересчитывается из 43200)
                        deltaI_A=deltaI_A,
                        # отклонение наклонения от номинала 64.8 градуса (для кодовых пересчитывается 63)
                        deltaTdot=deltaTdot,  # скорость изменения периода, б/р
                        e_A=e_A,  # эксцентриситет, б/р
                        omega_A=omega_A,  # аргумент перигея, полуциклы
                        lambda_A=lambda_A,  # долгота восходящего узла, полуциклы
                        ).on_conflict_ignore().execute())
