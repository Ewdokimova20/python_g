from __future__ import annotations

import logging
import os
from collections import defaultdict, Counter
from datetime import datetime
from math import floor
from typing import Dict

from typing_extensions import DefaultDict

from communication.types import ZMQTopic
from global_data.appdata import SignalTypes, MEAS_PACKET_TYPE, NKA_SIGNALS
from global_data.config_schema import config
from scripts.process_registry import get_partial_counters, get_current_visibility, get_partial_nka_statuses
from utils.caches import cache_bis
from utils.lib.types.type_aliases import NkaSysNum, Bis
from utils.statuses.bis_connection.get_current_bis_connection_status import get_current_bis_communication_status
from utils.statuses.bis_connection.types import BisConnectionStatus
from utils.statuses.nka_reception_status.common import SignalReceptionStatus
from utils.validity.types import ValidityStatus
from utils.validity.validity_ttl_list import ValidityTTLList
from utils.visibility.types import VisibilityStatus

logger = logging.getLogger(__name__)

VALIDITY_POINTS_NUMBER = 15
"""Число точек, по которому определяется достоверность сигнала"""

LatestValidityValuesType = Dict[NkaSysNum, Dict[SignalTypes, Dict[Bis, ValidityTTLList]]]
ValidityDataType = DefaultDict[NkaSysNum, DefaultDict[SignalTypes, DefaultDict[Bis, ValidityStatus]]]


class PartialValidity:
    """
    Класс для определения годности сигналов в дочернем процессе обработки.

    Отправляет состояние счетчиков при вызове извне с помощью функции send_on_socket.
    Ожидается, что в процессе обработки будет обрабатываться несколько БИС (3-4),
    поэтому иерархия по БИС сохранена (не все БИС, поэтому Partial).

    С сокета данные впоследствии попадают в класс GeneralValidity, в котором собирается информация о годности по всем БИС

    Возможные значения статуса годности:
    - VALID (10): достоверный сигнал
    - UNAVAILABLE_UNCONFIRMED (5): сигнал не принимается (не подтверждено)
    - INVALID (4): недостоверный сигнал
    - QUASIINVALID (3): недостоверный сигнал по оценке недостаточного числа станций
    - UNAVAILABLE (2): сигнал не принимается (хотя должен излучаться)
    - UNDEFINED (1): состояние не определено
    - OUT_OF_SIGHT (0): вне зоны радиовидимости
    - NOT_ON_AIR (-1): сигнал не излучается
    """

    def __init__(self) -> None:
        self._validity_ttl_lists: LatestValidityValuesType = dict()
        """Список значений годности сигналов по всем НКА и всем БИС на заданном интервале.
        Уровни НКА, сигнал, кортеж (станция, бис)."""

        self._last_sent_at: datetime = datetime.min
        """Время последней отправки данных на сокет"""

        self._validity_number_threshold: int = floor(
            VALIDITY_POINTS_NUMBER * config['bis_control']['signal_validity_percent'] / 100
        )

        # Инициализация структур
        self._initialize_validity_structures()
        self._zmq_manager = None

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def _initialize_validity_structures(self) -> None:
        """
        Инициализирует структуры данных для хранения годности сигналов.

        Создает словари для каждого НКА, сигнала и БИС с начальными объектами BisValidity.
        """
        all_bis = cache_bis.get_all()
        for nka, nka_signals in NKA_SIGNALS.items():
            self._validity_ttl_lists[nka] = dict()
            for signal in nka_signals:
                self._validity_ttl_lists[nka][signal] = dict()
                for (bis_number, station) in all_bis:
                    self._validity_ttl_lists[nka][signal][(station, bis_number)] = ValidityTTLList(length=VALIDITY_POINTS_NUMBER)

    def set_instant_validity(self, station_number: int, bis_number: int, nka: NkaSysNum, signal_type: SignalTypes,
                             is_valid: bool):
        """
        Устанавливает годность сигнала, оцененную по текущей невязке.

        Добавляет годность в список, по которому идёт оценка интегральной годности.

        Args:
            station_number (int): Номер станции.
            bis_number (int): Номер БИС.
            nka (NkaSysNum): Системный номер НКА.
            signal_type (SignalTypes): Тип сигнала.
            is_valid (bool): Флаг годности сигнала.
        """
        try:
            self._validity_ttl_lists[nka][signal_type][(station_number, bis_number)].append_status(is_valid)
        except KeyError:
            pass

    def _define_one_bis_validity(self, nka: NkaSysNum, signal_type: 'SignalTypes', station: int,
                                 bis_num: int) -> 'ValidityStatus':
        """
        Определяет годность сигнала для одного БИС.

        Проверяет состояние приёма сигнала, видимость и связь с БИС.

        Args:
            nka (NkaSysNum): Системный номер НКА.
            signal_type (SignalTypes): Тип сигнала.
            station (int): Номер станции.
            bis_num (int): Номер БИС.

        Returns:
            ValidityStatus: Статус годности сигнала.
        """
        partial_nka_statuses = get_partial_nka_statuses()
        current_visibility = get_current_visibility()
        partial_counters = get_partial_counters()

        nka_status = partial_nka_statuses.get_status(station, bis_num, nka, signal_type, MEAS_PACKET_TYPE)
        if nka_status is None:
            return ValidityStatus.UNDEFINED

        visibility_status = current_visibility.get_status(station, nka)
        bis_connection_status = get_current_bis_communication_status(station, bis_num, partial_counters)

        if (
                nka_status <= SignalReceptionStatus.UNDEFINED or
                visibility_status != VisibilityStatus.RELIABILITY_CONTROL or
                bis_connection_status != BisConnectionStatus.OK
        ):
            return ValidityStatus.OUT_OF_SIGHT

        if nka_status == SignalReceptionStatus.UNAVAILABLE:
            return ValidityStatus.UNAVAILABLE

        validity_counter: Counter[ValidityStatus] = Counter(
            self._validity_ttl_lists[nka][signal_type][(station, bis_num)].get_all_items())

        return self._calculate_validity_status(validity_counter)

    def _calculate_validity_status(self, validity_counter: Counter[ValidityStatus]) -> ValidityStatus:
        """
        Вычисляет статус годности на основе счетчика значений годности.

        Args:
            validity_counter (Counter[ValidityStatus]): Счетчик статусов годности.

        Returns:
            ValidityStatus: Итоговый статус годности.
        """
        if ValidityStatus.VALID in validity_counter:
            if validity_counter[ValidityStatus.VALID] * 100 > self._validity_number_threshold:
                return ValidityStatus.VALID
            if validity_counter[ValidityStatus.INVALID] * 100 > self._validity_number_threshold:
                return ValidityStatus.INVALID
            return ValidityStatus.UNDEFINED

        if validity_counter[ValidityStatus.INVALID] * 100 > self._validity_number_threshold:
            return ValidityStatus.INVALID

        return ValidityStatus.UNDEFINED

    def send_on_socket(self) -> None:
        """
        Отправляет текущее состояние годности на сокет ZMQ главного процесса (обобщающего).
        """
        self._expire()

        data: ValidityDataType = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: ValidityStatus.UNDEFINED)))

        for nka, nka_validity in self._validity_ttl_lists.items():
            for signal_type, signal_validity in nka_validity.items():
                for (station, bis_num), bis_validity in signal_validity.items():
                    data[nka][signal_type][(station, bis_num)] = self._define_one_bis_validity(nka, signal_type, station, bis_num)

        try:
            self._zmq_manager.publish_data(ZMQTopic.VALIDITY, data=data)
            self._last_sent_at = datetime.now()
            logger.debug(f'Отправка словаря годности сигналов с процесса PID: {os.getpid()}')
        except Exception as e:
            logger.error(f'Ошибка при отправке словаря годности сигналов с процесса PID {os.getpid()}: {e}')

    def _expire(self) -> None:
        """
        Очищает списки годности от устаревших записей.

        Вызывает метод expire() для каждого объекта BisValidity с текущим временем.
        """
        now = datetime.now()
        for validity_by_nka in self._validity_ttl_lists.values():
            for validity_by_nka_signal in validity_by_nka.values():
                for validity_by_nka_signal_bis in validity_by_nka_signal.values():
                    validity_by_nka_signal_bis.expire(now)
