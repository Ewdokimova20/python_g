from __future__ import annotations

from collections import Counter
from datetime import datetime
from typing import Dict

from global_data.appdata import NKA_SIGNALS, SignalTypes
from global_data.config_schema import config
from models.op_message import KNPOpMessage
from utils.SignalFlags import UNDEFINED_BIS_ID, signal_flag_service
from utils.caches import cache_bis
from utils.lib.types.type_aliases import NkaSysNum, Bis, StationNum, BisNum
from utils.validity.types import ValidityStatus

NkaBisValidityType = Dict[NkaSysNum, Dict[SignalTypes, Dict[StationNum, Dict[BisNum, ValidityStatus]]]]
SignalsGeneralizedValidityType = Dict[NkaSysNum, Dict[SignalTypes, ValidityStatus]]


class GeneralValidity:
    """
    Класс для определения общей годности сигналов для всех БИС в основном процессе (обобщающем).

    Основные функции:
    - Собирает информацию от классов PartialValidity из дочерних процессов через ZMQ
    - Формирует общие словари годности сигналов
    - Взаимодействует с клиентом и обобщенными сигнальными признаками

    Атрибуты:
        nka_bis_validity (NkaBisValidityType): Годность сигналов для каждого НКА
            по каждому БИС с детализацией до станции и номера БИС.
        _signals_generalized_validity (SignalsGeneralizedValidityType):
            Интегральная годность сигналов для каждого НКА.
    """

    def __init__(self) -> None:
        self.nka_bis_validity: NkaBisValidityType = dict()
        """Годность сигналов для каждого НКА отдельно по каждому БИС.
        Уровни: НКА, сигнал, станция, номер БИС"""

        self._signals_generalized_validity: SignalsGeneralizedValidityType = dict()
        """Годность сигналов для каждого НКА, интегральная по всем БИС.
        Уровни: НКА, сигнал"""

        self._init_structures()

    def _init_structures(self) -> None:
        """
        Инициализирует структуры данных для хранения годности сигналов.
        """
        all_bis = cache_bis.get_all()
        for nka, nka_signals in NKA_SIGNALS.items():
            self.nka_bis_validity[nka] = dict()
            self._signals_generalized_validity[nka] = dict()
            for signal in nka_signals:
                self.nka_bis_validity[nka][signal] = dict()
                self._signals_generalized_validity[nka][signal] = ValidityStatus.OUT_OF_SIGHT
                for bis_number, station_number in all_bis:
                    self.nka_bis_validity[nka][signal].setdefault(station_number, {})
                    self.nka_bis_validity[nka][signal][station_number][bis_number] = ValidityStatus.OUT_OF_SIGHT

    def define_validity(self) -> None:
        """
        Определяет интегральную годность сигналов на текущий момент.

        Алгоритм:
        1. Перебирает оценки достоверности (годности) по всем комбинациям НКА-сигнал-станция-БИС
        3. Выбирает лучшую достоверность по станции
        4. Осуществляет голосование по станциям
        5. Обновляет обобщенный статус годности сигналов
        6. Формирует сигнальный признак при отсутствии сигнала
        """
        for nka, nka_dict in self.nka_bis_validity.items():
            for signal, signal_dict in nka_dict.items():
                stations_validity: Dict[StationNum, ValidityStatus] = dict()
                for station, station_dict in signal_dict.items():
                    stations_validity[station] = max(station_dict.values())

                validity_statuses: Counter[ValidityStatus] = Counter(stations_validity.values())

                # Определение обобщенного статуса с учетом приоритетов
                generalised_status: ValidityStatus = self._determine_generalized_status(validity_statuses)

                # Обновляем состояние по сигналу НКА
                self._signals_generalized_validity[nka][signal] = generalised_status

                # Выделение сигнального признака при отсутствии сигнала в ЗРВ
                if generalised_status == ValidityStatus.UNAVAILABLE:
                    self._handle_unavailable_signal(nka, signal)

    def _determine_generalized_status(self, validity_statuses: Counter[ValidityStatus]) -> ValidityStatus:
        """
        Определяет обобщенный статус на основе счетчика статусов годности.

        Args:
            validity_statuses (Counter[ValidityStatus]): Счетчик статусов годности.

        Returns:
            ValidityStatus: Обобщенный статус годности.
        """
        if ValidityStatus.VALID in validity_statuses:
            return ValidityStatus.VALID

        if ValidityStatus.INVALID in validity_statuses:
            if validity_statuses[ValidityStatus.INVALID] >= config['bis_control']['station_validity_error_threshold']:
                return ValidityStatus.INVALID
            return ValidityStatus.QUASIINVALID

        if ValidityStatus.UNAVAILABLE in validity_statuses:
            if validity_statuses[ValidityStatus.UNAVAILABLE] >= config['bis_control']['station_receiving_error_threshold']:
                return ValidityStatus.UNAVAILABLE
            return ValidityStatus.UNAVAILABLE_UNCONFIRMED

        if ValidityStatus.UNDEFINED in validity_statuses:
            return ValidityStatus.UNDEFINED

        return ValidityStatus.OUT_OF_SIGHT

    def _handle_unavailable_signal(self, nka: NkaSysNum, signal: 'SignalTypes') -> None:
        """
        Формирует оперативное сообщение при отсутствии сигнала в зоне радиовидимости.

        Args:
            nka (NkaSysNum): Системный номер НКА
            signal (SignalTypes): Тип сигнала.
        """
        signal_flag_service.add_operative_message(KNPOpMessage(
            bis=UNDEFINED_BIS_ID,
            nka=nka,
            timestamp=datetime.now(),
            letter=-1,
            signal_type=signal,
            snr=0,
            not_in_sight=1,
            excess_of_residual=0,
            excess_of_pseudorange_difference=0,
            excess_of_navsolution_error=0,
            ground_control_call=0,
            unreliable_frame=0,
            unreliable_signal=0,
            unreliable_digital_info=0,
            tk_inconsistency=0,
            tb_inconsistency=0
        ))

    def load_data(self, data: Dict[NkaSysNum, Dict[SignalTypes, Dict[Bis, ValidityStatus]]]) -> None:
        """
        Загружает данные о годности сигналов в общий словарь

        Данная функция вызывается при обработке пакетов c сокета ZMQ с топиком VALIDITY, пришедших от процессов обработки (дочерних)

        Args:
            data (Dict[NkaSysNum, Dict[SignalTypes, Dict[Bis, ValidityStatus]]]):
                Словарь данных о годности сигналов.
        """
        for nka, nka_data in data.items():
            for signal_type, signal_data in nka_data.items():
                for bis_key, bis_data in signal_data.items():
                    station, bis = bis_key
                    try:
                        self.nka_bis_validity[nka][signal_type][station][bis] = bis_data
                    except KeyError:
                        pass
        self.define_validity()

    def get_signals_generalized_validity(self) -> SignalsGeneralizedValidityType:
        """
        Возвращает интегральную годность сигналов по всем БИС.

        Returns:
            SignalsGeneralizedValidityType: Словарь с обобщенной годностью сигналов.
        """
        return self._signals_generalized_validity


general_validity = GeneralValidity()
