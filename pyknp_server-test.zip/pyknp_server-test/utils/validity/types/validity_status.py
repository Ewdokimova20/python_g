from enum import IntEnum


class ValidityStatus(IntEnum):
    VALID = 10  # достоверный сигнал
    UNAVAILABLE_UNCONFIRMED = 5  # сигнал не принимается (не подтверждено)
    INVALID = 4  # недостоверный сигнал
    QUASIINVALID = 3  # недостоверный сигнал по оценке недостаточного числа станций
    UNAVAILABLE = 2  # сигнал не принимается (хотя должен излучаться)
    UNDEFINED = 1  # состоянияе не определено
    OUT_OF_SIGHT = 0  # вне зоны радиовидимости
    NOT_ON_AIR = -1  # сигнал не излучается
