from __future__ import annotations

from global_data.config_schema import config
from utils.fixed_list_ttl.fixed_list_ttl import FixedListManualTTL
from utils.validity.types import ValidityStatus


class ValidityTTLList(FixedListManualTTL):
    """TTL-список для мговенных значений достоверности (годности)"""

    def __init__(self, length: int):
        super().__init__(max_length=length, hold_time=config['bis_control']['signal_validity_analyzing_time'])

    def append_status(self, is_valid: bool) -> None:
        """Добавить значение годности в список"""
        if is_valid:
            self.append(ValidityStatus.VALID)
        else:
            self.append(ValidityStatus.INVALID)
