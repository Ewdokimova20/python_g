# DEPRECATED
from collections import deque
import datetime
from statistics import mean

from global_data.config_schema import config

class KNPNavSolutionAverage:
    def __init__(self, window_size: int):
        self.window_size = window_size  # за какой период усреднять результаты решения НВЗ, в секундах (берем из конфига)
        self.buffer = {}  # словарь, хранящий буфер для каждого решения НВЗ
        self.averages = {}  # словарь, хранящий последнее вычисленное среднее для каждого решения НВЗ

    def add_data(self, bis: int, signal: int, nvz_solution):
        solution_id = (bis, signal)

        # Инициализируем буфер для текущего решения НВЗ, если оно еще не существует
        if solution_id not in self.buffer:
            self.buffer[solution_id] = deque(maxlen=self.window_size)
            self.averages[solution_id] = (0, 0, 0)

        # Добавляем новое значение в буфер
        self.buffer[solution_id].append((nvz_solution.timestamp, nvz_solution.x, nvz_solution.y, nvz_solution.z))

        # Удаляем все значения, которые старше window_size секунд
        current_time = nvz_solution.timestamp
        while self.buffer[solution_id] and current_time - self.buffer[solution_id][0][0] > datetime.timedelta(seconds=self.window_size):
            self.buffer[solution_id].popleft()

        # Вычисляем среднее значение по данным в буфере
        xyz_values = [(item[1], item[2], item[3]) for item in self.buffer[solution_id]]
        x_values, y_values, z_values = zip(*xyz_values)
        self.averages[solution_id] = (mean(x_values), mean(y_values), mean(z_values))

    def get_average(self, bis: int, signal: int) -> float:
        stream_id = (bis, signal)
        return self.averages.get(stream_id, (0, 0, 0))


#average_nvz = KNPNavSolutionAverage(config['bis_control']['nvz_averaging_interval'])