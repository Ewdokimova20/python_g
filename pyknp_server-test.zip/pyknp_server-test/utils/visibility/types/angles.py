from typing import NamedTuple

from utils.visibility.types.elevation_trend import ElevationTrend


class Angles(NamedTuple):
    """Словарь для хранения азимута, угла места и тренда для угла места"""
    azimuth: float
    elevation: float
    trend: 'ElevationTrend'
