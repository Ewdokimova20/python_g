from typing import TYPE_CHECKING

from typing_extensions import TypedDict

if TYPE_CHECKING:
    from utils.visibility.types import ElevationTrend, VisibilityStatus


class VisibilityForClient(TypedDict):
    """
    Словарь с углами, трендом и состоянием видимости для отправки на клиент
    """
    azimuth: float
    elevation: float
    trend: 'ElevationTrend'
    visibility: 'VisibilityStatus'
