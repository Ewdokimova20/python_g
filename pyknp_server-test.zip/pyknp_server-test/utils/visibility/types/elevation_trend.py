from enum import IntEnum


class ElevationTrend(IntEnum):
    """Тренд изменения угла места"""
    UNDEFINED = 0
    ASCENDING = 1
    DESCENDING = 2
