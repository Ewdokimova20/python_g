from enum import IntEnum


class VisibilityStatus(IntEnum):
    """Перечисление состояний радиовидимости"""
    RELIABILITY_CONTROL = 3  # гарантированный уровень точностных
    GUARANTEED = 2  # гарантированный приём
    MAYBE = 1  # возможный приём
    OUT_OF_SIGHT = 0
    UNDEFINED = -1
