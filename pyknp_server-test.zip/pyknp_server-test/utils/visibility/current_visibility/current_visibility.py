import logging
from collections import defaultdict
from datetime import datetime
from typing import Dict, List

from cachetools import TTLCache
from peewee import IntegrityError, fn, EXCLUDED

from communication.types import ZMQTopic
from db.db_connection import db
from global_data import appdata
from models.current_angles import CurrentAngles
from utils.almanac.get_almanac_slot import get_almanac_slot
from utils.caches import station_cache
from utils.caches.cache import cache_manager
from utils.coordinates.coordinates import Coordinates
from utils.lib.kepler_to_xyz import kepler_to_xyz
from utils.visibility.current_visibility.get_nka_visibility import get_nka_visibility
from utils.visibility.types import VisibilityForClient
from utils.visibility.types.angles import Angles
from utils.visibility.types.elevation_trend import ElevationTrend
from utils.visibility.types.visibility_status import VisibilityStatus

logger = logging.getLogger(__name__)


class CurrentVisibility:
    """Текущее состояние видимости группировки со всех станций (азимут, угол места, тренд и статус)"""

    def __init__(self):
        self.angles: Dict[int, TTLCache[int, 'Angles']] = defaultdict(lambda: TTLCache(maxsize=64, ttl=300))
        self.status: Dict[int, Dict[int, 'VisibilityStatus']] = defaultdict(
            lambda: defaultdict(lambda: VisibilityStatus.UNDEFINED))
        self._last_sent_at = datetime.min
        self._zmq_manager = None

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def set_angles(self, station_number: int, nka: int,
                   azimuth: float, elevation: float,
                   trend: 'ElevationTrend') -> None:
        self.angles[station_number][nka] = Angles(
            azimuth=azimuth,
            elevation=elevation,
            trend=trend
        )

    def set_status(self, station_number: int, nka: int,
                   status: 'VisibilityStatus') -> None:
        self.status[station_number][nka] = status

    def expire_angles_for_station(self, station_number: int):
        self.angles[station_number].expire()

    def update_visibility_by_almanac(self, time_now: datetime):

        current_angles = []
        angles_out_of_sight = []
        nkas_out_of_sight = set()  # для отслеживания НКА вне ЗРВ для всех станций
        stations = station_cache.get_list()

        for nka_sys_num, nka_signals in appdata.NKA_SIGNALS.items():
            almanac_slot = get_almanac_slot(nka_sys_num)  # Получаем слот альманаха

            # При полном отсутствии альманах для НКА выводим предупреждение
            if almanac_slot is None:
                logger.warning(f'Для НКА с системной точкой {str(nka_sys_num)} отсутствует альманах.')
                continue

            # расчитываем координаты НКА для определения взамоположения относительно ПЭ
            x, y, z, _, _, _ = kepler_to_xyz(
                almanac_slot.N4,
                almanac_slot.N_A,
                almanac_slot.Tlambda_A,
                almanac_slot.deltaT_A + (43200 - 40544),
                almanac_slot.deltaI_A + (63 - 64.8) / 180,
                almanac_slot.deltaTdot,
                almanac_slot.e_A,
                almanac_slot.omega_A,
                almanac_slot.lambda_A,
                time_now
            )

            # для каждой станции из словаря текущих принятых сигналов
            for station in stations:
                coordinates = station.coordinates
                station_number = station.station_number
                # Определеляем положение их относительно ПЭ
                nka_elevation_grad = coordinates.elevation_grad(Coordinates.XYZ(x=x, y=y, z=z))
                nka_azimuth_grad = coordinates.azimuth_grad(Coordinates.XYZ(x=x, y=y, z=z))
                if nka_azimuth_grad < 0:
                    nka_azimuth_grad += 360.0

                """Определение гарантированности видимости КА по порогу угла места"""
                visibility_status = get_nka_visibility(station_number, nka_elevation_grad)
                self.set_status(station_number, nka_sys_num, visibility_status)

                if visibility_status != VisibilityStatus.OUT_OF_SIGHT:
                    self.expire_angles_for_station(station_number)

                    # Определяем направление НКА. Если нет старых значений, то неопределено
                    try:
                        _, prev_el, _ = self.angles[station_number][nka_sys_num]
                    except KeyError:
                        el_trend = ElevationTrend.UNDEFINED
                    else:
                        el_trend = (ElevationTrend.ASCENDING
                                    if prev_el <= nka_elevation_grad
                                    else ElevationTrend.DESCENDING)
                    self.set_angles(station_number, nka_sys_num, nka_azimuth_grad, nka_elevation_grad, el_trend)

                    current_nka = cache_manager.get_nka(nka_sys_num)
                    current_angles.append(
                        (current_nka, station_number, nka_elevation_grad, nka_azimuth_grad,
                         el_trend, visibility_status, time_now)
                    )
                else:
                    # НКА вне ЗРВ БИС, добавляем в кандидаты на финализацию СП для него
                    nkas_out_of_sight.add(nka_sys_num)

                    # добавляем в список на удаление инфы из БД в CurrentAngles
                    angles_out_of_sight.append((nka_sys_num, station_number))

        if current_angles:
            try:
                with db.atomic():
                    CurrentAngles.insert_many(current_angles).on_conflict(
                        conflict_target=[CurrentAngles.nka, CurrentAngles.station],
                        update={
                            CurrentAngles.elevation: EXCLUDED.elevation,
                            CurrentAngles.azimuth: EXCLUDED.azimuth,
                            CurrentAngles.visibility_state: EXCLUDED.visibility_state,
                            CurrentAngles.trend: EXCLUDED.trend,
                            CurrentAngles.timestamp: EXCLUDED.timestamp
                        }).execute()
            except IntegrityError as e:
                logger.warning(f'Ошибка при записи в CurrentAngles: {str(e)}')

        if angles_out_of_sight:
            with db.atomic():
                CurrentAngles.delete().where(
                    fn.ROW(CurrentAngles.nka, CurrentAngles.station).in_(angles_out_of_sight)
                ).execute()

        # Отправляем текущее состояние видимости
        self.send_state()

        if nkas_out_of_sight:
            self._send_nka_out_of_sight_event(list(nkas_out_of_sight))

    def _send_nka_out_of_sight_event(self, nka_list: List[int]):
        """Отправка списка НКА, вышедших из ЗРВ, для финализации СП на сокет ZMQ главного процесса"""
        try:
            self._zmq_manager.publish_data(ZMQTopic.NKA_OUT_OF_SIGHT, data=nka_list)
            logger.debug(f'Отправлен список НКА, вышедших из ЗРВ, для финализации СП: {nka_list}')
        except Exception as e:
            logger.warning(f'Ошибка отправки списка НКА, вышедших из ЗРВ, для финализации СП: {e}')

    def send_state(self) -> None:
        """Отправка текущего состояния кэша на сокет ZMQ главного процесса"""

        for station_number, nka_statuses in self.status.items():
            data_by_station: Dict[int, VisibilityForClient] = {}
            for nka, status in nka_statuses.items():
                if status > VisibilityStatus.OUT_OF_SIGHT:
                    if nka not in data_by_station:
                        data_by_station[nka] = {}
                    data_by_station[nka] = self.angles[station_number][nka]._asdict()
                    data_by_station[nka]['visibility'] = status
            try:
                self._zmq_manager.publish_data(ZMQTopic.CURRENT_ANGLES, station_number=station_number, data=data_by_station)
                logger.debug(f'Отправлено состояние кэша текущих углов на НКА для станции {station_number}')
            except Exception as e:
                logger.warning(f'Ошибка при отправке текущих углов на НКА для станции {station_number}: {e}')

        self._last_sent_at = datetime.now()

    def get_status(self, station_number: int, nka: int) -> 'VisibilityStatus':
        """Текущее состояние видимости заданного НКА с заданной станции"""
        return self.status[station_number][nka]
