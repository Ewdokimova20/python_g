import logging
from collections import defaultdict
from typing import Dict

from utils.lib.types.type_aliases import StationNum, NkaSysNum
from utils.visibility.types import VisibilityForClient, VisibilityStatus

logger = logging.getLogger(__name__)


class CurrentVisibilityForClient:
    """Текущее состояние видимости группировки со всех станций для отправки на клиент (азимут, угол места, тренд и статус)"""

    def __init__(self):
        self._visibility: Dict[StationNum, Dict[NkaSysNum, VisibilityForClient]] = defaultdict()

    def load_data(self, station_number: int, data: Dict[int, VisibilityForClient]) -> None:
        """Запись углов и статусов из дочерних процессов"""
        self._visibility[station_number] = data

    def get_data(self):
        """Отдает текущее состояние видимости на клиент"""
        result = {}
        for station_number, nka_visibility in self._visibility.items():
            for nka, visibility in nka_visibility.items():
                if nka not in result:
                    result[nka] = {}
                result[nka][station_number] = visibility
        return result

    def get_status(self, station_number: int, nka: int) -> 'VisibilityStatus':
        """Текущее состояние видимости заданного НКА с заданной станции"""
        try:
            return self._visibility[station_number][nka]['visibility']
        except KeyError:
            return VisibilityStatus.UNDEFINED


current_visibility_for_client = CurrentVisibilityForClient()
