"""Файл содержит функцию проверки состояния видимости НКА для заданной станции"""

from global_data.appdata import reliability_control_elevation as relce, receive_control_elevation as recce, \
    min_elevation as me
from utils.visibility.types import VisibilityStatus


def get_nka_visibility(station_number: int, elevation_angle_grad: float):
    """Присутствие в зоне радиовидимости конкретной станции

    Возвращает присутствие в зоне гарантированного или возможного приема
    """
    reliability_control_elevation = relce.get(station_number, relce['default'])
    receive_control_elevation = recce.get(station_number, recce['default'])
    min_elevation = me.get(station_number, me['default'])

    if elevation_angle_grad > reliability_control_elevation:
        return VisibilityStatus.RELIABILITY_CONTROL
    elif elevation_angle_grad > receive_control_elevation:
        return VisibilityStatus.GUARANTEED
    elif elevation_angle_grad > min_elevation:
        return VisibilityStatus.MAYBE
    else:
        return VisibilityStatus.OUT_OF_SIGHT
