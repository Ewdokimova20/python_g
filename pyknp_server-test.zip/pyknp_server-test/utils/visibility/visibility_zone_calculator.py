import datetime
import logging
from enum import IntEnum
from typing import List, Tuple

from typing_extensions import TypedDict

import global_data.config_schema
from utils.PDOP.AlmanacClass import kepler_to_xyz
from utils.almanac.get_almanac_slot import get_almanac_slot
from utils.caches import cache_bis
from utils.coordinates.coordinates import Coordinates
from utils.lib.get_date_from_N4_and_N import get_almanac_time_by_datetime

logger = logging.getLogger('visibility_zones')


class CalculateResult(IntEnum):
    """Коды результатов расчета ЗРВ"""
    Ok = 0,  # Расчет успешно выполнен, результат доступен
    UnorderedBorders = 1,  # начальная граница позднее во времени чем окончание
    TooLong = 2,  # интервал больше допустимого
    AlmanacUnavailable = 3,  # не доступен альманах для данного НКА
    UnknownBis = 4,  # для БИС не доступны координаты
    UnknownStation = 5,  # для станции не доступны границы видимости


calculate_result_labels = {
    CalculateResult.Ok: "Расчет успешно выполнен",
    CalculateResult.UnorderedBorders: "Начальная граница интервала по времени позднее, чем конечная",
    CalculateResult.TooLong: "Длительность интервала превышает предельное значение, заданное в файле конфигурации",
    CalculateResult.AlmanacUnavailable: "Недоступен альманах для данного НКА",
    CalculateResult.UnknownBis: "Недоступны координаты для данного БИС",
    CalculateResult.UnknownStation: "Для станции недоступны границы видимости"
}


class VisibilityZoneData(TypedDict):
    nka: int
    bis_id: int
    possible_receive_time_start: datetime.datetime
    guaranteed_receive_time_start: datetime.datetime
    possible_receive_time_end: datetime.datetime
    guaranteed_receive_time_end: datetime.datetime


def calc_visibility_zones_for_single_nka(bis_id: int, nka_id: int, interval_start: datetime,
                                         interval_end: datetime.datetime
                                         ) -> Tuple[CalculateResult, List[VisibilityZoneData]]:
    """Возвращает код результата расчета и список ЗРВ для заданных НКА и БИС

    Args:
        bis_id (int): id Bis.
        nka_id (int): id Nka.
        interval_start (datetime): начало интервала.
        interval_end (datetime.datetime): конец интервала.

    Returns:
        Tuple[CalculateResult, List[VisibilityZoneData]]: кортеж кодов результата расчёта ЗРВ и шаблон заполненный значениями краев
    """

    # блок проверки корректности входных данных и подготовки ИД расчета
    if interval_start > interval_end:
        logging.debug(calculate_result_labels[CalculateResult.UnorderedBorders])
        return CalculateResult.UnorderedBorders, []

    nka_almanac = get_almanac_slot(nka_id)
    if nka_almanac is None:
        logging.debug(calculate_result_labels[CalculateResult.AlmanacUnavailable])
        return CalculateResult.AlmanacUnavailable, []

    bis = cache_bis.get_item_by_id(bis_id)
    if bis is None:
        logging.debug(calculate_result_labels[CalculateResult.UnknownBis])
        return CalculateResult.UnknownBis, []

    bis_coordinates = bis.coordinates
    # получаем значения углов возможного и гарантированного приема
    current_station = bis.station

    possible_elevation = 1.0 * current_station.min_elevation
    guaranteed_elevation = 1.0 * current_station.receive_control_elevation

    # подготавливаем данные для проведения расчета
    step_s = global_data.config_schema.config["zrv_analyse"]["step"]
    current_fragment_start = interval_start
    zone_list: List[VisibilityZoneData] = []

    # шаблон заполненный значениями краев нужен для корректной обработки первой и последней зоны, границы которых не будут полноценно определены
    zone_data: VisibilityZoneData = {
        "nka": nka_id,
        "bis_id": bis_id,
        "possible_receive_time_start": interval_start,
        "guaranteed_receive_time_start": interval_start,
        "possible_receive_time_end": interval_end,
        "guaranteed_receive_time_end": interval_end,
    }
    current_zone = zone_data.copy()

    # далее реализован (фактически) ДКА, определяющий границы ЗРВ
    is_possible_receive_prev = False
    is_guaranteed_receive_prev = False

    # непосредственный расчет
    while current_fragment_start < interval_end:
        # рассчитываем момент прогноза в терминах прогноза по альманаху
        (N4_current, NA_current, ti) = get_almanac_time_by_datetime(current_fragment_start)
        # рассчитываем координаты НКА для определения взаимоположения относительно ПЭ
        x, y, z, _, _, _ = kepler_to_xyz(nka_almanac.N4, nka_almanac.N_A, nka_almanac.Tlambda_A,
                                         nka_almanac.deltaT_A + (43200 - 40544),
                                         nka_almanac.deltaI_A + (63 - 64.8) / 180,
                                         nka_almanac.deltaTdot, nka_almanac.e_A,
                                         nka_almanac.omega_A, nka_almanac.lambda_A,
                                         current_fragment_start)

        # определяем положение НКА относительно ЗРВ выбранного ПЭ
        nka_elevation_grad = bis_coordinates.elevation_grad(Coordinates.XYZ(x=x, y=y, z=z))
        is_possible_receive = nka_elevation_grad > possible_elevation
        is_guaranteed_receive = nka_elevation_grad > guaranteed_elevation

        # определяем пересечение границ видимости
        if is_guaranteed_receive_prev != is_guaranteed_receive:  # вошел в область или вышел из области гарантированного приема (важно изменение состояния)
            if is_guaranteed_receive:
                current_zone['guaranteed_receive_time_start'] = current_fragment_start
            else:
                current_zone['guaranteed_receive_time_end'] = current_fragment_start
        if is_possible_receive_prev != is_possible_receive:  # вошел в ЗРВ или вышел из ЗРВ (важно изменение состояния)
            if is_possible_receive:  # был не виден, а стал виден
                current_zone['possible_receive_time_start'] = current_fragment_start
                if current_zone['guaranteed_receive_time_start'] < current_zone['possible_receive_time_start']:
                    current_zone['guaranteed_receive_time_start'] = interval_end
            else:
                current_zone['possible_receive_time_end'] = current_fragment_start
                if current_zone['guaranteed_receive_time_end'] > current_zone['possible_receive_time_end']:
                    current_zone['guaranteed_receive_time_end'] = interval_start
                # НКА вышел из зоны, больше изменений в рамках этой зоны не будет
                zone_list.append(current_zone)
                current_zone = zone_data.copy()

        # запоминаем прошлое состояние для выявления границ зон
        is_possible_receive_prev = is_possible_receive
        is_guaranteed_receive_prev = is_guaranteed_receive

        # вычисляем следующее время расчета
        current_fragment_start += datetime.timedelta(seconds=step_s)

    # мы закончили обработку интервала, но последняя зона могла быть не финализирована
    # если на момент конца расчета НКА в ЗРВ, то текущее состояние нужно использовать в качестве описания последней зоны
    if is_possible_receive_prev:
        zone_list.append(current_zone)

    return CalculateResult.Ok, zone_list
