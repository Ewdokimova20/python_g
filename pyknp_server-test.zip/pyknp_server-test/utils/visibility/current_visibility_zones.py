from datetime import datetime
from typing import Optional, List, Dict

from peewee import IntegerField, DateTimeField

from models.base import BaseModel
from models.visibility_zone import VisibilityZone

FULL_CACHE_UPDATE_RATE = 60
"""Периодичность полного обновления текущих ЗРВ для всех НКА в кэше, секунд"""


class CurrentVisibilityZone(BaseModel):
    """
    Модель для представления текущих ЗРВ
    """
    nka: int = IntegerField()
    bis_id: int = IntegerField()
    zone_start: datetime = DateTimeField()
    zone_end: datetime = DateTimeField()

    class Meta:
        schema = 'visibility'
        table_name = 'current_visibility_zone'
        primary_key = False


class CurrentVisibilityZoneCache:
    """
    Класс кэша с длящейся на текущий момент времени ЗРВ для всех НКА
    """

    def __init__(self, bis_id: int):
        self.bis_id = bis_id
        self.cache: Dict[int, CurrentVisibilityZone] = {}
        self.last_update_all = datetime.min
        self.update_all_from_db()

    def update_all_from_db(self, current_time=datetime.now()):
        """
        Обновить в кэше текущие ЗРВ для всех НКА из ТЛБД, если пора
        """

        if (current_time - self.last_update_all).total_seconds() >= FULL_CACHE_UPDATE_RATE:
            zones_for_all_nka: List[CurrentVisibilityZone] = list((CurrentVisibilityZone
                                                                   .select()
                                                                   .where(CurrentVisibilityZone.bis_id == self.bis_id)))
            for zone in zones_for_all_nka:
                self.cache[zone.nka] = zone
            self.last_update_all = datetime.now()

    def get_zone(self, nka_id: int) -> Optional[VisibilityZone]:
        """
        Берет для заданного НКА ЗРВ из кэша или загружает ее из ТЛБД, если ее нет в кэше
        """
        return self.cache.get(nka_id)
