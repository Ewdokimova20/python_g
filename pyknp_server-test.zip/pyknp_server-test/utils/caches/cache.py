from typing import Optional

from cachetools import TTLCache

from models.nka import Nka
from models.signal_type import SignalType
from models.station import Station


class CacheManager:
    """класс CacheManager, который будет управлять кэшем и иметь методы для получения, сохранения и удаления данных из кэша"""

    def __init__(self):
        # Создаем кэш с максимальным размером 100 и временем жизни ttl 60 секунд
        self.cache_nka = TTLCache(maxsize=1000, ttl=600)
        """Кэш для НКА"""

        # Создаем кэш с максимальным размером 1000 и временем жизни ttl
        self.cache_signal_type = TTLCache(maxsize=1000, ttl=43200)
        """Кэш для таблицы: Тип сигнала."""

        # Создаем кэш с максимальным размером 1000 и временем жизни ttl - 12 часов
        self.cache_all_bis = TTLCache(maxsize=1000, ttl=43200)
        """Кэш для таблицы: БИС (aka комплект). Возвращает все записи."""

        # Создаем кэш с максимальным размером 1000 и временем жизни ttl
        self.cache_station = TTLCache(maxsize=1000, ttl=43200)
        """Кэш для таблицы: Станция беззапросных измерительных средств (БИС)."""

    def get_nka(self, nka_sys_number: int) -> Optional[Nka]:
        """Возвращает экземпляр НКА с заданным номером из кэша, если есть.

        Args:
            nka_sys_number (int): системный номер НКА.

        Returns:
            Optional[Nka]: экземпляр НКА или None.
        """

        # Проверяем, есть ли данные для данного nka в кэше
        nka = self.cache_nka.get(nka_sys_number)
        if nka is None:
            # Если данных нет в кэше, делаем запрос к БД и сохраняем результат в кэше
            nka = Nka.get_or_none(Nka.nka_sys_number == nka_sys_number)
            self.cache_nka[nka_sys_number] = nka
        return nka

    def get_or_create_nka(self, nka_sys_num: int) -> Nka:
        """
        Возвращает экземпляр НКА с заданным номером из кэша

        Если отсутствует в кэше, то создает его в ЛБД, пишет в кэш и возвращает.

        Args:
            nka_sys_num: системный номер НКА
        Returns:
            Nka: НКА
        """

        # Проверяем, есть ли данные для данного nka в кэше или в БД
        nka = self.get_nka(nka_sys_num)
        if nka is not None:
            return nka

        # Если данных нет ни в кэше, ни в БД, создаем в БД и сохраняем результат в кэше
        nka, _ = Nka.get_or_create(nka_sys_number=nka_sys_num)  # не просто create из за гонки между процессами
        self.cache_nka[nka_sys_num] = nka
        return nka

    def get_signal_type(self, signal_type_id: int) -> Optional[int]:
        """Получаем тип сигнала

        Args:
            signal_type_id (int): id типа сигнала.

        Returns:
            Optional[int]: id типа сигнала или None.
        """

        # Проверяем, есть ли данные для данного signal_type_id в кэше
        signal_type = self.cache_signal_type.get(signal_type_id)
        if signal_type is None:
            # Если данных нет в кэше, делаем запрос к БД и сохраняем результат в кэше
            signal_type = SignalType.get_or_none(SignalType.signal_type_id == signal_type_id)
            self.cache_signal_type[signal_type_id] = signal_type
        return signal_type

    def get_station(self, station_number: int) -> Optional[Station]:
        """Возвращает объект станции

        Args:
            station_number (int): id станции.

        Returns:
            Optional[Station]: Объект Station, если найден, иначе None.
        """

        station = self.cache_station.get(station_number)
        if station is None:
            # Если данных нет в кэше, делаем запрос к БД и сохраняем результат в кэше
            station = Station.get_or_none(Station.station_number == station_number)
            self.cache_station[station_number] = station
        return station


cache_manager = CacheManager()
"""Кэш менеджер"""
