from abc import ABC, abstractmethod


class BaseCache(ABC):

    @abstractmethod
    def get_item_by_key(self, *args):
        """Получение данных"""
        pass

    def get_all_cache_data(self):
        """Получение всего кэша данных"""
        pass

    @abstractmethod
    def add_data(self, *args):
        """Добавление данных"""
        pass

    def update_cache_data_from_db(self, *args):
        """Обновление данных из базы данных"""
        pass
