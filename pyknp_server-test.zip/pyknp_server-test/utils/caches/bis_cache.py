from typing import Dict, Optional, Tuple, List

from models.bis import Bis
from utils.caches.base_model_cache import BaseCache


class BisCache(BaseCache):
    def __init__(self):
        self._cache: Dict[Tuple[int, int], Bis] = {}
        self.model = Bis

    def add_data(self, bis_number: int, station_number: int, bis: Bis) -> None:
        """Добавление данных в кэш для модели

        Args:
            bis_number (int): номер Bis.
            station_number (int): номер станции.
            bis (Bis): модель Bis.

        Returns:
            None
        """
        _ = bis.coordinates  # инициализация кэшируемого свойства coordinate для Bis
        self._cache[(bis_number, station_number)] = bis

    def get_item_by_key(self, bis_number: int, station_number: int) -> Optional[Bis]:
        """Получение данных из кэша для модели

        Args:
            bis_number (int): номер Bis.
            station_number (int): номер станции.

        Returns:
            Optional[Bis]: модель Bis или None.
        """
        return self._cache.get((bis_number, station_number))

    def get_item_by_id(self, bis_id: int) -> Optional[Bis]:
        """Получение данных из кэша для модели по id

        Args:
            bis_id (int): id Bis.

        Returns:
            Optional[Bis]: модель Bis или None.
        """
        for bis in self._cache.values():
            if bis.id == bis_id:
                return bis
        return None

    def get_all(self) -> Dict[Tuple[int, int], Bis]:
        """Получение всего кэша с ключами для БИС

        Returns:
            Dict[Tuple[int, int], Bis]: весь кэш с ключами для БИС
        """
        return self._cache

    def get_bis_list(self) -> List[Bis]:
        """Получение всех БИСов из кэша

        Returns:
            List[Bis]: массив всех бисов
        """
        return list(self._cache.values())

    def __str__(self):
        return f"{self.__class__.__name__}: cache={self._cache}"


# Создание экземпляров кэша
cache_bis = BisCache()
"""Кэш для Bis"""
