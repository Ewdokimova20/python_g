from typing import Dict, Optional, List

from models.station import Station
from utils.caches.base_model_cache import BaseCache
from utils.coordinates.coordinates import Coordinates


class StationCache(BaseCache):
    def __init__(self):
        self._cache: Dict[int, Station] = {}

    def add_data(self, station: 'Station', coordinates: 'Coordinates') -> None:
        """Добавление данных в кэш для модели

        Args:
            station (int): объект станции
            coordinates (Coordinates): координаты одного из БИС, расположенных на этой станции

        Returns:
            None
        """
        station.coordinates = coordinates
        self._cache[station.station_number] = station

    def get_item_by_key(self, station_number: int) -> Optional['Station']:
        """Получение данных из кэша для модели

        Args:
            station_number (int): номер станции.

        Returns:
            Optional[Station]: модель Station или None.
        """
        return self._cache.get(station_number)

    def get_list(self) -> List['Station']:
        """Получение всех станций из кэша

        Returns:
            List[Station]: список объектов станций
        """
        return list(self._cache.values())

    def __str__(self):
        return f"{self.__class__.__name__}: cache={self._cache}"


# Создание экземпляров кэша
station_cache = StationCache()
"""Кэш для станций"""
