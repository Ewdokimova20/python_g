import logging
from collections import defaultdict
from datetime import datetime
from typing import DefaultDict, TYPE_CHECKING

from cachetools import TTLCache

from communication.types import ZMQTopic
from global_data.appdata import GLONASS_SIGNALS
from utils.nav_solution.types import NavSolutionType, ZMQRecentNavSolutionsCache

if TYPE_CHECKING:
    from data import KNPNavSolution

logger = logging.getLogger(__name__)

SEND_INTERVAL_SECONDS = 3  # интервал передачи текущего состояния кэша в секундах


class RecentNavSolutionsCache:
    """
    Кэш списков последних значений невязок для всех БИС, НКА и сигналов, накопленных за время RESIDUAL_CACHE_TTL.
    Кэш отправляет свое состояние главному процессу раз в SEND_INTERVAL_SECONDS.
    """
    first_signals_in_residuals_pair = [0x01, 0x21, 0x06, 0x46, 0x26, 0x66, 0x16, 0x56]
    """Список первых сигналов из пар сигналов, по которым считаются невязки"""

    def __init__(self, cache_type: NavSolutionType):
        self._cache_type = cache_type
        self._cache: DefaultDict[int, TTLCache] = defaultdict(lambda: TTLCache(maxsize=30, ttl=30))
        self._last_sent_at = datetime.min
        self._zmq_manager = None

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def append(self, solution: 'KNPNavSolution') -> None:
        """Добавление новой невязки в кэш"""
        signal_type = solution.signal_id
        if signal_type in GLONASS_SIGNALS and signal_type in self.first_signals_in_residuals_pair:
            self._cache[solution.bis.id][signal_type] = solution

        # Проверяем необходимость персистентного сохранения
        if (datetime.now() - self._last_sent_at).seconds >= SEND_INTERVAL_SECONDS:
            self.send_cache_state()

    def expire(self) -> None:
        """Принудительное удаление устаревших записей из всех кэшей"""

        for bis_cache in self._cache.values():
            bis_cache.expire()

    def send_cache_state(self) -> None:
        """Отправка текущего состояния кэша на сокет ZMQ галвного процесса"""

        for bis_id, bis_cache in self._cache.items():
            if bis_cache:
                is_data_present = False
                data_by_bis = {}

                for signal_type, solution in bis_cache.items():
                    if solution:
                        is_data_present = True
                        data_by_bis[signal_type] = solution.as_dict()

                if is_data_present:
                    try:
                        logger.debug(f'Отправка состояния кэша НВЗ для БИС {bis_id}')
                        message_data = ZMQRecentNavSolutionsCache(cache_type=self._cache_type, data=data_by_bis)
                        self._zmq_manager.publish_data(ZMQTopic.RECENT_NAV_SOLUTIONS_CACHE, bis_id=bis_id, data=message_data)
                    except Exception as e:
                        logger.warning(f'Ошибка при отправке состояния кэша НВЗ для БИС {bis_id}: {e}')

        self._last_sent_at = datetime.now()
