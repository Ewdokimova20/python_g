import time
from copy import deepcopy
from typing import Tuple, Dict

from global_data.user_navsolution_parameters import PERMITED_TIME_FOR_USER_SOLUTION
from models.knp_nav_solution.types.nav_solution_for_client import NavSolutionForClient
from utils.nav_solution.types import NavSolutionType, ZMQRecentNavSolutionsCache


class NavSolutionsCacheForClient:
    """Кэш последних рассчитанных решений НВЗ для всех БИС, НКА и сигналов"""

    TIMEOUT = PERMITED_TIME_FOR_USER_SOLUTION  # время в секундах для сброса кэша, взято для обнуления пользовательского НВЗ,

    # но не помешает сбрасывать и мгновенные нвз

    def __init__(self):
        self.data: Dict[NavSolutionType, Dict[int, Dict[int, NavSolutionForClient]]] = {NavSolutionType.IMMEDIATE: {},
                                                                                        NavSolutionType.USER: {},
                                                                                        NavSolutionType.BEST: {}}
        # Время последнего обновления для каждого типа
        self.last_update_time: Dict[NavSolutionType, float] = {
            NavSolutionType.IMMEDIATE: 0,
            NavSolutionType.USER: 0,
            NavSolutionType.BEST: 0
        }

    def load_data(self, bis_id: int, data: ZMQRecentNavSolutionsCache) -> None:
        """Запись невязок в кэш"""
        nav_solution_type = data['cache_type']
        self.data[nav_solution_type][bis_id] = data['data']
        self.last_update_time[nav_solution_type] = time.time()

    def _check_and_reset_expired(self):
        """Проверка времени последнего обновления и обнуление устаревших данных"""
        current_time = time.time()
        for nav_type in self.data.keys():
            if current_time - self.last_update_time[nav_type] > self.TIMEOUT:
                self.data[nav_type] = {}
                self.last_update_time[nav_type] = 0

    def get_data(self) -> Tuple[Dict[NavSolutionType, Dict[int, Dict[int, NavSolutionForClient]]], bool]:
        """Метод для API, возвращающий последние записанные невязки"""
        self._check_and_reset_expired()

        data = deepcopy(self.data)  # копия сделана для того, чтоб параллельное изменение self.data не повлияло на эту функцию
        is_data_present = any(any(solution_dict.values()) for solution_dict in self.data.values())

        return data, is_data_present


nav_solutions_cache_for_client = NavSolutionsCacheForClient()
