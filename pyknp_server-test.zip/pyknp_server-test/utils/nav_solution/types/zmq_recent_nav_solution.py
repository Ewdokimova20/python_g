from typing import Dict

from typing_extensions import TypedDict

from models.knp_nav_solution import NavSolutionForClient
from utils.nav_solution.types import NavSolutionType


class ZMQRecentNavSolutionsCache(TypedDict):
    """Типизированный словарь полезной нагрузки сообщения с темой RECENT_NAV_SOLUTIONS_CACHE для обмена через ZMQ """
    cache_type: NavSolutionType
    data: Dict[int, NavSolutionForClient]
