from enum import Enum


class NavSolutionType(str, Enum):
    """Перечисление возможных типов решения НВЗ"""
    IMMEDIATE = 'immediate'
    USER = 'user'
    BEST = 'best'
