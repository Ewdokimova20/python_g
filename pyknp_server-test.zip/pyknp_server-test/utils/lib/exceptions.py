class BadEIException(BaseException):
    """Исключение для случая, когда ЭИ не получилось размножить"""
    pass


class ParseDIStringError(Exception):
    """Исключение для случая, когда при расшифровке строки с кодовым разделением возникла ошибка"""

    def __init__(self, message, content, string_num=None):
        self.message = message
        self.string_num = string_num
        self.content = content


class CompareDItoSIError(Exception):
    """Исключение для случая, когда при сравнении ЭИ, ЧВП и альманаха из ЦИ с заложенными СИ возникла ошибка"""
    pass


class CompareEIinDIError(Exception):
    """Исключение для случая, когда при сравнении ЭИ в ЦИ на соседних интервалах возникла ошибка"""
    pass


class ResidualCalcError(Exception):
    """Исключение для случая, когда при расчете невязки возникла ошибка"""
    pass


class LFImmediateInfoError(Exception):
    """Исключение для случая, когда в LFImmediateInfo нету пары НКА - Сигнал"""

    def __init__(self, message: str):
        super().__init__(message)


class LCImmediateInfoError(Exception):
    """Исключение для случая, когда в LCImmediateInfo нету пары НКА - Сигнал"""

    def __init__(self, message: str):
        super().__init__(message)


class BisCacheError(Exception):
    """Исключение для случая, когда в bis_cache нет значения и возвращается None"""

    def __init__(self, message: str):
        super().__init__(message)


class MissingParamError(Exception):
    """Исключение для случая, когда попытке получить параметр из строки ЦИ возникает ошибка"""
    pass
