from functools import wraps

from global_data.config_schema import config


class PacketDecimator:
    """Декоратор для прореживания вызовов функций обработки пакетов.

    Особенности:
    - Гарантирует однократный вызов функции при старте программы
    - Далее выполняет прореживание каждого N-ого пакета (N задается аргументом декоратора), кроме метеопараметров
    - Отдельная логика прореживания для пакетов c метеопараметрами (не по счетчику сообщений, а раз в N секунд)
    - Раздельное отслеживание счетчиков для каждой функции

    Attributes:
        _counters (dict): Словарь счетчиков для каждой функции.
        _first_run (dict): Флаги первого запуска для каждой функции.
    """

    def __init__(self):
        """Инициализирует экземпляр PacketDecimator."""
        self._counters = {}  # словарь счетчиков для каждой функции
        self._first_run = {}  # флаги первого запуска для каждой функции

    def decimate(self, interval_config_path):
        """Декоратор для прореживания вызовов функций.

        Args:
            interval_config_path (str): Путь к значению интервала в конфиге.

        Returns:
            callable: Декоратор для функции обработки пакетов.
        """

        def decorator(func):
            """Внутренний декоратор для обработки функции.

            Args:
                func (callable): Декорируемая функция.

            Returns:
                callable: Обертка для функции с логикой прореживания.
            """
            func_name = func.__name__

            # Инициализируем флаг первого запуска для функции
            self._first_run[func_name] = True

            @wraps(func)
            def wrapper(*args, **kwargs):
                """Обертка для функции с логикой прореживания.

                Args:
                    *args: Позиционные аргументы функции.
                    **kwargs: Именованные аргументы функции.

                Returns:
                    Any: Результат функции или None.
                """
                # Проверяем, есть ли аргументы
                if not args:
                    return func(*args, **kwargs)

                # Инициализация счетчика для функции, если его нет
                if func_name not in self._counters:
                    self._counters[func_name] = 0

                # Проверяем, первый ли это запуск
                if self._first_run[func_name]:
                    self._first_run[func_name] = False
                    return func(*args, **kwargs)

                # Получаем интервал из конфига
                interval = self._get_config_value(interval_config_path)

                # Увеличиваем счетчик
                self._counters[func_name] += 1

                # Проверяем, нужно ли обрабатывать пакет (все остальные типы пакетов)
                if self._counters[func_name] % interval == 0:
                    result = func(*args, **kwargs)
                    # Сбрасываем счетчик
                    self._counters[func_name] = 0
                    return result

                return None

            return wrapper

        return decorator

    @staticmethod
    def _get_config_value(path):
        """Получение значения из конфига по пути.

        Args:
            path (str): Путь к значению в конфигурации.

        Returns:
            Any: Значение из конфигурации по указанному пути.
        """
        parts = path.split('.')
        value = config
        for part in parts:
            value = value[part]
        return value


# Создаем единственный экземпляр декоратора
packet_decimator = PacketDecimator()
