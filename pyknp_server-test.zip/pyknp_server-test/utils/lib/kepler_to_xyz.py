import datetime
from math import pi, sin, cos, atan, tan
from utils.lib.get_date_from_N4_and_N import get_date_from_N4_and_N
#import utils.PDOP.AlmanacClass as AlmanacClass
#from utils.PDOP.AlmanacClass import get_n4_na_by_date




def kepler_to_xyz(N4: int, Na: int, tlambdaA: float, deltatA: float, deltaia: float, deltaTdot: float, ea: float, omegala: float, lambdaA: float,
                  ti: datetime) -> list:  # перевод кеплеровых элементов в координаты
    """
 Реализация алгоритма расчета координат и вектора скорости по данным альманаха
 Приложение Н к ИКД (общее описание системы с КРС),п. Н.1 т.е. функция расчета координат и скоростей КА на заданный момент времени по данным альманаха.

   :param N4: номер четырехлетия от 1996 года
   :param Na: номер суток в четырехлетии,на который заданы параметры движения КА
   :param tlambdaA: момент времени, на который заданы параметры движения КА, с (первое прохождение ДВУ с начала суток)
   :param deltatA: поправка к среднему значению для кодовых сигналов (40544 с) драконического периода обращения, с
   :param deltaia: поправка к номинальному значению для кодовых сигналов (64.8 градуса) наклонения орбиты КА, полуциклы
   :param deltaTdot: скорость изменения Драконического периода, б/р
   :param ea: эксцентриситет, б/р
   :param omegala: аргумент перигея, полуциклы
   :param lambdaA: долгота восходящего узла (ДВУ), полуциклы
   :param ti: момент времени в сутках, на который нужно рассчитать координаты, с

    :returns out: вектор кинематических параметров КА на заданный момент времени (координаты,м и скорость,м/с)
    """
    Tsr = 40544 # номинальное значение периода обращения КА (ИКД с КР)

    # 1 - расчет интервала прогноза в секундах

    deltatpr = ti - (get_date_from_N4_and_N(Na, N4) + datetime.timedelta(seconds = tlambdaA)) # интервал интегрирования через datetime.
    deltatpr = deltatpr.total_seconds()  # переводим интервал интегрирования в секунды

    # 2 - расчет количества целых витков на интервале прогноза
    W = (deltatpr / (Tsr + deltatA)) - ((deltatpr / (Tsr + deltatA)) % 1)

    # 3 - расчет текущего наклонения
    isr = 64.8 # номинальное значение наклонения орбиты
    i = (isr / 180 + deltaia) * pi

    # 4 - расчет среднего драконического периода на витке W + 1 и среднего движения
    Tdr = Tsr + deltatA + (2 * W + 1) * deltaTdot
    n = 2 * pi / Tdr

    # 5 - итеративный рассчет большой полуоси
    GM = 398600441800000  # геоцентрическая константа ГПЗ с учетом атмосферы
    a = (((Tdr / (2 * pi)) ** 2) * GM) ** (1 / 3)  # начальное приближение
    ae = 6378136 # радиус Земли
    J02 = 1082.62575e-6  # зональный гармонический коэффициент 2й степени
    an1 = a + 1000
    while (abs(an1 - a) >= 1e-2):
        a = an1
        pn = a * (1 - ea ** 2)
        Tosk = Tdr / (1 - 3 / 2 * J02 * ((ae / pn) ** 2) * (
                    (2 - 5 / 2 * (sin(i)) ** 2) * ((1 - ea ** 2) ** (3 / 2)) / ((1 + ea * cos(omegala * pi)) ** 2) + (
                        (1 + ea * cos(omegala * pi)) ** 3) / (1 - ea ** 2)))
        an1 = (((Tosk / (2 * pi)) ** 2) * GM) ** (1 / 3)

    a = an1

    # 6 - определение текущих значений ДВУ и аргумента перигея
    wz = 7.2921150e-5
    lambdA = lambdaA * pi - (wz + 3 / 2 * J02 * n * ((ae / pn) ** 2) * cos(i)) * deltatpr #+ 6.02401539573 + wz*(33300 - 10800)  # последние 2 слагаемых ЧР
    omega = omegala * pi - 3 / 4 * J02 * n * ((ae / pn) ** 2) * (1 - 5 * (cos(i) ** 2)) * deltatpr

    # 7 - расчет средней долготы на момент прохождения текущего восходящего узла
    E0 = -2 * atan((((1 - ea) / (1 + ea)) ** 0.5) * tan(omega / 2))
    L1 = omega + E0 - ea * sin(E0)

    # 8 - расчет текущего значения средней долготы НКА
    L = L1 + n * (deltatpr - (Tsr + deltatA) * W - deltaTdot * (W ** 2))

    # 9 - корректировка параметров с учетом периодических возмущений от сжатия Земли
    l = ea * cos(omega)
    h = ea * sin(omega)

    B = 3 / 2 * J02 * (ae / a) ** 2

    Lk = L1

    da1 = 2 * B * (1 - 3 / 2 * (sin(i) ** 2)) * (l * cos(Lk) + h * sin(Lk)) + \
          B * (sin(i) ** 2) * (1 / 2 * h * sin(Lk) - 1 / 2 * l * cos(Lk) + cos(2 * Lk) + 7 / 2 * l * cos(
        3 * Lk) + 7 / 2 * h * sin(3 * Lk))

    dh1 = B * (1 - 3 / 2 * (sin(i) ** 2)) * (sin(Lk) + 3 / 2 * l * sin(2 * Lk) - 3 / 2 * h * cos(2 * Lk)) \
          - 1 / 4 * B * (sin(i) ** 2) * (
                      sin(Lk) - 7 / 3 * sin(3 * Lk) + 5 * l * sin(2 * Lk) - 17 / 2 * l * sin(4 * Lk) + 17 / 2 * h * cos(
                  4 * Lk) + h * cos(2 * Lk)) \
          - 1 / 2 * B * (cos(i) ** 2) * l * sin(2 * Lk)

    dl1 = B * (1 - 3 / 2 * (sin(i) ** 2)) * (cos(Lk) + 3 / 2 * l * cos(2 * Lk) + 3 / 2 * h * sin(2 * Lk)) \
          - 1 / 4 * B * (sin(i) ** 2) * (-cos(Lk) - 7 / 3 * cos(3 * Lk) - 5 * h * sin(2 * Lk) - 17 / 2 * l * cos(
        4 * Lk) - 17 / 2 * h * sin(4 * Lk) + l * cos(2 * Lk)) \
          + 1 / 2 * B * h * (cos(i) ** 2) * sin(2 * Lk)

    dlambda1 = -B * cos(i) * (7 / 2 * l * sin(Lk) - 5 / 2 * h * cos(Lk) - 1 / 2 * sin(2 * Lk) - 7 / 6 * l * sin(
        3 * Lk) + 7 / 6 * h * cos(3 * Lk))

    di1 = 1 / 2 * B * sin(i) * cos(i) * (
                -l * cos(Lk) + h * sin(Lk) + cos(2 * Lk) + 7 / 3 * l * cos(3 * Lk) + 7 / 3 * h * sin(3 * Lk))

    dL1 = 2 * B * (1 - 3 / 2 * (sin(i) ** 2)) * (7 / 4 * l * sin(Lk) - 7 / 4 * h * cos(Lk)) \
          + 3 * B * (sin(i) ** 2) * (
                      -7 / 24 * h * cos(Lk) - 7 / 24 * l * sin(Lk) - 49 / 72 * h * cos(3 * Lk) + 49 / 72 * l * sin(
                  3 * Lk) + 1 / 4 * sin(2 * Lk)) \
          + B * (cos(i) ** 2) * (7 / 2 * l * sin(Lk) - 5 / 2 * h * cos(Lk) - 1 / 2 * sin(2 * Lk) - 7 / 6 * l * sin(
        3 * Lk) + 7 / 6 * h * cos(3 * Lk))

    Lk = L

    da2 = 2 * B * (1 - 3 / 2 * (sin(i) ** 2)) * (l * cos(Lk) + h * sin(Lk)) \
          + B * (sin(i) ** 2) * (1 / 2 * h * sin(Lk) - 1 / 2 * l * cos(Lk) + cos(2 * Lk) + 7 / 2 * l * cos(
        3 * Lk) + 7 / 2 * h * sin(3 * Lk))

    dh2 = B * (1 - 3 / 2 * (sin(i) ** 2)) * (sin(Lk) + 3 / 2 * l * sin(2 * Lk) - 3 / 2 * h * cos(2 * Lk)) \
          - 1 / 4 * B * (sin(i) ** 2) * (
                      sin(Lk) - 7 / 3 * sin(3 * Lk) + 5 * l * sin(2 * Lk) - 17 / 2 * l * sin(4 * Lk) + 17 / 2 * h * cos(
                  4 * Lk) + h * cos(2 * Lk)) \
          - 1 / 2 * B * (cos(i) ** 2) * l * sin(2 * Lk)

    dl2 = B * (1 - 3 / 2 * (sin(i) ** 2)) * (cos(Lk) + 3 / 2 * l * cos(2 * Lk) + 3 / 2 * h * sin(2 * Lk)) \
          - 1 / 4 * B * (sin(i) ** 2) * (-cos(Lk) - 7 / 3 * cos(3 * Lk) - 5 * h * sin(2 * Lk) - 17 / 2 * l * cos(
        4 * Lk) - 17 / 2 * h * sin(4 * Lk) + l * cos(2 * Lk)) \
          + 1 / 2 * B * h * (cos(i) ** 2) * sin(2 * Lk)

    dlambda2 = -B * cos(i) * (7 / 2 * l * sin(Lk) - 5 / 2 * h * cos(Lk) - 1 / 2 * sin(2 * Lk) - 7 / 6 * l * sin(
        3 * Lk) + 7 / 6 * h * cos(3 * Lk))

    di2 = 1 / 2 * B * sin(i) * cos(i) * (
                -l * cos(Lk) + h * sin(Lk) + cos(2 * Lk) + 7 / 3 * l * cos(3 * Lk) + 7 / 3 * h * sin(3 * Lk))

    dL2 = 2 * B * (1 - 3 / 2 * (sin(i) ** 2)) * (7 / 4 * l * sin(Lk) - 7 / 4 * h * cos(Lk)) \
          + 3 * B * (sin(i) ** 2) * (
                      -7 / 24 * h * cos(Lk) - 7 / 24 * l * sin(Lk) - 49 / 72 * h * cos(3 * Lk) + 49 / 72 * l * sin(
                  3 * Lk) + 1 / 4 * sin(2 * Lk)) \
          + B * (cos(i) ** 2) * (7 / 2 * l * sin(Lk) - 5 / 2 * h * cos(Lk) - 1 / 2 * sin(2 * Lk) - 7 / 6 * l * sin(
        3 * Lk) + 7 / 6 * h * cos(3 * Lk))

    hbar = h + dh2 - dh1
    lbar = l + dl2 - dl1
    abar = a + (da2 - da1) * a
    ebar = (hbar ** 2 + lbar ** 2) ** 0.5
    ibar = i + di2 - di1
    lambdabar = lambdA + dlambda2 - dlambda1# - (6.02401539573+ wz* ti)
    omegabar = pi + atan(hbar / lbar)
    Lbar = L + dL2 - dL1

    # 10 -  расчет эксцентрической аномалии
    Ei0 = Lbar - omegabar
    Ei = Ei0 + 1e-8
    while abs(Ei0 - Ei) > 1e-9:
        Ei0 = Ei
        Ei = Lbar - omegabar + ebar * sin(Ei0)

    # 11 - расчет истинной аномалии и аргумента широты
    v = 2 * atan((((1 + ebar) / (1 - ebar)) ** 0.5) * tan(Ei / 2))
    u = v + omegabar

    # 12  рассчет координат ЦМ НКА
    lambdabar = lambdabar   #+ 6.02401539573 + wz*(33300 - 10800) # это слагаемое нужно использовать для проверки примера в ИКД с ЧР -
    p = abar * (1 - ebar ** 2)
    r = p / (1 + ebar * cos(v))
    x = r * (cos(lambdabar) * cos(u) - sin(lambdabar) * sin(u) * cos(ibar))
    y = r * (sin(lambdabar) * cos(u) + cos(lambdabar) * sin(u) * cos(ibar))
    z = r * sin(u) * sin(ibar)

    # 13 - расчет составляющих вектора скорости
    vr = ((GM/p)**0.5)*ebar*sin(v)
    vu = ((GM/p)**0.5)*(1+ ebar*cos(v))

    vx = vr * (cos(lambdabar)*cos(u)-sin(lambdabar)*sin(u)*cos(ibar))\
         -vu * (cos(lambdabar)*sin(u)+sin(lambdabar)*cos(u)*cos(ibar)) + wz*y
    vy = vr * (sin(lambdabar)*cos(u)+cos(lambdabar)*sin(u)*cos(ibar))\
         -vu * (sin(lambdabar)*sin(u)-cos(lambdabar)*cos(u)*cos(ibar)) - wz*x

    vz = vr*sin(u)*sin(ibar) + vu*cos(u)*sin(ibar)

    out = [x, y, z , vx, vy, vz]

    return out