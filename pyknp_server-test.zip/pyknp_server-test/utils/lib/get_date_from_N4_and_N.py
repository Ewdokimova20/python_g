import datetime


def get_date_from_N4_and_N(N: int, N4: int):
    return datetime.datetime(year=1996 + (N4 - 1) * 4, month=1, day=1) + datetime.timedelta(days=N - 1)


def get_almanac_time_by_datetime(time_now: datetime.datetime) -> (int, int, int):
    """Возвращает для поданного времени N4, NA, секунда_в_сутках"""

    current_timestamp = time_now.timestamp() + (3*3600)
    current_day = 731 + (current_timestamp // 86400)
    NA_current = round(1 + current_day % 1461)  # преобразовываем индекс дня в номер в четырехлетии
    N4_current = round(1 + current_day // 1461 - 7)
    ti = round(current_timestamp % 86400)
    return N4_current, NA_current, ti
