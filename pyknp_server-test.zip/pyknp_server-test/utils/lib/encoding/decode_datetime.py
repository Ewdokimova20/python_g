from datetime import datetime, date


def decode_datetime(dct):
    for key, value in dct.items():
        # Попытка распознать datetime
        if isinstance(value, str):
            try:
                # Попробуем распознать как datetime
                dct[key] = datetime.fromisoformat(value)
            except ValueError:
                try:
                    # Попробуем распознать как date
                    dct[key] = date.fromisoformat(value)
                except ValueError:
                    # Если не удалось распознать - оставим как есть
                    pass
    return dct
