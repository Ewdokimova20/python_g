from datetime import datetime, date


def encode_datetime(obj):
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
