from datetime import datetime, date
from enum import Enum


def encode_for_json(obj):
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, Enum):
        return obj.value  # или obj.name, если хотите строковое имя
    raise TypeError(f"Неизвестный тип для сериализации: {type(obj)}")
