from utils.SI.si_embedding_verification.types import SIEmbeddingVerificationFlagColor as FlagColor


def decode_uplink_control_flags(data: dict) -> dict:
    if 'flag_cdb' in data:
        data['flag_cdb'] = FlagColor(data['flag_cdb'])
    if 'flag_sui' in data:
        data['flag_sui'] = FlagColor(data['flag_sui'])
    if 'flag_ka' in data:
        data['flag_ka'] = FlagColor(data['flag_ka'])
    if 'flag_r4' in data:
        data['flag_r4'] = FlagColor(data['flag_r4'])
    return data
