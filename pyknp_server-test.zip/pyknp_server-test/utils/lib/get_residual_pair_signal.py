from typing import Optional, Union

from global_data.appdata import RESIDUAL_SIGNAL_PAIR_MAP, SignalTypes


def get_residual_pair_signal(signal1: Union[SignalTypes, int]) -> Optional[SignalTypes]:
    """
    Возвращает тип пары переданного сигнала.

    Args:
        signal1: (Union[SignalTypes, int]): Тип сигнала или его числовое значение.

    Returns:
        Optional[SignalTypes]: Тип сигнала или None, если сигнал не определен.
    """
    return RESIDUAL_SIGNAL_PAIR_MAP.get(signal1, None)
