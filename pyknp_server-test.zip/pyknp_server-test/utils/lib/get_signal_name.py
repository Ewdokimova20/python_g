from typing import Optional, Union

from global_data.appdata import SignalTypes


def get_signal_name(signal: Optional[Union[SignalTypes, int]]) -> Optional[str]:
    """
    Возвращает имя сигнала по его значению.

    Args:
        signal (Optional[Union[SignalTypes, int]]): Тип сигнала или его числовое значение.

    Returns:
        Optional[str]: Имя сигнала или None, если сигнал не определен.
    """
    return SignalTypes(signal).name if signal else None
