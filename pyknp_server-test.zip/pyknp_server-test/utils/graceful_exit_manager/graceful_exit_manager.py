import logging
import os
import signal
import sys
from multiprocessing import Process
from threading import Event
from typing import List, Callable

from twisted.internet import reactor

logger = logging.getLogger('main')


class GracefulExitManager:
    def __init__(self):
        self.exiting = Event()
        self.processes = []
        self.cleanup_functions: List[Callable] = []  # Новое поле для функций очистки
        self._shutdown_called = False
        self.parent_pid = os.getpid()

        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        logger.info(f"Менеджер завершения запущен в процессе PID={self.parent_pid}")

    def register_process(self, process: Process):
        if os.getpid() == self.parent_pid:
            self.processes.append(process)
            logger.debug(f"Зарегистрирован дочерний процесс {process.name} (PID {process.pid})")
        else:
            logger.debug(f"Попытка регистрации дочернего процесса в дочернем процессе — игнорируем")

    def register_cleanup_function(self, cleanup_func: Callable):
        """
        Регистрирует функцию для вызова при завершении программы

        Args:
            cleanup_func: Функция очистки без параметров
        """
        if os.getpid() == self.parent_pid:
            self.cleanup_functions.append(cleanup_func)
            logger.debug(f"Зарегистрирована функция очистки: {cleanup_func.__name__}")
        else:
            logger.debug(f"Попытка регистрации функции очистки в дочернем процессе — игнорируем")

    def _signal_handler(self, signum, frame):
        sig_name = signal.Signals(signum).name
        logger.debug(f"PID {os.getpid()}: Получен сигнал {sig_name} ({signum}), инициируем завершение")
        self.shutdown()

    def shutdown(self):
        if self._shutdown_called:
            logger.debug(f"shutdown уже выполняется, повторный вызов игнорируется")
            return
        self._shutdown_called = True

        logger.debug(f"Начинаем процедуру завершения")

        # Выполняем функции очистки перед остановкой reactor
        if os.getpid() == self.parent_pid:
            logger.debug(f"Выполняем {len(self.cleanup_functions)} функций очистки")
            for cleanup_func in self.cleanup_functions:
                try:
                    cleanup_func()
                    logger.debug(f"Функция очистки {cleanup_func.__name__} выполнена успешно")
                except Exception as e:
                    logger.error(f"Ошибка при выполнении функции очистки {cleanup_func.__name__}: {e}")

        if reactor.running:
            logger.debug("Останавливаем Twisted reactor...")
            reactor.callFromThread(reactor.stop)

        self.exiting.set()

        if os.getpid() == self.parent_pid:
            for proc in self.processes:
                if proc.is_alive():
                    logger.info(f"Завершаем процесс {proc.name} (PID {proc.pid})")
                    proc.terminate()

            for proc in self.processes:
                proc.join(timeout=5)
                if proc.is_alive():
                    logger.warning(f"Процесс {proc.name} (PID {proc.pid}) не завершился, принудительно убиваем")
                    proc.kill()

            logger.info("Все дочерние процессы успешно завершены")
            logger.debug(f"Завершение работы процесса")
            sys.exit(0)
        else:
            # В дочерних процессах — минимальный лог
            logger.debug(
                f"shutdown вызван не в родительском процессе, пропускаем управление дочерними процессами")
            logger.debug(f"Завершение работы процесса")
            # Не вызываем sys.exit(), пусть процесс завершится естественно
