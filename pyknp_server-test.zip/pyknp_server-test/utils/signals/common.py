from typing import Dict

from global_data.appdata import SIGNALS_NAME, FREQ_SIGNAL_TYPES, SignalTypes
from utils.signals import L1OF_STRING_DURATION, L1SF_STRING_DURATION, L3OC_STRING_DURATION, SC_STRING_DURATION, \
    L2KSI_STRING_DURATION, L1OC_STRING_DURATION

DI_SIGNAL_TYPES = [SignalTypes.L1OF, SignalTypes.L1SF, SignalTypes.L2OF, SignalTypes.L1OCd, SignalTypes.L1SCd,
                   SignalTypes.L2KSI, SignalTypes.L2SCd, SignalTypes.L3OCd]
"""Список сигналов, по которым передается ЦИ"""

DI_STRING_DURATIONS: Dict[SignalTypes, int] = {
    SignalTypes.L1OF: L1OF_STRING_DURATION,
    SignalTypes.L1SF: L1SF_STRING_DURATION,
    SignalTypes.L2OF: L1OF_STRING_DURATION,
    SignalTypes.L1OCd: L1OC_STRING_DURATION,
    SignalTypes.L1SCd: SC_STRING_DURATION,
    SignalTypes.L2KSI: L2KSI_STRING_DURATION,
    SignalTypes.L2SCd: SC_STRING_DURATION,
    SignalTypes.L3OCd: L3OC_STRING_DURATION,
}
"""Словарь сопоставления типа сигнала и длительности строки ЦИ этого сигнала"""


def format_ground_call_control_raw_value(signal_type, value):
    """Представление бинарного ВНКУ в виде определенного кол-ва битов"""
    if signal_type in FREQ_SIGNAL_TYPES:  # L1OF, L2OF, L1SF - 2 бита
        return '{:02b}'.format(value)
    elif signal_type in [SIGNALS_NAME['L1OCd'], SIGNALS_NAME['L2КСИ'],
                         SIGNALS_NAME['L3OCd']]:  # L1OCd, L2КСИ, L3OCd - 4 бита
        return '{:04b}'.format(value)
    elif signal_type in [SIGNALS_NAME['L1SCd'], SIGNALS_NAME['L2SCd']]:  # L1SCd, L2SCd, L3OCd - 3 бита
        return '{:03b}'.format(value)
    else:
        return value
