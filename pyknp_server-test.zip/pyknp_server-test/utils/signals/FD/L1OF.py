from bitarray.util import int2ba

from utils.bytestring_parser import PartPosition, SingleParam, append_common_fields_to_patterns

STRING_2SEC_BITLENGTH = 85
""""Длина 2-секундной строки, бит"""

L1OF_STRING_DURATION = 2

L1OF_STRINGS_IN_FRAME = 15

L1OF_STRING_IN_SUPERFRAME = 75


def seconds_from_tk(t_k: int) -> int:
    """Конвертация из tk в секунды"""
    hour = t_k >> 7 & 0b11111
    minutes = t_k >> 1 & 0b111111
    seconds = (t_k & 0b1) * 30
    frame_time = hour * 3600 + minutes * 60 + seconds
    return frame_time


def frame_seq_from_tk(t_k: int) -> int:
    """Порядковый номер кадра в сутках"""
    return int(seconds_from_tk(t_k) / 30) + 1


def frame_num_from_tk(t_k: int) -> int:
    """Номер кадра в суперкадре"""
    return int(seconds_from_tk(t_k) / 30) % 5 + 1


string1_pattern = {
    'reserve1': SingleParam(content=[PartPosition(start=79, length=2)], sign=False, CMR=1, type='int',
                            description="Резерв"),
    'P1': SingleParam(content=[PartPosition(start=77, length=2)], sign=False, CMR=1, type='int',
                      description="Признак смены оперативной информации"),
    'tk': SingleParam(content=[PartPosition(start=65, length=12)], sign=False, CMR=1, type='int',
                      description="Время начала кадра"),
    'Vx': SingleParam(content=[PartPosition(start=41, length=24)], sign=True, CMR=2 ** (-20), type='float',
                      description="Скорость по x", units="м/с", range=(-4300, 4300)),
    'Ax': SingleParam(content=[PartPosition(start=36, length=5)], sign=True, CMR=2 ** (-30), type='float',
                      description="Ускорение по x", units="м/с2", range=(-6.2e-6, 6.2e-6)),
    'x': SingleParam(content=[PartPosition(start=9, length=27)], sign=True, CMR=2 ** (-11), type='float',
                     description="Координата по x", units="м", range=(-2.7e7, 2.7e7))
}
"""Строка тип 1"""

string2_pattern = {
    'ln1': SingleParam(content=[PartPosition(start=80, length=1)], sign=False, CMR=1, type='int',
                       description='Признак недостоверности кадра НКА, "0" - НКА пригоден для навигации, "1" - НКА непригоден для навигации"'),
    'Bn': SingleParam(content=[PartPosition(start=78, length=2)], sign=False, CMR=1, type='int',
                      description="Вызов НКУ"),
    'P2': SingleParam(content=[PartPosition(start=77, length=1)], sign=False, CMR=1, type='int',
                      description="Признак чётности временного интервала"),
    'tb': SingleParam(content=[PartPosition(start=70, length=7)], sign=False, CMR=1, type='int',
                      description="Номер временного интервала в сутках", units="мин", range=(15, 1425)),
    'reserve2': SingleParam(content=[PartPosition(start=65, length=5)], sign=False, CMR=1, type='int',
                            description="Резерв"),
    'Vy': SingleParam(content=[PartPosition(start=41, length=24)], sign=True, CMR=2 ** (-20), type='float',
                      description="Скорость по y", units="м/с", range=(-4300, 4300)),
    'Ay': SingleParam(content=[PartPosition(start=36, length=5)], sign=True, CMR=2 ** (-30), type='float',
                      description="Ускорение по y", units="м/с2", range=(-6.2e-6, 6.2e-6)),
    'y': SingleParam(content=[PartPosition(start=9, length=27)], sign=True, CMR=2 ** (-11), type='float',
                     description="Координата по y", units="м", range=(-2.7e7, 2.7e7))
}
"""Строка тип 2"""

string3_pattern = {
    'P3': SingleParam(content=[PartPosition(start=80, length=1)], sign=False, CMR=1, type='int',
                      description="Признак альманаха от 5-ти или 4-х НКА"),
    'gamma': SingleParam(content=[PartPosition(start=69, length=11)], sign=True, CMR=2 ** (-40), type='float',
                         description="Отклонение несущей частоты", range=(-2 ** -30, 2 ** -30)),
    'reserve3': SingleParam(content=[PartPosition(start=68, length=1)], sign=False, CMR=1, type='int',
                            description="Резерв"),
    'p': SingleParam(content=[PartPosition(start=66, length=2)], sign=False, CMR=1, type='int',
                     description="Режим работы по ЧВИ"),
    'ln3': SingleParam(content=[PartPosition(start=65, length=1)], sign=False, CMR=1, type='int',
                       description="Недостоверность кадра"),
    'Vz': SingleParam(content=[PartPosition(start=41, length=24)], sign=True, CMR=2 ** (-20), type='float',
                      description="Скорость по z", units="м/с", range=(-4300, 4300)),
    'Az': SingleParam(content=[PartPosition(start=36, length=5)], sign=True, CMR=2 ** (-30), type='float',
                      description="Ускорение по z", units="м/с2", range=(-6.2e-6, 6.2e-6)),
    'z': SingleParam(content=[PartPosition(start=9, length=27)], sign=True, CMR=2 ** (-11), type='float',
                     description="Координата по z", units="м", range=(-2.7e7, 2.7e7))
}
"""Строка тип 3"""

string4_pattern = {
    'tau': SingleParam(content=[PartPosition(start=59, length=22)], sign=True, CMR=2 ** (-30), type='float',
                       description="Сдвиг шкалы времени", units="с", range=(-2 ** (-9), 2 ** (-9))),
    'deltaTau': SingleParam(content=[PartPosition(start=54, length=5)], sign=True, CMR=2 ** (-30), type='float',
                            description="Смещение L2 относительно L1", units="с", range=(-13.97e-9, 13.97e-9)),
    'En': SingleParam(content=[PartPosition(start=49, length=5)], sign=False, CMR=1, type='int',
                      description="Возраст оперативной информации", units="сутки", range=(0, 31)),
    'reserve42': SingleParam(content=[PartPosition(start=35, length=14)], sign=False, CMR=1, type='int',
                             description="Резерв"),
    'P4': SingleParam(content=[PartPosition(start=34, length=1)], sign=False, CMR=1, type='int',
                      description="Признак закладки ЭИ и ЧВИ"),
    'Ft': SingleParam(content=[PartPosition(start=30, length=4)], sign=False, CMR=1, type='int',
                      description="Фактор точности", units="м", range=(0, 15)),
    'reserve41': SingleParam(content=[PartPosition(start=27, length=3)], sign=False, CMR=1, type='int',
                             description="Резерв"),
    'Nt': SingleParam(content=[PartPosition(start=16, length=11)], sign=False, CMR=1, type='int',
                      description="Номер суток в 4-хлетнем периоде", units="сутки", range=(0, 1461)),
    'n': SingleParam(content=[PartPosition(start=11, length=5)], sign=False, CMR=1, type='int',
                     description="Номер НКА"),
    'Mn': SingleParam(content=[PartPosition(start=9, length=2)], sign=False, CMR=1, type='int',
                      description="Модификация НКА")
}
"""Строка тип 4"""

string5_pattern = {
    'Na': SingleParam(content=[PartPosition(start=70, length=11)], sign=False, CMR=1, type='int',
                      description="Номер суток в 4-хлетнем периоде", units="сутки", range=(0, 1461)),
    'tau_c': SingleParam(content=[PartPosition(start=38, length=32)], sign=True, CMR=2 ** (-31), type='float',
                         description="Поправка к шкале времени по UTC", units="c", range=(-1, 1)),
    'reserve5': SingleParam(content=[PartPosition(start=37, length=1)], sign=False, CMR=1, type='int',
                            description="Резерв"),
    'N4': SingleParam(content=[PartPosition(start=32, length=5)], sign=False, CMR=1, type='int',
                      description="Номер 4-хлетнего периода", range=(1, 31)),
    'tau_gps': SingleParam(content=[PartPosition(start=10, length=22)], sign=True, CMR=2 ** (-30), type='float',
                           description="Поправка к шкале времени по GPS", units="c", range=(-1.9e-3, 1.9e-3)),
    'ln5': SingleParam(content=[PartPosition(start=9, length=1)], sign=False, CMR=1, type='int',
                       description="Недостоверность кадра")
}
"""Строка тип 5"""

stringA1_pattern = {
    'C_n': SingleParam(content=[PartPosition(start=80, length=1)], sign=False, CMR=1, type='int',
                       description="Состояние НКА на момент закладки"),
    'M_a': SingleParam(content=[PartPosition(start=78, length=2)], sign=False, CMR=1, type='int',
                       description="Модификация НКА"),
    'n_a': SingleParam(content=[PartPosition(start=73, length=5)], sign=False, CMR=1, type='int',
                       description="Номер НКА"),
    'tau_a': SingleParam(content=[PartPosition(start=63, length=10)], sign=True, CMR=2 ** (-18), type='float',
                         description="Сдвиг шкалы времени", units="c", range=(-1.9e-3, 1.9e-3)),
    'lambda_': SingleParam(content=[PartPosition(start=42, length=21)], sign=True, CMR=2 ** (-20), type='float',
                           description="Долгота восходящего узла", units="полуцикл", range=(-1, 1)),
    'delta_i': SingleParam(content=[PartPosition(start=24, length=18)], sign=True, CMR=2 ** (-20), type='float',
                           description="Поправка к наклонению орбиты", units="полуцикл", range=(-0.067, 0.067)),
    'epsilon': SingleParam(content=[PartPosition(start=9, length=15)], sign=False, CMR=2 ** (-20), type='float',
                           description="Эксцентриситет орбиты", range=(0, 0.03))
}
"""Строка с типом первой из слота альманаха"""

stringA2_pattern = {
    'omega': SingleParam(content=[PartPosition(start=65, length=16)], sign=True, CMR=2 ** (-15), type='float',
                         description="Аргумент перигея", units="полуцикл", range=(-1, 1)),
    't_lambda': SingleParam(content=[PartPosition(start=44, length=21)], sign=False, CMR=2 ** (-5), type='float',
                            description="Время прохождения 1-го восходящего угла", units="с", range=(0, 44100)),
    'delta_T': SingleParam(content=[PartPosition(start=22, length=22)], sign=True, CMR=2 ** (-9), type='float',
                           description="Поправка к драконическому периоду", units="c/виток", range=(-3.6e3, 3.6e3)),
    'd_delta_T': SingleParam(content=[PartPosition(start=15, length=7)], sign=True, CMR=2 ** (-14), type='float',
                             description="Скорость изменения драконического периода", units="c/виток2",
                             range=(-2 ** (-8), 2 ** (-8))),
    'Hn': SingleParam(content=[PartPosition(start=10, length=5)], sign=False, CMR=1, type='int',
                      description="Номер частоты сигнала", range=(1, 31)),
    'ln_a': SingleParam(content=[PartPosition(start=9, length=1)], sign=False, CMR=1, type='int',
                        description="Недостоверность кадра")
}
"""Строка с типом второй из слота альманаха"""

stringS1_pattern = {
    'B1': SingleParam(content=[PartPosition(start=71, length=11)], sign=True, CMR=2 ** (-10), type='float',
                      description="Коэффициент полинома UT1", units="c", range=(-0.9, 0.9)),
    'B2': SingleParam(content=[PartPosition(start=60, length=10)], sign=False, CMR=2 ** (-16), type='float',
                      description="Коэффициент полинома UT1", units="c/сутки", range=(-4.5e-3, 3.5e-3)),
    'KP': SingleParam(content=[PartPosition(start=58, length=2)], sign=False, CMR=1, type='int',
                      description="Признак ожидаемой коррекции"),
    'reserve14': SingleParam(content=[PartPosition(start=9, length=49)], sign=False, CMR=1, type='int',
                             description="Резерв")
}
"""Предпоследняя Строка последнего кадра суперкадра"""

stringS2_pattern = {
    'reserve15': SingleParam(content=[PartPosition(start=10, length=71)], sign=False, CMR=1, type='int',
                             description="Резерв"),
    'ln_a': SingleParam(content=[PartPosition(start=9, length=1)], sign=False, CMR=1, type='int',
                        description="Недостоверность кадра")
}
"""Последняя Строка последнего кадра суперкадра"""

service_pattern = {
    'm': SingleParam(content=[PartPosition(start=81 - 8, length=4)], sign=False, CMR=1, type='int',
                     description="Номер строки в кадре", range=(0, 15))
    # 'CC': SingleParam(content=[PartPosition(start=1, length=8)], sign=False, CMR=1, type='int')
}
"""Служебные поля всех строк"""

# Список шаблонов для строк длиной 85 бит
L1OF_strings_pattern = {
    1: string1_pattern,
    2: string2_pattern,
    3: string3_pattern,
    4: string4_pattern,
    5: string5_pattern,
    6: stringA1_pattern,
    7: stringA2_pattern,
    8: stringA1_pattern,
    9: stringA2_pattern,
    10: stringA1_pattern,
    11: stringA2_pattern,
    12: stringA1_pattern,
    13: stringA2_pattern,
    14: stringA1_pattern,
    15: stringA2_pattern,
    74: stringS1_pattern,
    # 14 строка 5 кадра (74 строка суперкадра) особая, и содержит вместо 25 слота альманаха неоперативную информацию
    75: stringS2_pattern,
    # 15 строка 5 кадра (75 строка суперкадра) особая, и содержит вместо 25 слота альманаха неоперативную информацию
}

"""Пересчёт смещений адресов параметров для списка шаблонов"""
for key in [1, 2, 3, 4, 5, 6, 7, 74, 75]:
    for param in L1OF_strings_pattern[key].values():
        param.content[0].start -= 8
append_common_fields_to_patterns(L1OF_strings_pattern, service_pattern)  # должна после пересчета


def check_hamming_code(string: bytes, checksum: int) -> bool:
    """
    Проверка достоверности информации в строке с частотным разделением

    Алгоритм проверки достоверности информации в строке описан в документе
    "ИКД Навигационный радиосигнал в диапазонах L1, L2  с открытым доступом
    и частотным разделением" (стр. 44-45)

    В данный момент строка проверяется на отсутствие искажений. Исправления не проводятся
    """

    data_bits = int2ba(int.from_bytes(string, byteorder='big'), length=96)
    del data_bits[76:]
    ba_check = int2ba(checksum, length=8)
    data_bits.extend(ba_check)
    data_bits.reverse()
    data_bits.append(0)

    iter_i = [9, 10, 12, 13, 15, 17, 19, 20, 22, 24, 26, 28, 30, 32, 34, 35, 37, 39, 41,
              43,
              45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 66, 68, 70, 72, 74, 76, 78, 80,
              82, 84]
    iter_j = [9, 11, 12, 14, 15, 18, 19, 21, 22, 25, 26, 29, 30, 33, 34, 36, 37, 40, 41,
              44,
              45, 48, 49, 52, 53, 56, 57, 60, 61, 64, 65, 67, 68, 71, 72, 75, 76, 79, 80,
              83, 84]
    iter_k = [10, 11, 12, 16, 17, 18, 19, 23, 24, 25, 26, 31, 32, 33, 34, 38, 39, 40, 41,
              46,
              47, 48, 49, 54, 55, 56, 57, 62, 63, 64, 65, 69, 70, 71, 72, 77, 78, 79, 80,
              85]
    iter_l = [13, 14, 15, 16, 17, 18, 19, 27, 28, 29, 30, 31, 32, 33, 34, 42, 43, 44, 45,
              46,
              47, 48, 49, 58, 59, 60, 61, 62, 63, 64, 65, 73, 74, 75, 76, 77, 78, 79, 80]
    iter_m = [20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 50, 51, 52, 53,
              54,
              55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 81, 82, 83, 84, 85]

    control_sum = []
    checksums = [0, 0, 0, 0, 0, 0, 0]

    for ba_iter in iter_i:
        checksums[0] = checksums[0] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[0] ^ checksums[0])

    for ba_iter in iter_j:
        checksums[1] = checksums[1] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[1] ^ checksums[1])

    for ba_iter in iter_k:
        checksums[2] = checksums[2] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[2] ^ checksums[2])

    for ba_iter in iter_l:
        checksums[3] = checksums[3] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[3] ^ checksums[3])

    for ba_iter in iter_m:
        checksums[4] = checksums[4] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[4] ^ checksums[4])

    for iter_n in range(34, 65):
        checksums[5] = checksums[5] ^ data_bits[iter_n]
    control_sum.append(data_bits[5] ^ checksums[5])

    for iter_p in range(65, 85):
        checksums[6] = checksums[6] ^ data_bits[iter_p]
    control_sum.append(data_bits[6] ^ checksums[6])

    sum_check_bits = 0
    for iter_q in range(0, 8):
        sum_check_bits = sum_check_bits ^ data_bits[iter_q]

    sum_data_bits = 0
    for iter_q in range(8, 85):
        sum_data_bits = sum_data_bits ^ data_bits[iter_q]

    sum_checksums = sum_data_bits ^ sum_check_bits

    if not any(control_sum) and not sum_checksums:
        return False
    elif control_sum.count(1) == 1 and sum_checksums:
        return False
    else:
        return True
