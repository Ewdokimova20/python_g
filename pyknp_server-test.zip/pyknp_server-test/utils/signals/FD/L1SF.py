"""Модуль содержит константы и функции, относящиеся к ЦИ L1SF"""

from bitarray.util import int2ba

from global_data.appdata import values_in_pattern_L1SF
from utils.bytestring_parser import PartPosition, SingleParam, append_common_fields_to_patterns

STRING_1SEC_BITLENGTH = values_in_pattern_L1SF["constants"]["STRING_1SEC_BITLENGTH"]
""""Длина 1-секундной строки, бит"""

L1SF_STRING_DURATION = values_in_pattern_L1SF["constants"]["L1SF_STRING_DURATION"]

L1SF_STRINGS_IN_FRAME = values_in_pattern_L1SF["constants"]["L1SF_STRINGS_IN_FRAME"]

L1SF_STRINGS_IN_SEGMENT = values_in_pattern_L1SF["constants"]["L1SF_STRINGS_IN_SEGMENT"]

L1SF_STRING_IN_SUPERFRAME = values_in_pattern_L1SF["constants"]["L1SF_STRING_IN_SUPERFRAME"]


def seconds_from_tk(t_k: int) -> int:
    """Конвертация из tk в секунды"""
    hour = t_k >> 9 & 0b11111
    minutes = t_k >> 3 & 0b111111
    seconds = (t_k & 0b111) * 10
    frame_time = hour * 3600 + minutes * 60 + seconds
    return frame_time


def frame_seq_from_tk(t_k: int) -> int:
    """Порядковый номер кадра в сутках"""
    return int(seconds_from_tk(t_k) / L1SF_STRINGS_IN_FRAME) + 1


def frame_num_from_tk(t_k: int) -> int:
    """Номер кадра в суперкадре"""
    return int(seconds_from_tk(t_k) / L1SF_STRINGS_IN_FRAME) % (L1SF_STRING_IN_SUPERFRAME // L1SF_STRINGS_IN_FRAME) + 1


def frame_num_from_segment(t_k: int) -> int:
    """
    Номер кадра в сегменте(1, 2, 3)
    к 1 сегменту относятся паттерны 1-10
    ко 2 сегменту относятся паттерны 1-7, 18, 19, 20
    к 3 сегменту относятся паттерны 1-7, 28, 29, 30
    """
    number = frame_num_from_tk(t_k) % 3
    number = 3 if number == 0 else number
    return number


string1_pattern = {
    'P1': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Признак смены оперативной информации'),  # Wn официально
    'Gb': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'tk': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Время начала кадра'),
    'tau': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float',
                       description='Сдвиг шкалы времени')
}
"""Строка тип 1"""

string2_pattern = {
    'ln1': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                       description='Признак недостоверности кадра НКА, "0" - НКА пригоден для навигации, "1" - НКА непригоден для навигации'),
    # ln официально
    'Bn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Вызов НКУ'),
    'Vn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Pn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Ax': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Ускорение по x'),
    'x': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Координата по x'),
}
"""Строка тип 2"""

string3_pattern = {
    'Mn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Модификация НКА'),
    'Dn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Gm': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Ay': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Ускорение по y'),
    'y': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Координата по y')
}
"""Строка тип 3"""

string4_pattern = {
    'n': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Номер НКА'),
    'Az': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Ускорение по z'),
    'z': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Координата по z')
}
"""Строка тип 4"""

string5_pattern = {
    'tb': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер временного интервала в сутках'),
    'ETn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Vx': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='Скорость по x')
}
"""Строка тип 5"""

string6_pattern = {
    'ln3': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                       description='Недостоверность кадра'),  # ln
    'gamma': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float',
                         description='Отклонение несущей частоты'),
    'Vy': SingleParam(content=[PartPosition(start=0, length=0)], sign=True, CMR=0, type='float', description='Скорость по y')
}
"""Строка тип 6"""

string7_pattern = {
    'rez': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'dtaun': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Een': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Vz': SingleParam(content=[PartPosition(start=0, length=0)], sign=True, CMR=0, type='float', description='Скорость по z')
}
"""Строка тип 7"""

string8_pattern = {
    'n_a': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Номер НКА'),
    'tau_a': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float',
                         description='Сдвиг шкалы времени'),
    'PC': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='')
}
"""Строка тип 8"""

string9_pattern = {
    'M_a': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='Модификация НКА'),
    'omega': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                         description='Аргумент перигея'),
    'lambda_': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                           description='Долгота восходящего узла')
}
"""Строка тип 9"""

string10_pattern = {
    'rez': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'N4': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер 4-хлетнего периода'),
    'Nt': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер суток в 4-хлетнем периоде')
}
"""Строка тип 10"""

string18_pattern = {
    'epsilon': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                           description='Эксцентриситет орбиты'),
    'PZ': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='')
}
"""Строка тип 18"""

string19_pattern = {
    'delta_i': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                           description='Поправка к наклонению орбиты'),
    't_lambda': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                            description='Время прохождения 1-го восходящего угла')
}
"""Строка тип 19"""

string20_pattern = {
    'rez': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'N4': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер 4-хлетнего периода'),
    'Nt': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер суток в 4-хлетнем периоде')
}
"""Строка тип 20"""

string28_pattern = {
    'Na': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер 4-хлетнего периода'),
    'tau_c_start': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='float', description='')
}
"""Строка тип 28"""

string29_pattern = {
    'Qn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'tau_c_end': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Hn': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'd_delta_T': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'delta_T': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='')
}
"""Строка тип 29"""

string30_pattern = {
    'B0': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'Bc': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description=''),
    'KP': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Признак ожидаемой коррекции'),
    'N4': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер 4-хлетнего периода'),
    'Nt': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int',
                      description='Номер суток в 4-хлетнем периоде')
}
"""Строка тип 30"""

service_pattern = {
    'm': SingleParam(content=[PartPosition(start=0, length=0)], sign=False, CMR=0, type='int', description='')
}
"""Служебные поля всех строк"""

# Список шаблонов для строк длиной 50 бит
L1SF_strings_pattern = {
    1: string1_pattern,
    2: string2_pattern,
    3: string3_pattern,
    4: string4_pattern,
    5: string5_pattern,
    6: string6_pattern,
    7: string7_pattern,
    8: string8_pattern,
    9: string9_pattern,
    10: string10_pattern,
    18: string18_pattern,
    19: string19_pattern,
    20: string20_pattern,
    28: string28_pattern,
    29: string29_pattern,
    30: string30_pattern,
}


def write_all_values_in_pattern_L1SF():
    """Функция для записи значений в паттерны всех строк"""
    for number, pattern in L1SF_strings_pattern.items():
        values = values_in_pattern_L1SF[f"string{number}_pattern"]
        write_values_in_pattern_L1SF(pattern, values)
    values_service_pattern = values_in_pattern_L1SF["service_pattern"]
    write_values_in_pattern_L1SF(service_pattern, values_service_pattern)


def write_values_in_pattern_L1SF(string_pattern, values_in_pattern):
    """Функция для записи значений в паттерн строки"""
    for parametr in string_pattern:
        string_pattern[parametr] = SingleParam(
            content=[PartPosition(start=values_in_pattern[parametr]["start"], length=values_in_pattern[parametr]["length"])],
            sign=values_in_pattern[parametr]["sign"], CMR=values_in_pattern[parametr]["CMR"],
            type=values_in_pattern[parametr]["type"], description=string_pattern[parametr].description)


write_all_values_in_pattern_L1SF()

append_common_fields_to_patterns(L1SF_strings_pattern, service_pattern)  # должна находится до пересчета стартовых бит


def check_hamming_code_7b(string: bytes, checksum: int) -> bool:
    """
    Проверка достоверности информации в строке с частотным разделением
    """
    data_bits = int2ba(int.from_bytes(string, byteorder='big'), length=48)
    del data_bits[43:]
    ba_check = int2ba(checksum, length=7)
    data_bits.extend(ba_check)
    data_bits.reverse()

    iter_i = [8, 9, 11, 12, 14, 16, 18, 19, 21, 23, 25, 27, 29, 31, 33, 34, 36, 38, 40, 42, 44, 46, 48, 50]
    iter_j = [8, 10, 11, 13, 14, 17, 18, 20, 21, 24, 25, 28, 29, 32, 33, 35, 36, 39, 40, 43, 44, 47, 48]
    iter_k = [9, 10, 11, 15, 16, 17, 18, 22, 23, 24, 25, 30, 31, 32, 33, 37, 38, 39, 40, 45, 46, 47, 48]
    iter_l = [12, 13, 14, 15, 16, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33, 41, 42, 43, 44, 45, 46, 47, 48]
    iter_m = [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 49, 50]

    control_sum = []
    checksums = [0, 0, 0, 0, 0, 0]

    for ba_iter in iter_i:
        checksums[0] = checksums[0] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[0] ^ checksums[0])

    for ba_iter in iter_j:
        checksums[1] = checksums[1] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[1] ^ checksums[1])

    for ba_iter in iter_k:
        checksums[2] = checksums[2] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[2] ^ checksums[2])

    for ba_iter in iter_l:
        checksums[3] = checksums[3] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[3] ^ checksums[3])

    for ba_iter in iter_m:
        checksums[4] = checksums[4] ^ data_bits[ba_iter - 1]
    control_sum.append(data_bits[4] ^ checksums[4])

    for iter_n in range(33, 50):
        checksums[5] = checksums[5] ^ data_bits[iter_n]
    control_sum.append(data_bits[5] ^ checksums[5])

    sum_check_bits = 0
    for iter_q in range(0, 7):
        sum_check_bits = sum_check_bits ^ data_bits[iter_q]

    sum_data_bits = 0
    for iter_q in range(7, 50):
        sum_data_bits = sum_data_bits ^ data_bits[iter_q]

    sum_checksums = sum_data_bits ^ sum_check_bits

    if not any(control_sum) and not sum_checksums:
        return False
    elif control_sum.count(1) == 1 and sum_checksums:
        return False
    else:
        return True
