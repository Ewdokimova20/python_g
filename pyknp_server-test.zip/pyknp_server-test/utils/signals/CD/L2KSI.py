# Строки  служебных полей строки сигнала L2 КСИ   Стартовая позиция указана как младций (правый) разряд каждого поля .
# Нумерация бит от 1

"""Модуль содержит константы и функции, относящиеся к ЦИ L2KSI"""

from utils.bytestring_parser import PartPosition, SingleParam, parse_string_to_params, calc_pattern_start_index
from utils.CD_strings_utils import ServiceFields
from dataclasses import dataclass


L2KSI_STRING_DURATION = 1
"""Длительность строки L2KSI, с"""

L2KSI_STRING_BIT_LENGTH = 250
"""Длительность строки L2КСИ в битах"""


@dataclass
class ServiceFieldsL2KSI(ServiceFields):
    """Служебные поля строки. Смотри ИКД по сигналам L2КСИ"""
    type: int
    j: int
    gj: int
    KR: int
    A: int
    BC: int
    omv: int
    N4: int
    NT: int
    Pk: int
    CC: int
    P1: int = 0  # для регуляризации состава полей с остальными сигналами. Реально отсутствует
    lj: int = 0  # для регуляризации состава полей с остальными сигналами. Реально отсутствует


string_L2KSI_base_pattern = {
    'CMB': SingleParam(content=[PartPosition(start=12, length=12)], sign=False, CMR=1, type='int', range='010111110001',
                       units='б/р', description='Код метки времени'),
    'type': SingleParam(content=[PartPosition(start=18, length=6)], sign=False, CMR=1, type='int', range='0-63',
                        units='б/р', description='Тип строки'),
    'j': SingleParam(content=[PartPosition(start=24, length=6)], sign=False, CMR=1, type='int', range='0-63',
                     units='б/р', description='Номер НКА'),
    'Gj': SingleParam(content=[PartPosition(start=25, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                      units='б/р', description='Оперативный признак годности (0)  или негодности (1)'),
    'KR': SingleParam(content=[PartPosition(start=27, length=2)], sign=False, CMR=1, type='int', range='0-3',
                      units='б/р', description='Признак плановой коррекции БШВ'),
    'A': SingleParam(content=[PartPosition(start=28, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                     units='б/р', description='Признак ОМВ после коррекции БШВ'),
    'BC': SingleParam(content=[PartPosition(start=29, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                      units='б/р', description='Признак готовности принять АС'),
    'OMB': SingleParam(content=[PartPosition(start=46, length=17)], sign=False, CMR=1, type='int', range='0-63',
                       units='б/р', description='Оцифровка метки времени'),
    'N4': SingleParam(content=[PartPosition(start=51, length=5)], sign=False, CMR=1, type='int', range='1-31',
                      units='4-летие', description='Номер четырехлетия'),
    'NT': SingleParam(content=[PartPosition(start=62, length=11)], sign=False, CMR=1, type='int', range='1-1461',
                      units='сутки', description='Номер суток '),
    'Pk': SingleParam(content=[PartPosition(start=70, length=8)], sign=False, CMR=1, type='int', range='1-1461',
                      units='б/р', description='Признак СК'),
    'raw_content': SingleParam(content=[PartPosition(start=234, length=164)], sign=False, CMR=1, type='int', range='',
                      units='б/р', description='Содержимое строки'),
    'CC': SingleParam(content=[PartPosition(start=250, length=16)], sign=False, CMR=1, type='int', range='0-FF',
                      units='б/р', description='Циклический код')
}
"""Строка L2KSI_base    Общая структура строки"""

string_L2KSI_t0_pattern = {
    'CMB': SingleParam(content=[PartPosition(start=12, length=12)], sign=False, CMR=1, type='int', range='010111110001',
                       units='б/р', description='Код метки времени'),
    'type': SingleParam(content=[PartPosition(start=18, length=6)], sign=False, CMR=1, type='int', range='0-63',
                        units='б/р', description='Тип строки'),
    'j': SingleParam(content=[PartPosition(start=24, length=6)], sign=False, CMR=1, type='int', range='0-63',
                     units='б/р', description='Номер НКА'),
    'Gj': SingleParam(content=[PartPosition(start=25, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                      units='б/р', description='Оперативный признак годности (0)  или негодности (1)'),
    'KR': SingleParam(content=[PartPosition(start=27, length=2)], sign=False, CMR=1, type='int', range='0-3',
                      units='б/р', description='Признак плановой коррекции БШВ'),
    'A': SingleParam(content=[PartPosition(start=28, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                     units='б/р', description='Признак ОМВ после коррекции БШВ'),
    'BC': SingleParam(content=[PartPosition(start=29, length=1)], sign=False, CMR=1, type='boolean', range='0-1',
                      units='б/р', description='Признак готовности принять АС'),
    'OMB': SingleParam(content=[PartPosition(start=46, length=17)], sign=False, CMR=1, type='int', range='0-63',
                       units='б/р', description='Оцифровка метки времени'),
    'N4': SingleParam(content=[PartPosition(start=51, length=5)], sign=False, CMR=1, type='int', range='1-31',
                      units='4-летие', description='Номер четырехлетия'),
    'NT': SingleParam(content=[PartPosition(start=62, length=11)], sign=False, CMR=1, type='int', range='1-1461',
                      units='сутки', description='Номер суток '),
    'Pk': SingleParam(content=[PartPosition(start=70, length=8)], sign=False, CMR=1, type='int', range='1-1461',
                      units='б/р', description='Признак СК'),
    'TI': SingleParam(content=[PartPosition(start=234, length=164)], sign=False, CMR=1, type='int', range=' ',
                      units='б/р', description='Технологическая инф.'),
    'CC': SingleParam(content=[PartPosition(start=250, length=16)], sign=False, CMR=1, type='int', range='0-FF',
                      units='б/р', description='Циклический код')
}
"""Строка L2KSI_t0    Общая структура строки  0"""


def get_service_fields_l2ksi(int_string: int):
    """Функция возвращает значения служебных полей для сигнала L2КСИ (неаномальные строки)"""

    service_fields_dict, _ = parse_string_to_params(int_string, string_L2KSI_base_pattern)
    service_fields = ServiceFieldsL2KSI(
        type=service_fields_dict.get('type'),
        j=service_fields_dict.get('j'),
        gj=service_fields_dict.get('Gj'),
        KR=service_fields_dict.get('KR'),
        A=service_fields_dict.get('A'),
        BC=service_fields_dict.get('BC'),
        omv=service_fields_dict.get('OMB'),
        N4=service_fields_dict.get('N4'),
        NT=service_fields_dict.get('NT'),
        Pk=service_fields_dict.get('Pk'),
        CC=service_fields_dict.get('CC')
    )
    return service_fields


# Пересчет адресов смещений в словарях- шаблонах строк
calc_pattern_start_index(string_L2KSI_t0_pattern, L2KSI_STRING_BIT_LENGTH)
calc_pattern_start_index(string_L2KSI_base_pattern, L2KSI_STRING_BIT_LENGTH)
