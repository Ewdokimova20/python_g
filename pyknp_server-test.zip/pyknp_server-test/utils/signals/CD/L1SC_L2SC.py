"""Модуль содержит константы и функции, относящиеся к ЦИ L1SC и L2SC"""

from dataclasses import dataclass

from bitarray import bitarray
from bitarray.util import int2ba

from utils.CD_strings_utils import ServiceFields
from utils.bytestring_parser import PartPosition, SingleParam, parse_string_to_params, calc_pattern_start_index, \
    calc_pattern_list_start_index, append_common_fields_to_patterns

SC_STRING_DURATION = 2
"""Длительность строки L1SC и L2SC, с"""

STRING_1SEC_BITLENGTH = 125
""""Длина 1-секундной строки, бит"""
STRING_2SEC_BITLENGTH = 250
""""Длина 2-секундной строки, бит"""
STRING_3SEC_BITLENGTH = 375
""""Длина 3-секундной строки, бит"""


@dataclass
class ServiceFieldsSC(ServiceFields):
    """Служебные поля строки. Смотри ИКД по сигналам L1SC и L2SC"""
    cmb: int
    type: int
    omv: int
    N4: int
    Nt: int
    gj: int
    lj: int
    Pk: int
    j: int
    P1: int
    P2: int
    KR: int
    A: int
    CC: int


def get_service_fields_sc(int_string: int):
    """Функция возвращает значения служебных полей для сигналв L1SC и L2SC (неаномальные строки)"""

    service_fields_dict, _ = parse_string_to_params(int_string, service_pattern)
    service_fields = ServiceFieldsSC(
        cmb=service_fields_dict.get('cmb'),
        type=service_fields_dict.get('type'),
        omv=service_fields_dict.get('OMB'),
        N4=service_fields_dict.get('N4'),
        Nt=service_fields_dict.get('Nt'),
        gj=service_fields_dict.get('Gj'),
        lj=service_fields_dict.get('Lj'),
        Pk=service_fields_dict.get('Pk'),
        j=service_fields_dict.get('j'),
        P1=service_fields_dict.get('P1'),
        P2=service_fields_dict.get('P2'),
        KR=service_fields_dict.get('KR'),
        A=service_fields_dict.get('A'),
        CC=service_fields_dict.get('CC')
    )

    return service_fields


def get_pseudoframe_length_sc(int_string_10: int):
    """Функция возвращает длину псевдокадар из строки 10"""
    string10_fields_dict, _ = parse_string_to_params(int_string_10, string10_pattern)
    return string10_fields_dict.get('RP')


def check_cyclic_code_long(string: bytes) -> bool:
    """
    Проверка сигнала L1SC и L2SC на ошибки в строке

    Процедура обнаружения ошибок в принятом блоке описана в документе
    "КА Глонасс-К2. Структура цифровой информации радиосигналов с кодовым разделением частотных диапазонов L1, L2, L3.
     Редакция 2"
    (стр. 23 - 25)

    В случае отсутствия ошибок в ЦК возвращается "False", иначе "True" - "есть ошибки в ЦК"
    """

    lfsr_string = int2ba(int.from_bytes(string, byteorder='big'), length=256)
    del lfsr_string[250:]

    shift_register = bitarray(lfsr_string[:16])
    shift_register.reverse()

    poly = [1, 5, 6, 8, 9, 10, 11, 13, 14]

    for left_bit in lfsr_string[16:]:
        copy_shift_register = shift_register[:]

        shift_register >>= 1
        shift_register[0] = left_bit ^ copy_shift_register[15]

        for num_poly in poly:
            shift_register[num_poly] = \
                copy_shift_register[num_poly - 1] ^ copy_shift_register[15]

    return any(shift_register)


# Выделение отдельных значений из строк L1SC и L2SC

string10_pattern = {
    'Mj': SingleParam(content=[PartPosition(start=76, length=3)], sign=False, CMR=1, type='int',
                      description='Модификация НКА'),
    'RP': SingleParam(content=[PartPosition(start=82, length=6)], sign=False, CMR=1, type='int',
                      description='Размер псевдокадра', range=(0, 63)),
    'tb': SingleParam(content=[PartPosition(start=92, length=10)], sign=False, CMR=90, type='int',
                      description='Момент времени', units='с', range=(0, 86310)),
    'Ee': SingleParam(content=[PartPosition(start=100, length=8)], sign=False, CMR=1, type='int',
                      description='Возраст ЭИ', units='6 ч', range=(1, 255)),
    'Et': SingleParam(content=[PartPosition(start=108, length=8)], sign=False, CMR=1, type='int',
                      description='Возраст ЧВИ', units='6 ч', range=(1, 255)),
    'Re': SingleParam(content=[PartPosition(start=110, length=2)], sign=False, CMR=1, type='int',
                      description='Режим формирования ЭИ'),
    'Rt': SingleParam(content=[PartPosition(start=112, length=2)], sign=False, CMR=1, type='int',
                      description='Режим формирования ЧВИ'),
    'Fe': SingleParam(content=[PartPosition(start=117, length=5)], sign=True, CMR=1, type='int',
                      description='Фактор точности с погрешностями ЭИ'),
    'Ft': SingleParam(content=[PartPosition(start=122, length=5)], sign=True, CMR=1, type='int',
                      description='Фактор точности с погрешностями ЧВИ'),
    'tau': SingleParam(content=[PartPosition(start=154, length=32)], sign=True, CMR=2 ** (-38), type='float',
                       description='Поправка к БШВ для перехода к ШВС', units='с', range=(-7.8e-3, 7.8e-3)),
    'gamma': SingleParam(content=[PartPosition(start=173, length=19)], sign=True, CMR=2 ** (-48), type='float',
                         description='Относительное отклонение', range=(-0.9e-9, 0.9e-9)),
    'beta': SingleParam(content=[PartPosition(start=188, length=15)], sign=True, CMR=2 ** (-57), type='float',
                        description='Скорость изменения отклонения', units='с-1', range=(-1.1e-13, 1.1e-13)),
    'tau_c': SingleParam(content=[PartPosition(start=228, length=40)], sign=True, CMR=2 ** (-31), type='float',
                         description='Поправка для перехода от ШВС к МДВ', units='с', range=(-256, 256)),
}
"""Строка тип 10"""

string11_pattern = {
    'tau_dot_c': SingleParam(content=[PartPosition(start=86, length=13)], sign=True, CMR=2 ** (-49), type='float',
                             description='Скорость изменения поправки', range=(-0.7e-11, 0.7e-11)),
    'x': SingleParam(content=[PartPosition(start=126, length=40)], sign=True, CMR=2 ** (-20), type='float',
                     description='Координаты центра масс по х', units='км', range=(-5.2e5, 5.2e5)),
    'y': SingleParam(content=[PartPosition(start=166, length=40)], sign=True, CMR=2 ** (-20), type='float',
                     description='Координаты центра масс по y', units='км', range=(-5.2e5, 5.2e5)),
    'z': SingleParam(content=[PartPosition(start=206, length=40)], sign=True, CMR=2 ** (-20), type='float',
                     description='Координаты центра масс по z', units='км', range=(-5.2e5, 5.2e5)),
}
"""Строка тип 11"""

string12_pattern = {
    'Vx': SingleParam(content=[PartPosition(start=108, length=35)], sign=True, CMR=2 ** (-30), type='float',
                      description='Составляющая вектора скорости по x', units='км/с', range=(-16, 16)),
    'Vy': SingleParam(content=[PartPosition(start=143, length=35)], sign=True, CMR=2 ** (-30), type='float',
                      description='Составляющая вектора скорости по y', units='км/с', range=(-16, 16)),
    'Vz': SingleParam(content=[PartPosition(start=178, length=35)], sign=True, CMR=2 ** (-30), type='float',
                      description='Составляющая вектора скорости по z', units='км/с', range=(-16, 16)),
    'Ax': SingleParam(content=[PartPosition(start=193, length=15)], sign=True, CMR=2 ** (-39), type='float',
                      description='Составляющая вектора ускорения по x', units='км/с2', range=(-2.9e-8, 2.9e-8)),
    'Ay': SingleParam(content=[PartPosition(start=208, length=15)], sign=True, CMR=2 ** (-39), type='float',
                      description='Составляющая вектора ускорения по y', units='км/с2', range=(-2.9e-8, 2.9e-8)),
    'Az': SingleParam(content=[PartPosition(start=223, length=15)], sign=True, CMR=2 ** (-39), type='float',
                      description='Составляющая вектора ускорения по z', units='км/с2', range=(-2.9e-8, 2.9e-8)),
    'si_baus': SingleParam(content=[PartPosition(start=233, length=10)], sign=False, CMR=1, type='int',
                           description='Служебная информация')
}
"""Строка тип 12"""

string13_pattern = {
    'delta_x_fc': SingleParam(content=[PartPosition(start=86, length=13)], sign=True, CMR=2 ** (-10), type='float',
                              description='Координата фазового центра антенны по x', units='м', range=(-4, 4)),
    'delta_y_fc': SingleParam(content=[PartPosition(start=99, length=13)], sign=True, CMR=2 ** (-10), type='float',
                              description='Координата фазового центра антенны по y', units='м', range=(-4, 4)),
    'delta_z_fc': SingleParam(content=[PartPosition(start=112, length=13)], sign=True, CMR=2 ** (-10), type='float',
                              description='Координата фазового центра антенны по z', units='м', range=(-4, 4)),
}
"""Строка тип 13"""

string20_pattern = {
    'TO': SingleParam(content=[PartPosition(start=75, length=2)], sign=False, CMR=1, type='int',
                      description='Тип орбиты'),
    'Ns': SingleParam(content=[PartPosition(start=81, length=6)], sign=False, CMR=1, type='int',
                      description='Число НКА в ОГ', range=(0, 63)),
    'Ea': SingleParam(content=[PartPosition(start=87, length=6)], sign=False, CMR=1, type='int',
                      description='Возраст альманаха', units='сутки', range=(0, 63)),
    'Na': SingleParam(content=[PartPosition(start=98, length=11)], sign=False, CMR=1, type='int',
                      description='Календарный номер суток', units='сутки', range=(1, 1461)),
    'PCa': SingleParam(content=[PartPosition(start=103, length=5)], sign=False, CMR=1, type='int',
                       description='Регистр состояния сигналов'),
    'Ma': SingleParam(content=[PartPosition(start=106, length=3)], sign=False, CMR=1, type='int',
                      description='Модификация НКА'),
    'tau_a': SingleParam(content=[PartPosition(start=120, length=14)], sign=True, CMR=2 ** (-20), type='float',
                         description='Значение поправки', units='с', range=(-7.8e-3, 7.8e-3)),
    'lambda_': SingleParam(content=[PartPosition(start=141, length=21)], sign=True, CMR=2 ** (-20), type='float',
                           description='Геодезическая долгота', units='полуцикл', range=(-1, 1)),
    't_lambda': SingleParam(content=[PartPosition(start=162, length=21)], sign=False, CMR=2 ** (-5), type='float',
                            description='Момент прохождения НКА узла', units='с', range=(0, 44100)),
    'delta_i': SingleParam(content=[PartPosition(start=177, length=15)], sign=True, CMR=2 ** (-20), type='float',
                           description='Поправка к значению наклонения', units='полуцикл', range=(-0.0156, 0.0156)),
    'epsilon': SingleParam(content=[PartPosition(start=192, length=15)], sign=False, CMR=2 ** (-20), type='float',
                           description='Эксцентриситет орбиты НКА', range=(0, 0.03)),
    'omega': SingleParam(content=[PartPosition(start=208, length=16)], sign=True, CMR=2 ** (-15), type='float',
                         description='Аргумент перигея орбиты НКА', units='полуцикл', range=(-1, 1)),
    'delta_T': SingleParam(content=[PartPosition(start=227, length=19)], sign=True, CMR=2 ** (-9), type='float',
                           description='Поправка к драконическому периоду', units='с', range=(-512, 512)),
    'delta_dot_Ta': SingleParam(content=[PartPosition(start=234, length=7)], sign=True, CMR=2 ** (-14), type='float',
                                description='Скорость изменения драконического периода', units='с/виток',
                                range=(-3.9e-3, 3.9e-3)),
}
"""Строка тип 20"""

string25_pattern = {
    'Nb': SingleParam(content=[PartPosition(start=84, length=11)], sign=False, CMR=1, type='int',
                      description='Календарный номер суток', units='сутки', range=(1, 1461)),
    'x_p': SingleParam(content=[PartPosition(start=100, length=16)], sign=True, CMR=2 ** (-14), type='float',
                       description='Параметр полинома для определения положения по х', units='угл.с', range=(-1, 1)),
    'y_p': SingleParam(content=[PartPosition(start=116, length=16)], sign=True, CMR=2 ** (-14), type='float',
                       description='Параметр полинома для определения положения по y', units='угл.с', range=(-1, 1)),
    'Vx_p': SingleParam(content=[PartPosition(start=125, length=9)], sign=True, CMR=2 ** (-14), type='float',
                        description='Параметр полинома для определения положения по х', units='угл.с/сутки',
                        range=(-8e-3, 8e-3)),
    'Vy_p': SingleParam(content=[PartPosition(start=134, length=9)], sign=True, CMR=2 ** (-14), type='float',
                        description='Параметр полинома для определения положения по y', units='угл.с/сутки',
                        range=(-8e-3, 8e-3)),
    'Ax_p': SingleParam(content=[PartPosition(start=141, length=7)], sign=True, CMR=2 ** (-14), type='float',
                        description='Параметр полинома для определения положения по x', units='угл.с/сутки2',
                        range=(-2e-3, 2e-3)),
    'Ay_p': SingleParam(content=[PartPosition(start=148, length=7)], sign=True, CMR=2 ** (-14), type='float',
                        description='Параметр полинома для определения положения по y', units='угл.с/сутки2',
                        range=(-2e-3, 2e-3)),
    'B0': SingleParam(content=[PartPosition(start=173, length=25)], sign=True, CMR=2 ** (-16), type='float',
                      description='Параметр полинома для определения расхождения', units='с', range=(-256, 256)),
    'B1': SingleParam(content=[PartPosition(start=183, length=10)], sign=True, CMR=2 ** (-16), type='float',
                      description='Параметр полинома для определения расхождения', units='с/ссс',
                      range=(-7.8e-3, 7.8e-3)),
    'B2': SingleParam(content=[PartPosition(start=191, length=8)], sign=True, CMR=2 ** (-16), type='float',
                      description='Параметр полинома для определения расхождения', units='с/ссс2',
                      range=(-1.9e-3, 1.9e-3)),
    'C_A': SingleParam(content=[PartPosition(start=200, length=9)], sign=False, CMR=2 ** (-7), type='float',
                       description='Значение множителя для ионосферы', range=(0, 4)),
    'C_F10.7': SingleParam(content=[PartPosition(start=213, length=13)], sign=False, CMR=2 ** (-4), type='float',
                           description='Значение индекса солнечной активности', units='с.е.п.', range=(0, 500)),
    'C_Ap': SingleParam(content=[PartPosition(start=222, length=9)], sign=False, CMR=1, type='int',
                        description='Значение индекса геомагнитной активности', units='нТл', range=(0, 500)),
    'utc_tai': SingleParam(content=[PartPosition(start=231, length=9)], sign=True, CMR=1, type='int',
                           description='Расхождение шкал времени', units='с', range=(-255, 255)),
}
"""Строка тип 25"""

string16_pattern = {
    'Tvh': SingleParam(content=[PartPosition(start=95, length=22)], sign=False, CMR=2 ** (-5), type='float',
                       description='Момент времени входа в разворот', units='c', range=(0, 86399)),
    'psi_vh': SingleParam(content=[PartPosition(start=110, length=15)], sign=False, CMR=2 ** (-14), type='float',
                          description='Угол рыскания', units='полуцикл', range=(0, 2)),
    'SN': SingleParam(content=[PartPosition(start=111, length=1)], sign=False, CMR=1, type='int',
                      description='Знак упреждающего разворота'),
    'omega_max': SingleParam(content=[PartPosition(start=128, length=17)], sign=False, CMR=2 ** (-26), type='float',
                             description='Максимальная скорость разворота', units='полуцикл/с', range=(0, 16e-4)),
    'omega_vh': SingleParam(content=[PartPosition(start=145, length=17)], sign=False, CMR=2 ** (-26), type='float',
                            description='Угловая скорость разворота', units='полуцикл/с', range=(0, 16e-4)),
    'omega_dot': SingleParam(content=[PartPosition(start=160, length=15)], sign=False, CMR=2 ** (-30), type='float',
                             description='Постоянное угловое ускорение', units='полуцикл/с2', range=(0, 2.96e-5)),
    'tau1': SingleParam(content=[PartPosition(start=173, length=13)], sign=False, CMR=2 ** (-5), type='float',
                        description='Время до окончания наращивания угловой скорости', units='с', range=(0, 200)),
    'tau2': SingleParam(content=[PartPosition(start=190, length=17)], sign=False, CMR=2 ** (-5), type='float',
                        description='Длительность разворота', units='с', range=(0, 3480)),
}
"""Строка тип 16"""

string31_pattern = {
    'tb31': SingleParam(content=[PartPosition(start=83, length=10)], sign=False, CMR=90, type='int',
                        description='Момент времени', units='c', range=(0, 86310)),
    'delta_Ax0_tb': SingleParam(content=[PartPosition(start=88, length=5)], sign=True, CMR=2 ** (-42), type='float',
                                description='Коэффициент для ускорения по x', units='км/с2',
                                range=(-3.41e-12, 3.41e-12)),
    'delta_Ay0_tb': SingleParam(content=[PartPosition(start=93, length=5)], sign=True, CMR=2 ** (-42), type='float',
                                description='Коэффициент для ускорения по y', units='км/с2',
                                range=(-3.41e-12, 3.41e-12)),
    'delta_Az0_tb': SingleParam(content=[PartPosition(start=98, length=5)], sign=True, CMR=2 ** (-42), type='float',
                                description='Коэффициент для ускорения по z', units='км/с2',
                                range=(-3.41e-12, 3.41e-12)),
    'Ax1_tb': SingleParam(content=[PartPosition(start=116, length=18)], sign=True, CMR=2 ** (-54), type='float',
                          description='Коэффициент для ускорения по x', units='км/с3',
                          range=(-7.276e-12, 7.276e-12)),
    'Ay1_tb': SingleParam(content=[PartPosition(start=134, length=18)], sign=True, CMR=2 ** (-54), type='float',
                          description='Коэффициент для ускорения по y', units='км/с3',
                          range=(-7.276e-12, 7.276e-12)),
    'Az1_tb': SingleParam(content=[PartPosition(start=152, length=18)], sign=True, CMR=2 ** (-54), type='float',
                          description='Коэффициент для ускорения по z', units='км/с3',
                          range=(-7.276e-12, 7.276e-12)),
    'Ax2_tb': SingleParam(content=[PartPosition(start=170, length=18)], sign=True, CMR=2 ** (-67), type='float',
                          description='Коэффициент для ускорения по x', units='км/с4', range=(2 ** (-50), 2 ** (-50))),
    'Ay2_tb': SingleParam(content=[PartPosition(start=188, length=18)], sign=True, CMR=2 ** (-67), type='float',
                          description='Коэффициент для ускорения по y', units='км/с4', range=(2 ** (-50), 2 ** (-50))),
    'Az2_tb': SingleParam(content=[PartPosition(start=206, length=18)], sign=True, CMR=2 ** (-67), type='float',
                          description='Коэффициент для ускорения по z', units='км/с4', range=(2 ** (-50), 2 ** (-50)))
}
"""Строка тип 31"""

string32_pattern = {
    'tb32': SingleParam(content=[PartPosition(start=83, length=10)], sign=False, CMR=90, type='int',
                        description='Момент времени', units='c', range=(0, 86310)),
    'Ax3_tb': SingleParam(content=[PartPosition(start=101, length=18)], sign=True, CMR=2 ** (-80), type='float',
                          description='Коэффициент для ускорения по x', units='км/с5', range=(2 ** (-63), 2 ** (-63))),
    'Ay3_tb': SingleParam(content=[PartPosition(start=119, length=18)], sign=True, CMR=2 ** (-80), type='float',
                          description='Коэффициент для ускорения по y', units='км/с5', range=(2 ** (-63), 2 ** (-63))),
    'Az3_tb': SingleParam(content=[PartPosition(start=136, length=18)], sign=True, CMR=2 ** (-80), type='float',
                          description='Коэффициент для ускорения по z', units='км/с5', range=(2 ** (-63), 2 ** (-63))),
    'Ax4_tb': SingleParam(content=[PartPosition(start=155, length=18)], sign=True, CMR=2 ** (-95), type='float',
                          description='Коэффициент для ускорения по x', units='км/с6', range=(2 ** (-78), 2 ** (-78))),
    'Ay4_tb': SingleParam(content=[PartPosition(start=173, length=18)], sign=True, CMR=2 ** (-95), type='float',
                          description='Коэффициент для ускорения по y', units='км/с6', range=(2 ** (-78), 2 ** (-78))),
    'Az4_tb': SingleParam(content=[PartPosition(start=191, length=18)], sign=True, CMR=2 ** (-95), type='float',
                          description='Коэффициент для ускорения по z', units='км/с6', range=(2 ** (-78), 2 ** (-78))),
}
"""Строка тип 32"""

string60_pattern = srting0_pattern = {
    'message': SingleParam(content=[PartPosition(start=234, length=161)], sign=False, CMR=1, type='int',
                           description='Текстовое сообщение'),
    'CC': SingleParam(content=[PartPosition(start=250, length=16)], sign=False, CMR=1, type='int',
                      description='Циклический код'),
}
"""Строка тип 60 и 0"""

string1_pattern = {
    'CMB': SingleParam(content=[PartPosition(start=12, length=12)], sign=False, CMR=1, type='int',
                       description='Константа'),
    'type': SingleParam(content=[PartPosition(start=18, length=6)], sign=False, CMR=1, type='int',
                        description='Тип строки', range=(0, 63)),
    'OMB': SingleParam(content=[PartPosition(start=34, length=16)], sign=False, CMR=1, type='int',
                       description='Оцифровка метки времени', units='2 с', range=(0, 43199)),
    'N4': SingleParam(content=[PartPosition(start=39, length=5)], sign=False, CMR=1, type='int',
                      description='Номер 4-хлетнего периода', range=(1, 31)),
    'Nt': SingleParam(content=[PartPosition(start=50, length=11)], sign=False, CMR=1, type='int',
                      description='Номер суток в 4-хлетнем периоде', units='сутки', range=(1, 1461)),
    'Gj': SingleParam(content=[PartPosition(start=51, length=1)], sign=False, CMR=1, type='int',
                      description='Признак годности ("0") или негодности ("1") нав. сигнала НКА'),
    'Lj': SingleParam(content=[PartPosition(start=52, length=1)], sign=False, CMR=1, type='int',
                      description='Признак достоверности ("0") или недостоверности ("1") ЦИ в данной строке НКА'),
    'Pk': SingleParam(content=[PartPosition(start=60, length=8)], sign=False, CMR=1, type='int',
                      description='Признак параметра специального кодирования'),
    'j': SingleParam(content=[PartPosition(start=66, length=6)], sign=False, CMR=1, type='int',
                     description='Системный номер НКА', range=(0, 63)),
    'P1': SingleParam(content=[PartPosition(start=69, length=3)], sign=False, CMR=1, type='int',
                      description='Признак вызова НКУ'),
    'P2': SingleParam(content=[PartPosition(start=70, length=1)], sign=False, CMR=1, type='int',
                      description='Признак режима ориентации'),
    'KR': SingleParam(content=[PartPosition(start=72, length=2)], sign=False, CMR=1, type='int',
                      description='Признак ожидаемой коррекции'),
    'A': SingleParam(content=[PartPosition(start=73, length=1)], sign=False, CMR=1, type='int',
                     description='Признак выполнения коррекции'),
    'CC': SingleParam(content=[PartPosition(start=125, length=16)], sign=False, CMR=1, type='int',
                      description='Циклический код'),
}
"""Строка тип 1"""

string2_pattern = {
    'CMB': SingleParam(content=[PartPosition(start=12, length=12)], sign=False, CMR=1, type='int',
                       description='Константа'),
    'type': SingleParam(content=[PartPosition(start=18, length=6)], sign=False, CMR=1, type='int',
                        description='Тип строки', range=(0, 63)),
    'OMB': SingleParam(content=[PartPosition(start=34, length=16)], sign=False, CMR=1, type='int',
                       description='Оцифровка метки времени', units='2 с', range=(0, 43199)),
    'N4': SingleParam(content=[PartPosition(start=39, length=5)], sign=False, CMR=1, type='int',
                      description='Номер 4-хлетнего периода', range=(1, 31)),
    'Nt': SingleParam(content=[PartPosition(start=50, length=11)], sign=False, CMR=1, type='int',
                      description='Номер суток в 4-хлетнем периоде', units='сутки', range=(1, 1461)),
    'Gj': SingleParam(content=[PartPosition(start=51, length=1)], sign=False, CMR=1, type='int',
                      description='Признак годности ("0") или негодности ("1") нав. сигнала НКА'),
    'Lj': SingleParam(content=[PartPosition(start=52, length=1)], sign=False, CMR=1, type='int',
                      description='Признак достоверности ("0") или недостоверности ("1") ЦИ в данной строке НКА'),
    'Pk': SingleParam(content=[PartPosition(start=60, length=8)], sign=False, CMR=1, type='int',
                      description='Признак параметра специального кодирования'),
    'j': SingleParam(content=[PartPosition(start=66, length=6)], sign=False, CMR=1, type='int',
                     description='Системный номер НКА', range=(0, 63)),
    'P1': SingleParam(content=[PartPosition(start=69, length=3)], sign=False, CMR=1, type='int',
                      description='Признак вызова НКУ'),
    'P2': SingleParam(content=[PartPosition(start=70, length=1)], sign=False, CMR=1, type='int',
                      description='Признак режима ориентации'),
    'KR': SingleParam(content=[PartPosition(start=72, length=2)], sign=False, CMR=1, type='int',
                      description='Признак ожидаемой коррекции'),
    'A': SingleParam(content=[PartPosition(start=73, length=1)], sign=False, CMR=1, type='int',
                     description='Признак выполнения коррекции'),
    'CC': SingleParam(content=[PartPosition(start=375, length=24)], sign=False, CMR=1, type='int',
                      description='Циклический код'),
}
"""Строка тип 2"""

service_pattern = {
    'CMB': SingleParam(content=[PartPosition(start=12, length=12)], sign=False, CMR=1, type='int',
                       description='Константа'),
    'type': SingleParam(content=[PartPosition(start=18, length=6)], sign=False, CMR=1, type='int',
                        description='Тип строки', range=(0, 63)),
    'OMB': SingleParam(content=[PartPosition(start=34, length=16)], sign=False, CMR=1, type='int',
                       description='Оцифровка метки времени', units='2 с', range=(0, 43199)),
    'N4': SingleParam(content=[PartPosition(start=39, length=5)], sign=False, CMR=1, type='int',
                      description='Номер 4-хлетнего периода', range=(1, 31)),
    'Nt': SingleParam(content=[PartPosition(start=50, length=11)], sign=False, CMR=1, type='int',
                      description='Номер суток в 4-хлетнем периоде', units='сутки', range=(1, 1461)),
    'Gj': SingleParam(content=[PartPosition(start=51, length=1)], sign=False, CMR=1, type='int',
                      description='Признак годности ("0") или негодности ("1") нав. сигнала НКА'),
    'Lj': SingleParam(content=[PartPosition(start=52, length=1)], sign=False, CMR=1, type='int',
                      description='Признак достоверности ("0") или недостоверности ("1") ЦИ в данной строке НКА'),
    'Pk': SingleParam(content=[PartPosition(start=60, length=8)], sign=False, CMR=1, type='int',
                      description='Признак параметра специального кодирования'),
    'j': SingleParam(content=[PartPosition(start=66, length=6)], sign=False, CMR=1, type='int',
                     description='Системный номер НКА', range=(0, 63)),
    'P1': SingleParam(content=[PartPosition(start=69, length=3)], sign=False, CMR=1, type='int',
                      description='Признак вызова НКУ'),
    'P2': SingleParam(content=[PartPosition(start=70, length=1)], sign=False, CMR=1, type='int',
                      description='Признак режима ориентации'),
    'KR': SingleParam(content=[PartPosition(start=72, length=2)], sign=False, CMR=1, type='int',
                      description='Признак ожидаемой коррекции'),
    'A': SingleParam(content=[PartPosition(start=73, length=1)], sign=False, CMR=1, type='int',
                     description='Признак выполнения коррекции'),
    'CC': SingleParam(content=[PartPosition(start=250, length=16)], sign=False, CMR=1, type='int',
                      description='Циклический код'),
}

"""Служебные поля всех строк"""

# Список шаблонов для строк длиной 250 бит
strings_pattern_250bit = {
    10: string10_pattern,
    11: string11_pattern,
    12: string12_pattern,
    13: string13_pattern,
    20: string20_pattern,
    25: string25_pattern,
    16: string16_pattern,
    31: string31_pattern,
    32: string32_pattern,
    60: string60_pattern,
    0: {}  # отражает тот факт, что у этого типа строк нет иных полей, кроме служебных (общих)
}

calc_pattern_start_index(service_pattern, STRING_2SEC_BITLENGTH)
calc_pattern_start_index(string1_pattern, STRING_1SEC_BITLENGTH)
calc_pattern_start_index(string2_pattern, STRING_3SEC_BITLENGTH)
calc_pattern_list_start_index(strings_pattern_250bit, STRING_2SEC_BITLENGTH)  # добавляем уже пересчитанные позиции
append_common_fields_to_patterns(strings_pattern_250bit, service_pattern)  # должна находится до пересчета стартовых бит
