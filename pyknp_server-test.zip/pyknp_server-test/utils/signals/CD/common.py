from datetime import datetime, timedelta

from cachetools import TTLCache, cached

from utils.lib.get_date_from_N4_and_N import get_date_from_N4_and_N

# Создаем TTLCache с временем жизни 30 минут и максимальным размером 100 элементов
cache = TTLCache(maxsize=100, ttl=30 * 60)  # 30 минут * 60 секунд


@cached(cache)
def tb_to_datetime(tb: int, N=None, N4=None) -> datetime:
    delta = timedelta(seconds=tb)
    if N is None or N4 is None:
        return datetime.now().replace(hour=0, minute=0, second=0) + delta
    return get_date_from_N4_and_N(N=N, N4=N4) + delta
