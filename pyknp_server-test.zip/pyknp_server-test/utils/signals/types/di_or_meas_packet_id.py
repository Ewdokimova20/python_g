from typing_extensions import Literal

DIOrMeasPacketID = Literal[0x11, 0x21]
"""Тип, который описывает, что ИД пакета является либо ЦИ, либо 1с измерения"""
