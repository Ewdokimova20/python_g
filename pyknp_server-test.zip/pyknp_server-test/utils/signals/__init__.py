from utils.signals.CD.L1OC import L1OC_STRING_DURATION
from utils.signals.CD.L1SC_L2SC import SC_STRING_DURATION
from utils.signals.CD.L2KSI import L2KSI_STRING_DURATION
from utils.signals.CD.L3OC import L3OC_STRING_DURATION
from utils.signals.FD.L1OF import L1OF_STRING_DURATION
from utils.signals.FD.L1SF import L1SF_STRING_DURATION
