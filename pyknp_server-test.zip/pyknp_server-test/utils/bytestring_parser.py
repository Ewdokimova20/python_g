import struct
from dataclasses import dataclass
from functools import reduce
from typing import List, Union


@dataclass(frozen=False)
class PartPosition:
    start: int
    """Номер бита, с которого начинается параметр (началом считается первый младший бит параметра)
    относительно младшего бита строки"""
    length: int
    """Длина параметра в битах"""


@dataclass(frozen=False)
class SingleParam:
    content: List
    """Части, из которых состоит параметр (обычно одна или две, первая часть - младшие биты)"""
    sign: bool
    """Знак"""
    CMR: float
    """ЦМР (цена младшего разряда)"""
    type: str
    """Тип параметра (int, str, boolean)"""
    description: str = None
    range: tuple = None
    units: str = None
    ieee754_flag: bool = None
    """Необязательное поле для указания, что формат данных IEEE754 (число с плавающей точкой)"""


def parse_string_to_params(byte_string: Union[bytes, int], pattern: dict):
    """
    Распарсить байтовую строку в виде словаря параметр: значение
    :param byte_string: Байтовая строка, которую необходимо распарсить
    :param pattern: Словарь, содержащий координаты (и пр. инфу) параметров, подлежащих парсингу, во входной строке
    """

    def get_param(string: int, param: SingleParam):
        """
        Получить значение параметра
        :param string: Строка в целочисленном виде
        :param param: Параметр, который необходимо извлечь
        """

        param_parts = []
        param_parts_raw = []
        prev_parts_len = 0  # длина предыдущих частей параметра
        sign = 1
        num_of_parts = len(param.content)

        for idx, part in enumerate(param.content):
            shift = (part.start - 1)
            mask = 2 ** part.length - 1

            # извлекаем значение параметра
            val = (string >> shift) & mask
            # сдвигаем на длину младшей части (если текущая младшая - ничего не сдвигается)
            val = val << prev_parts_len
            # прибавляем к длине предыдущих частей текущую
            prev_parts_len = prev_parts_len + part.length
            param_parts_raw.append(val)

            if param.sign and (idx == num_of_parts - 1):
                # извлекаем знак из самой старшей (последней) части
                bit_sign = (val >> (prev_parts_len - 1)) & 0b1
                sign = -1 if bit_sign else 1
                # убираем знак из текущей части, чтоб он не влиял на числовое значение
                signless_mask = 2 ** (prev_parts_len - 1) - 1
                val = val & signless_mask
            # помещаем извлеченную часть в список
            param_parts.append(val)

        # последовательное побитовое сложение всех частей
        extracted_param = reduce(lambda x, y: x | y, param_parts)

        # Декодируем формат чисел БИВК (процессор с архитектурой MIPS), соответствующего стандарту IEE754
        if param.ieee754_flag:

            value = struct.unpack('>f', bytearray.fromhex(f'{extracted_param:08X}'))[0]

        else:
            value = extracted_param * param.CMR * sign

        return value, reduce(lambda x, y: x | y, param_parts_raw)

    parsed = {}
    binary = {}
    string = 0

    if byte_string is not None:
        if isinstance(byte_string, (bytes, bytearray)):
            string = int.from_bytes(byte_string, byteorder='big')
        elif isinstance(byte_string, int):
            string = byte_string

        for key, value in pattern.items():
            val, raw = get_param(string, value)
            parsed[key] = val
            binary[key] = raw

    return parsed, binary


def calc_pattern_start_index(pattern, string_length):
    """Пересчёт смещений адресов параметров от младшего разряда для конкретного шаблона"""
    for param in pattern.values():
        param.content[0].start = string_length - param.content[0].start + 1


def calc_pattern_list_start_index(pattern_list, string_length):
    """Пересчёт смещений адресов параметров для списка шаблонов"""
    for pattern in pattern_list.values():
        calc_pattern_start_index(pattern, string_length)


def append_common_fields_to_patterns(pattern_list, common_fields):
    """Добавляет общие(служебные) поля во все строки из состава словаря шаблонов строк"""
    for key, pattern in pattern_list.items():
        pattern_list[key] = {**common_fields, **pattern}
