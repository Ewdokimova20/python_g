from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, TYPE_CHECKING

from global_data.nka_type import NkaType
from utils.SI.compare_si_to_di.types import SiFormNum
from utils.SI.si_embedding_verification.types import SIEmbeddingVerificationFlagColor as FlagColor, EmbeddingStage, \
    VerificationStage, SiEmbedEntryDict
from utils.SI.si_embedding_verification.utils.get_next_tb_switch import get_next_tb_switch
from utils.caches.cache import cache_manager
from utils.lib.types.type_aliases import NkaSysNum

if TYPE_CHECKING:
    from utils.SI.common import SIRecord


@dataclass
class SiEmbedEntry:
    """
    Класс контролируемой записи СИ (закладки) из плана закладок.

    Отвечает за хранение и обновление состояния записи на этапах закладки и контроля.

    Attributes:
        id (int): Уникальный идентификатор записи.
        nka (int): Системный номер НКА.
        si_form (SiFormNum): Форма СИ.
        start_time (datetime): Время начала закладки СИ.
        end_time (datetime): Время окончания закладки СИ.
        flag_cdb (Optional[int]): Флаг записи СИ в ЦБД.
        flag_sui (Optional[int]): Флаг передачи СИ на СУИ.
        flag_ka (Optional[int]): Флаг закладки СИ на НКА.
        embedding_stage (EmbeddingStage): Текущий этап закладки.
        verification_stage (VerificationStage): Текущий этап контроля.
        verification_result (Optional[bool]): Результат контроля (успешен или нет).
        start_waiting_verification_at (Optional[datetime]): Время начала ожидания результата контроля (смена TB).
        verified_at (Optional[datetime]): Время получения результата контроля.
        _record (SIRecord): Исходная запись из ЦБД для обновления.
    """

    def __init__(self, record: 'SIRecord'):
        self.id: int = record.id
        self.nka: NkaSysNum = record.nka_sys_num
        self.si_form: 'SiFormNum' = SiFormNum(record.si_form)
        self.start_time: datetime = record.start_time
        self.end_time: datetime = record.end_time
        self.flag_cdb: Optional[bool] = getattr(record, "flag_cdb", None)
        self.flag_sui: Optional[bool] = getattr(record, "flag_sui", None)
        self.flag_ka: Optional[bool] = getattr(record, "flag_ka", None)
        self.embedding_stage: EmbeddingStage = EmbeddingStage.PLANNING  # статус закладки СИ
        self.verification_stage: VerificationStage = VerificationStage.WAITING_VERIFICATION  # статус контроля закладки СИ
        self.verification_result: Optional[bool] = None  # флаг того, увидели ли мы в ЦИ заложенную СИ
        self.start_waiting_verification_at: Optional[datetime] = None  # время начала tb, с которого ожидаем результат контроля
        self.verified_at: Optional[datetime] = None  # время, когда получили результат контроля
        self._record: 'SIRecord' = record  # для обновления полей при обновлении из ЦБД

    def update_from_record(self, record: 'SIRecord'):
        """
        Обновляет поля из новой записи ЦБД, кроме статусов и флагов.

        Args:
            record (SIRecord): Новая версия записи из базы данных.
        """
        self.start_time = record.start_time
        self.end_time = record.end_time
        self.flag_cdb = record.flag_cdb
        self.flag_sui = record.flag_sui
        self.flag_ka = record.flag_ka
        self.flag_cdb = getattr(record, "flag_cdb", None)
        self.flag_sui = getattr(record, "flag_sui", None)
        self.flag_ka = getattr(record, "flag_ka", None)
        self._record = record

    def update_embedding_stage(self, now: datetime):
        """
        Обновляет статус этапа закладки (embedding_stage) в зависимости от текущего времени.

        Args:
            now (datetime): Текущее время для сравнения с периодом закладки.
        """
        if now < self.start_time:
            self.embedding_stage = EmbeddingStage.PLANNING
        elif self.start_time <= now < self.end_time:
            self.embedding_stage = EmbeddingStage.IN_PROGRESS
        else:
            self.embedding_stage = EmbeddingStage.COMPLETED

    @property
    def min_embed_apply_timedelta(self) -> timedelta:
        """
        Определяет мин. временной интервал embed_apply_time_shift между концом закладки СИ end_time и временем смены tb
        tb_switch_time, необходимый для применения этой закладки со следующего tb, в зависимости от типа НКА.

        Логика определения embed_apply_time_shift:
        1. По умолчанию используется константа 10 минут (для типов КА 14Ф113 и 14Ф143)
        2. Для типа НКА 14Ф160 константа равна 5 минут
        3. Алгоритм определения момента применения закладки СИ:
           - Если (tb_switch_time - end_time) > embed_apply_time_shift,
           то закладка применится со следующего tb (т.е. с tb_switch_time)
           - Если время окончания закладки (tb_switch_time - end_time) < embed_apply_time_shift,
             то закладка применится через tb (т.е. с tb_switch_time + 30 минут)

        Returns:
            timedelta: Мин. временной интервал между концом закладки СИ и временем смены tb в минутах для применения закладки
        """
        # Значение по умолчанию  (для типов КА 14Ф113 и 14Ф143)
        embed_apply_time_shift = 10

        # Получаем объект НКА для получения его типа
        nka = cache_manager.get_nka(self.nka)

        # Корректируем значение если тип НКА -- 14Ф160
        if nka and nka.type_ka == NkaType.KA14F160:
            embed_apply_time_shift = 5  # для 14Ф160 время равно 5 минут

        return timedelta(minutes=embed_apply_time_shift)

    def update_verification_stage(self):
        """
        Обновляет статус этапа контроля (verification_stage) на основе текущего этапа закладки и формата СИ.

        Рассчитывает время начала ожидания результата контроля (start_waiting_verification_at)
        и переходит в состояние WAITING_RESULT.
        """
        if self.embedding_stage == EmbeddingStage.PLANNING:
            self.verification_stage = VerificationStage.WAITING_VERIFICATION
        elif self.embedding_stage in (EmbeddingStage.IN_PROGRESS, EmbeddingStage.COMPLETED):
            if self.verification_stage == VerificationStage.WAITING_VERIFICATION:
                tb_switch_time = get_next_tb_switch(self.end_time)  # время ближайшей смены tb

                # Определяем время начала ожидания результата контроля
                if tb_switch_time - self.end_time > self.min_embed_apply_timedelta:
                    # Если tb_switch_time - self.end_time больше, чем мин. интервал между концом закладки СИ и временем смены tb,
                    # необходимый для закладки СИ на след. tb, то ожидаем результаты контроля со след. tb
                    self.start_waiting_verification_at = tb_switch_time
                else:
                    # Если нет, то считаем, что начало ожидания будет через tb
                    self.start_waiting_verification_at = tb_switch_time + timedelta(minutes=30)

                self.verification_stage = VerificationStage.WAITING_RESULT

    def get_flag_cdb(self) -> FlagColor:
        return FlagColor.GREEN if self.flag_cdb == 1 else FlagColor.RED

    def get_flag_sui(self) -> FlagColor:
        now = datetime.now()
        if self.start_time > now:
            return FlagColor.GRAY
        if self.flag_sui == 1:
            return FlagColor.GREEN
        return FlagColor.RED

    def get_flag_ka(self) -> FlagColor:
        now = datetime.now()
        if self.flag_ka == 1:
            return FlagColor.GREEN
        if now < self.end_time:
            return FlagColor.GRAY
        return FlagColor.RED

    def get_flag_control(self) -> FlagColor:
        if self.verification_result is None:
            return FlagColor.GRAY
        return FlagColor.GREEN if self.verification_result else FlagColor.RED

    def to_dict(self) -> SiEmbedEntryDict:
        """Возвращает словарь для интерфейса, используя DTO."""
        return SiEmbedEntryDict(
            id=self.id,
            nka=self.nka,
            si_form=self.si_form,
            start_time=self.start_time,
            end_time=self.end_time,
            flag_cdb=self.get_flag_cdb(),
            flag_sui=self.get_flag_sui(),
            flag_ka=self.get_flag_ka(),
            flag_verification_result=self.get_flag_control(),
            embedding_stage=self.embedding_stage,
            verification_stage=self.verification_stage,
            verified_at=self.verified_at,
            start_waiting_verification_at=self.start_waiting_verification_at,
        )
