import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from communication.types import ZMQTopic
from db.cdb.new import SIFormTable
from scripts.process_registry import get_zmq_manager
from utils.SI.compare_si_to_di.types import SiFormNum, SiFormNameForClient
from utils.SI.si_embedding_verification.si_embed_entry import SiEmbedEntry
from utils.SI.si_embedding_verification.types import EmbeddingStage, SiEmbedEntryDict
from utils.SI.si_embedding_verification.types.verification_stage import VerificationStage


class SIEmbeddingVerifier:
    """
    Класс для оперативного контроля закладок специнформации (СИ) на НКА.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # self.update_interval = timedelta(minutes=update_interval_minutes)
        self.update_interval = timedelta(seconds=30)
        self.status_check_interval = timedelta(seconds=30)
        # self.search_depth = timedelta(hours=2)
        self.search_depth = timedelta(weeks=2)
        self._zmq_manager = get_zmq_manager()
        self._entries: Dict[int, SiEmbedEntry] = {}  # id -> SiEmbedEntry

        # Для синхронизации многопоточного доступа
        self._lock = threading.Lock()

    def get_records_from_cdb_future(self):
        """Загрузка буфера закладок на ближайшие 2 часа"""
        now = datetime.now()
        time_start = now
        time_end = now + self.search_depth
        try:
            records = SIFormTable().get_records_from_cdb_for_operation_uplink_control(
                form=[SiFormNum.EPHEMERIS, SiFormNum.CLOCKP, SiFormNum.ALMANAC, SiFormNum.EPHEMERIS_PROP_MODE,
                      SiFormNum.CLOCKP_PROP_MODE],
                time_start=time_start, time_end=time_end
            )
            self.logger.debug(f"Получено {len(records)} записей из ЦБД для буфера ожидания")
            return records
        except Exception as e:
            self.logger.error(f"Ошибка при получении записей из ЦБД: {e}")
            return []

    def periodic_update_future_buffer(self):
        """Периодически обновляет буфер ожидания закладок"""
        records = self.get_records_from_cdb_future()
        with self._lock:
            ids_in_db = set()
            for record in records:
                ids_in_db.add(record.id)
                if record.id in self._entries:
                    self._entries[record.id].update_from_record(record)
                else:
                    self._entries[record.id] = SiEmbedEntry(record)

                # Удаляем закладки, завершившиеся больше 2 часов назад
                now = datetime.now()
                for entry_id in list(self._entries.keys()):
                    entry = self._entries[entry_id]
                    if entry.embedding_stage == EmbeddingStage.COMPLETED:
                        if (now - entry.end_time) > timedelta(hours=2):  # FIXME константу сделать
                            del self._entries[entry_id]

    def periodic_status_update(self):
        """Переходы между статусами"""
        now = datetime.now()
        with self._lock:
            for entry in self._entries.values():
                entry.update_embedding_stage(now)
                entry.update_verification_stage()

    def handle_verification_results_update(self, control_data: Dict[int, Dict[SiFormNameForClient, Optional[bool]]]):
        """
        Обработка результатов оперативного контроля.

        Args:
            control_data: {nka: {form_type: результат контроля}}
            Например: {1: {'form_169': True, 'form_893': False}, 2: {'form_169': None}}
        """
        # Маппинг числовых форм в строковые ключи
        form_mapping: Dict[SiFormNum, SiFormNameForClient] = {
            SiFormNum.CLOCKP: SiFormNameForClient.CLOCKP,
            SiFormNum.TAUA: SiFormNameForClient.TAUA,
            SiFormNum.EPHEMERIS: SiFormNameForClient.EPHEMERIS,
            SiFormNum.ALMANAC: SiFormNameForClient.ALMANAC,
            SiFormNum.TZ: SiFormNameForClient.TZ,
            SiFormNum.EPHEMERIS_PROP_MODE: SiFormNameForClient.EPHEMERIS,
            SiFormNum.CLOCKP_PROP_MODE: SiFormNameForClient.CLOCKP,
        }

        now = datetime.now()
        with self._lock:
            for entry in self._entries.values():
                if entry.verification_stage == VerificationStage.WAITING_RESULT and entry.nka in control_data:

                    # Проверяем, наступило ли время ожидания результата контроля
                    if entry.start_waiting_verification_at is None or now >= entry.start_waiting_verification_at:

                        # Получаем строковый ключ формы для данной записи
                        form_key = form_mapping.get(entry.si_form)

                        if form_key and form_key in control_data[entry.nka]:
                            control_result = control_data[entry.nka][form_key]

                            if control_result is not None:  # Есть результат контроля
                                entry.verification_result = control_result
                                entry.verified_at = now
                                entry.verification_stage = VerificationStage.COMPLETED
                                self.logger.info(
                                    f"Для НКА {entry.nka}, форма {entry.si_form} ({form_key.value}) "
                                    f"получен результат контроля: {control_result}"
                                )

    def form_table_data(self) -> List[SiEmbedEntryDict]:
        """Собирает данные для отправки в интерфейс через DTO."""
        with self._lock:
            return [entry.to_dict() for entry in self._entries.values()]

    def update_and_send_data(self):
        """Собирает, формирует и отправляет данные по ZMQ"""
        table_data = self.form_table_data()
        try:
            self._zmq_manager.publish_data(
                topic=ZMQTopic.SI_EMBEDDING_VERIFICATION,
                data=table_data
            )
            self.logger.info(f"Отправлены данные оперативного контроля: {len(table_data)} записей")
        except Exception as e:
            self.logger.warning(f'Ошибка при отправке данных оперативного контроля: {repr(e)}', exc_info=True)

    def run_periodic_updates(self, exiting_event):
        """Основной цикл: обновление буфера, статусов и отправка"""
        self.logger.info("Запущен цикл периодических обновлений оперативного контроля")
        while not exiting_event.is_set():
            start_time = datetime.now()
            try:
                self.periodic_update_future_buffer()
                self.periodic_status_update()
                self.update_and_send_data()
            except Exception as e:
                self.logger.error(f"Ошибка в цикле обновления: {e}")
            elapsed = (datetime.now() - start_time).total_seconds()
            sleep_time = max(0, self.update_interval.total_seconds() - elapsed)
            if sleep_time > 0:
                exiting_event.wait(timeout=sleep_time)
        self.logger.info("Цикл периодических обновлений остановлен по событию")
