import threading
from typing import List, Dict, Any

from utils.SI.compare_si_to_di.types import SiFormNum
from utils.SI.si_embedding_verification.types import SiEmbedEntryDict


class SIEmbeddingVerificationForCLient:
    """
    Класс для отдачи результатов оперативного контроля закладки СИ на клиент.
    Находится в основном (обобщающем) процессе
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._table_data: List[SiEmbedEntryDict] = []

    def load_data(self, data: Dict[str, List[SiEmbedEntryDict]]):
        """
        Хэндлер для загрузки данных из сообщения ZMQ
        """
        with self._lock:
            self._table_data = data

    def get_data(self, show_retranslation_forms: bool) -> List[Dict[str, Any]]:
        """
        Возвращает актуальные данные оперативного контроля закладки СИ.
        """
        with self._lock:
            if show_retranslation_forms is False:
                return [entry for entry in self._table_data if entry['si_form'] not in [SiFormNum.EPHEMERIS, SiFormNum.CLOCKP]]
            else:
                return self._table_data


si_embedding_verification_for_client = SIEmbeddingVerificationForCLient()
