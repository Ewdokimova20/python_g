from datetime import datetime, timedelta


def get_next_tb_switch(time_point: datetime) -> datetime:
    """Возвращает ближайшее время смены tb (оканчивается на 00 или 30 минут) для заданного time_point"""
    minute = time_point.minute
    if minute < 30:
        return time_point.replace(minute=30, second=0, microsecond=0)
    else:
        # Переход на следующий час
        next_hour = (time_point + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
        return next_hour
