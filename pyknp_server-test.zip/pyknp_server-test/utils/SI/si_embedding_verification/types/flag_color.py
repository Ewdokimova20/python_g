from enum import Enum


class SIEmbeddingVerificationFlagColor(str, Enum):
    """Цвет для флагов в оперативном контроле закладок"""
    GREEN = "green"
    RED = "red"
    GRAY = "gray"
    NOT_APPLICABLE = "not-applicable"
