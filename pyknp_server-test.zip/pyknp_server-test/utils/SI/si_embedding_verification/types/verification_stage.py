from enum import Enum


class VerificationStage(str, Enum):
    WAITING_VERIFICATION = "Ожидает начала контроля"
    WAITING_RESULT = "Ожидает результат контроля по ЦИ"
    COMPLETED = "Контроль завершён"
