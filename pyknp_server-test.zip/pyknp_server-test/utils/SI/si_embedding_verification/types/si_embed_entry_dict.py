from datetime import datetime
from typing import Optional

from typing_extensions import TypedDict

from utils.SI.si_embedding_verification.types.embedding_stage import EmbeddingStage
from utils.SI.si_embedding_verification.types.flag_color import SIEmbeddingVerificationFlagColor
from utils.SI.si_embedding_verification.types.verification_stage import VerificationStage


class SiEmbedEntryDict(TypedDict):
    """
    Словарь для передачи данных записи верификации между слоями приложения
    или для отправки на клиент.

    Attributes:
        id (int): Уникальный идентификатор записи.
        nka (int): Системный номер НКА.
        si_form (int): Форма СИ.
        start_time (datetime): Время начала закладки СИ.
        end_time (datetime): Время окончания закладки СИ.
        flag_cdb (SIEmbeddingVerificationFlagColor): Флаг записи СИ в ЦБД.
        flag_sui (SIEmbeddingVerificationFlagColor): Флаг передачи СИ на СУИ.
        flag_ka (SIEmbeddingVerificationFlagColor): Флаг закладки СИ на НКА.
        flag_verification_result (SIEmbeddingVerificationFlagColor): Результат контроля (флаг).
        embedding_stage (EmbeddingStage): Текущий этап закладки.
        verification_stage (VerificationStage): Текущий этап контроля.
        verified_at (Optional[datetime]): Время получения результата контроля.
        start_waiting_verification_at (Optional[datetime]): Время начала ожидания результата контроля (смена TB).
    """
    id: int
    nka: int
    si_form: int
    start_time: datetime
    end_time: datetime
    flag_cdb: SIEmbeddingVerificationFlagColor
    flag_sui: SIEmbeddingVerificationFlagColor
    flag_ka: SIEmbeddingVerificationFlagColor
    flag_verification_result: SIEmbeddingVerificationFlagColor
    embedding_stage: EmbeddingStage
    verification_stage: VerificationStage
    verified_at: Optional[datetime]
    start_waiting_verification_at: Optional[datetime]
