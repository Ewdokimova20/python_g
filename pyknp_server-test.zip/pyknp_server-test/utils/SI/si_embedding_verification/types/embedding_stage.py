from enum import Enum


class EmbeddingStage(str, Enum):
    PLANNING = 'PLANNING'  # Ожидает начала закладки
    IN_PROGRESS = 'IN_PROGRESS'  # Закладка в процессе
    COMPLETED = 'COMPLETED'  # Закладка завершена
