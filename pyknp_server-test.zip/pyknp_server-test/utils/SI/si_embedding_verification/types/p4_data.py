from datetime import datetime
from typing import Dict

from typing_extensions import TypedDict

from utils.lib.types.type_aliases import NkaSysNum


class P4ValueDict(TypedDict):
    value: int
    last_at: datetime


P4Data = Dict[NkaSysNum, P4ValueDict]
"""
Тип данных со значениями P4 для проведения оперативного контроля закладок.
Ключ - системный номер НКА,
значение - словарь с ключами:
  - value (int) - значение P4,
  - last_at (datetime) - время значения
"""
