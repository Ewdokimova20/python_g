import datetime
from dataclasses import dataclass, asdict
from enum import IntEnum, Enum
from typing import Set, Optional, List, Dict, Union, TypeVar

from typing_extensions import TypedDict, Literal


class SiFormNum(IntEnum):
    """Соответствие названия СИ и номера СИ"""
    CLOCKP = 169  # ЧВП
    TAUA = 701  # сдвиг ШВ
    EPHEMERIS = 893  # эфемеридная  информация
    ALMANAC = 895  # альманах
    TZ = 921  # временные задержки
    EPHEMERIS_PROP_MODE = 110  # эфемеридная  информация (режим размножения)
    CLOCKP_PROP_MODE = 703  # ЧВП (режим размножения)


class SiFormNameForClient(str, Enum):
    """Соответствие номера СИ и  ключа словаря с результатом сравнения ЭИ для отдачи на клиент"""
    CLOCKP = 'form_169'  # ЧВП
    TAUA = 'form_701'  # сдвиг ШВ
    EPHEMERIS = 'form_893'  # эфемеридная  информация
    ALMANAC = 'form_895'  # альманах
    TZ = 'form_921'  # временные задержки


class TimeDataDict(TypedDict, total=False):
    """Структура данных времени в формате словаря (результат as_dict у TimeData)."""
    timestamp: Optional[datetime.datetime]
    """Номинальное время излучения первой строки кадра"""
    Na: Optional[Union[int, Set[int]]]
    """Номер суток в 4-хлетнем периоде (альманах)"""
    tb: Optional[int]
    """Номер временного интервала в сутках"""
    N: Optional[int]
    """Номер суток в 4-хлетнем периоде"""
    NaT: Optional[int]
    """Номер суток в 4-хлетнем периоде (альманах) для кодовых в форме 701"""
    mode: Optional[Literal['DI', 'SI']]
    """Режим длительности tb (либо как в СИ, либо как в ЦИ)"""
    tb_timestamp: Optional[str]
    """Время tb в строковом формате дата-время"""
    N4: Optional[int]
    """Номер 4-хлетнего периода"""
    tk: Optional[int]
    """Время начала кадра"""


@dataclass
class TimeData:
    """Структура данных времени."""
    timestamp: Optional[datetime.datetime] = None
    """Номинальное время излучения первой строки кадра"""
    Na: Optional[Union[int, Set[int]]] = None
    """Номер суток в 4-хлетнем периоде (альманах)"""
    tb: Optional[int] = None
    """Номер временного интервала в сутках"""
    N: Optional[int] = None
    """Номер суток в 4-хлетнем периоде"""
    NaT: Optional[int] = None
    """Номер суток в 4-хлетнем периоде (альманах) для кодовых в форме 701"""
    mode: Optional[Literal['DI', 'SI']] = 'DI'
    """Режим длительности tb (либо как в СИ, либо как в ЦИ)"""
    tb_timestamp: Optional[str] = None
    """Время tb в строковом формате дата-время"""
    N4: Optional[int] = None
    """Номер 4-хлетнего периода"""
    tk: Optional[int] = None
    """Время начала кадра"""

    def as_dict(self) -> TimeDataDict:
        return asdict(self)

    def __str__(self):
        return (f'TimeData(timestamp={self.timestamp}, '
                f'Na={self.Na}, tb={self.tb}, N={self.N})')

    def __repr__(self):
        return self.__str__()


class FrameParameter(TypedDict):
    val: Union[float, int]
    raw: Union[float, int]
    description: str


class ComparisonItem(TypedDict, total=False):
    param: str  # Название параметра
    di: Union[int, float]  # Значение параметра из кадра
    si: Union[int, float, None]  # Значение параметра из СИ
    diff: Union[int, float, None]  # Расхождение параметра из кадра и из СИ
    is_valid: Optional[bool]  # Флаг находится ли расхождение в допустимых пределах
    threshold: Union[int, float]  # Допустимый порог для расхождения


ClockComparison = List[ComparisonItem]
"""Тип для результата сравнения параметров формы 169"""
AlmComparison = Dict[int, List[ComparisonItem]]
"""Тип для результата сравнения параметров формы 895"""
EphComparison = ClockComparison
"""Тип для результата сравнения параметров формы 893"""
TauAComparison = AlmComparison
"""Тип для результата сравнения параметров формы 701"""


class FormData(TypedDict, total=False):
    """Словарь для представления данных формы СИ.

        Attributes:
            data: Данные формы, могут быть представлены как список или словарь ComparisonItem.
            record_data: Дополнительные данные о записях СИ, связанные с формой СИ.
    """
    data: Union[EphComparison, ClockComparison, AlmComparison, TauAComparison]
    """Параметры фразы СИ с их значениями"""
    record_data: Dict[str, Union[int, datetime.datetime, str, None]]
    """Данные о записи СИ для её идентификации(id, timestamp, tb, format(для какого КА))"""


class Form169ParamKeys(str, Enum):
    """Перечень параметров формы СИ 169"""
    tau = 'tau'
    """Сдвиг шкалы времени"""
    gamma = 'gamma'
    """Отклонение несущей частоты"""
    gamma_L3 = 'gamma_L3'
    """Отклонение несущей частоты для сигналов с кодовым разделением"""
    beta = 'beta'
    """Скорость изменения отклонения"""


FORM_169_PARAMS = {member.value for member in Form169ParamKeys}


class Form893ParamKeys(str, Enum):
    """Перечень параметров формы СИ 893"""
    x = 'x'
    """Координата по х"""
    y = 'y'
    """Координата по y"""
    z = 'z'
    """Координата по z"""
    Vx = 'Vx'
    """Скорость по x"""
    Vy = 'Vy'
    """Скорость по y"""
    Vz = 'Vz'
    """Скорость по z"""
    Ax = 'Ax'
    """Ускорение по x"""
    Ay = 'Ay'
    """Ускорение по y"""
    Az = 'Az'
    """Ускорение по z"""
    x_L3 = 'x_L3'
    """Координата по х для сигналов с кодовым разделением"""
    y_L3 = 'y_L3'
    """Координата по y для сигналов с кодовым разделением"""
    z_L3 = 'z_L3'
    """Координата по z для сигналов с кодовым разделением"""
    Ax_L3 = 'Ax_L3'
    """Ускорение по x для сигналов с кодовым разделением"""
    Ay_L3 = 'Ay_L3'
    """Ускорение по y для сигналов с кодовым разделением"""
    Az_L3 = 'Az_L3'
    """Ускорение по z для сигналов с кодовым разделением"""


FORM_893_PARAMS = {member.value for member in Form893ParamKeys}


class Form895ParamKeys(str, Enum):
    """Перечень параметров формы СИ 895"""
    delta_T = 'delta_T'
    """Поправка к драконическому периоду"""
    t_lambda = 't_lambda'
    """Время прохождения 1-го восходящего угла"""
    epsilon = 'epsilon'
    """Эксцентриситет орбиты"""
    d_delta_T = 'd_delta_T'
    """Скорость изменения драконического периода"""
    omega = 'omega'
    """Аргумент перигея"""
    lambda_ = 'lambda_'
    """Долгота восходящего узла"""
    delta_i = 'delta_i'
    """Поправка к наклонению орбиты"""


FORM_895_PARAMS = {member.value for member in Form895ParamKeys}

AlmanacParams = Dict[Form895ParamKeys, Union[float, int, None]]
Form895Params = Dict[int, AlmanacParams]  # ключ - номер НКА, значение - альманах для данного КА
Form893Params = Dict[Form893ParamKeys, Union[float, int, None]]
Form169Params = Dict[Form169ParamKeys, Union[float, int, None]]


class Form701Params(TypedDict):
    """Параметры формы 701 (TauA)"""
    tau_a: Dict[str, dict]  # Словарь задержек tau_a для разных НКА


class Form921Params(TypedDict):
    """Параметры формы 921 (Временные задержки)"""
    tz: Dict[str, dict]  # Словарь задержек tz для разных НКА


SiFormData = TypeVar('SiFormData',
                     bound=Union[Form169Params, Form893Params, Form701Params, Form895Params, Form921Params])


class SIRecordDataForClient(TypedDict, total=False):
    """Данные о записи СИ в ЦБД и tb фразы, в которой содержались найденные параметры"""
    id: int
    """ID записи в ЦБД"""
    timestamp: datetime.datetime
    """Время записи СИ в ЦБД"""
    form: str
    """Тип СИ по КА (Название КА)"""
    tb: int
    """Значение tb"""


AllFormsComparison = Dict[SiFormNameForClient, FormData]
"""Тип для результата сравнения СИ и ЦИ для всех форм"""


class ComparisonResult(TypedDict, total=False):
    """Конечный результат сравнения СИ и ЦИ"""
    sys_num: Optional[int]
    time: Optional[TimeDataDict]
    forms: AllFormsComparison


class ComparisonParam(TypedDict):
    """Тип для сохранения параметров сравнения с СИ, вставляемых в таблицу SummarizedFrameComparison."""
    frame_info_id: int
    almanac_sys_num: Optional[int]
    name: str
    param_value: Optional[Union[float, int, str, datetime.datetime]]
    is_valid: Optional[bool]
    si_value: Optional[Union[float, int, str]]
    si_timestamp: Optional[datetime.datetime]
    si_phrase_tb: Optional[int]


ParamName = str


class SiCentre(TypedDict):
    """Данные СИ, полученные в центре масс или фазовом центре."""
    data: float
    type: Literal['mass', 'phaseL3']


class SiEntry(TypedDict, total=False):
    """Данные СИ для параметра (оперативка)."""
    ph_centre_fd: Optional[float]  # «фазовый центр FD»
    centre: Optional[SiCentre]  # центр масс / фаз. центр L3


class OperationalRow(TypedDict, total=False):
    """Одна строка таблицы оперативного сравнения."""
    param: ParamName
    si: Optional[SiEntry]
    # далее динамические ключи — номера сигналов (1,2,5,…) со значениями DiEntry


class ImmediateInfoResponse(TypedDict):
    """Ответ для get_immediate_info_online_comparison."""
    table_data: List[OperationalRow]
    si_timestamp: Dict[SiFormNum, List[Dict[str, str]]]  # '169' | '893'


SignalType = int
NkaNum = int

AlmanacResponse = Dict[NkaNum, Dict[SignalType, Dict[ParamName, Optional[bool]]]]


class SingleAlmanacRow(TypedDict):
    """Альманаха для одного НКА и одного типа сигнала."""
    param: ParamName
    di_value: Union[float, str]
    si_value: Optional[float]
    is_valid: Optional[bool]


class SingleAlmanacResponse(TypedDict):
    """Ответ функции get_single_nka_almanac_online_comparison."""
    table_data: List[SingleAlmanacRow]
    si_timestamp: Optional[str]
