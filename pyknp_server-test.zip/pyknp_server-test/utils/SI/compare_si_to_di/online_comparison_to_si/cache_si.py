from __future__ import annotations

from typing import Optional, Tuple, Any

import peewee
from cachetools import TTLCache

from models.nka import Nka
from utils.SI.common import SIRecord
from utils.SI.compare_si_to_di.types import TimeData
#: maxsize можно вынести в settings, но оставим значение по умолчанию здесь
from utils.SI.main import SI_FORMS

DEFAULT_MAX_SIZE = 1000


class SICache:
    """ TTL-кэш для записей СИ.
    Attributes
    ----------
    cache : TTLCache
        Экземпляр cachetools.TTLCache, хранящий пары ``key -> SIRecord``.
    """

    def __init__(self, ttl_seconds: int, max_size: int = DEFAULT_MAX_SIZE) -> None:
        """
        Parameters:
        ttl_seconds : int  Время жизни записи в кэше (секунды).
        max_size : int, optional Максимальное количество элементов в кэше.
        """
        self.cache: TTLCache[Tuple[Any, ...], SIRecord] = TTLCache(maxsize=max_size, ttl=ttl_seconds, )

    def _load_from_db(self, orm_model, nka_number: int, time_bind: TimeData) -> Optional[SIRecord]:
        """Получить запись СИ из БД.
        Parameters:
        orm_model :             Класс peewee-модели конкретной формы СИ.
        nka_number : int        Номер КА («НКА»).
        time_point : TimeData   Точка, относительно которой выбираем «попадание» по endtime.

        Returns:
        Optional[SIRecord]  Объект доменной модели или ``None``, если не найдено/ошибка.
        """
        time_start = time_bind.timestamp - orm_model().search_depth
        time_end = time_bind.timestamp

        try:
            row = (orm_model.select(orm_model.id, orm_model.nka, orm_model.si, orm_model.vitok, orm_model.formsi,
                                    orm_model.formatsi, orm_model.endtime, orm_model.time_zap_cbd)
                   .where((orm_model.endtime.between(time_start, time_end)) & (orm_model.nka == nka_number))
                   .order_by(orm_model.endtime.desc())
                   .first())
        except (peewee.DoesNotExist, peewee.OperationalError):
            return None

        if row is None:
            return None

        return SIRecord(
            id=row.id,
            nka=row.nka,
            data=row.si,
            si_form=row.formsi,
            si_format=orm_model.NAME_SI.get(row.formatsi),
            vitok=row.vitok,
            write_time_cdb=row.time_zap_cbd,
            timestamp=row.endtime,
        )

    def _get_or_load(self, orm_model, form_num: int, time_bind: TimeData, nka_number: int) -> Optional[SIRecord]:
        """Обёртка: сперва ищем в кэше, затем — в БД.
        Ключ включает класс формы, её номер и сам номер КА.
        """
        cache_key = (orm_model, form_num, nka_number)
        record: Optional[SIRecord] = self.cache.get(cache_key)

        if record is None:
            record = self._load_from_db(orm_model=orm_model, nka_number=nka_number, time_bind=time_bind)
            if record:
                self.cache[cache_key] = record

        return record

    def get_record(self, nka: Nka, time_bind: TimeData, form_num: int) -> Optional[SIRecord]:
        """Вернуть актуальную СИ для переданного НКА.
        Parameters:
        nka : Nka   Экземпляр НКА (объект доменной модели).
        time_bind : TimeData   Временная точка, к которой хотим «привязать» выборку.
        form_index : int

        Returns:
        Optional[SIRecord] SIRecord, либо ``None``, если СИ не найдена.
        """

        form_cls = SI_FORMS.get(nka.type_si, SI_FORMS[nka.type_ka])[form_num]
        nka_number = form_cls(nka_instance=nka).curr_nka.nku_number

        return self._get_or_load(orm_model=form_cls, form_num=form_num, time_bind=time_bind, nka_number=nka_number)
