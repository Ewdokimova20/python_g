import datetime
import logging
from typing import Dict, List, Optional, Any, Union

import peewee

from data import SummarizedFrameComparison, BaseDIFrame, CDSignalFrame
from global_data import appdata
from global_data.appdata import NKA_DATA
from models.base import db
from utils.SI.common import SIRecord
from utils.SI.compare_si_to_di.manual_comparison_to_si.manual_comparison_to_si import \
    get_SI_data_for_comparison_with_DI, get_comparison_to_si_result, replace_cm_with_fca_position
from utils.SI.compare_si_to_di.online_comparison_to_si.cache_si import SICache, DEFAULT_MAX_SIZE
from utils.SI.compare_si_to_di.online_comparison_to_si.di_to_si_validity_aggregator import DItoSIValidityAggregator
from utils.SI.compare_si_to_di.types import SiFormNum, ComparisonResult, AllFormsComparison, \
    SiFormNameForClient, FORM_895_PARAMS, ComparisonParam
from utils.lib.exceptions import CompareDItoSIError

logger = logging.getLogger('online_compare_to_si')
si_cache = SICache(ttl_seconds=DEFAULT_MAX_SIZE)

di_to_si_validity_aggregator = DItoSIValidityAggregator()

NKU_TO_SYS_NUMBER = {rec['nku_num']: rec['sys_num'] for rec in appdata.NKA_DATA.values()}

def online_compare_to_si(summarized_frame: BaseDIFrame, summarized_frame_info_id: int) -> \
        Optional[ComparisonResult]:
    """Получить оперативную информацию из ЦИ обобщенного кадра, для сравнения с СИ.
    При отсутсвии СИ сохраняются просто параметры из ЦИ."""

    nka = summarized_frame.nka.nka_sys_number
    if nka not in NKA_DATA:
        return

    # 1.1 - получаем словарь всех параметров кадра
    try:
        frame_data = summarized_frame.parse_frame()
    except CompareDItoSIError as exc:
        logger.debug(f"Ошибка при получении данных из кадра в формате словаря: {exc}", exc_info=True)
        return

    # 1.2 - получаем временные параметры кадра
    try:
        time = summarized_frame.get_timebind(frame_data)
    except AttributeError as exc:
        logger.debug(
            f'Не определены параметры Nt, Na или tb кадра {str(summarized_frame)}: '
            f'невозможно найти соответствующую СИ: {str(exc)}', exc_info=True)
        return
    frame_time = time.as_dict()

    # 2 - поиск СИ в кэше
    si_records: Dict[SiFormNum, List[SIRecord]] = {}
    required_si = [SiFormNum.CLOCKP, SiFormNum.EPHEMERIS, SiFormNum.ALMANAC]
    if summarized_frame.nka.type_si == '14Ф160':
        required_si.append(SiFormNum.TZ)  # 921 форма с поправками к ЧПВ есть только у '14Ф160'
    for form_num in required_si:
        si_record = si_cache.get_record(nka=summarized_frame.nka, time_bind=time, form_num=form_num)
        if si_record:
            si_records[form_num] = [si_record]
    # 3 - распарсить формы Cи для сравнения с ЦИ кадра
    si_data, records_data = get_SI_data_for_comparison_with_DI(summarized_frame.nka, time, si_records)
    comparison_result: Optional[ComparisonResult] = {}
    # 3.1 - для частотных на 14Ф160 в СИ необходим пересчет координат x,y,z из ЦМ в ФЦА
    type_si = summarized_frame.nka.type_si
    signal_type = summarized_frame.signal_type
    if type_si == '14Ф160' and signal_type in appdata.FREQ_SIGNAL_TYPES:
        si_data = replace_cm_with_fca_position(si_data)

    # 4 - сравнить ЦИ с СИ
    is_cd_frame = True if isinstance(summarized_frame, CDSignalFrame) else False
    comparison_data: Optional[AllFormsComparison] = {}
    try:
        # производит сравнение с СИ даже при отсутствии данных по СИ, результат is_valid = None в таком случае
        comparison_data: Optional[AllFormsComparison] = get_comparison_to_si_result(signal_type=signal_type,
                                                                                    type_si=type_si,
                                                                                    is_cd_frame=is_cd_frame,
                                                                                    si_data=si_data,
                                                                                    frame_data=frame_data,
                                                                                    records_data=records_data)
    except (CompareDItoSIError, IndexError, AttributeError, KeyError) as exc:
        logger.debug(f"Ошибка при сравнении информации из обобщенного кадра с СИ: {exc}", exc_info=True)
    else:
        if records_data:
            # для формирования сигнального признака необходим именно результат сравнения,
            # а не просто дикт заполненный данными кадра в случае отсутвия СИ
            di_to_si_validity_aggregator.update_from_comparison(signal_type=signal_type,
                                                                nka_sys_number=nka,
                                                                comparison_data=comparison_data)
            comparison_result = ComparisonResult(time=frame_time, sys_num=summarized_frame.nka.nka_sys_number,
                                                 forms=comparison_data)
    # 5 подготовить данные для записи в базу
    all_params_to_insert = format_summarized_frame_comparison_result(summarized_frame_info_id, summarized_frame,
                                                                     frame_time, comparison_data)
    # 6 - записать в базу параметры для данного нка и типа сигнала
    if all_params_to_insert:
        with db.atomic():
            try:
                SummarizedFrameComparison.insert_many(all_params_to_insert).execute()
            except peewee.PeeweeException:
                logger.debug(
                    f"Ошибка при записи результатов оперативного сравнения ЦИ с СИ для кадра {str(summarized_frame)}")
    return comparison_result


def format_summarized_frame_comparison_result(summarized_frame_info_id: int, summarized_frame: BaseDIFrame,
                                              frame_time_params: dict, comparison_data: AllFormsComparison) \
        -> List[ComparisonParam]:
    """Функция для обновления словаря one_nka_parameters результатами оперативного сравнения обобщенного кадра с СИ.
    """
    all_params_to_insert = []
    time_param_names = ['N', 'N4', 'tk', 'tb', 'OMB']  # fixme N = Nt чет это путает
    params_for_representation = ['tau', 'gamma', 'gamma_L3', 'beta_l3', 'beta', 'x',
                                 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az', 'dX', 'dY', 'dZ']
    add_time_params(frame_time_params, summarized_frame, time_param_names, all_params_to_insert,
                    summarized_frame_info_id)
    for form_si, all_data in comparison_data.items():  # заполнение основных параметров
        if form_si in [SiFormNameForClient.CLOCKP, SiFormNameForClient.EPHEMERIS]:
            params = all_data.get('data', [])
            si_timestamp = all_data.get('record_data', {}).get('timestamp')
            si_phrase_tb = all_data.get('record_data', {}).get('tb')
            for param in params:
                if param['param'] in params_for_representation:
                    all_params_to_insert.append(ComparisonParam(
                        frame_info_id=summarized_frame_info_id,
                        almanac_sys_num=None,
                        name=param['param'],
                        param_value=param['di'],
                        is_valid=param['is_valid'],
                        si_value=param['si'],
                        si_timestamp=si_timestamp,
                        si_phrase_tb=si_phrase_tb
                    ))
        if form_si in [SiFormNameForClient.ALMANAC]:
            almanac = all_data.get('data', {})
            if almanac:
                si_timestamp = all_data.get('record_data', {}).get('timestamp')
                si_phrase_tb = all_data.get('record_data', {}).get('tb')
                for nku_num, params in almanac.items():
                    almanac_sys_number = NKU_TO_SYS_NUMBER.get(nku_num)
                    if almanac_sys_number is None:
                        continue
                    for param in params:
                        if param['param'] in FORM_895_PARAMS:
                            all_params_to_insert.append(ComparisonParam(
                                frame_info_id=summarized_frame_info_id,
                                almanac_sys_num=almanac_sys_number,
                                name=param['param'],
                                param_value=param['di'],
                                is_valid=param['is_valid'],
                                si_value=param['si'],
                                si_timestamp=si_timestamp,
                                si_phrase_tb=si_phrase_tb
                            ))
    return all_params_to_insert


def create_time_param(frame_info_id: int, param_name: str, param_value: Union[float, str]) \
        -> ComparisonParam:
    """Фабричная функция для создания ComparisonParam с дефолтными значениями"""
    return ComparisonParam(
        frame_info_id=frame_info_id,
        almanac_sys_num=None,
        name=param_name,
        param_value=param_value,
        is_valid=None,
        si_value=None,
        si_timestamp=None,
        si_phrase_tb=None
    )


def add_time_params(frame_time: Dict[str, Union[float, datetime.datetime]], summarized_frame: BaseDIFrame,
                    time_param_names: List[str], all_params_to_insert: List[ComparisonParam],
                    summarized_frame_info_id: int) -> None:
    """Добавляет временные параметры"""

    def add_param(param_name: str, value: Any) -> None:
        """Вспомогательная функция для добавления параметра"""
        if value is not None:
            all_params_to_insert.append(create_time_param(summarized_frame_info_id, param_name, value))

    for param_name in frame_time:
        if param_name not in time_param_names:
            continue

        if param_name == 'tk':
            # Обрабатываем tk и tk_datetime
            tk_value = summarized_frame.time if isinstance(summarized_frame, CDSignalFrame) else frame_time.get('tk')
            add_param('tk', tk_value)
            add_param('tk_datetime', summarized_frame.timestamp)

        elif param_name == 'tb' and frame_time.get('tb'):
            # Обрабатываем tb и tb_datetime
            add_param('tb', frame_time.get('tb'))
            tb_timestamp = frame_time.get('tb_timestamp')
            if tb_timestamp:
                add_param('tb_datetime', tb_timestamp.strftime("%H:%M:%S"))
        elif param_name == 'N4':
            value = (summarized_frame.string10.content[0]['N4']
                     if summarized_frame.__class__.__name__ == 'L1SFFrame' and summarized_frame.string10
                     else frame_time.get('N4'))
            add_param('N4', value)
        elif param_name == 'N':
            value = (summarized_frame.string10.content[0]['Nt']
                     if summarized_frame.__class__.__name__ == 'L1SFFrame' and summarized_frame.string10
                     else frame_time.get('N'))
            add_param('Nt', value)
