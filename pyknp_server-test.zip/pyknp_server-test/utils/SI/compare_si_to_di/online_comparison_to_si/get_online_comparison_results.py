import datetime
import logging
from typing import Dict, Optional, List, Set, Tuple

import peewee

from data import SummarizedFramesInfo, SummarizedFrameComparison
from global_data import appdata, config_schema
from utils.SI.compare_si_to_di.types import FORM_169_PARAMS, FORM_893_PARAMS, ImmediateInfoResponse, SiFormNum, \
    SingleAlmanacResponse, FORM_895_PARAMS, AlmanacResponse
from utils.signals.FD.common import tb_to_datetime


def get_frame_ids(nka_sys_number: int) -> Dict[int, int]:
    """Получает ID обобщенных кадров для поиска их параметров и результатво сравнения с СИ в таблице SummarizedFrameComparison."""
    frame_ids = {}
    search_depth = datetime.datetime.now() - datetime.timedelta(
        minutes=config_schema.config['generalized_di']['frame_search_depth_for_operational_control'])

    for signal in appdata.NKA_SIGNALS.get(nka_sys_number, []):
        try:
            frame_id = (SummarizedFramesInfo.select(SummarizedFramesInfo.id)
                        .where((SummarizedFramesInfo.nka_id == nka_sys_number) &
                               (SummarizedFramesInfo.signal_type == signal) &
                               (SummarizedFramesInfo.timestamp >= search_depth))
                        .order_by(SummarizedFramesInfo.timestamp.desc()).first())

            if frame_id:
                frame_ids[signal] = frame_id.id

        except peewee.PeeweeException:
            logging.debug(f"Ошибка при получении id кадра из таблицы SummarizedFramesInfo: signal_type {signal}")

    return frame_ids


def get_frame_params(frame_id: int, almanac_sys_num: Optional[bool] = None) -> Optional[peewee.ModelSelect]:
    """
    Возвращает параметры сравнения для указанного кадра.
    almanac_sys_num = False  → almanac_sys_num IS NULL  (формы 169, 893)
    almanac_sys_num = True → almanac_sys_num IS NOT NULL (форма 895)
    """
    try:
        query = SummarizedFrameComparison.select().where(
            SummarizedFrameComparison.frame_info_id == frame_id
        )
        if almanac_sys_num is True:
            query = query.where(SummarizedFrameComparison.almanac_sys_num.is_null(False))
        elif almanac_sys_num is False:
            query = query.where(SummarizedFrameComparison.almanac_sys_num.is_null(True))
        return query
    except peewee.PeeweeException:
        logging.debug(f"Ошибка при получении данных из SummarizedFrameComparison: frame_id {frame_id}")
        return None


def get_immediate_info_online_comparison(nka_sys_number: int) -> Optional[ImmediateInfoResponse]:
    """Вернуть результаты сравнения оперативных данных с СИ (формы 169 и 893) для заданного НКА.
    Используется только для отображения результатов сравнения на клиенте,
    данные результатов сравнения берутся из базы."""

    operational_comparison_params = {}
    si_timestamp_raw: Dict[SiFormNum, Set[Tuple[str, int]]] = {
        SiFormNum.CLOCKP: set(),
        SiFormNum.EPHEMERIS: set(),
    }

    frame_ids = get_frame_ids(nka_sys_number)
    for signal, frame_id in frame_ids.items():
        params = get_frame_params(frame_id, almanac_sys_num=False)
        if not params:
            continue
        for param in params:
            operational_comparison_params.setdefault(param.name, {}).setdefault(signal, {})
            value = (
                float(param.param_value) if param.name not in ['tk_datetime', 'tb_datetime'] else param.param_value)
            is_valid = (bool(param.is_valid) if param.is_valid in [0, 1] else None)
            operational_comparison_params[param.name].setdefault(signal, {}).update(
                dict(value=value, is_valid=is_valid))
            if param.si_value is not None:
                process_si_value(nka_sys_number, signal, param, operational_comparison_params[param.name])
                # Добавляем параметры записи СИ timestamp и si_phrase_tb
                if param.name in FORM_169_PARAMS:
                    si_timestamp_raw[SiFormNum.CLOCKP].add(
                        (param.si_timestamp.strftime("%d.%m.%Y %H:%M:%S"), param.si_phrase_tb))
                elif param.name in FORM_893_PARAMS:
                    si_timestamp_raw[SiFormNum.EPHEMERIS].add(
                        (param.si_timestamp.strftime("%d.%m.%Y %H:%M:%S"), param.si_phrase_tb))
    if not operational_comparison_params:
        return None

    result = [{'param': param, **values, 'si': values.get('si')} for param, values in
              operational_comparison_params.items()]
    # Форматирование временных меток для фомата отображения на клиенте
    si_timestamp = {
        form: format_timestamps(values)
        for form, values in si_timestamp_raw.items()
    }

    return ImmediateInfoResponse(table_data=result, si_timestamp=si_timestamp)


def get_almanac_online_comparison(nka_sys_number: int) -> Optional[AlmanacResponse]:
    """
    Вернуть результаты сравнения альманаха (форма 895) для заданного НКА.
    almanac_sys_num → signal → {fixed_param: is_valid | None}
    """

    almanac_result: AlmanacResponse = {}
    default_params = dict.fromkeys(FORM_895_PARAMS, None)

    for signal, frame_id in get_frame_ids(nka_sys_number).items():
        params = get_frame_params(frame_id, almanac_sys_num=True)
        if not params:
            continue
        for param in params:
            # инициализация вложенных словарей
            signal_map = almanac_result.setdefault(param.almanac_sys_num, {})
            param_map = signal_map.setdefault(signal, default_params.copy())

            # заполняем, если имя входит в фиксированный набор
            if param.name in FORM_895_PARAMS:
                param_map[param.name] = bool(param.is_valid) if param.is_valid in (0, 1) else None
    if not almanac_result:
        return None
    return almanac_result


def get_single_nka_almanac_online_comparison(nka_sys_number: int, signal: int, almanac_sys_num: int) -> \
        Optional[SingleAlmanacResponse]:
    """
    Альманах 895 для одного КА и одного типа сигнала.

    Формат:
        {
            "table_data": [
                {"param": "tb", "di_value": 123.0, "si_value": 123.1, "is_valid": True},
                ...
            ],
            "si_timestamp": "26.06.2025 11:34:42" | None
        }
    """
    almanac_comparison_params = []
    si_timestamp = None

    frame_id = get_frame_ids(nka_sys_number).get(signal)
    if frame_id is None:
        return None
    params = get_frame_params(frame_id, almanac_sys_num=True)
    if params is None:
        return None
    for param in params:
        if param.name in FORM_895_PARAMS and param.almanac_sys_num == almanac_sys_num:
            value = float(param.param_value)
            is_valid = (bool(param.is_valid) if param.is_valid in [0, 1] else None)
            almanac_comparison_params.append(dict(param=param.name, di_value=value, si_value=param.si_value,
                                                  is_valid=is_valid))
            if param.si_timestamp is not None and not si_timestamp:
                si_timestamp = param.si_timestamp.strftime("%d.%m.%Y %H:%M:%S")
    if not almanac_comparison_params:
        return None

    return SingleAlmanacResponse(table_data=almanac_comparison_params, si_timestamp=si_timestamp)


def process_si_value(nka_sys_number: int, signal: int, param: SummarizedFrameComparison,
                     operational_comparison_param: dict) -> None:
    """Обрабатывает значение СИ для каждого параметра из сравнения.
    Добавляет в словарь к каждому параметру
    'si': {'ph_centre_fd':{'value': float/', 'is_valid':None},
           'centre': { 'data': {'value': float/', 'is_valid':None},
                       'type': 'mass'/'phaseL3' }
           }
    ph_centre_fd - координаты ФЦА (т.е. частотные сигналы)
    centre/mass - координаты ЦМ (т.е. кодовые сигналы в 14Ф160)
    centre/phaseL3 - координаты ФЦА для L3 (т.е. кодовые сигналы в 14Ф143)
    """

    # в СИ 14Ф160 передаются координаты ЦМ (для сравнение с частотными сигналами пересчет в ФЦА)
    si_from_centre_mass = (appdata.NKA_DATA[nka_sys_number]['type_si'] == '14Ф160' and
                           signal not in appdata.FREQ_SIGNAL_TYPES)
    # в СИ 14Ф143 координаты ФЦА для L3 передаются отдельно (значения одинаковы для всех кодовых)
    si_from_phase_centre_L3 = (appdata.NKA_DATA[nka_sys_number]['type_si'] == '14Ф143' and
                               signal not in appdata.FREQ_SIGNAL_TYPES)

    operational_comparison_param.setdefault('si', {})
    operational_comparison_param['si'].setdefault('ph_centre_fd', None)
    operational_comparison_param['si'].setdefault('centre', None)

    if si_from_centre_mass:  # Запись параметров СИ, где координаты ЦМ (т.е. кодовые сигналы в 14Ф160)
        operational_comparison_param['si']['centre'] = {'data': param.si_value,
                                                        'type': 'mass'}
    elif si_from_phase_centre_L3:  # Запись параметров СИ, где координаты ФЦА для L3 (т.е. кодовые сигналы в 14Ф143)
        operational_comparison_param['si']['centre'] = {'data': param.si_value,
                                                        'type': 'phaseL3'}
    else:  # Запись параметров СИ, где координаты ФЦА (т.е. частотные сигналы)
        operational_comparison_param['si']['ph_centre_fd'] = param.si_value


def format_timestamps(timestamp_set: Set[Tuple[str, int]]) -> List[dict]:
    """Форматирует временные метки."""
    formatted_timestamps = []
    for time_params in timestamp_set:
        tb_timestamp = time_params[1]
        if time_params[1]:
            tb_datetime_val = tb_to_datetime(tb=time_params[1], tb_minutes_amount=30)
            tb_timestamp = (tb_datetime_val - datetime.timedelta(minutes=15)).strftime("%d.%m.%Y %H:%M:%S")

        formatted_timestamps.append({'timestamp': time_params[0], 'tb': tb_timestamp})

    return formatted_timestamps
