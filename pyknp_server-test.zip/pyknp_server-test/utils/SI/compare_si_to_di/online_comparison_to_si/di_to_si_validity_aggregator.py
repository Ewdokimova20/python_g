import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Union

from communication.types import ZMQTopic
from global_data.appdata import SignalTypes
from scripts.process_registry import get_zmq_manager
from utils.SI.compare_si_to_di.types import AllFormsComparison, SiFormNameForClient
from utils.lib.types.type_aliases import NkaSysNum

logger = logging.getLogger('di_to_si_validity_aggregator')


class DItoSIValidityAggregator:
    """
    Класс для хранения и агрегации результатов контроля ЦИ (в виде флагов is_valid) по формам СИ,
    сгруппированных по типам сигналов и системным номерам НКА.

    Данные собираются в процессе обобщения ЦИ SummarizeProcess
    Результаты, собранные по сигналу L1SF, отправляются на процесс оперативного контроля закладок SiEmbeddingVerificationProcess

    Структура внутреннего словаря:
      {
        SignalTypes: {
          nka_sys_number (int): {
            SiFormNameForClient: Optional[bool]
          }
        }
      }

    Методы:
      - update_from_comparison: принимает результат сравнения для одного кадра,
        вычисляет итоговые флаги и сохраняет их в структуру.
      - get_l1sf_data: возвращает итоговые данные только для сигнала SignalTypes.L1SF.
    """

    SEND_INTERVAL_SECONDS = 5  # Интервал отправки результатов контрля

    def __init__(self) -> None:
        # Внутреннее хранилище итоговых флагов
        self._data: Dict[SignalTypes, Dict[NkaSysNum, Dict[SiFormNameForClient, Optional[bool]]]] = {}
        self._zmq_manager = get_zmq_manager()
        self._last_send_time = datetime.min  # Время последней отправки результатов контроля

    def update_from_comparison(self,
                               signal_type: int,
                               nka_sys_number: int,
                               comparison_data: AllFormsComparison) -> None:
        """
        Обновляет внутреннее состояние на основе данных сравнения для одного кадра.

        Args:
            signal_type (Union[SignalTypes, int]): Тип сигнала кадра.
            nka_sys_number (int): Номер НКА кадра.
            comparison_data (AllFormsComparison): Результаты сравнения по формам.
        """
        # Приводим signal_type к SignalTypes, если это int
        if not comparison_data:
            return

        if not isinstance(signal_type, SignalTypes):
            try:
                signal_type = SignalTypes(signal_type)
            except ValueError:
                # Если тип сигнала неизвестен, не сохраняем данные
                return

        # Вычисляем итоговые флаги is_valid по формам
        form_flags = self._calculate_overall_is_valid_by_form(comparison_data)

        if signal_type not in self._data:
            self._data[signal_type] = {}

        # Сохраняем или обновляем данные для данного НКА
        self._data[signal_type][nka_sys_number] = form_flags

        # Проверяем, пора ли отправлять данные
        current_time = datetime.now()
        if current_time - self._last_send_time >= timedelta(seconds=self.SEND_INTERVAL_SECONDS):
            self.send()
            self._last_send_time = current_time

    def get_l1sf_data(self) -> Dict[NkaSysNum, Dict[SiFormNameForClient, Optional[bool]]]:
        """
        Возвращает агрегированные флаги по формам только для сигнала SignalTypes.L1SF.

        Returns:
            Dict[int, Dict[SiFormNameForClient, Optional[bool]]]:
                Словарь с ключами — номера НКА и значениями — словари флагов по формам.
        """
        return self._data.get(SignalTypes.L1SF, {})

    @staticmethod
    def _calculate_overall_is_valid_by_form(comparison_data: AllFormsComparison) -> Dict[SiFormNameForClient, Optional[bool]]:
        """
        Определяет общий флаг is_valid для каждой формы в comparison_data.

        Логика обработки значений is_valid для параметров формы:
          - Значения могут быть True, False или None.
          - При расчёте итогового флага учитываются только True и False.
          - Значения None игнорируются.
          - Если все True — итоговый флаг True, иначе False.
          - Если все параметры — None (или отсутствует is_valid) — итог None.

        Формат данных для форм:
          - ALMANAC, TAUA: данные представлены словарём с ключами — номерами НКА и списками параметров.
          - Остальные формы: данные представлены списком параметров.

        Args:
            comparison_data (AllFormsComparison): Словарь с результатами сравнения для всех форм.

        Returns:
            Dict[SiFormNameForClient, Optional[bool]]: Словарь с общим флагом is_valid для каждой формы.
        """
        is_valid_by_form: Dict[SiFormNameForClient, Optional[bool]] = {}

        # Формы, у которых данные представлены в виде словаря (ключ — НКА, значение — список параметров)
        dict_data_forms = {SiFormNameForClient.ALMANAC, SiFormNameForClient.TAUA}

        for form, form_data in comparison_data.items():
            data = form_data.get('data')
            if not data:
                # Если данных нет вовсе — возвращаем None для этой формы
                is_valid_by_form[form] = None
                continue

            # Получаем список всех параметров для текущей формы
            if form in dict_data_forms:
                # Для словарей объединяем все списки параметров в один список
                items = [param for params_list in data.values() for param in params_list]
            else:
                # Для остальных форм data уже является списком параметров
                items = data

            if not items:
                # Если список параметров пустой — итог None
                is_valid_by_form[form] = None
                continue

            # Собираем флаги is_valid, игнорируя отсутствующие и None
            is_valid_flags = [item.get('is_valid') for item in items if item.get('is_valid') is not None]

            if not is_valid_flags:
                # Если после фильтрации остались только None или отсутствующие, итог None
                is_valid_by_form[form] = None
                continue

            # Если все флаги True — итог True
            if all(flag is True for flag in is_valid_flags):
                is_valid_by_form[form] = True
            else:
                is_valid_by_form[form] = False

        return is_valid_by_form

    def send(self) -> None:
        """
        Отправляет текущие данные результато контроля ЦИ по СИ для сигнала L1SF (Максим сказал, что по нему смотрим) по ZMQ
        в процесс оперативного контроля закладок SiEmbeddingVerificationProcess

        """
        data = self.get_l1sf_data()
        if data:
            self._zmq_manager.publish_data(topic=ZMQTopic.DI_TO_SI_OVERALL_VALIDITY, data=data)
            logger.debug('Успешная отправка обобщенных результатов контроля ЦИ (ОИ, альманах) по заложенным формам СИ')
