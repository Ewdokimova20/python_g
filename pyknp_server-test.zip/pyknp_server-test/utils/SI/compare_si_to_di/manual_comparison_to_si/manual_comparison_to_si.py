import logging
from typing import Dict, Optional, Tuple, Union, List, TYPE_CHECKING, cast

from peewee import OperationalError, DoesNotExist

from global_data import appdata
from global_data.appdata import SignalTypes
from global_data.config_schema import comparison_si_threshold
from models.nka import Nka
from utils.SI.common import SIRecord
from utils.SI.compare_si_to_di.types import TimeData, FormData, ComparisonItem, Form893Params, \
    Form895Params, Form701Params, Form921Params, SiFormData, SIRecordDataForClient, SiFormNum, Form893ParamKeys, \
    Form895ParamKeys, SiFormNameForClient, ComparisonResult, AllFormsComparison, TauAComparison, AlmComparison, \
    ClockComparison, EphComparison, FORM_893_PARAMS, FORM_169_PARAMS
from utils.lib.exceptions import CompareDItoSIError

logger = logging.getLogger('compare_to_si')

if TYPE_CHECKING:
    from data import BaseDIFrame


def manual_compare_to_si(frame: "BaseDIFrame", is_cd_frame: bool) -> Optional[ComparisonResult]:
    """Сравнить данные из кадра с данными из СИ.
    Args:
        frame: кадр для которого провиодится сравнение, класс BaseDIFrame
        is_cd_frame: флаг является ли сигнал кодовым
    Returns:
        Dict: Результат сравнения
    """

    if int(frame.nka.nka_sys_number) not in appdata.NKA_DATA:
        return

    # 1.1 - получаем словарь всех параметров кадра
    frame_data = frame.parse_frame()

    # 1.2 - получаем временные параметры кадра
    try:
        time_data = frame.get_timebind(frame_data)
    except AttributeError as e:
        raise CompareDItoSIError(
            f'Не определены параметры Nt, Na или tb кадра {str(frame)}: невозможно найти соответствующую СИ: {str(e)}')

    # 2 - получить нужные CИ
    si_records: Dict[SiFormNum, List[SIRecord]] = {}
    required_si = [SiFormNum.CLOCKP, SiFormNum.TAUA, SiFormNum.EPHEMERIS, SiFormNum.ALMANAC]
    if frame.nka.type_si == '14Ф160':
        required_si.append(SiFormNum.TZ)  # 921 форма с поправками к ЧПВ есть только у '14Ф160'
    for form_num in required_si:
        si_record_list = get_si_records_from_cdb(nka=frame.nka, time_bind=time_data, form_num=form_num)
        if si_record_list:
            si_records[form_num] = si_record_list
    if not si_records:
        raise CompareDItoSIError(f'Не найдены соответствующие СИ (169, 701, 893, 895) для кадра {str(frame)}')
    # 3 - распарсить формы Cи
    si_data, records_data = get_SI_data_for_comparison_with_DI(frame.nka, time_data, si_records)
    # 3.1 - для частотных на 14Ф160 в СИ необходим пересчет координат x,y,z из ЦМ в ФЦА
    if si_data[SiFormNum.EPHEMERIS] and frame.nka.type_si == '14Ф160' \
            and frame.signal_type in appdata.FREQ_SIGNAL_TYPES:
        si_data = replace_cm_with_fca_position(si_data)
    # 4 - получить результат сравнения в форме словаря
    if not records_data:
        raise CompareDItoSIError(f'Не удалось получить данные из СИ форм для сравнения с кадром {str(frame)}')
    comparison_data: Optional[AllFormsComparison] = get_comparison_to_si_result(type_si=frame.nka.type_si,
                                                                                signal_type=frame.signal_type,
                                                                                is_cd_frame=is_cd_frame,
                                                                                si_data=si_data,
                                                                                frame_data=frame_data,
                                                                                records_data=records_data)
    if not comparison_data:
        raise CompareDItoSIError(f'Не удалось провести сравнение ЭИ кадра {str(frame)} с ЭИ в СИ')
    comparison_result = ComparisonResult(forms=comparison_data, time=time_data.as_dict(),
                                         sys_num=frame.nka.nka_sys_number)
    return comparison_result


def get_si_records_from_cdb(nka: Nka, time_bind: TimeData, form_num: int) -> List[SIRecord]:
    """Получить самые свежие СИ для указанного НКА в заданном интервале времени."""

    from utils.SI.main import SI_FORMS
    si_records = []
    form = SI_FORMS.get(nka.type_si, SI_FORMS[nka.type_ka])[form_num]
    nka = form(nka_instance=nka).curr_nka.nku_number
    try:
        si_records = form.get_records_from_cdb(nka,
                                               time_start=time_bind.timestamp - form(
                                               ).search_depth,
                                               time_end=time_bind.timestamp)
    except DoesNotExist:
        pass
    except OperationalError:
        logger.info('Ошибка подключения к ЦБД')
    return si_records


def get_SI_data_for_comparison_with_DI(nka: Nka, time_data: TimeData,
                                       si_records: Dict[SiFormNum, List[SIRecord]]) -> \
        Tuple[Dict[SiFormNum, SiFormData], Dict[SiFormNum, SIRecordDataForClient]]:
    """ Получает данные из СИ форм, полученных из ЦБД."""

    si_data: Dict[SiFormNum, SiFormData] = {
        SiFormNum.CLOCKP: {},  # Параметры формы 169
        SiFormNum.EPHEMERIS: {},  # Параметры формы 893
        SiFormNum.TAUA: {},  # Параметры формы 701
        SiFormNum.ALMANAC: {},  # Параметры формы 895
        SiFormNum.TZ: {}  # Параметры формы 921
    }
    records_data: Dict[SiFormNum, SIRecordDataForClient] = {}

    for form_num, form_records in si_records.items():
        parsed_si: SiFormData = {}
        record_data = {}
        if not form_records:
            logger.debug(f'Не найдено записей СИ для формы {form_num} в ЦБД для кадра с параметрами: {time_data}')
            continue
        if form_num == SiFormNum.ALMANAC:
            parsed_si, record_data = process_almanac_form(nka, time_data, form_records)
        elif form_num == SiFormNum.TAUA or form_num == SiFormNum.TZ:
            parsed_si, record_data = process_tau_a_tz_form(nka, time_data, form_num, form_records)
        elif form_num == SiFormNum.CLOCKP or form_num == SiFormNum.EPHEMERIS:
            if time_data.tb and time_data.N is not None:  # распарсить 169, 893 форму
                parsed_si, record_data = parse_SI_form(nka=nka, time_bind=time_data, form_num=form_num,
                                                       si_records=form_records)
        si_data[form_num].update(parsed_si)
        records_data.update(record_data)
    return si_data, records_data


def process_almanac_form(nka: Nka, time: TimeData, si_records: List[SIRecord]) -> \
        Tuple[Form895Params, Dict[SiFormNum, SIRecordDataForClient]]:
    """Обрабатывает форму альманаха."""

    Na_set = time.Na
    complete_almanac: Form895Params = {}
    record_data: Dict[SiFormNum, SIRecordDataForClient] = {}
    if Na_set:
        for Na in Na_set:
            alm_time = TimeData(Na=Na, timestamp=time.timestamp)
            parsed_alm, record_data = parse_SI_form(nka=nka, time_bind=alm_time,
                                                    form_num=SiFormNum.ALMANAC, si_records=si_records)
            if parsed_alm:
                complete_almanac.update(parsed_alm)
    return complete_almanac, record_data


def process_tau_a_tz_form(nka: Nka, time: TimeData, form_num: SiFormNum, si_records: List[SIRecord]) -> \
        Tuple[Union[Form701Params, Form921Params], Dict[SiFormNum, SIRecordDataForClient]]:
    """Обрабатывает формы TAU_A и TZ."""

    Na_set = time.Na
    parsed_si: Union[Form701Params, Form921Params] = cast(Union[Form701Params, Form921Params], {})
    found_record: Dict[SiFormNum, SIRecordDataForClient] = {}
    if Na_set:
        Na = list(Na_set)[0]
        tauA_time = TimeData(Na=Na, timestamp=time.timestamp)
        parsed_si, found_record = parse_SI_form(
            nka=nka,
            time_bind=tauA_time,
            form_num=form_num,
            si_records=si_records
        )
    return parsed_si, found_record


def parse_SI_form(nka: Nka, time_bind: TimeData, form_num: SiFormNum, si_records: List[SIRecord]) -> \
        Tuple[SiFormData, Dict[SiFormNum, SIRecordDataForClient]]:
    """Распарсить форму СИ, релевантную для данного кадра"""

    from utils.SI.main import SI_FORMS
    parsed: SiFormData = {}
    record_data: Dict[SiFormNum, SIRecordDataForClient] = {form_num: SIRecordDataForClient()}
    form = SI_FORMS.get(nka.type_si, SI_FORMS[nka.type_ka])[form_num](nka_instance=nka)
    form_data, record = form.parse_form(si_records, time_bind=time_bind)
    if form_data:
        record_data[form_num] = SIRecordDataForClient(
            timestamp=record.write_time_cdb,
            id=record.id,
            form=record.si_format,
            tb=form_data.get('phrase_tb')
        )
    parsed.update(form_data)
    return parsed, record_data


def get_comparison_to_si_result(signal_type: int, type_si: str, is_cd_frame: bool,
                                si_data: Dict[SiFormNum, SiFormData],
                                frame_data: Dict[str, Union[int, float, dict]],
                                records_data: Dict[SiFormNum, SIRecordDataForClient]) -> AllFormsComparison:
    """
    Сравнивает данные кадра с данными СИ и возвращает результат сравнения.
    При отсутсвии СИ заполняет словарь данными кадра, результат is_valid = None в таком случае
    Args:
        signal_type: тип сигнала
        type_si: тип СИ выраженный в имени НКА
        is_cd_frame: флаг является ли сигнал кодовым
        si_data: Данные из СИ форм
        frame_data: Данные кадра
        records_data: Информация о найденных записях СИ
    Returns:
        Dict: Результат сравнения
    """

    comparison_result_ephemeris: EphComparison = []
    comparison_result_clock: ClockComparison = []
    comparison_result_almanac: AlmComparison = {}
    comparison_result_tau_a: TauAComparison = {}
    for param, value in frame_data.items():
        if param in FORM_893_PARAMS:
            comparison_item = compare_ephemeris_params(si_data[SiFormNum.EPHEMERIS], value['val'], type_si,
                                                       Form893ParamKeys(param), is_cd_frame)
            if comparison_item:
                comparison_result_ephemeris.append(comparison_item)
        elif param in FORM_169_PARAMS:
            comparison_item = compare_clock_params(signal_type, param, value['val'], si_data)
            if comparison_item:
                comparison_result_clock.append(comparison_item)
        elif param == 'alm':
            comparison_result_almanac = compare_almanac_params(si_data[SiFormNum.ALMANAC], frame_data.get('alm'),
                                                               is_cd_frame)
            comparison_result_tau_a = compare_tau_a_params(si_data[SiFormNum.TAUA], frame_data, is_cd_frame)

    forms: AllFormsComparison = {
        SiFormNameForClient.CLOCKP: FormData(data=comparison_result_clock,
                                             record_data=records_data.get(SiFormNum.CLOCKP, {})),
        SiFormNameForClient.TAUA: FormData(data=comparison_result_tau_a,
                                           record_data=records_data.get(SiFormNum.TAUA, {})),
        SiFormNameForClient.EPHEMERIS: FormData(data=comparison_result_ephemeris,
                                                record_data=records_data.get(SiFormNum.EPHEMERIS, {})),
        SiFormNameForClient.ALMANAC: FormData(data=comparison_result_almanac,
                                              record_data=records_data.get(SiFormNum.ALMANAC, {})),
    }
    return forms


def compare_ephemeris_params(si_data: Form893Params, frame_value: Union[int, float, None], type_si: str,
                             param: Form893ParamKeys,
                             is_cd_frame: bool) -> ComparisonItem:
    """Сравнивает оперативные параметры. (СИ 893)"""
    comparison_item = ComparisonItem()
    si_value = si_data.get(param)
    threshold = comparison_si_threshold.get(param, 0)
    if si_value is not None and frame_value is not None:
        if type_si == '14Ф143' and is_cd_frame and param in ['x', 'y', 'z', 'Ax', 'Ay', 'Az']:
            si_value = si_data.get(param + '_L3', si_value)  # корректировка для 14Ф143, у кодовых свои параметры
        diff_di_si = frame_value - si_value
        is_valid = True if abs(diff_di_si) <= threshold else False
        comparison_item = ComparisonItem(param=param, di=frame_value, si=si_value,
                                         diff=diff_di_si, is_valid=is_valid,
                                         threshold=threshold)
    elif si_value is None:
        comparison_item = ComparisonItem(param=param, di=frame_value, si=si_value,
                                         diff=None, is_valid=None,
                                         threshold=threshold)

    return comparison_item


def compare_clock_params(signal_type: int, param: str, frame_value: Union[int, float],
                         si_data: Dict[SiFormNum, SiFormData]) -> ComparisonItem:
    """Сравнивает оперативные параметры. (СИ 169)"""

    comparison_item = ComparisonItem()
    si_value = si_data[SiFormNum.CLOCKP].get(param)
    threshold = comparison_si_threshold.get(param, 0)
    if si_value is not None and frame_value is not None:
        diff_di_si = frame_value - si_value
        is_valid = True if abs(diff_di_si) <= threshold else False
        if param == 'tau' and si_data[SiFormNum.TZ].get(
                'tz'):  # корректировка параметра tau параметром tz из СИ 921
            tz = get_tz_from_si921(si_data[SiFormNum.TZ].get('tz'), signal_type)
            if tz is not None:
                si_value -= tz
                diff_di_si += tz
                is_valid = True if abs(diff_di_si) <= threshold else False
        comparison_item = ComparisonItem(param=param, di=frame_value, si=si_value,
                                         diff=diff_di_si, is_valid=is_valid, threshold=threshold)
    elif si_value is None:
        comparison_item = ComparisonItem(param=param, di=frame_value, si=si_value, diff=None, is_valid=None,
                                         threshold=threshold)
    return comparison_item


def get_tz_from_si921(si_921: dict, signal_type: int) -> float:
    """Определить временную задержку для текущего типа сигнала из массива 'ВЗ' форма СИ 921."""

    SIGNALS_NAME_TZ_NAME = {
        SignalTypes.L1OF: 'tz3',
        SignalTypes.L1SF: 'tz1',
        SignalTypes.L2OF: 'tz4',
        SignalTypes.L2SF: 'tz2',
        SignalTypes.L1OCd: 'tz5',
        SignalTypes.L1OCp: None,
        SignalTypes.L1SCd: 'tz7',
        SignalTypes.L1SCp: None,
        SignalTypes.L2KSI: None,
        SignalTypes.L2OCp: 'tz6',
        SignalTypes.L2SCd: 'tz8',
        SignalTypes.L2SCp: None,
        SignalTypes.L3OCd: 'tz9',
        SignalTypes.L3OCp: 'tz10',
    }
    # словарь соответствия типа сигнала и названия параметра tz - значения временной задержки

    tz = si_921.get(SIGNALS_NAME_TZ_NAME.get(signal_type))
    return tz


def replace_cm_with_fca_position(si_data: Dict[SiFormNum, SiFormData]) -> \
        Dict[SiFormNum, SiFormData]:
    """
    Функция, которая приводит положение центра масс (ЦМ) к положению фазового центра антенны (ФЦА) в СИ
    для сравнения с ЦИ КА 14Ф160 сигналов с частотным разделением.
    """
    for axis in ['x', 'y', 'z']:
        current_value = si_data[SiFormNum.EPHEMERIS].get(axis)
        if current_value is None:
            continue
        else:
            offset = si_data[SiFormNum.EPHEMERIS].get(f'd{axis.upper()}', 0)
            si_data[SiFormNum.EPHEMERIS][axis] += offset
    return si_data


def compare_almanac_params(si_data: Form895Params, frame_alm: Dict[int, Dict[Form895ParamKeys, Dict]],
                           is_cd_frame: bool) \
        -> Dict[int, List[ComparisonItem]]:
    """Сравнивает параметры альманаха."""

    comparison_result_almanac: Dict[int, List[ComparisonItem]] = {}
    for nka_num, alm in frame_alm.items():
        if nka_num not in appdata.NKA_DATA:
            continue
        curr_frame_alm = frame_alm[nka_num]
        nku_num = appdata.NKA_DATA.get(nka_num)['nku_num']
        comparison_result_almanac[nku_num] = []
        if nka_num not in si_data:  # если нет данных СИ
            for par_name, par_val in curr_frame_alm.items():
                threshold = comparison_si_threshold.get(par_name, 0)
                comparison_result_almanac[nku_num].append(ComparisonItem(param=par_name, di=par_val['val'], si=None,
                                                                         diff=None, is_valid=None, threshold=threshold))
        else:
            curr_si_alm = si_data.get(nka_num, [])
            for par_name, par_val in curr_frame_alm.items():
                threshold = comparison_si_threshold.get(par_name, 0)
                if par_name in curr_si_alm and curr_si_alm[par_name] is not None and par_val['val'] is not None:
                    # поправка 0.01 компенсирует разницу между частоным разделением в СИ и кодовым в кадре для параметра delta_i
                    if is_cd_frame and par_name in ("delta_i"):
                        correction = 0.01
                    # поправка -2656 компенсирует разницу между частоным разделением в СИ и кодовым в кадре для параметра delta_T
                    elif is_cd_frame and par_name in ("delta_T"):
                        correction = - 2656
                    else:
                        correction = 0
                    diff = par_val['val'] - curr_si_alm[par_name] + correction
                    is_valid = True if abs(diff) <= threshold else False
                    comparison_result_almanac[nku_num].append(ComparisonItem(
                        param=par_name, di=par_val['val'], si=curr_si_alm[par_name],
                        diff=diff, is_valid=is_valid, threshold=threshold))
    return comparison_result_almanac


def compare_tau_a_params(si_data: Form701Params, frame_data: Dict[str, dict], is_cd_frame: bool) \
        -> Dict[int, List[ComparisonItem]]:
    # отдельно достаем данные из формы 701

    comparison_result_tau_a: Dict[int, List[ComparisonItem]] = {}
    if 'alm' in frame_data:
        for nka_num, alm in frame_data['alm'].items():
            if nka_num not in appdata.NKA_DATA:
                continue
            if 'tau_a' not in alm:
                continue
            nku_num = appdata.NKA_DATA.get(nka_num)['nku_num']
            threshold = comparison_si_threshold.get('tau_a', 0)
            tau_a_from_frame = alm['tau_a']['val']
            if tau_a_from_frame is not None:
                tau_a_name_in_si = 'tau_a' + str(nka_num)
                if is_cd_frame:
                    tau_a_name_in_si += '_cd'
                tau_a_from_si = si_data.get('tau_a', {}).get(tau_a_name_in_si, None)
                if tau_a_from_si is not None:
                    diff_di_si = tau_a_from_frame - tau_a_from_si
                    is_valid = True if abs(diff_di_si) <= threshold else False
                    comparison_item = ComparisonItem(param='tau_a', di=tau_a_from_frame, si=tau_a_from_si,
                                                     diff=diff_di_si, is_valid=is_valid,
                                                     threshold=threshold)
                else:
                    comparison_item = ComparisonItem(param='tau_a', di=tau_a_from_frame, si=None, diff=None,
                                                     is_valid=None, threshold=threshold)
                comparison_result_tau_a[nku_num] = [comparison_item]

    return comparison_result_tau_a
