from utils.SI.common import prepare_SI_pattern, SIPartPosition, SIConst
from utils.bytestring_parser import SingleParam, PartPosition

constants = SIConst(phrase_length=16, word_bit_size=34, offset=2)
"""Константы, относящиеся к фразам СИ для 14Ф113"""

HEADER_LENGTH = 124
"""Длина заголовка массива фраз в битах для форм 14Ф113"""

SI_ARRAY_LENGTH = 14
"""Количество массивов фраз в СИ для форм 14Ф113"""

ARRAY_LENGTH = 29
"""Максимальное количество фраз в массиве фраз для форм 14Ф113"""

header_pattern = {
    'num_of_words_local': SingleParam(content=[PartPosition(start=3, length=11)], sign=False, CMR=2 ** 0,
                                      type='int')
}
"""Параметры парсинга заголовка для форм 14Ф113"""

phrase_num_pattern = prepare_SI_pattern({
    'Afr': SingleParam(content=[
        SIPartPosition(start=16, length=11, word_num=1)
    ], sign=False, CMR=2 ** 0, type='int')
}, constants)
"""Координаты номера фразы для 14Ф113"""

Kfr_pattern = prepare_SI_pattern({
    'Kfr': SingleParam(content=[
        SIPartPosition(start=29, length=2, word_num=1)
    ], sign=False, CMR=2 ** 0, type='int'),
    'iEnd': SingleParam(content=[
        SIPartPosition(start=-2, length=2, word_num=16)
    ], sign=False, CMR=2 ** 0, type='int')
}, constants)
"""Координаты признака последней фразы для 14Ф113"""
