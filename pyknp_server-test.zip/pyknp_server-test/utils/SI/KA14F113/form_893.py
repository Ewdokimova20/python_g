from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F113.common import constants

phrase_num_range = list(range(1, 75+1))
"""Диапазон номеров фраз"""

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=7, length=6, word_num=8)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=20, length=11, word_num=5)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=23, length=6, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=4, length=11, word_num=12)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants)
]
"""Координаты параметров временной привязки фразы"""

data_pattern = [
    prepare_SI_pattern({
        'x': SingleParam(content=[
            SIPartPosition(start=18, length=13, word_num=6),
            SIPartPosition(start=0, length=15, word_num=5),
            SIPartPosition(start=16, length=4, word_num=5)
        ], sign=True, CMR=2 ** -16, type='float'),
        'y': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=7),
            SIPartPosition(start=0, length=15, word_num=6),
            SIPartPosition(start=16, length=2, word_num=6)
        ], sign=True, CMR=2 ** -16, type='float'),
        'z': SingleParam(content=[
            SIPartPosition(start=13, length=2, word_num=8),
            SIPartPosition(start=16, length=15, word_num=8),
            SIPartPosition(start=0, length=15, word_num=7)
        ], sign=True, CMR=2 ** -16, type='float'),
        'Vx': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=2),
            SIPartPosition(start=16, length=15, word_num=2)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Vy': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=3),
            SIPartPosition(start=16, length=15, word_num=3)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Vz': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=4),
            SIPartPosition(start=16, length=15, word_num=4)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Ax': SingleParam(content=[SIPartPosition(start=0, length=7, word_num=8)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Ay': SingleParam(content=[SIPartPosition(start=24, length=7, word_num=9)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Az': SingleParam(content=[SIPartPosition(start=17, length=7, word_num=9)],
                          sign=True, CMR=2 ** -32, type='float'),
    }, constants),
    prepare_SI_pattern({
        'x': SingleParam(content=[
            SIPartPosition(start=2, length=13, word_num=13),
            SIPartPosition(start=16, length=15, word_num=13),
            SIPartPosition(start=0, length=4, word_num=12)
        ], sign=True, CMR=2 ** -16, type='float'),
        'y': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=14),
            SIPartPosition(start=16, length=15, word_num=14),
            SIPartPosition(start=0, length=2, word_num=13)
        ], sign=True, CMR=2 ** -16, type='float'),
        'z': SingleParam(content=[
            SIPartPosition(start=29, length=2, word_num=16),
            SIPartPosition(start=0, length=15, word_num=15),
            SIPartPosition(start=16, length=15, word_num=15)
        ], sign=True, CMR=2 ** -16, type='float'),
        'Vx': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=10),
            SIPartPosition(start=0, length=15, word_num=9)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Vy': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=11),
            SIPartPosition(start=0, length=15, word_num=10)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Vz': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=12),
            SIPartPosition(start=0, length=15, word_num=11)
        ], sign=True, CMR=2 ** -26, type='float'),
        'Ax': SingleParam(content=[SIPartPosition(start=16, length=7, word_num=16)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Ay': SingleParam(content=[SIPartPosition(start=8, length=7, word_num=16)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Az': SingleParam(content=[SIPartPosition(start=1, length=7, word_num=16)],
                          sign=True, CMR=2 ** -32, type='float'),
    }, constants)
]
"""Координаты параметров фразы"""
