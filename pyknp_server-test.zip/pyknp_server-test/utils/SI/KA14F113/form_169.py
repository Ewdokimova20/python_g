from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F113.common import constants

service_phrase_num = 521
"""Номер служебной фразы"""

phrase_num_range = list(range(522, 531+1))
"""Диапазон номеров фраз"""

service_phrase_pattern = prepare_SI_pattern({
        'N': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=2)
        ], sign=False, CMR=2 ** 0, type='int'),
        'Afr': SingleParam(content=[
            SIPartPosition(start=16, length=11, word_num=1)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants)

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=16, length=6, word_num=3)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=22, length=5, word_num=3)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=5, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=16, length=6, word_num=6)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=22, length=5, word_num=6)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=5, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=16, length=6, word_num=9)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=22, length=5, word_num=9)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=5, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=16, length=6, word_num=12)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=22, length=5, word_num=12)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=5, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=16, length=6, word_num=15)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=22, length=5, word_num=15)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=5, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants)
]
"""Координаты параметров временной привязки фразы"""

data_pattern = [
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=27, length=4, word_num=3),
            SIPartPosition(start=0, length=15, word_num=2),
            SIPartPosition(start=16, length=3, word_num=2)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=19, length=11, word_num=2)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=11, length=4, word_num=4),
            SIPartPosition(start=16, length=15, word_num=4),
            SIPartPosition(start=0, length=3, word_num=3)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=3, length=11, word_num=3)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=27, length=4, word_num=6),
            SIPartPosition(start=0, length=15, word_num=5),
            SIPartPosition(start=16, length=3, word_num=5)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=19, length=11, word_num=5)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=11, length=4, word_num=7),
            SIPartPosition(start=16, length=15, word_num=7),
            SIPartPosition(start=0, length=3, word_num=6)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=3, length=11, word_num=6)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=27, length=4, word_num=9),
            SIPartPosition(start=0, length=15, word_num=8),
            SIPartPosition(start=16, length=3, word_num=8)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=19, length=11, word_num=8)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=11, length=4, word_num=10),
            SIPartPosition(start=16, length=15, word_num=10),
            SIPartPosition(start=0, length=3, word_num=9)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=3, length=11, word_num=9)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=27, length=4, word_num=12),
            SIPartPosition(start=0, length=15, word_num=11),
            SIPartPosition(start=16, length=3, word_num=11)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=19, length=11, word_num=11)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=11, length=4, word_num=13),
            SIPartPosition(start=16, length=15, word_num=13),
            SIPartPosition(start=0, length=3, word_num=12)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=3, length=11, word_num=12)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=27, length=4, word_num=15),
            SIPartPosition(start=0, length=15, word_num=14),
            SIPartPosition(start=16, length=3, word_num=14)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=19, length=11, word_num=14)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=11, length=4, word_num=16),
            SIPartPosition(start=16, length=15, word_num=16),
            SIPartPosition(start=0, length=3, word_num=15)
        ], sign=True, CMR=2 ** -30, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=3, length=11, word_num=15)
        ], sign=True, CMR=2 ** -40, type='int')
    }, constants),
]
"""Координаты параметров фразы"""
