from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F160.common import constants

phrase_num_range = list(range(2351, 2980 + 1))
"""Диапазон номеров фраз для формы К895"""

time_pattern = [
    prepare_SI_pattern({
        'Na': SingleParam(content=[
            SIPartPosition(start=4, length=11, word_num=2)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'Na': SingleParam(content=[
            SIPartPosition(start=4, length=11, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'Na': SingleParam(content=[
            SIPartPosition(start=4, length=11, word_num=12)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants)
]
"""Координаты параметров временной привязки фразы K895"""

data_pattern = [
    prepare_SI_pattern({
        'n': SingleParam(content=[SIPartPosition(start=25, length=6, word_num=2)],
                         sign=False, CMR=2 ** 0, type='int'),
        'delta_T': SingleParam(content=[
            SIPartPosition(start=8, length=7, word_num=4),
            SIPartPosition(start=16, length=15, word_num=4)
        ], sign=True, CMR=2 ** -9, type='float'),
        't_lambda': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=6),
            SIPartPosition(start=0, length=6, word_num=5)
        ], sign=False, CMR=2 ** -5, type='float'),
        'epsilon': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=6)
        ], sign=False, CMR=2 ** -20, type='float'),
        'd_delta_T': SingleParam(content=[SIPartPosition(start=1, length=7, word_num=4)],
                                 sign=True, CMR=2 ** -14, type='float'),
        'omega': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=3),
            SIPartPosition(start=16, length=1, word_num=3)
        ], sign=True, CMR=2 ** -15, type='float'),
        'lambda_': SingleParam(content=[
            SIPartPosition(start=6, length=9, word_num=5),
            SIPartPosition(start=16, length=12, word_num=5)
        ], sign=True, CMR=2 ** -20, type='float'),
        'delta_i': SingleParam(content=[
            SIPartPosition(start=17, length=14, word_num=3),
            SIPartPosition(start=0, length=4, word_num=2)
        ], sign=True, CMR=2 ** -20, type='float'),
    }, constants),
    prepare_SI_pattern({
        'n': SingleParam(content=[SIPartPosition(start=25, length=6, word_num=7)],
                         sign=False, CMR=2 ** 0, type='int'),
        'delta_T': SingleParam(content=[
            SIPartPosition(start=8, length=7, word_num=9),
            SIPartPosition(start=16, length=15, word_num=9)
        ], sign=True, CMR=2 ** -9, type='float'),
        't_lambda': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=11),
            SIPartPosition(start=0, length=6, word_num=10)
        ], sign=False, CMR=2 ** -5, type='float'),
        'epsilon': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=11)
        ], sign=False, CMR=2 ** -20, type='float'),
        'd_delta_T': SingleParam(content=[SIPartPosition(start=1, length=7, word_num=9)],
                                 sign=True, CMR=2 ** -14, type='float'),
        'omega': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=8),
            SIPartPosition(start=16, length=1, word_num=8)
        ], sign=True, CMR=2 ** -15, type='float'),
        'lambda_': SingleParam(content=[
            SIPartPosition(start=6, length=9, word_num=10),
            SIPartPosition(start=16, length=12, word_num=10)
        ], sign=True, CMR=2 ** -20, type='float'),
        'delta_i': SingleParam(content=[
            SIPartPosition(start=17, length=14, word_num=8),
            SIPartPosition(start=0, length=4, word_num=7)
        ], sign=True, CMR=2 ** -20, type='float'),
    }, constants),
    prepare_SI_pattern({
        'n': SingleParam(content=[SIPartPosition(start=25, length=6, word_num=12)],
                         sign=False, CMR=2 ** 0, type='int'),
        'delta_T': SingleParam(content=[
            SIPartPosition(start=8, length=7, word_num=14),
            SIPartPosition(start=16, length=15, word_num=14)
        ], sign=True, CMR=2 ** -9, type='float'),
        't_lambda': SingleParam(content=[
            SIPartPosition(start=16, length=15, word_num=16),
            SIPartPosition(start=0, length=6, word_num=15)
        ], sign=False, CMR=2 ** -5, type='float'),
        'epsilon': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=16)
        ], sign=False, CMR=2 ** -20, type='float'),
        'd_delta_T': SingleParam(content=[SIPartPosition(start=1, length=7, word_num=14)],
                                 sign=True, CMR=2 ** -14, type='float'),
        'omega': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=13),
            SIPartPosition(start=16, length=1, word_num=13)
        ], sign=True, CMR=2 ** -15, type='float'),
        'lambda_': SingleParam(content=[
            SIPartPosition(start=6, length=9, word_num=15),
            SIPartPosition(start=16, length=12, word_num=15)
        ], sign=True, CMR=2 ** -20, type='float'),
        'delta_i': SingleParam(content=[
            SIPartPosition(start=17, length=14, word_num=13),
            SIPartPosition(start=0, length=4, word_num=12)
        ], sign=True, CMR=2 ** -20, type='float'),
    }, constants),
]
"""Координаты параметров фразы K895"""
