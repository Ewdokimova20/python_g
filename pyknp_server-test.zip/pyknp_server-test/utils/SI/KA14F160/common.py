from utils.SI.common import prepare_SI_pattern, SIPartPosition, SIConst
from utils.bytestring_parser import SingleParam


constants = SIConst(phrase_length=16, word_bit_size=32, offset=0)
"""Константы, относящиеся к фразам СИ для 14Ф160"""


phrase_num_pattern = prepare_SI_pattern({
    'Afr': SingleParam(content=[
        SIPartPosition(start=16, length=13, word_num=1)
    ], sign=False, CMR=2 ** 0, type='int')
}, constants)
"""Координаты номера фразы для 14Ф160"""

