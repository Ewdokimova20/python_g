from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F160.common import constants


phrase_num_range = list(range(3152, 3295 + 1))
"""Диапазон номеров фраз для формы К893"""

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=3)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=16, length=11, word_num=3)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants)
]
"""Координаты параметров временной привязки фразы K893"""

data_pattern = [
    prepare_SI_pattern({
        'x': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=7),
            SIPartPosition(start=0, length=8, word_num=6)
        ], sign=True, CMR=2 ** -20, type='float'),
        'y': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=11),
            SIPartPosition(start=0, length=8, word_num=10)
        ], sign=True, CMR=2 ** -20, type='float'),
        'z': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=15),
            SIPartPosition(start=0, length=8, word_num=14)
        ], sign=True, CMR=2 ** -20, type='float'),
        'Vx': SingleParam(content=[
            SIPartPosition(start=10, length=22, word_num=6),
            SIPartPosition(start=0, length=13, word_num=5)
        ], sign=True, CMR=2 ** -30, type='float'),
        'Vy': SingleParam(content=[
            SIPartPosition(start=10, length=22, word_num=10),
            SIPartPosition(start=0, length=13, word_num=9)
        ], sign=True, CMR=2 ** -30, type='float'),
        'Vz': SingleParam(content=[
            SIPartPosition(start=10, length=22, word_num=14),
            SIPartPosition(start=0, length=13, word_num=13)
        ], sign=True, CMR=2 ** -30, type='float'),
        'Ax': SingleParam(content=[SIPartPosition(start=15, length=15, word_num=5)],
                          sign=True, CMR=2 ** -39, type='float'),
        'Ay': SingleParam(content=[SIPartPosition(start=15, length=15, word_num=9)],
                          sign=True, CMR=2 ** -39, type='float'),
        'Az': SingleParam(content=[SIPartPosition(start=15, length=15, word_num=13)],
                          sign=True, CMR=2 ** -39, type='float'),
        'dX': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=8)],
                          sign=True, CMR=2 ** -16, type='float'),
        'dY': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=12)],
                          sign=True, CMR=2 ** -16, type='float'),
        'dZ': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=16)],
                          sign=True, CMR=2 ** -16, type='float'),
    }, constants)
]
"""Координаты параметров фразы K893"""