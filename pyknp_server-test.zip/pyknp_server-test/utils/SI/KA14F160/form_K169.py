from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F160.common import constants

phrase_num_range = list(range(3512, 3540+1))
"""Диапазон номеров фраз"""

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=26, length=6, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=15, length=11, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=26, length=6, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=15, length=11, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=26, length=6, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=15, length=11, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=26, length=6, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=15, length=11, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=26, length=6, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=15, length=11, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
]
"""Координаты параметров временной привязки фразы"""

data_pattern = [
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=3),
        ], sign=True, CMR=2 ** -38, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=19, word_num=2)
        ], sign=True, CMR=2 ** -48, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=4)
        ], sign=True, CMR=2 ** -57, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=6),
        ], sign=True, CMR=2 ** -38, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=19, word_num=5)
        ], sign=True, CMR=2 ** -48, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=7)
        ], sign=True, CMR=2 ** -57, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=9),
        ], sign=True, CMR=2 ** -38, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=19, word_num=8)
        ], sign=True, CMR=2 ** -48, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=10)
        ], sign=True, CMR=2 ** -57, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=12),
        ], sign=True, CMR=2 ** -38, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=19, word_num=11)
        ], sign=True, CMR=2 ** -48, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=13)
        ], sign=True, CMR=2 ** -57, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=32, word_num=15),
        ], sign=True, CMR=2 ** -38, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=19, word_num=14)
        ], sign=True, CMR=2 ** -48, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=0, length=15, word_num=16)
        ], sign=True, CMR=2 ** -57, type='int'),
    }, constants),
]
"""Координаты параметров фразы"""
