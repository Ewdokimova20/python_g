from utils.SI.KA14F160.common import constants
from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam

phrase_num_range = list(range(3125, 3126 + 1))
"""Диапазон номеров фраз для формы 921"""


data_pattern_1 = [
    prepare_SI_pattern({
        'n': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=2),
        ], sign=False, CMR=2 ** 0, type='int'),
        'n_nku': SingleParam(content=[
            SIPartPosition(start=0, length=16, word_num=2),
        ], sign=False, CMR=2 ** 0, type='int'),
        'tz1': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=3),
            SIPartPosition(start=24, length=8, word_num=3),
            SIPartPosition(start=0, length=8, word_num=3),
            SIPartPosition(start=8, length=8, word_num=3),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz2': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=4),
            SIPartPosition(start=24, length=8, word_num=4),
            SIPartPosition(start=0, length=8, word_num=4),
            SIPartPosition(start=8, length=8, word_num=4),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz3': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=5),
            SIPartPosition(start=24, length=8, word_num=5),
            SIPartPosition(start=0, length=8, word_num=5),
            SIPartPosition(start=8, length=8, word_num=5),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz4': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=6),
            SIPartPosition(start=24, length=8, word_num=6),
            SIPartPosition(start=0, length=8, word_num=6),
            SIPartPosition(start=8, length=8, word_num=6),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz5': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=7),
            SIPartPosition(start=24, length=8, word_num=7),
            SIPartPosition(start=0, length=8, word_num=7),
            SIPartPosition(start=8, length=8, word_num=7),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz6': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=8),
            SIPartPosition(start=24, length=8, word_num=8),
            SIPartPosition(start=0, length=8, word_num=8),
            SIPartPosition(start=8, length=8, word_num=8),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz7': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=9),
            SIPartPosition(start=24, length=8, word_num=9),
            SIPartPosition(start=0, length=8, word_num=9),
            SIPartPosition(start=8, length=8, word_num=9),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz8': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=10),
            SIPartPosition(start=24, length=8, word_num=10),
            SIPartPosition(start=0, length=8, word_num=10),
            SIPartPosition(start=8, length=8, word_num=10),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz9': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=11),
            SIPartPosition(start=24, length=8, word_num=11),
            SIPartPosition(start=0, length=8, word_num=11),
            SIPartPosition(start=8, length=8, word_num=11),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz10': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=12),
            SIPartPosition(start=24, length=8, word_num=12),
            SIPartPosition(start=0, length=8, word_num=12),
            SIPartPosition(start=8, length=8, word_num=12),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz11': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=13),
            SIPartPosition(start=24, length=8, word_num=13),
            SIPartPosition(start=0, length=8, word_num=13),
            SIPartPosition(start=8, length=8, word_num=13),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz12': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=14),
            SIPartPosition(start=24, length=8, word_num=14),
            SIPartPosition(start=0, length=8, word_num=14),
            SIPartPosition(start=8, length=8, word_num=14),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz13': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=15),
            SIPartPosition(start=24, length=8, word_num=15),
            SIPartPosition(start=0, length=8, word_num=15),
            SIPartPosition(start=8, length=8, word_num=15),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz14': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=16),
            SIPartPosition(start=24, length=8, word_num=16),
            SIPartPosition(start=0, length=8, word_num=16),
            SIPartPosition(start=8, length=8, word_num=16),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
    }, constants), ]

# !!!Какой CMR
data_pattern_2 = [
    prepare_SI_pattern({
        'tz15': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=3),
            SIPartPosition(start=24, length=8, word_num=3),
            SIPartPosition(start=0, length=8, word_num=3),
            SIPartPosition(start=8, length=8, word_num=3),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz16': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=4),
            SIPartPosition(start=24, length=8, word_num=4),
            SIPartPosition(start=0, length=8, word_num=4),
            SIPartPosition(start=8, length=8, word_num=4),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz17': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=5),
            SIPartPosition(start=24, length=8, word_num=5),
            SIPartPosition(start=0, length=8, word_num=5),
            SIPartPosition(start=8, length=8, word_num=5),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz18': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=6),
            SIPartPosition(start=24, length=8, word_num=6),
            SIPartPosition(start=0, length=8, word_num=6),
            SIPartPosition(start=8, length=8, word_num=6),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz19': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=7),
            SIPartPosition(start=24, length=8, word_num=7),
            SIPartPosition(start=0, length=8, word_num=7),
            SIPartPosition(start=8, length=8, word_num=7),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz20': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=8),
            SIPartPosition(start=24, length=8, word_num=8),
            SIPartPosition(start=0, length=8, word_num=8),
            SIPartPosition(start=8, length=8, word_num=8),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz21': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=9),
            SIPartPosition(start=24, length=8, word_num=9),
            SIPartPosition(start=0, length=8, word_num=9),
            SIPartPosition(start=8, length=8, word_num=9),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz22': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=10),
            SIPartPosition(start=24, length=8, word_num=10),
            SIPartPosition(start=0, length=8, word_num=10),
            SIPartPosition(start=8, length=8, word_num=10),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
        'tz23': SingleParam(content=[
            SIPartPosition(start=16, length=8, word_num=11),
            SIPartPosition(start=24, length=8, word_num=11),
            SIPartPosition(start=0, length=8, word_num=11),
            SIPartPosition(start=8, length=8, word_num=11),
        ], sign=True, CMR=2 ** 0, type='float', ieee754_flag=True),
    }, constants), ]

"""Координаты параметров фразы 921"""
