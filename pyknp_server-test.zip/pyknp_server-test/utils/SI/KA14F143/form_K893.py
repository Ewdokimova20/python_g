from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F143.common import constants


phrase_num_range = list(range(363, 506 + 1))
"""Диапазон номеров фраз для формы К893"""

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=7, length=6, word_num=8)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=20, length=11, word_num=5)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants)
]
"""Координаты параметров временной привязки фразы K893"""

data_pattern = [
    prepare_SI_pattern({
        'x': SingleParam(content=[
            SIPartPosition(start=20, length=12, word_num=6),
            SIPartPosition(start=0, length=20, word_num=5)
        ], sign=True, CMR=2 ** -16, type='float'),
        'y': SingleParam(content=[
            SIPartPosition(start=19, length=13, word_num=7),
            SIPartPosition(start=0, length=19, word_num=6)
        ], sign=True, CMR=2 ** -16, type='float'),
        'z': SingleParam(content=[
            SIPartPosition(start=18, length=14, word_num=8),
            SIPartPosition(start=0, length=18, word_num=7)
        ], sign=True, CMR=2 ** -16, type='float'),
        'Vx': SingleParam(content=[SIPartPosition(start=0, length=30, word_num=2)],
                          sign=True, CMR=2 ** -26, type='float'),
        'Vy': SingleParam(content=[SIPartPosition(start=0, length=30, word_num=3)],
                          sign=True, CMR=2 ** -26, type='float'),
        'Vz': SingleParam(content=[SIPartPosition(start=0, length=30, word_num=4)],
                          sign=True, CMR=2 ** -26, type='float'),
        'Ax': SingleParam(content=[SIPartPosition(start=0, length=7, word_num=8)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Ay': SingleParam(content=[SIPartPosition(start=24, length=7, word_num=9)],
                          sign=True, CMR=2 ** -32, type='float'),
        'Az': SingleParam(content=[SIPartPosition(start=17, length=7, word_num=9)],
                          sign=True, CMR=2 ** -32, type='float'),
        'x_L3': SingleParam(content=[SIPartPosition(start=0, length=32, word_num=10)],
                            sign=True, CMR=2 ** -16, type='float'),
        'y_L3': SingleParam(content=[SIPartPosition(start=0, length=32, word_num=11)],
                            sign=True, CMR=2 ** -16, type='float'),
        'z_L3': SingleParam(content=[SIPartPosition(start=0, length=32, word_num=12)],
                            sign=True, CMR=2 ** -16, type='float'),
        'Ax_L3': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=13)],
                             sign=True, CMR=2 ** -35, type='float'),
        'Ay_L3': SingleParam(content=[SIPartPosition(start=10, length=10, word_num=13)],
                             sign=True, CMR=2 ** -35, type='float'),
        'Az_L3': SingleParam(content=[SIPartPosition(start=20, length=10, word_num=13)],
                             sign=True, CMR=2 ** -35, type='float'),
    }, constants)
]
"""Координаты параметров фразы K893"""
