from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F143.common import constants


phrase_num_range = list(range(541, 552 + 1))
"""Диапазон номеров фраз для формы 701"""

time_pattern = [
    prepare_SI_pattern({
        'Na': SingleParam(content=[
            SIPartPosition(start=4, length=11, word_num=2)
        ], sign=False, CMR=2 ** 0, type='int'),
        'NaT': SingleParam(content=[
            SIPartPosition(start=20, length=11, word_num=2)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants)
]
"""Координаты параметров временной привязки фразы 701"""

data_pattern_1 = [
    prepare_SI_pattern({'tau_a1': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=3)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a2': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=3)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a3': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=4)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a4': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=4)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a5': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=5)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a6': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=5)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a7': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=6)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a8': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=6)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a9': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=7)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a10': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=7)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a11': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=8)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a12': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=8)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a13': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=9)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a14': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=9)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a15': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=10)], sign=True, CMR=2 ** -18, type='float')}, constants),
]


data_pattern_2 = [
    prepare_SI_pattern({'tau_a16': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=3)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a17': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=3)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a18': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=4)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a19': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=4)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a20': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=5)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a21': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=5)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a22': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=6)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a23': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=6)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a24': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=7)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a25': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=7)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a26': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=8)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a27': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=8)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a28': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=9)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a29': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=9)], sign=True, CMR=2 ** -18, type='float'),
                        'tau_a30': SingleParam(content=[SIPartPosition(start=16, length=10, word_num=10)], sign=True, CMR=2 ** -18, type='float')}, constants),
]


data_pattern_3 = [
    prepare_SI_pattern({'tau_a1_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=2)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a1_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=2)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a2_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=3)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a2_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=3)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a3_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=4)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a3_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=4)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a4_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=5)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a4_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=5)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a5_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=6)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a5_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=6)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a6_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=7)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a6_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=7)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a7_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=8)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a7_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=8)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a8_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=9)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a8_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=9)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a9_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=10)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a9_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=10)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a10_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=11)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a10_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=11)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a11_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=12)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a11_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=12)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a12_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=13)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a12_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=13)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a13_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=14)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a13_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=14)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a14_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=15)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a14_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=15)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a15_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=16)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a15_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=16)], sign=True, CMR=2 ** -39, type='float'),}, constants),
]

data_pattern_4 = [
    prepare_SI_pattern({'tau_a16_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=2)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a16_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=2)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a17_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=3)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a17_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=3)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a18_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=4)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a18_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=4)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a19_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=5)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a19_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=5)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a20_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=6)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a20_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=6)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a21_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=7)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a21_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=7)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a22_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=8)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a22_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=8)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a23_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=9)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a23_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=9)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a24_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=10)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a24_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=10)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a25_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=11)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a25_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=11)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a26_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=12)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a26_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=12)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a27_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=13)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a27_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=13)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a28_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=14)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a28_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=14)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a29_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=15)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a29_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=15)], sign=True, CMR=2 ** -39, type='float'),
                        'tau_a30_cd': SingleParam(content=[SIPartPosition(start=16, length=14, word_num=16)], sign=True, CMR=2 ** -20, type='float'),
                        'gamma_a30_cd': SingleParam(content=[SIPartPosition(start=0, length=10, word_num=16)], sign=True, CMR=2 ** -39, type='float'),}, constants),
]
"""Координаты параметров фразы 701"""