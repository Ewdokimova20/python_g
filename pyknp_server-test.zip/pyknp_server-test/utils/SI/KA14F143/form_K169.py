from utils.SI.common import prepare_SI_pattern, SIPartPosition
from utils.bytestring_parser import SingleParam
from utils.SI.KA14F143.common import constants

phrase_num_range = list(range(512, 531+1))
"""Диапазон номеров фраз"""

time_pattern = [
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=11, word_num=4)
        ], sign=False, CMR=2 ** 0, type='int')
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=11, word_num=7)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=11, word_num=10)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=11, word_num=13)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tb': SingleParam(content=[
            SIPartPosition(start=0, length=6, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
        'N': SingleParam(content=[
            SIPartPosition(start=6, length=11, word_num=16)
        ], sign=False, CMR=2 ** 0, type='int'),
    }, constants),
]
"""Координаты параметров временной привязки фразы"""

data_pattern = [
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=29, word_num=2),
        ], sign=True, CMR=2 ** -35, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=3)
        ], sign=True, CMR=2 ** -40, type='int'),
        'gamma_L3': SingleParam(content=[
            SIPartPosition(start=16, length=16, word_num=3)
        ], sign=True, CMR=2 ** -45, type='int'),
        'beta': SingleParam(content=[                      # этот параметр есть только у кодовых
            SIPartPosition(start=19, length=13, word_num=4)
        ], sign=True, CMR=2 ** -55, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=29, word_num=5),
        ], sign=True, CMR=2 ** -35, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=6)
        ], sign=True, CMR=2 ** -40, type='int'),
        'gamma_L3': SingleParam(content=[
            SIPartPosition(start=16, length=16, word_num=6)
        ], sign=True, CMR=2 ** -45, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=19, length=13, word_num=7)
        ], sign=True, CMR=2 ** -55, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=29, word_num=8),
        ], sign=True, CMR=2 ** -35, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=9)
        ], sign=True, CMR=2 ** -40, type='int'),
        'gamma_L3': SingleParam(content=[
            SIPartPosition(start=16, length=16, word_num=9)
        ], sign=True, CMR=2 ** -45, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=19, length=13, word_num=10)
        ], sign=True, CMR=2 ** -55, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=29, word_num=11),
        ], sign=True, CMR=2 ** -35, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=12)
        ], sign=True, CMR=2 ** -40, type='int'),
        'gamma_L3': SingleParam(content=[
            SIPartPosition(start=16, length=16, word_num=12)
        ], sign=True, CMR=2 ** -45, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=19, length=13, word_num=13)
        ], sign=True, CMR=2 ** -55, type='int'),
    }, constants),
    prepare_SI_pattern({
        'tau': SingleParam(content=[
            SIPartPosition(start=0, length=29, word_num=14),
        ], sign=True, CMR=2 ** -35, type='int'),
        'gamma': SingleParam(content=[
            SIPartPosition(start=0, length=11, word_num=15)
        ], sign=True, CMR=2 ** -40, type='int'),
        'gamma_L3': SingleParam(content=[
            SIPartPosition(start=16, length=16, word_num=15)
        ], sign=True, CMR=2 ** -45, type='int'),
        'beta': SingleParam(content=[
            SIPartPosition(start=19, length=13, word_num=16)
        ], sign=True, CMR=2 ** -55, type='int'),
    }, constants),
]
"""Координаты параметров фразы"""
