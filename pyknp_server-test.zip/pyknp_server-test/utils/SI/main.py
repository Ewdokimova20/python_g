import datetime
import logging
import math
from typing import List, Union, Optional, Tuple, cast

import utils.SI.KA14F113 as KA14F113
import utils.SI.KA14F143 as KA14F143
import utils.SI.KA14F160 as KA14F160
from data import Nka
from db.cdb import SIFormTable
from global_data.config_schema import config
from global_data.nka_type import NkaType
from utils.SI.KA14F113.form_169 import service_phrase_num
from utils.SI.common import SIPhrase, BITS_IN_BYTE, SIConst, SIRecord
from utils.SI.compare_si_to_di.types import TimeData, SiFormData
from utils.bytestring_parser import parse_string_to_params


class SIMetaKA:
    """Базовый класс для всех классов SIMetaKA."""

    phrase_num_pattern = None
    """Шаблон номера фразы"""
    const = None
    """Набор констант, релевантных данной форме СИ (в зависимости от типа КА)"""

    def __init__(self):
        self.phrases = []
        """Извлеченные из записей фразы СИ"""

    def _create_phrase(self, phrase_content, nka_num, timestamp) -> SIPhrase:
        """Абстрактный метод для создания объекта SIPhrase из содержимого фразы, номера НКА и метки времени"""

    def split_on_phrases(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз"""
        phrases = []
        byte_arr = bytearray(rec.data)
        byte_arr_len = len(byte_arr)
        for i in range(0, byte_arr_len, self.const.PHRASE_BYTE_SIZE):
            phrase_content = byte_arr[i:(i + self.const.PHRASE_BYTE_SIZE)]
            phrases.append(self._create_phrase(phrase_content, int(rec.nka), rec.timestamp)),
        phrases = list(filter(lambda phrase: phrase.num in self.phrase_num_range, phrases))
        self.phrases = phrases
        return phrases

    def split_by_single_time_moment(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз, по одному tb в каждой"""

        phrases_by_tb = []
        phrases = self.split_on_phrases(rec)

        if phrases:
            for phr in phrases:
                if self.form_num == 921:  # в 921 форме нет временной привязки
                    phrases_by_tb.append(SIPhrase(num=phr.num,
                                                  nka=phr.nka,
                                                  time=TimeData(),
                                                  content=phr.content,
                                                  timestamp_db=phr.timestamp_db,
                                                  form_num=phr.form_num,
                                                  data_pattern=phr.data_pattern))
                else:
                    for t in phr.time:
                        phrases_by_tb.append(SIPhrase(num=phr.num,
                                                      nka=phr.nka,
                                                      time=t,
                                                      content=phr.content,
                                                      timestamp_db=phr.timestamp_db,
                                                      form_num=phr.form_num,
                                                      data_pattern=phr.data_pattern))
        self.phrases = phrases_by_tb
        return phrases_by_tb


class SIMetaKA14F160(SIMetaKA):
    """Общие параметры СИ для КА14Ф160"""

    phrase_num_pattern = KA14F160.common.phrase_num_pattern
    """Координаты номера фразы"""
    const: SIConst = KA14F160.common.constants
    """Набор констант, релевантных данной форме СИ (в зависимости от типа КА)"""


class SIMetaKA14F143(SIMetaKA):
    """Общие параметры СИ для КА14Ф143"""

    phrase_num_pattern = KA14F143.common.phrase_num_pattern
    """Координаты номера фразы"""
    const: SIConst = KA14F143.common.constants
    """Набор констант, релевантных данной форме СИ (в зависимости от типа КА)"""


class SIMetaKA14F113(SIMetaKA):
    """Общие параметры СИ для КА14Ф113"""

    phrase_num_pattern = KA14F113.common.phrase_num_pattern
    """Координаты номера фразы"""
    const: SIConst = KA14F113.common.constants
    """Набор констант, релевантных данной форме СИ (в зависимости от типа КА)"""
    Kfr_pattern = KA14F113.common.Kfr_pattern
    """Координаты признака Kfr"""

    @staticmethod
    def extract_data(byte_array: bytes, index_start: int, data_length: int) -> int:
        """Извлечь отрезок из байтового массива

         :param byte_array: массив байтов, из которого нужно извлечь отрезок
         :param index_start: номер первого бита
         :param data_length: длина отрезка в битах
         """

        index_end = index_start + data_length - 1
        byte_num_start = index_start // BITS_IN_BYTE
        byte_num_end = math.ceil(index_end / BITS_IN_BYTE)
        content = byte_array[byte_num_start:byte_num_end]

        # величина сдвига в битах до конца байта
        shift = (BITS_IN_BYTE - (index_end + 1) % BITS_IN_BYTE) % BITS_IN_BYTE

        return int.from_bytes(content, 'big') >> shift

    # noinspection PyMethodMayBeStatic
    def read_service_info(self, byte_array: bytes, index: int, should_break: bool):
        """Извлечь информацию, предшествующую массиву фраз.
        При необходимости метод переопределяется в дочернем.

         :param byte_array: массив СИ в байтах
         :param index: битовый указатель
         :param should_break: флаг, нужно ли остановить цикл по массиву СИ
         """

        return index, should_break

    def split_on_phrases(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз"""

        MAGIC_SHIFT_ARR_END = 46  # [бит] из кода Сагалакова (dbform.cpp), в конце каждого массива
        MAGIC_SHIFT_START = 48  # [байт] из кода Сагалакова (dbform.cpp), в начале СИ
        byte_arr = bytearray(rec.data)[MAGIC_SHIFT_START:]
        byte_arr_len = len(byte_arr)
        phrases = []  # список всех фраз в СИ
        index = 0  # битовый указатель
        arr_count = 0  # счетчик массивов в СИ
        is_end = False  # флаг конца СИ

        while not is_end:  # цикл по всей СИ из нескольких массивов
            # читаем служебную информацию
            should_break = False  # флаг, нужно ли остановить цикл по массиву СИ (нужен для 169 формы)
            index += KA14F113.common.HEADER_LENGTH + 4 * self.const.WORD_BIT_SIZE  # пропуск шапки и 4 СС (124+4*34 бит)
            index, should_break = self.read_service_info(byte_arr, index, should_break)
            if should_break:
                break

            word_count = 0
            phrase_count = 0
            Kfr = None
            iEnd = 0
            # 01 - конец массива, 10 - конец СИ

            while not iEnd:  # цикл по одному массиву
                phrase_content = self.extract_data(byte_arr, index, self.const.PHRASE_BIT_SIZE)
                phrases.append(self._create_phrase(phrase_content, int(rec.nka), rec.timestamp))

                # Kfr - признак последнего массива, равен 11 в первом слове последней фразы массива фраз
                Kfr = parse_string_to_params(phrase_content, self.Kfr_pattern)[0]['Kfr']

                if not config['cdb']['simulated']:
                    # iEnd - недокументированный признак конца массива фраз/массива СИ из кода Сагалакова
                    iEnd = parse_string_to_params(phrase_content, self.Kfr_pattern)[0]['iEnd']

                index += self.const.PHRASE_BIT_SIZE + self.const.WORD_BIT_SIZE  # сдвиг на длину фразы + СС3(544+34 бит)
                word_count += self.const.PHRASE_LENGTH + 1  # 16 слов фразы + СС3
                phrase_count += 1

                if phrase_count >= KA14F113.common.ARRAY_LENGTH:
                    break

                if index > byte_arr_len * BITS_IN_BYTE:  # выходим, если указатель превысил длину записи в битах
                    is_end = True
                    break

            index += self.const.WORD_BIT_SIZE * 2 + MAGIC_SHIFT_ARR_END  # сдвиг на два СС и 46 бит в конце кажд.массива
            arr_count += 1

            if Kfr == 0b11 or arr_count >= KA14F113.common.SI_ARRAY_LENGTH or iEnd == 0b10:
                is_end = True

        phrases = list(filter(lambda phrase: phrase.num in self.phrase_num_range, phrases))
        self.phrases = phrases

        return phrases


class SIForm(SIFormTable):
    """Класс для форм СИ, содержит общий для всех форм СИ функционал"""

    form_num: None
    """Номер формы, переопределяется в классе формы"""
    pattern_num: Union[int, None]
    """Номер массива в паттерне"""

    def __init__(self, sys_num: int = None, nku_num: int = None, nka_instance: Nka = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.pattern_num = None
        self.phrase = None
        self.parsed = {}
        if sys_num:
            self.curr_nka = Nka.get_or_none(nka_sys_number=sys_num)
        if nku_num:
            self.curr_nka = Nka.get_or_none(nku_number=nku_num)
        if nka_instance:
            self.curr_nka = nka_instance

    def _extract_time(self, phr: Union[int, bytes]) -> List[TimeData]:
        """Извлечь из фразы параметры временной привязки"""

        time_list: List[TimeData] = []
        for pattern in self.time_pattern:
            time_i, _ = parse_string_to_params(phr, pattern)
            time_list.append(TimeData(**time_i))
        return time_list

    def _extract_num(self, phr: Union[int, bytes]) -> int:
        """Извлечь из фразы ее номер"""
        phrase_num, _ = parse_string_to_params(phr, self.phrase_num_pattern)
        return phrase_num.get('Afr')

    def _create_phrase(self, phrase_content, nka_num, timestamp) -> SIPhrase:
        """Сформировать фразу"""
        return SIPhrase(num=self._extract_num(phrase_content),
                        nka=nka_num,
                        time=self._extract_time(phrase_content),
                        content=phrase_content,
                        timestamp_db=timestamp,
                        form_num=self.form_num,
                        data_pattern=self.data_pattern,
                        )

    def _find_phrase_in_record(self, record, time_bind: TimeData) -> (List, Optional[None]):
        """Найти фразу в записях из ЦБД, соответствующую заданным номеру НКА и моменту времени"""

        found_phrase = None
        phrase_arr = self.split_on_phrases(record)

        if len(phrase_arr):
            for phr in phrase_arr:
                found_pattern_num = phr._compare_time(time_bind=time_bind)
                if found_pattern_num is not None:
                    self.pattern_num = found_pattern_num
                    found_phrase = phr
                    break
        self.phrase = found_phrase
        return found_phrase, phrase_arr

    def find_phrase_in_record_by_num(self, record, phr_num):
        """Найти фразу в записях из ЦБД, соответствующую заданным номеру НКА и моменту времени"""

        found_phrase = None
        phrase_arr = self.split_on_phrases(record)

        if len(phrase_arr) > 0:
            for phr in phrase_arr:
                if phr.num == phr_num:
                    found_phrase = phr
                if found_phrase:
                    break
        self.phrase = found_phrase
        return found_phrase

    def _parse_result(self, phrase=None):
        """Распарсить найденную фразу"""

        if not phrase:
            phrase = self.phrase

        parsed = phrase.parse_with_pattern()

        self.parsed = parsed
        return parsed

    def parse_form(self, records: List[SIRecord], time_bind: TimeData) -> Tuple[SiFormData, Optional[SIRecord]]:
        """
        Распарсить форму СИ

        :param records Список записей, в которых потенциально лежит нужная инфа
        :param time_bind Параметры временной привязки кадра, для которого нужно распарсить форму СИ
        """

        parsed = cast(SiFormData, {})
        record = None
        records = records if isinstance(records, list) else [records]
        for record in records:
            found, _ = self._find_phrase_in_record(record=record, time_bind=time_bind)
            if found:
                parsed = self._parse_result(found)
                if record.si_form in (169, 893):
                    parsed['phrase_tb'] = found.phrase_tb
                return parsed, record
            record_id = getattr(record, "id", None)
            write_time_cdb = getattr(record, "write_time_cdb", None)
            logging.info(
                f'Не найдена фраза СИ {self.form_num} для НКА {record.nka} для параметров: {time_bind.as_dict()} в записи из ЦБД с id {record_id} на время записи {write_time_cdb}')
        return parsed, record


class Form893(SIForm):
    """Класс для всех форм с номером 893 (ЭИ)"""

    form_num = 893
    """Номер формы по протоколу СИ"""
    search_depth = datetime.timedelta(days=config['SI']['search_depth_893'])
    """Глубина поиска нужной фразы в ЦБД"""

    def _parse_result(self, phrase=None):
        parsed = super()._parse_result(phrase)

        param_in_km = ['x', 'y', 'z', 'Vx', 'Vy', 'Vz', 'Ax', 'Ay', 'Az', 'x_L3', 'y_L3', 'z_L3', 'Ax_L3', 'Ay_L3',
                       'Az_L3', 'dX', 'dY', 'dZ']
        for k, v in parsed.items():
            if k in param_in_km:
                parsed[k] = v * 1e3

        self.parsed = parsed
        return parsed


class Form169(SIForm):
    """Класс для всех форм с номером 169 (ЧВП)"""

    form_num = 169
    """Номер формы по протоколу СИ"""
    search_depth = datetime.timedelta(days=config['SI']['search_depth_169'])
    """Глубина поиска нужной фразы в ЦБД"""
    N: int = 0
    """Количество суток из служебной фразы ЧВП"""

    def _extract_time(self, phr: Union[int, bytes]) -> List[TimeData]:
        """Извлечь из фразы параметры временной привязки"""

        time = []
        for _, pattern in enumerate(self.time_pattern):
            time_i, _ = parse_string_to_params(phr, pattern)
            if 'N' in time_i:
                time_i['N'] += self.N
            time.append(TimeData(**time_i))
        return time

    def read_service_info(self, byte_array: bytes, index: int, should_break: bool):
        """Извлечь информацию, предшествующую массиву фраз

         :param byte_array: массив СИ в байтах
         :param index: указатель
         :param should_break: флаг, нужно ли остановить цикл по массиву СИ
         """

        # Извлекаем из служебной фразы ЧВП количество суток N и номер фразы Afr
        service_phrase = self.extract_data(byte_array, index, self.const.PHRASE_BIT_SIZE)
        self.N = parse_string_to_params(service_phrase, KA14F113.form_169.service_phrase_pattern)[0]['N']
        Afr = parse_string_to_params(service_phrase, KA14F113.form_169.service_phrase_pattern)[0]['Afr']

        index += self.const.PHRASE_BIT_SIZE + self.const.WORD_BIT_SIZE  # сдвиг на длину служ. фразы + СС3 (544+34 бит)

        if Afr != service_phrase_num:
            should_break = True

        return index, should_break


class Form895(SIForm):
    """Класс для всех форм с номером 895 (АС)"""

    form_num = 895
    """Номер формы по протоколу СИ"""
    search_depth = datetime.timedelta(days=config['SI']['search_depth_895'])
    """Глубина поиска нужной фразы в ЦБД"""

    def _find_phrase_in_record(self, record, time_bind: TimeData) -> (List, None):
        """Найти массив фраз в ЦБД, соответствующих заданным номеру НКА и моменту времени"""

        result = []
        phrase_arr = self.split_on_phrases(
            record)  # FIXME разобраться, зачем тут был вызов split_on_phrases через новый конструктор
        if len(phrase_arr):
            for phr in phrase_arr:
                if phr.num in self.phrase_num_range:  # проверка, что номер фразы лежит в нужном диапазоне
                    found_pattern_num = phr._compare_time(time_bind=time_bind)
                    if found_pattern_num is not None:
                        self.pattern_num = found_pattern_num
                        result.append(phr)

        self.phrase = result
        return result, None  # None - необходимо оставить для консистентности с классом родителя

    def _parse_result(self, result=None):
        """Распарсить массив найденных фраз"""

        parsed = {}
        if not result:
            result = self.phrase

        for phrase in result:
            for pattern in self.data_pattern:
                phrase_dict = phrase.parse_with_pattern(pattern=pattern)
                parsed[phrase_dict['n']] = {par: phrase_dict[par] for par in phrase_dict if par != 'n'}

        self.parsed = parsed
        return parsed

    def split_by_single_time_moment(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз, по одному tb в каждой"""

        phrases_by_tb = []
        phrases = self.split_on_phrases(rec)

        if phrases:
            for phr in phrases:
                phrases_by_tb.append(SIPhrase(num=phr.num,
                                              nka=phr.nka,
                                              time=phr.time[0],  # в 895 фразе три времени Na одинаковых
                                              content=phr.content,
                                              timestamp_db=phr.timestamp_db,
                                              form_num=phr.form_num,
                                              data_pattern=phr.data_pattern))

        self.phrases = phrases_by_tb
        return phrases_by_tb


class Form701(SIForm):
    """Класс для всех форм с номером 701(tay_n_A)"""

    form_num = 701
    """Номер формы по протоколу СИ"""
    search_depth = datetime.timedelta(days=config['SI']['search_depth_701'])
    """Глубина поиска нужной фразы в ЦБД"""


class Form921(SIForm):
    """Класс для всех форм с номером 921(ВЗ)"""

    form_num = 921
    """Номер формы по протоколу СИ"""
    search_depth = datetime.timedelta(days=config['SI']['search_depth_921'])
    """Глубина поиска нужной фразы в ЦБД"""


class KA14F160_SI893(Form893, SIMetaKA14F160):
    """Форма K893 (ЭИ) для КА14Ф160"""

    time_pattern = KA14F160.form_K893.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F160.form_K893.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F160.form_K893.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si893'


class K893(Form893, SIMetaKA14F143):
    """Форма K893 (ЭИ) для КА14Ф143"""

    time_pattern = KA14F143.form_K893.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F143.form_K893.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F143.form_K893.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si893'


class NF893(Form893, SIMetaKA14F113):
    """Форма 893 (ЭИ) для КА14Ф113"""

    time_pattern = KA14F113.form_893.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F113.form_893.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F113.form_893.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si893'


class KA14F160_SI169(Form169, SIMetaKA14F160):
    """Форма 169 (ЧВП) для КА14Ф160"""

    time_pattern = KA14F160.form_K169.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F160.form_K169.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F160.form_K169.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si169'


class K169(Form169, SIMetaKA14F143):
    """Форма 169 (ЧВП) для КА14Ф143"""

    time_pattern = KA14F143.form_K169.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F143.form_K169.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F143.form_K169.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si169'


class NF169(Form169, SIMetaKA14F113):
    """Форма 169 (ЧВП) для КА14Ф113"""

    time_pattern = KA14F113.form_169.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F113.form_169.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F113.form_169.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si169'


class KA14F160_SI895(Form895, SIMetaKA14F160):
    """Форма K895 (АС) для КА14Ф160"""

    time_pattern = KA14F160.form_K895.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F160.form_K895.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F160.form_K895.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si895'


class K895(Form895, SIMetaKA14F143):
    """Форма K895 (АС) для КА14Ф143"""

    time_pattern = KA14F143.form_K895.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F143.form_K895.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F143.form_K895.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si895'


class NF895(Form895, SIMetaKA14F113):
    """Форма K895 (АС) для КА14Ф113"""

    time_pattern = KA14F113.form_895.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F113.form_895.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F113.form_895.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si895'


class KA14F160_SI701(Form701, SIMetaKA14F160):
    """Форма K701 (tau_a) для КА14Ф160"""

    time_pattern = KA14F160.form_K701.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    phrase_num_range = KA14F160.form_K701.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    def _get_data_patterns(self, phrase_number):
        """Получить data_pattern в зависимости от номера фразы"""

        data_pattern = KA14F160.form_K701.data_pattern_1
        if phrase_number in [3004, 3006, 3008]:
            data_pattern = KA14F160.form_K701.data_pattern_1
        elif phrase_number in [3005, 3007, 3009]:
            data_pattern = KA14F160.form_K701.data_pattern_2
        elif phrase_number in [3010, 3013, 3016]:
            data_pattern = KA14F160.form_K701.data_pattern_3
        elif phrase_number in [3011, 3014, 3017]:
            data_pattern = KA14F160.form_K701.data_pattern_4
        elif phrase_number in [3012, 3015, 3018]:
            data_pattern = KA14F160.form_K701.data_pattern_5
        return data_pattern

    def _create_phrase(self, phrase_content, nka_num, timestamp) -> SIPhrase:
        """Сформировать фразу"""

        phrase_num = self._extract_num(phrase_content)
        data_pattern = self._get_data_patterns(phrase_num)
        phrase_time = []
        if phrase_num in [3004, 3005, 3006, 3007, 3008, 3009]:  # номера фраз, в которых есть параметры врем. привязки
            phrase_time = self._extract_time(phrase_content)
        return SIPhrase(num=phrase_num,
                        nka=nka_num,
                        time=phrase_time,
                        content=phrase_content,
                        timestamp_db=timestamp,
                        form_num=self.form_num,
                        data_pattern=data_pattern,
                        )

    def parse_form(self, records: List[SIRecord], time_bind: TimeData) -> Tuple[SiFormData, Optional[SIRecord]]:
        """
        Распарсить форму СИ

        :param records Список записей ЦИ из ЦБД
        :param time_bind Параметры временной привязки кадра, для которого нужно распарсить форму СИ
        """

        parsed = {}
        record = None
        records = records if isinstance(records, list) else [records]
        for record in records:
            found, phrase_arr = self._find_phrase_in_record(record=record, time_bind=time_bind)
            phrases_num = None
            if found:
                if found.num == 3004:  # фраза содержащая Na на первые сутки из СИ 701
                    phrases_num = [0, 1, 6, 7, 8]  # фразы с параметром tau для L1-L2-L3 на первые сутки, далее на 2 и 3
                elif found.num == 3006:  # фраза содержащая Na на вторые сутки из СИ 701
                    phrases_num = [2, 3, 9, 10, 11]
                elif found.num == 3008:  # фраза содержащая Na на третьи сутки из СИ 701
                    phrases_num = [4, 5, 12, 13, 14]
                if phrases_num is not None:
                    # чтобы получить все данные на один Na нужно объеденить 5 фраз
                    phrase_arr = [phrase_arr[i] for i in phrases_num]
                    parsed = self._parse_result(phrase_arr)
                return parsed, record
            record_id = getattr(record, "id", None)
            write_time_cdb = getattr(record, "write_time_cdb", None)
            logging.info(
                f'Не найдена фраза СИ {self.form_num} для НКА {record.nka} для параметров: {time_bind.as_dict()} в записи из ЦБД с id {record_id} на время записи {write_time_cdb}')
        return parsed, record

    def _parse_result(self, result=None):
        """Распарсить массив найденных фраз"""

        parsed = {}
        if not result:
            result = self.phrase

        for phrase in result:  # тут проходимся по 5 фразам, содержит все tau на одни сутки
            data_pattern = self._get_data_patterns(phrase.num)
            for pattern in data_pattern:
                phrase_dict = phrase.parse_with_pattern(pattern=pattern)
                parsed.update(phrase_dict)

        self.parsed = parsed
        return {'tau_a': parsed}

    def split_by_single_time_moment(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз"""

        phrases_by_tb = []
        phrases = self.split_on_phrases(rec)
        t_cd: List[int] = []
        t = TimeData()

        if phrases:
            for phr in phrases:
                try:
                    if phr.num in [3004, 3006, 3008]:  # фразы в которых содержится Na и NaT
                        t = phr.time[0]
                        t_cd.append(t.NaT)
                    if phr.num in [3010, 3011, 3012]:
                        t = TimeData(Na=t_cd[0])
                    if phr.num in [3013, 3014, 3015]:
                        t = TimeData(Na=t_cd[1])
                    if phr.num in [3016, 3017, 3018]:
                        t = TimeData(Na=t_cd[2])
                    if t:
                        phrases_by_tb.append(SIPhrase(num=phr.num,
                                                      nka=phr.nka,
                                                      time=t,
                                                      content=phr.content,
                                                      timestamp_db=phr.timestamp_db,
                                                      form_num=phr.form_num,
                                                      data_pattern=phr.data_pattern))
                except Exception as e:
                    logging.error(
                        f'Ошибка в функции split_by_single_time_moment для класса {self.__class__.__name__}: {str(e)}')
                    continue

        self.phrases = phrases_by_tb
        return phrases_by_tb

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si701'


class K701(Form701, SIMetaKA14F143):
    """Форма K701 (tay_n_A) для КА14Ф143"""

    time_pattern = KA14F143.form_K701.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    phrase_num_range = KA14F143.form_K701.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    def _get_data_patterns(self, phrase_number):
        """Получить data_pattern в зависимости от номера фразы"""

        data_pattern = KA14F143.form_K701.data_pattern_1
        if phrase_number in [541, 543, 545]:
            data_pattern = KA14F143.form_K701.data_pattern_1
        elif phrase_number in [542, 544, 546]:
            data_pattern = KA14F143.form_K701.data_pattern_2
        elif phrase_number in [547, 549, 551]:
            data_pattern = KA14F143.form_K701.data_pattern_3
        elif phrase_number in [548, 550, 552]:
            data_pattern = KA14F143.form_K701.data_pattern_4
        return data_pattern

    def _create_phrase(self, phrase_content, nka_num, timestamp) -> SIPhrase:
        """Сформировать фразу"""

        phrase_num = self._extract_num(phrase_content)
        data_pattern = self._get_data_patterns(phrase_num)
        phrase_time = []
        if phrase_num in [541, 542, 543, 544, 545, 546]:  # номера фраз, в которых есть параметры временной привязки
            phrase_time = self._extract_time(phrase_content)
        return SIPhrase(num=phrase_num,
                        nka=nka_num,
                        time=phrase_time,
                        content=phrase_content,
                        timestamp_db=timestamp,
                        form_num=self.form_num,
                        data_pattern=data_pattern,
                        )

    def parse_form(self, records: List[SIRecord], time_bind: TimeData) -> Tuple[SiFormData, Optional[SIRecord]]:
        """
        Распарсить форму СИ

        :param records Список записей ЦИ из ЦБД
        :param time_bind Параметры временной привязки кадра, для которого нужно распарсить форму СИ
        """

        parsed = {}
        record = None
        records = records if isinstance(records, list) else [records]
        for record in records:
            found, phrase_arr = self._find_phrase_in_record(record=record, time_bind=time_bind)
            phrases_num = None
            if found:
                if found.num == 541:  # фраза содержащая Na на первые сутки из СИ 701
                    phrases_num = [0, 1, 6, 7]  # фразы с параметром tau для L1-L2-L3 на первые сутки, далее на 2 и 3
                elif found.num == 543:  # фраза содержащая Na на вторые сутки из СИ 701
                    phrases_num = [2, 3, 8, 9]
                elif found.num == 545:  # фраза содержащая Na на третьи сутки из СИ 701
                    phrases_num = [4, 5, 10, 11]
                if phrases_num is not None:
                    # чтобы получить все данные на один Na нужно объеденить 4 фразы
                    phrase_arr = [phrase_arr[i] for i in phrases_num]
                    parsed = self._parse_result(phrase_arr)
                return parsed, record
            record_id = getattr(record, "id", None)
            write_time_cdb = getattr(record, "write_time_cdb", None)
            logging.info(
                f'Не найдена фраза СИ {self.form_num} для НКА {record.nka} для параметров: {time_bind.as_dict()} в записи из ЦБД с id {record_id} на время записи {write_time_cdb}')
        return parsed, record

    def _parse_result(self, result=None):
        """Распарсить массив найденных фраз"""

        parsed = {}
        if not result:
            result = self.phrase

        for phrase in result:  # тут проходимся по 4 фразам, содержит все tau на одни сутки
            data_pattern = self._get_data_patterns(phrase.num)
            for pattern in data_pattern:
                phrase_dict = phrase.parse_with_pattern(pattern=pattern)
                parsed.update(phrase_dict)

        self.parsed = parsed
        return {'tau_a': parsed}

    def split_by_single_time_moment(self, rec: SIRecord) -> List[SIPhrase]:
        """Разбить содержимое записи из ЦБД на массив отдельных фраз"""

        phrases_by_tb = []
        phrases = self.split_on_phrases(rec)
        t_cd = []
        t = None

        if phrases:
            for phr in phrases:
                try:
                    if phr.num in [541, 543, 545]:  # фразы в которых содержится Na и NaT
                        t = phr.time[0]
                        t_cd.append(phr.time[0].get('NaT'))
                    if phr.num in [547, 548]:
                        t = {'Na': t_cd[0]}
                    if phr.num in [549, 550]:
                        t = {'Na': t_cd[1]}
                    if phr.num in [551, 552]:
                        t = {'Na': t_cd[2]}
                    if t:
                        phrases_by_tb.append(SIPhrase(num=phr.num,
                                                      nka=phr.nka,
                                                      time=t,
                                                      content=phr.content,
                                                      timestamp_db=phr.timestamp_db,
                                                      form_num=phr.form_num,
                                                      data_pattern=phr.data_pattern))
                except Exception as e:
                    logging.error(
                        f'Ошибка в функции split_by_single_time_moment для класса {self.__class__.__name__}: {str(e)}')
                    continue

        self.phrases = phrases_by_tb
        return phrases_by_tb

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si701'


class NF701(Form701, SIMetaKA14F113):
    """Форма K701 (tay_n_A) для КА14Ф113"""

    time_pattern = KA14F113.form_701.time_pattern
    """Координаты параметров временной привязки в форме СИ"""
    data_pattern = KA14F113.form_701.data_pattern
    """Координаты всех параметров в форме СИ"""
    phrase_num_range = KA14F113.form_701.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    def _parse_result(self, phrase=None):
        """Распарсить массив найденных фраз"""

        if not phrase:
            phrase = self.phrase

        parsed = phrase.parse_with_pattern()

        self.parsed = parsed
        return {'tau_a': parsed}

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si701'


class KA14F160_SI921(Form921, SIMetaKA14F160):
    """Форма K921 (ВЗ) для КА14Ф160"""

    phrase_num_range = KA14F160.form_K921.phrase_num_range
    """Диапазон номеров строк, встречающихся в данной форме"""

    def _get_data_patterns(self, phrase_number):
        """Получить data_pattern в зависимости от номера фразы"""

        data_pattern = KA14F160.form_K701.data_pattern_1
        if phrase_number == 3125:
            data_pattern = KA14F160.form_K921.data_pattern_1
        elif phrase_number == 3126:
            data_pattern = KA14F160.form_K921.data_pattern_2
        return data_pattern

    def _create_phrase(self, phrase_content, nka_num, timestamp) -> SIPhrase:
        """Сформировать фразу"""

        phrase_num = self._extract_num(phrase_content)
        data_pattern = self._get_data_patterns(phrase_num)
        return SIPhrase(num=phrase_num,
                        nka=nka_num,
                        time=TimeData(),
                        content=phrase_content,
                        timestamp_db=timestamp,
                        form_num=self.form_num,
                        data_pattern=data_pattern,
                        )

    def parse_form(self, records: List[SIRecord], time_bind: TimeData) -> Tuple[SiFormData, Optional[SIRecord]]:
        """
        Распарсить форму СИ

        :param records Список записей ЦБД
        :param nka Номер НКА в НКУ (трехзначный)
        :param time_bind Параметры временной привязки кадра, для которого нужно распарсить форму СИ
        """

        parsed = {}
        record = None
        records = records if isinstance(records, list) else [records]
        for record in records:
            found, phrase_arr = self._find_phrase_in_record(record=record, time_bind=time_bind)
            if found:
                return self._parse_result(phrase_arr), record
            record_id = getattr(record, "id", None)
            record_timestamp = getattr(record, "timestamp", None)
            logging.info(
                f'Не найдена фраза СИ {self.form_num} для НКА {record.nka} для параметров: {time_bind.as_dict()} в записи из ЦБД с id {record_id} на время {record_timestamp}')
        return parsed, record

    def _find_phrase_in_record(self, record, time_bind: TimeData) -> (List, None):
        """Найти фразу в записях из ЦБД, соответствующую заданным номеру НКА и моменту времени"""

        found_phrase = None
        phrase_arr = self.split_on_phrases(record)

        if len(phrase_arr):
            found_phrase = phrase_arr[
                0]  # у 921 формы нет временной привязки, и все параметры нужные находятся в 1 фразе из массива
        self.phrase = found_phrase
        return found_phrase, phrase_arr

    def _parse_result(self, result=None):
        """Распарсить массив найденных фраз"""

        parsed = {}
        if not result:
            result = self.phrase

        for phrase in result:  # тут проходимся по 2 фразам
            data_pattern = self._get_data_patterns(phrase.num)
            for pattern in data_pattern:
                phrase_dict = phrase.parse_with_pattern(pattern=pattern)
                parsed.update(phrase_dict)

        self.parsed = parsed
        return {'tz': parsed}

    class Meta:
        if config['cdb']['mode'] == 'new':
            table_name = 'si921'


SI_FORMS = {
    NkaType.KA14F160: {921: KA14F160_SI921,
                       893: KA14F160_SI893,
                       895: KA14F160_SI895,
                       701: KA14F160_SI701,
                       169: KA14F160_SI169},
    NkaType.KA14F143: {893: K893,
                       895: K895,
                       701: K701,
                       169: K169},
    NkaType.KA14F113: {893: NF893,
                       895: NF895,
                       701: NF701,
                       169: NF169,
                       },
}
