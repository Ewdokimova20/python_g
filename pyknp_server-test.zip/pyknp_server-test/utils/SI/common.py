from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from typing import NamedTuple, List, Union, Optional

from utils.SI.compare_si_to_di.types import TimeData
from utils.bytestring_parser import PartPosition, parse_string_to_params

BITS_IN_BYTE = 8


class SIFORM(IntEnum):
    """Перечисление форм СИ"""
    EPHEMERIS = 0  # эфемеридная  информация
    CLOCKP = 1  # ЧВП
    ALMANAC = 2  # альманах


class SIConst:
    """Константы, относящиеся к фразам СИ"""

    WORD_BIT_SIZE: int
    """Размер слова в битах"""
    PHRASE_LENGTH: int
    """Количество слов в фразе"""
    PHRASE_BYTE_SIZE: int
    """Размер фразы в байтах"""
    OFFSET: int
    """Число служебных разрядов"""

    def __init__(self, word_bit_size, phrase_length, offset):
        self.WORD_BIT_SIZE = word_bit_size
        self.PHRASE_LENGTH = phrase_length
        self.OFFSET = offset
        self.PHRASE_BIT_SIZE = (phrase_length * word_bit_size)
        self.PHRASE_BYTE_SIZE = (phrase_length * word_bit_size) // 8


@dataclass(frozen=True)
class SIPartPosition:
    start: int
    """Номер бита, с которого начинается параметр (началом считается первый младший бит параметра)
    относительно младшего бита СЛОВА, в котором находится этот параметр """
    length: int
    """Длина параметра в битах"""
    word_num: int
    """Номер слова, в котором находится параметр"""


class SIPhrase:
    phrase_tb: int
    """Значение tb данной фразы."""

    def __init__(self, num: int, nka: int, time: Union[List[TimeData], TimeData], content, timestamp_db, form_num,
                 data_pattern: dict):
        self.num = num
        """Номер фразы"""
        self.nka = nka
        """Номер КА"""
        self.time = time
        """Параметры временной привязки"""
        self.content = content
        """Фраза в байтовом представлении"""
        self.timestamp_db = timestamp_db
        """Время записи из ЦБД, из которой была создана эта фраза"""
        self.form_num = form_num
        """Номер формы"""
        self.data_pattern = data_pattern
        """Паттерн расшифровки"""
        self.pattern_num = None
        """Индекс внутри паттерна (если паттерн предназначен для нескольких типов фраз)"""

    def _compare_single_timemoment(self, phrase_time: TimeData, ref_time: TimeData) -> bool:
        """Проверить, соответствует ли время привязки из кадра моменту времени из фразы"""
        mode = ref_time.mode

        def tb_to_minutes(tb) -> int:
            if mode == 'SI':  # если функция вызвана для контроля согласованности СИ
                return tb * 30
            elif mode == 'DI':  # если функция вызвана для сравнения СИ с ЦИ
                return tb * 15 + 15

        # tb в СИ - интервалы по 30 мин, tb в кадре - по 15 мин, поэтому приводим к минутам

        if self.form_num == 893 or self.form_num == 169:
            return (phrase_time.N == ref_time.N) and (phrase_time.tb * 30 == tb_to_minutes(ref_time.tb))
        if self.form_num == 895 or self.form_num == 701:
            return phrase_time.Na == ref_time.Na

    def _compare_time(self, time_bind: TimeData) -> int:
        """Проверить, соответствует ли время привязки из кадра какому-либо моменту времени из фразы"""
        found = None
        for pattern_num, moment in enumerate(self.time):
            if self._compare_single_timemoment(moment, time_bind):
                found = pattern_num
                self.pattern_num = pattern_num
                self.phrase_tb = moment.tb
                break
        return found

    def parse_with_time(self, ref_time: TimeData):
        """Распарсить фразу на параметры по заданной временной привязке"""

        parsed = {}
        if self.form_num == 701 or self.form_num == 921:  # у 701 формы только одна временная привязка на фразу, у 921 формы нет временной привязки
            parsed, _ = parse_string_to_params(self.content, self.data_pattern[0])
            return parsed
        if self.form_num == 895:  # у 895 три data_pattern во фразе
            for pattern_num in range(len(self.data_pattern)):
                one_nka_parsed, _ = parse_string_to_params(self.content, self.data_pattern[pattern_num])
                parsed[one_nka_parsed['n']] = one_nka_parsed  # n номер КА, в каждой фразе данные для 3 КА
            return parsed
        pattern_num = self._compare_time(ref_time)
        if pattern_num is not None:
            parsed, _ = parse_string_to_params(self.content, self.data_pattern[pattern_num])
        return parsed

    def parse_with_pattern(self, pattern: dict = None):
        """Распарсить фразу на параметры по заданному паттерну, если он не задан, используется паттерн с номером, определенным в compare_time()"""
        parsed = {}
        if pattern:
            parsed, _ = parse_string_to_params(self.content, pattern)
        elif self.pattern_num is not None:
            parsed, _ = parse_string_to_params(self.content, self.data_pattern[self.pattern_num])
        return parsed

    def as_dict(self):
        result = {'phr_num': self.num, 'nku_num': self.nka}
        if isinstance(self.time, TimeData):
            result.update(self.time.as_dict())
        if isinstance(self.time, List):
            result['time'] = [t.as_dict() for t in self.time]

        return result


class SIRecord(NamedTuple):
    """Формат записи, полученной из ЦБД"""

    id: int
    nka: int
    data: bytes
    vitok: int
    timestamp: datetime
    nka_sys_num: Optional[int] = None
    si_form: Optional[int] = None
    si_format: Optional[str] = None
    flag_cdb: Optional[int] = None
    flag_sui: Optional[int] = None
    flag_ka: Optional[int] = None
    write_time_cdb: Optional[datetime] = None
    write_time_sui: Optional[datetime] = None
    write_time_ka: Optional[datetime] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


def prepare_SI_pattern(pattern: dict, constants: SIConst):
    """Привести к формату универсального парсера"""

    def _get_abs_pos(part: SIPartPosition):
        """
        Рассчитать абсолютное положение параметра во фразе от конца фразы
        Абсолютное положение - номер начального бита параметра (началом считается младший бит) от самого младшего бита фразы,
        без привязки к номеру слова.
        """
        return (constants.PHRASE_LENGTH - part.word_num) * constants.WORD_BIT_SIZE + (part.start + constants.OFFSET) + 1

    def _conv_to_abs_pos(parts: List):
        """Преобразовать к формату с абсолютным положением параметра во фразе"""
        parts_abs = []
        for part in parts:
            abs_pos = _get_abs_pos(part)
            parts_abs.append(PartPosition(start=abs_pos, length=part.length))
        return parts_abs

    for key, value in pattern.items():
        value.content = _conv_to_abs_pos(value.content)
    return pattern
