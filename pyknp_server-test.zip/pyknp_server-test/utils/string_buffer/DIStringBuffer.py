import logging
import threading
import time
from collections import defaultdict
from typing import Any, Dict, List, Type, TypeVar

from peewee import Model, chunked

from db.db_connection import create_tldb_connection
from global_data.appdata import SIGNALS_NAME
from global_data.config_schema import config
from models.base import db
from models.bis import Bis
from models.nka import Nka
from utils.composers import FrameComposer
from utils.immediate_info.update_immediate_info import update_immediate_info
from utils.reception_control.di_reception.di_reception_data_collector_manager import di_reception_manager

TModel = TypeVar('TModel', bound=Model)
RecordDict = Dict[str, Any]

logger = logging.getLogger('di_string_buffer')


class DIStringBuffer:
    """
    Буфер для сбора и пакетной записи строк ЦИ  в БД

    Принцип работы:
    1. Основной поток быстро добавляет записи в активный буфер
    2. Каждые flush_interval секунд происходит атомарная смена буферов
    3. Фоновый поток записывает данные из заполненного буфера в БД
    4. Дедупликация происходит только перед записью в БД
    """

    def __init__(self):
        # Создаем соединение для записи
        self._write_db = create_tldb_connection()

        # Двойная буферизация для минимизации блокировок
        self._active_buffer = defaultdict(list)  # Активный буфер для записи
        self._flush_buffer = defaultdict(list)  # Буфер для записи в БД

        # Блокировка только для смены буферов (очень быстрая операция)
        self._buffer_lock = threading.Lock()

        # Конфигурация
        self._flush_interval = config['write_instance_to_ldb']['bulk_string_insert_interval']
        self._unique_fields = ['nka', 'bis', 'timestamp']

        # Управление потоком
        self._stop_event = threading.Event()
        self._flush_event = threading.Event()  # Событие для принудительной записи

        # Вспомогательные объекты
        self._frame_composer = FrameComposer()

        # Запуск фонового потока
        self._worker_thread = threading.Thread(target=self._worker, daemon=True)
        self._worker_thread.start()

        logger.info("Инициализация DIStringBuffer завершена")

    def add_record(self, model: Type[TModel], data: RecordDict) -> None:
        """
        Добавление записи в активный буфер.
        """
        # Блокировка не нужна для добавления в список, т.к. используется defaultdict
        # и операция append() атомарна в CPython
        self._active_buffer[model].append(data)

    def _swap_buffers(self) -> bool:
        """
        Атомарная смена буферов. Возвращает True, если есть данные для записи.
        """
        with self._buffer_lock:
            # Проверяем, есть ли данные для записи
            has_data = any(len(records) > 0 for records in self._active_buffer.values())

            if has_data:
                # Меняем буферы местами
                self._active_buffer, self._flush_buffer = self._flush_buffer, self._active_buffer
                # Очищаем новый активный буфер
                self._active_buffer.clear()

            return has_data

    def _deduplicate_records(self, records: List[RecordDict]) -> List[RecordDict]:
        """Дедупликация по уникальным полям."""
        if len(records) <= 1:
            return records

        seen = set()
        unique_records = []

        for record in records:
            # Создаем ключ из уникальных полей
            key = tuple(record.get(field) for field in self._unique_fields)
            if key not in seen:
                seen.add(key)
                unique_records.append(record)

        return unique_records

    def _bulk_insert(self, model: Type[TModel], records: List[RecordDict]) -> List[TModel]:
        """
        Пакетная вставка в БД с откатом на поштучную запись при возникновении ошибок.
        """
        if not records:
            return []

        conflict_target = [model._meta.fields[field].column_name for field in self._unique_fields]
        preserve_fields = [f for f in records[0].keys() if f not in self._unique_fields]

        inserted_strings = []

        # ВАЖНО: Привязываем модель к нашему соединению для записи
        model._meta.database = self._write_db

        try:
            with self._write_db.atomic():
                result = (model.insert_many(records)
                          .on_conflict(conflict_target=conflict_target, preserve=preserve_fields)
                          .returning(model)
                          .execute())
                inserted_strings = list(result)

            logger.debug(f"Пакетная вставка: {len(inserted_strings)} записей для {model.__name__}")

        except Exception as e:
            logger.warning(f"Ошибка пакетной вставки для {model.__name__}: {e}")

            # Откат на запись пачками по 50 записей
            for batch in chunked(records, 50):
                try:
                    with self._write_db.atomic():
                        result = (model.insert_many(batch)
                                  .on_conflict(conflict_target=conflict_target, preserve=preserve_fields)
                                  .returning(model)
                                  .execute())
                        inserted_strings.extend(list(result))

                except Exception as e2:
                    logger.warning(f"Ошибка пакетной вставки для {model.__name__}: {e2}")

                    # Последний откат - поштучная запись
                    for record in batch:
                        try:
                            with self._write_db.atomic():
                                result = (model.insert(record)
                                          .on_conflict(conflict_target=conflict_target, preserve=preserve_fields)
                                          .returning(model)
                                          .execute())
                                inserted_strings.extend(list(result))
                        except Exception as e3:
                            logger.debug(f"Ошибка единичной вставки для {model.__name__}: {e3}")

        return inserted_strings

    def _process_inserted_strings(self, inserted_strings: List[TModel]) -> None:
        """Обработка записанных строк ЦИ."""
        if not inserted_strings:
            return

        # Получаем модель из первой записи
        model = type(inserted_strings[0])

        # Получаем ID вставленных записей
        new_ids = [string.id for string in inserted_strings]

        # ВАЖНО: Для чтения используем основное соединение (db)
        # Временно привязываем модель к основному соединению для чтения
        original_db = model._meta.database
        model._meta.database = db

        try:
            # Делаем один запрос с join'ами для всех записей
            joined_strings = (model.select(model, Nka, Bis)
                              .join(Nka)
                              .switch(model)
                              .join(Bis)
                              .where(model.id.in_(new_ids)))

            # Обрабатываем каждую строку
            for string in joined_strings:
                # Учет в контроле приема ЦИ
                di_reception_manager.collect_string(string)

                # Обработка для сборщика кадров (кроме L2КСИ)
                if string.signal_id != SIGNALS_NAME["L2КСИ"]:
                    immediate_buf = self._frame_composer.append(string=string)
                    if immediate_buf:
                        update_immediate_info(string, immediate_buf)
        finally:
            # Возвращаем модели исходное соединение
            model._meta.database = original_db

    def _worker(self) -> None:
        """Фоновый поток для записи данных в БД."""
        logger.info("Запущен фоновый поток записи DIStringBuffer")

        while not self._stop_event.is_set():
            # Ждем либо таймаут, либо принудительную запись
            self._flush_event.wait(timeout=self._flush_interval)
            self._flush_event.clear()

            # Меняем буферы местами
            if self._swap_buffers():
                start_time = time.time()
                total_records = 0  # счетчик всех записанных записей за итерацию

                # Обрабатываем каждую модель
                for model, records in self._flush_buffer.items():
                    if not records:
                        continue

                    # Дедупликация
                    unique_records = self._deduplicate_records(records)
                    total_records += len(unique_records)

                    if unique_records:
                        # Запись в БД
                        inserted_strings = self._bulk_insert(model, unique_records)

                        # Постобработка
                        self._process_inserted_strings(inserted_strings)

                # Очищаем буфер записи
                self._flush_buffer.clear()

                elapsed = time.time() - start_time
                logger.debug(f"Записано {total_records} записей за {elapsed:.3f} сек")

        logger.info("Фоновый поток записи DIStringBuffer завершен")

    def force_flush(self) -> None:
        """Принудительная запись всех накопленных данных."""
        self._flush_event.set()

    def stop(self) -> None:
        """Остановка буфера с записью всех накопленных данных."""
        logger.info("Остановка DIStringBuffer...")

        # Принудительная запись перед остановкой
        self.force_flush()
        time.sleep(0.1)  # Даем время на запись

        # Останавливаем поток
        self._stop_event.set()
        self._worker_thread.join(timeout=5.0)

        # Закрываем наше соединение для записи
        if not self._write_db.is_closed():
            self._write_db.close()
            logger.debug("Соединение для записи DIStringBuffer закрыто")

        logger.info("DIStringBuffer остановлен")
