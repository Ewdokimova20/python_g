from __future__ import annotations

from math import sqrt, pi, atan2, atan, sin, asin, cos, copysign, isclose
from typing import NamedTuple

from pymatrix import Matrix

__all__ = ['Coordinates',
           'CoordinatesENU'
           ]


class Coordinates:
    """Хранилище координат с пересчетом из XYZ в BLH и обратно"""

    class XYZ(NamedTuple):
        """Координаты в XYZ, м"""
        x: float = None
        y: float = None
        z: float = None

        def distance(self, other: Coordinates.XYZ) -> float:
            """
            Функция расчёта Евклидового расстояния в Евклидовом пространстве
            d(p,q) = sqrt((p1 - q1) ** 2 + (p2 - q2) ** 2 + ... + (pn - qn) **2)

            Args:
                other (Coordinates.XYZ): объект до которого требуется вычислить расстояние.

            Raises:
                NotImplemented: Если переданный объект не является экземпляром класса Coordinates

            Returns:
                float: Евклидово расстояние между текущей точкой и переданной.

            """
            if isinstance(other, type(self)):
                x = self.x - other.x
                y = self.y - other.y
                z = self.z - other.z
                return sqrt(x * x + y * y + z * z)
            else:
                raise NotImplemented

        def __hash__(self):
            return hash((self.x, self.y, self.z))

        def __eq__(self, other):
            return isinstance(other, type(self)) and \
                isclose(self.x, other.x) and \
                isclose(self.y, other.y) and \
                isclose(self.z, other.z)

        def __str__(self):
            return f"x: {str(self.x)} y: {str(self.y)} z: {str(self.z)}"

    class BLH(NamedTuple):
        """Координаты в BLH, рад, рад, м над уровнем моря"""
        b: float = None
        l: float = None
        h: float = None

    class Vxyz(NamedTuple):
        """Вектор скорости в XYZ, м/с"""
        Vx: float = None
        Vy: float = None
        Vz: float = None

    class Axyz(NamedTuple):
        """Вектор ускорения в XYZ, м/(с*с)"""
        Ax: float = None
        Ay: float = None
        Az: float = None

    xyz: XYZ
    blh: BLH
    vel: Vxyz
    acc: Axyz

    def __init__(self, xyz: XYZ = None, blh: BLH = None, vel: Vxyz = None, acc: Axyz = None, coord: Coordinates = None):
        """Класс можно инициализировать или прямоугольным координатами, или геодезическим.
        Также можно инициализовать таким же классом (приоритетно).
        Прямоугольные или геодезические координаты досчитываются в зависимости от вида инициализации"""
        if not coord:
            if xyz and blh:
                raise ValueError("Нельзя инициализировать двумя наборами координат одновременно")
            if xyz:
                self.xyz = xyz
                self.blh = self.xyz_to_blh(self.xyz)
            if blh:
                self.blh = blh
                self.xyz = self.blh_to_xyz(blh)
            if not xyz and not blh:
                raise ValueError("Необходимо передать ровно один набор координат для инициализации")

            self.vel = vel
            self.acc = acc
        else:
            self.xyz = coord.xyz
            self.blh = coord.blh
            self.acc = coord.acc
            self.vel = coord.vel

    def xyz_to_blh(self, xyz: XYZ) -> BLH:
        X = xyz.x
        Y = xyz.y
        Z = xyz.z
        tau = 0.00001
        e2 = 0.0066943662
        a = 6378136.0
        f = 298.25784
        R = sqrt(X * X + Y * Y)
        if R < tau:
            B = pi * copysign(1, Z) / 2
            L = 0
            H = Z * copysign(1, B) - a * sqrt(1 - e2 * copysign(1, B) * copysign(1, B))
            return self.BLH(b=B, l=L, h=H)

        L = atan2(Y, X)

        k0 = (f - 1) / f
        k1 = a * (2 * f - 1) / (f * (f - 1))
        k2 = k0 * k1
        u = atan((k1 / sqrt(Z * Z + (k0 * R) * (k0 * R)) + 1) * k0 * Z / R)
        B = atan2(Z + k1 * pow(sin(u), 3), R - k2 * pow(cos(u), 3))
        H = R * cos(B) + Z * sin(B) - a * sqrt(1 - k2 * sin(B) * sin(B) / a)
        return self.BLH(b=B, l=L, h=H)

    def blh_to_xyz(self, blh: BLH) -> XYZ:
        e2 = 0.0066943662
        a = 6378136.0
        B = blh.b
        H = blh.h
        L = blh.l
        N = a / sqrt(1 - e2 * sin(B) * sin(blh.b))
        X = (N + H) * cos(B) * cos(L)
        Y = (N + H) * cos(B) * sin(L)
        Z = (N * (1 - e2) + H) * sin(B)
        return self.XYZ(x=X, y=Y, z=Z)

    def distance(self, other: Coordinates) -> float:
        return self.xyz.distance(other.xyz)

    def __hash__(self):
        return hash(self.xyz)

    def __eq__(self, other):
        return self.xyz == other.xyz

    def __str__(self):
        return f"{self.xyz.__str__()} | {self.Vxyz.__str__(self.vel)} | {self.Axyz.__str__(self.acc)}"

    def __repr__(self):
        return self.__str__()

    def elevation_grad(self, external_coordinates: Coordinates.XYZ) -> float:
        """Ф-я рассчета угла места . Возвращает значение в градусах

        :param external_coordinates: координаты внешнего объекта, м
        """

        """Вычисляем вектор сам-объект и нормируем его"""
        geometrical_distance = self.xyz.distance(external_coordinates)
        k_x = (external_coordinates.x - self.xyz.x) / geometrical_distance
        k_y = (external_coordinates.y - self.xyz.y) / geometrical_distance
        k_z = (external_coordinates.z - self.xyz.z) / geometrical_distance
        """Вычисляем длину радиус-вектора для дальнейшего нормирования"""
        r_self_length = self.xyz.distance(Coordinates.XYZ(x=0, y=0, z=0))
        """Непосредственно расчитываем угол места на основании скалярного произведения векторов"""
        return asin(((k_x * self.xyz.x)
                     + (k_y * self.xyz.y)
                     + (k_z * self.xyz.z)) / r_self_length) * 180.0 / pi

    def azimuth_grad(self, external_coordinates: Coordinates.XYZ) -> float:
        """Ф-я рассчета азимута НКА относительно БИС. Возвращает значение в градусах

        :param external_coordinates: координаты внешнего объекта, м
        """

        """Вычисляем вектор сам-объект и нормируем его"""
        geometrical_distance = self.xyz.distance(external_coordinates)
        k_x = (external_coordinates.x - self.xyz.x) / geometrical_distance
        k_y = (external_coordinates.y - self.xyz.y) / geometrical_distance
        k_z = (external_coordinates.z - self.xyz.z) / geometrical_distance
        """Используем собственные топоцентрические координаты """
        self_blh = Coordinates(self.xyz).xyz_to_blh(self.xyz)
        """Расчитываем направляющие топоцентрические косинусы (только два необходимых)"""
        kt_0 = (-1.0 * sin(self_blh.b) * sin(self_blh.l)) * k_y - (sin(self_blh.b) * cos(self_blh.l)) * k_x + (
            cos(self_blh.b)) * k_z
        kt_2 = (cos(self_blh.l)) * k_y - (sin(self_blh.l)) * k_x
        """Непосредственно расчитываем азимут на НКА"""
        return atan2(kt_2, kt_0) * 180.0 / pi


class CoordinatesENU(Coordinates):
    """Класс обеспечивает расчёт коордиант ENU относительно опорной точки
    >>> coord = Coordinates(Coordinates.XYZ(x=-171819.1746, y=3572207.7905, z=5263709.1333))
    >>> coord0 =  Coordinates(Coordinates.XYZ(x=-168353.141, y=3570872.781, z=5264442.200))
    >>> print(CoordinatesENU(coord, coord0))
    ENU(e=3399.3171074325865, n=-1650.7938501446797, u=229.23554591210143)
    """

    class ENU(NamedTuple):
        """Координаты в ENU"""
        e: float = None
        n: float = None
        u: float = None

    enu: ENU
    coord0: Coordinates

    def __init__(
            self,
            coord: Coordinates,
            coord0: Coordinates,
    ):
        super().__init__(coord=coord)
        self.coord0 = coord0
        self.enu = self.xyz_to_enu()

    def xyz_to_enu(self) -> ENU:
        X = self.xyz.x
        Y = self.xyz.y
        Z = self.xyz.z

        blh0 = self.coord0.blh
        latitude = blh0.b
        longitude = blh0.l

        # переносим координаты положения спутника из геоцентрической в систему с центром в точке установки антенны
        x_local: float = X - self.coord0.xyz.x
        y_local: float = Y - self.coord0.xyz.y
        z_local: float = Z - self.coord0.xyz.z

        # матрицы вращения из Integration of Google Maps/Earth with microscale meteorology models and data visualization
        rotation_matrix = Matrix.from_list([[-sin(longitude), cos(longitude), 0],
                                            [-sin(latitude) * cos(longitude), -sin(latitude) * sin(longitude),
                                             cos(latitude)],
                                            [cos(latitude) * cos(longitude), cos(latitude) * sin(longitude),
                                             sin(latitude)]])
        coord_local = Matrix.from_list([[x_local], [y_local], [z_local]])
        coord_topocentric = rotation_matrix * coord_local
        E = ((coord_topocentric[0])[0])
        N = ((coord_topocentric[1])[0])
        U = ((coord_topocentric[2])[0])
        return self.ENU(e=E, n=N, u=U)

    def __str__(self):
        return self.ENU.__str__(self.enu)
