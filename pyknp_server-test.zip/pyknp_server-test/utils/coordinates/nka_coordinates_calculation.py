import datetime
from math import sin, cos, isclose
from typing import Optional

from cachetools import TTLCache

from global_data import appdata
from global_data.appdata import INTEGRATION_STEP, EARTH_ROTATION_RATE, SPEED_OF_LIGHT, tolerance, max_steps
from models.bis import Bis
from models.common import next_state
from utils.coordinates.coordinates import Coordinates
from utils.coordinates.coordinates_cache import coordinate_cache_lc, coordinate_cache_lf, CoordinateCache
from utils.immediate_info.get_immediate_info_cache import get_immediate_info
from utils.lib.exceptions import LFImmediateInfoError, LCImmediateInfoError


def calculate(coordinates: Coordinates, nka_sys_number: int, t_start: datetime.datetime,
              t_final: datetime.datetime, coordinate_cache: Optional[CoordinateCache]) -> Coordinates:
    """Расчёт координат

    Args:
        coordinates (Coordinates): Модель Coordinates.
        nka_sys_number (int): НКА id системный номер.
        t_start (datetime.datetime): Время начала.
        t_final (datetime.datetime): Время окончания.
        coordinate_cache (CoordinateCache): Кэш координат.

    Returns:
        модель Coordinates.
    """

    # по мотивам https://github.com/commaai/laika/blob/master/laika/ephemeris.py

    tdiff = t_final.timestamp() - t_start.timestamp()

    state = coordinates

    if coordinate_cache:
        cached_timestamp, cached_coordinates, cached_time_tb = coordinate_cache.get(
            nka_sys_number)

        # используем кэшированные координаты для ускорения расчета, только если они было рассчитаны от текущего
        # времени tb, и только если от них рамзножаться ближе, чем от времени tb

        # Внимание! Данный метод дает разрывы,
        # как при смене tb, так и при закладке нового tb Это происходит, потому что при размножении от tb вперед на
        # 15 минут у нас кэшированные значения более точные, потому что размножаются всегда меньше, чем на 15 минут.
        # Когда мы размножаемся на -15 минут от tb, мы сначала делаем прогноз на 15 минут назад, кэшируем его,
        # а потом делаем последующее размножение от этого закэшированного значения, которое уже соедржит погрешность.
        # Поэтому чем больше рассчитываемое значение приближается к tb слева, тем большую ошибку оно имеет,
        # и в результате прогноз не сходится с реальным tb, от этого небольшой разрыв. Между tb присутсвуют бОльшие
        # разрывы в виду того, что с перезакладкой tb перезаложились и эфемериды.
        # Подробнее здесь: https://gitlab.iss-reshetnev.ru/105/knp/pyknp_server/-/merge_requests/538

        if (cached_time_tb.timestamp() == t_start.timestamp()) and (
                abs(tdiff) > abs(t_final.timestamp() - cached_timestamp.timestamp())):
            state = cached_coordinates
            tdiff = t_final.timestamp() - cached_timestamp.timestamp()

    time_step = INTEGRATION_STEP  # номинальный шаг
    time_step_current = time_step  # фактический шаг
    if tdiff < 0:
        time_step_current = -time_step  # меняем знак фактического шага если требуется
    while abs(tdiff) > 1e-9:
        if abs(tdiff) < time_step:
            # подгоняем фактический шаг под оставшееся время если требуется
            time_step_current = tdiff
        # считаем координаты, скорости на следующий шаг
        state = next_state(state, time_step_current)
        tdiff -= time_step_current  # вычитаем посчитанное время

    if coordinate_cache:
        coordinate_cache.set(
            coordinates=state, timestamp=t_final, nka_sys_number=nka_sys_number, time_tb=t_start)

    return state


def rotate(coordinates: Coordinates, tdelta: datetime.timedelta) -> Coordinates:
    """Учет вращения земли за время распростронения сигнала

    Args:
        coordinates (Coordinates): Модель Coordinates.
        tdelta (datetime.datetime): Время распространения сигнала

    Returns:
        Coordinates: модель Coordinates.
    """
    phi = tdelta.total_seconds() * EARTH_ROTATION_RATE
    x = coordinates.xyz.x * cos(phi) + coordinates.xyz.y * sin(phi)
    y = -coordinates.xyz.x * sin(phi) + coordinates.xyz.y * cos(phi)
    z = coordinates.xyz.z
    return Coordinates(xyz=Coordinates.XYZ(x=x, y=y, z=z), vel=coordinates.vel, acc=coordinates.acc)


def coordinates_from_last_DI(timestamp: datetime.datetime, nka_sys_number: int,
                             tdelta: datetime.timedelta = datetime.timedelta(seconds=0),
                             is_use_cdma: bool = False) -> Optional[Coordinates]:
    """    Функция расчета координат НКА на заданный таймштамп
    ПО ПОСЛЕДНЕЙ ПРИНЯТОЙ ЦИФРОВОЙ ИНФОРМАЦИИ

    Args:
        timestamp (datetime.datetime): Время, на которое требуется рассчитать координаты.
        nka_sys_number (int): НКА id системный номер.
        tdelta (datetime.datetime): Время распространения сигнала.
        is_use_cdma (bool): Признак используемого источника ОИ (для совместимости по умолчанию частотные).

    Raises:
        LFImmediateInfoError: если в базе данных таблицы LFImmediateInfo нет пары nka_id-signal_id.
        LCImmediateInfoError: если в базе данных таблицы LCImmediateInfo нет пары nka_id-signal_id.

    Returns:
        Optional[Coordinates]: модель Coordinates или None.
    """

    # используем общую переменную т.к. состав используемых в данной ф-ии полей совпадает
    try:
        last_efemerides = get_immediate_info(nka_sys_number, 0x16 if is_use_cdma else 0x01)
    except (LFImmediateInfoError, LCImmediateInfoError):
        return None

    #  достаем timestamp для координат из альманаха
    l1of_timestamp = last_efemerides.data_timestamp()

    if abs(l1of_timestamp.timestamp() - timestamp.timestamp()) > 16 * 60:
        raise ValueError(f"Too far in time: {str(l1of_timestamp)}, {str(timestamp)}")

    # достаем координаты, скорость и ускорение из ОИ
    coords = last_efemerides.coordinates()
    # считаем координаты НКА упрощенным расчетом (сохраняя результат в надлежащие кэши)
    if is_use_cdma:
        res = calculate(coords, nka_sys_number, l1of_timestamp, timestamp - tdelta, coordinate_cache_lc)
    else:
        res = calculate(coords, nka_sys_number, l1of_timestamp, timestamp - tdelta, coordinate_cache_lf)
    # учитываем вращение Земли (на самом деле расчитываем псевдокоординаты НКА для ненарущения ОТО)
    res = rotate(res, tdelta)
    return res


def update_coordinates(bis: Bis, nka_sys_number: int, timestamp: datetime.datetime) -> bool:
    """Обновление словаря текущих координат и углов места и азимутов НКА

    Args:
        bis (Bis): модель Bis.
        nka_sys_number (int): НКА id системный номер.
        timestamp (datetime): Время.

    Raises:
        ValueError: Если переданные аргументы имеют неверный формат или значение.
        ZeroDivisionError: Если происходит попытка деления на ноль в процессе вычислений.
        AttributeError: Если пытаемся получить доступ к атрибуту, который не существует у объекта.

    Returns:
        bool: True / False.
    """

    distance, prev_distance = (1e3, 0)
    steps = 0
    tdelta = datetime.timedelta(milliseconds=0)
    nka_coordinates = Coordinates(xyz=Coordinates.XYZ(x=0, y=0, z=0), vel=Coordinates.Vxyz(Vx=0, Vy=0, Vz=0),
                                  acc=Coordinates.Axyz(Ax=0, Ay=0, Az=0))
    elevation_angle_grad = 0
    azimuth_angle_grad = 0

    # если от сигналов с частотных разделением есть координаты, будем их обновлять
    nka_coordinates_lf = None
    # но сначала проверяем пригодность их в окрестности целевого времени
    try:
        nka_coordinates_lf = coordinates_from_last_DI(timestamp=timestamp, nka_sys_number=nka_sys_number,
                                                      tdelta=tdelta, is_use_cdma=False)
    except ValueError:
        pass

    # если от сигналов с кодовым разделением есть координаты, будем их обновлять
    nka_coordinates_lc = None
    # но сначала проверяем пригодность их в окрестности целевого времени
    try:
        nka_coordinates_lc = coordinates_from_last_DI(timestamp=timestamp, nka_sys_number=nka_sys_number,
                                                      tdelta=tdelta, is_use_cdma=True)
    except ValueError:
        pass

    # Выбираем основной сигнал, по которому будет вестись расчет
    if not nka_coordinates_lf and not nka_coordinates_lc:  # если ничего нет, то и нечего обновлять
        return False
    elif not nka_coordinates_lf:  # нет частотных --- используем в качестве основного кодовый
        source_selector = True  # признак выбора основного сигнала для расчета
        nka_coordinates = nka_coordinates_lc
    else:  # нет кодовых или оба есть --- используем как основной частотные
        source_selector = False  # признак выбора основного сигнала для расчета
        nka_coordinates = nka_coordinates_lf
    bis_coordinates = bis.coordinates
    distance = bis_coordinates.distance(nka_coordinates)

    try:
        while not (isclose(distance, prev_distance, rel_tol=tolerance) or steps > max_steps):
            # расчитываем время распространения сигнала, для, в частности, учета поворота Земли
            tdelta = datetime.timedelta(microseconds=distance * 1000000 / SPEED_OF_LIGHT)
            steps += 1
            # пересчитываем координаты для выбранного источника для уточнения времени распространения сигнала
            nka_coordinates = coordinates_from_last_DI(timestamp=timestamp, nka_sys_number=nka_sys_number,
                                                       tdelta=tdelta, is_use_cdma=source_selector)
            prev_distance = distance
            distance = bis_coordinates.distance(nka_coordinates)
            if not nka_coordinates:
                return False

        """Расчитываем угол места принимаемого сигнала на основе координат БИС и НКА для определения тропосферной
        задержки по модели и определения необходимости учета его невязки в расчете их статистики
        Также расчитываем азимут для информирования оператора о положении НКА на небесной сфере"""

    except ZeroDivisionError:
        pass

    # Формируем два набора координат для сохранения к кэш (при наличии)
    if not nka_coordinates_lc:
        nka_coordinates_lf = nka_coordinates
    elif not nka_coordinates_lf:
        nka_coordinates_lc = nka_coordinates
    else:
        nka_coordinates_lf = nka_coordinates
        # т.к. мы знаем время распространения итерационный процесс уточненния не нужен
        nka_coordinates_lc = coordinates_from_last_DI(timestamp=timestamp, nka_sys_number=nka_sys_number,
                                                      tdelta=tdelta, is_use_cdma=True)

    try:
        # удаляем "протухшие" значения в кэше
        appdata.NKA_coordinates[bis.id].expire()
    except AttributeError:
        # если не получилось, значит это не TTLCache. Создаем его
        appdata.NKA_coordinates[bis.id] = TTLCache(maxsize=64, ttl=600)
    appdata.NKA_coordinates[bis.id][nka_sys_number] = (nka_coordinates_lf, nka_coordinates_lc)
    return True


def nka_coordinates(nka_sys_number: int, coords: Coordinates,
                    time_start: datetime.datetime, time_end: datetime.datetime,
                    tdelta: datetime.timedelta = datetime.timedelta(seconds=0)) -> Coordinates:
    """Функция расчета координат НКА на заданный таймштамп относительно заданной ЦИ

    Args:
        nka_sys_number (int): НКА id системный номер.
        coords (Coordinates): Модель Coordinates координаты из ЦИ, относительно которой нужно рассчитать.
        time_start (datetime.datetime): Время таймштамп ЦИ, относительно которой нужно рассчитать.
        time_end (datetime.datetime): Время таймштамп, на который нужно рассчитать координаты.
        tdelta (datetime.datetime): Время распространения сигнала.

    Returns:
        модель Coordinates.
    """

    if abs(time_end.timestamp() - time_start.timestamp()) > 16 * 60:
        raise ValueError("Too far in time")
    # считаем координаты НКА упрощенным расчетом
    res = calculate(coords, nka_sys_number, time_start, time_end - tdelta, coordinate_cache=None)
    # учитываем вращение земли
    res = rotate(res, tdelta)
    return res
