import datetime
from typing import Dict, NamedTuple

from utils.coordinates.coordinates import Coordinates


class CoordinateCache:
    class TimedCoordinate(NamedTuple):
        coord: Coordinates
        """Координаты НКА"""
        timestamp: datetime.datetime
        """Время, на которое рассчитаны координаты НКА"""
        time_tb: datetime.datetime
        """
        Время tb, от которого рассчитаны координаты НКА. Необходимо, чтобы координаты не рассчитывались от старых tb
        """

    cache: Dict[int, TimedCoordinate]

    def __init__(self):
        zero_coordinates = Coordinates(Coordinates.XYZ(x=0, y=0, z=0))
        zero_timestamp = datetime.datetime(year=2000, day=1, month=1)
        zero_time_tb = datetime.datetime(year=2000, day=1, month=1)
        self.default_return = self.TimedCoordinate(
            coord=zero_coordinates, timestamp=zero_timestamp, time_tb=zero_time_tb)
        self.cache = {}

    def get(self, nka_sys_number: int) -> (datetime.datetime, Coordinates):
        try:
            cached = self.cache[nka_sys_number]
            return cached.timestamp, cached.coord, cached.time_tb
        except KeyError:
            return self.default_return.timestamp, self.default_return.coord, self.default_return.time_tb

    def set(self, nka_sys_number: int, timestamp: datetime.datetime, coordinates: Coordinates,
            time_tb: datetime.datetime):
        self.cache[nka_sys_number] = self.TimedCoordinate(
            coord=coordinates, timestamp=timestamp, time_tb=time_tb)


# позднейшие рассчитанные координаты для чигналов с частотным разделением
coordinate_cache_lf = CoordinateCache()
# позднейшие рассчитанные координаты для чигналов с кодовым разделением
coordinate_cache_lc = CoordinateCache()
