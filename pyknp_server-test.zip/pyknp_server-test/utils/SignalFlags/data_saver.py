import datetime
import logging
from typing import Tuple, List

from db.db_connection import db
from global_data.appdata import SignalTypes
from models.signal_flag_groups import SignalFlagGroups, SourcesSignalFlagGroups
from .processor import SignalFlagProcessor, SignalFlagGroup
from .types import AlarmId
from ..lib.types.type_aliases import NkaSysNum

logger = logging.getLogger('signal_flags')


class SignalFlagPersistence:
    """Класс для сохранения в базу данных групп сигнальных признаков и их источников."""

    def __init__(self, processor: SignalFlagProcessor):
        self.processor = processor
        # Интервал между сохранениями в БД (в секундах)
        self.flush_interval = 5

        # Время последнего сохранения в БД
        self.last_flush_to_db = datetime.datetime.min

    @staticmethod
    def update_group_in_db(group: SignalFlagGroup) -> None:
        """
        Обновляет одну группу в базе данных.
        """
        if not group.is_saved or group.db_id is None:
            logger.info(f'Попытка обновить не сохраненную группу СП')
            return

        try:
            # Обновляем запись
            (SignalFlagGroups
             .update(
                finalize_code=group.finalize_code,
                last_appear_timestamp=group.last_appear_timestamp,
                approved_timestamp=group.approved_timestamp)
             .where(SignalFlagGroups.group_id == group.db_id)
             .execute())
        except Exception as e:
            logger.info(f'Не удалось обновить группу СП с group_id = {group.db_id}, ошибка {str(e)}')

    @staticmethod
    def update_groups_in_transaction(groups: List[SignalFlagGroup]) -> None:
        """
        Обновляет несколько групп в базе данных в рамках одной транзакции.
        """
        try:
            with db.atomic():
                for group in groups:
                    SignalFlagPersistence.update_group_in_db(group)
        except Exception as e:
            logger.info(f'Не удалось обновить группу СП, ошибка {str(e)}')

    def flush_to_db(self) -> None:
        """Сохраняет все измененные группы в БД."""
        now = datetime.datetime.now()

        # Проверяем, нужно ли сохранять по времени
        if (now - self.last_flush_to_db).total_seconds() < self.flush_interval:
            return

        groups_to_save = self.processor.get_groups_to_save()
        self.last_flush_to_db = now
        if not groups_to_save:
            return
        # Сохраняем группы в БД
        self._save_groups_to_db(groups_to_save)
        self.processor.clear_groups_to_save()

    def _save_groups_to_db(self, groups_to_save: List[Tuple[NkaSysNum, AlarmId, SignalTypes, SignalFlagGroup]]) -> None:
        """
        Сохраняет группы в БД вместе с их связями с БИС.

        Args:
            groups_to_save: Множество кортежей (nka_id, alarm_id, signal_id)
        """
        # Обрабатываем каждую группу в отдельной транзакции
        for nka_id, alarm_id, signal_id, group in groups_to_save:
            try:
                with db.atomic():
                    if group.is_saved and group.db_id is not None:
                        # Обновляем существующую группу
                        try:
                            rows_updated = (SignalFlagGroups
                                            .update(alarm_value=group.alarm_value,
                                                    finalize_code=group.finalize_code,
                                                    last_appear_timestamp=group.last_appear_timestamp,
                                                    approved_timestamp=group.approved_timestamp)
                                            .where(SignalFlagGroups.group_id == group.db_id)
                                            .execute())

                            if rows_updated == 0:
                                group.is_saved = False
                                group.db_id = None
                        except Exception as e:
                            logger.info(f'Не удалось обновить группу СП, ошибка {str(e)}')
                            group.is_saved = False
                            group.db_id = None
                            raise  # Прерываем транзакцию

                    # Если группа не сохранена, создаем новую запись
                    if not group.is_saved or group.db_id is None:
                        new_group = SignalFlagGroups.create(
                            nka=nka_id,
                            alarm_id=alarm_id,
                            signal_id=signal_id,
                            alarm_value=group.alarm_value,
                            finalize_code=group.finalize_code,
                            first_appear_timestamp=group.first_appear_timestamp,
                            last_appear_timestamp=group.last_appear_timestamp,
                            approved_timestamp=group.approved_timestamp
                        )
                        group.db_id = new_group.group_id
                        group.is_saved = True

                    # Сохраняем новые источники
                    if group.db_id is not None and group.new_sources:
                        for source_id, bis_id in group.new_sources:
                            if source_id is not None and bis_id is not None:
                                try:
                                    SourcesSignalFlagGroups.create(
                                        group_id=group.db_id,
                                        source_id=source_id,
                                        bis_id=bis_id
                                    )
                                except Exception as e:
                                    logger.debug(
                                        f'Не удалось сохранить источник для группы СП (group_id={group.db_id}, '
                                        f'source_id={source_id}, bis_id={bis_id}): {str(e)}'
                                    )
                    group.new_sources.clear()
            except Exception as e:
                logger.warning(
                    f'Не удалось сохранить группу СП для НКА {nka_id}, alarm_id{alarm_id}, ошибка {str(e)}'
                )
                continue
