import datetime
import logging
from collections import defaultdict
from typing import List, Optional, Dict

from global_data.appdata import NKA_SIGNALS, ServerStatusCode, allowed_hide_intervals, SignalTypes
from .processor import SignalFlagProcessor, SignalFlagGroup
from .types import AlarmId, SourceId, SoundAlarmStatus, SignalFlagsForClient, DATE_PERMANENT_FILTER, \
    NotificationStatus, CombinationInfo, FiltersDict
from .utils import encode_combination_id, decode_combination_id, format_alarm_value, get_all_sources
from ..lib.types.type_aliases import NkaSysNum

logger = logging.getLogger('signal_flags')


class SignalFlagFilter:
    """Стуруктура описания параметров фильтрации"""

    def __init__(self):
        self.filtered_satellites: Dict[
            NkaSysNum, datetime.datetime] = {}  # ключ: идентификатор Nka, значение: время сброса фильтра
        self.filtered_combination: Dict[int, datetime.datetime] = {}  # ключ: время сброса фильтра

    def __str__(self):
        return f"filter content:\nnka:{str(self.filtered_satellites)}\ncombination:{str(self.filtered_combination)}"


class SignalFlagClientService:
    """Класс для преобразования групп СП для отображения на клиент с учетом фильтров."""
    filters = defaultdict(SignalFlagFilter)  # ключи: идентификатор клиента / МВ окончания применения
    ground_control_call_lists: list = []
    """Список оперативных сообщений: Вызов НКУ."""

    def __init__(self, processor: SignalFlagProcessor):
        self.processor = processor

    def get_actual_filters(self) -> SignalFlagFilter:
        """Получаем сосвокупное состяоние фильтров дял конкретного клиента"""

        result = SignalFlagFilter()  # Пустая структура, используемая как контейнер для сохранения результатов
        time_now = datetime.datetime.now()  # Однократно получаем текущее время для проверки устаревания фильтров
        # удаляем устаревшие записи (т.к. количество фильтров оценивается для клиента менее 25, то копирование быстро)
        client_filters = {key: val for key, val in self.filters.items() if key > time_now}
        self.filters = client_filters

        # Проходим по всем фильтрам для клиента
        for actual_border, current_filter in client_filters.items():
            # мало проверок корректности данных не бывает
            if actual_border < time_now:
                continue

            # Собираем воедино фильтры, заданные в разные времена для совокупной картины
            for nka_id in current_filter.filtered_satellites.keys():
                result.filtered_satellites[nka_id] = actual_border
            for combination_id in current_filter.filtered_combination.keys():
                # возвращаем идентификатор без БИС и типа источника, т.к. фильтрация не зависит от них
                result.filtered_combination[(combination_id // 100000) * 100000] = actual_border
        return result

    @staticmethod
    def _create_signal_flags_for_client(nka: NkaSysNum, alarm_id: AlarmId, signal_id: SignalTypes,
                                        alarm_group: SignalFlagGroup, satellite_muted: bool,
                                        filters: SignalFlagFilter) -> Optional[SignalFlagsForClient]:
        """Формирование объекта SignalFlagsForClient для отображения группы сигнальных признаков на клиенте."""

        # отключаем сигнализацию у записи при нахождении их в перечне комбинаций
        sourcless_combination_id = encode_combination_id(nka, alarm_id, signal_id, 0, SourceId.undefined)
        # если сигнализация скрыта для целого НКА, то она скрыта для всех БИС-источников
        alarm_muted = satellite_muted or sourcless_combination_id in filters.filtered_combination
        alarm_group.sound_alarm_status = SoundAlarmStatus.muted if alarm_muted else SoundAlarmStatus.unmuted

        alarm_param_value = format_alarm_value(alarm_id, signal_id, alarm_group.alarm_value)
        message_value = None
        # реализуем приоритет заполнения значения: в первую очередь заполняем значениями от КНП
        if alarm_group.bis_by_source[SourceId.KNP] is not None:
            message_value = alarm_param_value
        # для всех СП, кроме ВНКУ: если значение пустое, то используем значение от БИС
        if (alarm_id != AlarmId.ground_control_call) and (message_value is None):
            message_value = alarm_param_value

        all_sources = get_all_sources(alarm_group)

        return SignalFlagsForClient(
            nka=nka,
            signal_type=signal_id,
            message={'type': int(alarm_id), 'value': message_value},
            sources=all_sources,
            first_at=alarm_group.first_appear_timestamp,
            last_at=alarm_group.last_appear_timestamp,
            combination=sourcless_combination_id,
            event_status=int(alarm_group.event_status),
            notification_status=int(alarm_group.notification_status),
            sound_status=int(alarm_group.sound_alarm_status),
        )

    def _process_nka_signal_flag_groups(self, nka: NkaSysNum,
                                        signal_groups: Dict[AlarmId, Dict[SignalTypes, SignalFlagGroup]],
                                        satellite_muted: bool, filters: SignalFlagFilter) -> List[SignalFlagsForClient]:
        """Обработка групп сигнальных признаков для конкретного НКА"""
        result = []

        for alarm_id, alarm_val in signal_groups.items():
            for signal_id, alarm_group in alarm_val.items():

                if (len(alarm_group.raw_flags) == 0) or (alarm_group.sound_alarm_status == SoundAlarmStatus.undefined):
                    continue

                signal_flag = self._create_signal_flags_for_client(nka, alarm_id, signal_id, alarm_group,
                                                                   satellite_muted, filters)

                if signal_flag:
                    result.append(signal_flag)
                    if alarm_id == AlarmId.ground_control_call:
                        if signal_flag.get('message', {}).get('value', 0) == '10000':
                            signal_flag['message']['value'] = None
                        self.ground_control_call_lists.append(signal_flag)

        return result

    def as_dict_for_client(self) -> List[SignalFlagsForClient]:
        """Формируем сигнальные признаки для конкретного клиента с целью отображения"""
        actual_filters = self.get_actual_filters()
        result = []
        self.ground_control_call_lists = []

        signal_flag_groups = self.processor.get_signal_flag_groups()
        for nka, signal_groups_one_nka in signal_flag_groups.items():
            if nka not in NKA_SIGNALS.keys():
                continue

            satellite_muted = nka in actual_filters.filtered_satellites
            result.extend(self._process_nka_signal_flag_groups(nka, signal_groups_one_nka, satellite_muted,
                                                               actual_filters))
        return result

    def set_filter(self, filtered_nka: List[NkaSysNum], filtered_combinations: List[int],
                   cooldown_seconds: Optional[int] = None) -> ServerStatusCode:
        """Задаем фильтры с контролем времени скрытия данных"""

        # проверить, что значение cooldown_seconds в ОДЗ
        if cooldown_seconds and cooldown_seconds not in allowed_hide_intervals:
            return ServerStatusCode.BAD_DATA

        # Расссчитываем время, когда фильтр должен прекращаться использоваться
        # Если это фильтр без времени, то устанавливаем его время далеко вперед
        if cooldown_seconds:
            filter_actual_time = datetime.datetime.now() + datetime.timedelta(seconds=cooldown_seconds)
            # Пакуем фильтры в структуру и сохраняем в хранилище с ключом времени актуальности
            filter_parameters = SignalFlagFilter()
            filter_parameters.filtered_satellites = {key: 0 for key in filtered_nka if key}
            filter_parameters.filtered_combination = {key: 0 for key in filtered_combinations if key}
            self.filters[filter_actual_time] = filter_parameters

        else:
            if DATE_PERMANENT_FILTER not in self.filters:
                self.filters[DATE_PERMANENT_FILTER] = SignalFlagFilter()
            filter_permanent = self.filters[DATE_PERMANENT_FILTER]
            for key in filtered_nka:
                if key:
                    filter_permanent.filtered_satellites[key] = 0
            for key in filtered_combinations:
                if key:
                    filter_permanent.filtered_combination[key] = 0
        return ServerStatusCode.OK

    def filters_as_dict(self) -> FiltersDict:
        """Представляем информацию о фильтрах клиента"""

        actual_filters = self.get_actual_filters()

        # Пакуем информацию о комбинациях
        combination_list = {}
        for combination_id, actual_time in actual_filters.filtered_combination.items():
            nka_id, alarm_id, signal_id, bis_id, source_id = decode_combination_id(combination_id)
            combination_list[combination_id] = CombinationInfo(nka=nka_id,
                                                               alarm=alarm_id,
                                                               signal=signal_id,
                                                               bis=bis_id,
                                                               source=source_id,
                                                               present=actual_time)

        # Формируем структуру верхнего уровня описания
        result = FiltersDict(
            nka={nka_id: actual_time for nka_id, actual_time in actual_filters.filtered_satellites.items()},
            combination=combination_list,
            allowed_durations=[single_interval for single_interval in allowed_hide_intervals])
        return result

    def kill_permanent_filter(self, not_filtered_nka: List[NkaSysNum],
                              not_filtered_combinations: List[int]) -> ServerStatusCode:
        """Удаление постоянных фильтров из списка"""
        filter_permanent = self.filters[DATE_PERMANENT_FILTER]
        key = None
        try:
            for key in not_filtered_nka:
                if key:
                    del filter_permanent.filtered_satellites[key]

                    # Ищем в словаре фильтруемых комбинаций те, что относятся к данному НКА
                    combinations_to_delete = []
                    for combination in filter_permanent.filtered_combination.keys():
                        if int(combination // 1e9) == int(key):
                            combinations_to_delete.append(combination)

                    #  И тоже их вычищаем
                    for combination in combinations_to_delete:
                        del filter_permanent.filtered_combination[combination]
            for key in not_filtered_combinations:
                if key:
                    del filter_permanent.filtered_combination[key]
        except KeyError:
            logger.info(f'Не удалось удалить сигнализацию для комбинации {key}')
            pass

        return ServerStatusCode.OK

    def get_status(self) -> str:
        """Признак наличия новых СП """
        signal_flag_groups = self.processor.get_signal_flag_groups()
        for nka_id, nka_signal_groups in signal_flag_groups.items():
            for alarm_id, alarm_val in nka_signal_groups.items():
                for signal_flag_group in alarm_val.values():
                    if signal_flag_group.notification_status == NotificationStatus.new:
                        return 'Present'
        return 'Absent'
