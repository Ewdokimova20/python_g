import datetime
from collections import defaultdict
from typing import Optional, Set, Tuple

from .types import EventStatus, NotificationStatus, SoundAlarmStatus, AlarmId, SourceId, RawSignalFlag, FinalizeCode


class SignalFlagGroup:
    """Описание группы сигнальных признаков, имеющих общие параметры индикации"""

    def __init__(self):
        # Словарь для хранения сырых сигнальных признаков
        # Структура: source_id -> bis_id -> RawSignalFlag
        self.raw_flags = defaultdict(lambda: defaultdict(RawSignalFlag))

        # Для каждого source_id храним множество bis_id
        self.bis_by_source = {
            SourceId.BIS: set(),  # Множество БИС для source_id = 1
            SourceId.KNP: set(),  # Множество БИС для source_id = 2
            SourceId.KNPSum: set()  # Множество БИС для source_id = 3
        }

        # Общие атрибуты группы
        self.event_status = EventStatus.active
        self.notification_status = NotificationStatus.new
        self.sound_alarm_status = SoundAlarmStatus.unmuted

        # Временные метки для группы
        self.first_appear_timestamp: Optional[datetime] = None
        self.last_appear_timestamp: Optional[datetime] = None
        self.approved_timestamp: Optional[datetime] = None

        # Дополнительные атрибуты для сохранения в БД
        self.alarm_value: Optional[int, str] = None
        self.finalize_code = FinalizeCode.in_progress
        self.new_sources: Set[Tuple[SourceId, int]] = set()

        # Флаг, указывающий, была ли группа сохранена в БД
        self.is_saved: bool = False
        # ID группы в БД (если группа была сохранена)
        self.db_id: Optional[int] = None

    def add_raw_flag_to_group(self, source_id: SourceId, bis_id: int, raw_flag: RawSignalFlag):
        """
        Добавляет сырой сигнальный признак в группу

        Args:
            source_id: Идентификатор источника
            bis_id: Идентификатор БИС
            raw_flag: Сырой сигнальный признак
        """
        # Проверяем, является ли этот источник новым
        is_new_source = bis_id not in self.bis_by_source[source_id]

        # Сохраняем сырой сигнальный признак
        self.raw_flags[source_id][bis_id] = raw_flag

        # Если это новый источник, добавляем его в множество новых источников
        if is_new_source:
            self.new_sources.add((source_id, bis_id))

        # Добавляем БИС в множество для указанного источника
        self.bis_by_source[source_id].add(bis_id)

        # Обновляем временные метки группы
        self._update_timestamps(raw_flag['last_appear_timestamp'])

        # Обновляем дополнительные атрибуты # пришлось добавить проверку, потому что от КНП и БИС шло разное значение ВНКУ
        if raw_flag['alarm_id'] == AlarmId.ground_control_call \
                and source_id == SourceId.BIS and self.alarm_value is not None:
            pass  # fixme не учитываем значение ВНКУ от БИС, если оно уже было записано другим источником
        else:
            self.alarm_value = raw_flag['alarm_value']

    def _update_timestamps(self, timestamp: datetime.datetime):
        """
        Обновляет временные метки группы

        Args:
            timestamp: Новая временная метка
        """
        if self.first_appear_timestamp is None:
            self.first_appear_timestamp = timestamp

        if self.last_appear_timestamp is None:
            self.last_appear_timestamp = timestamp
        else:
            self.last_appear_timestamp = max(self.last_appear_timestamp, timestamp)
