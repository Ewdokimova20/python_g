import threading
from collections import defaultdict
from typing import Union, DefaultDict, Tuple, List

from global_data.appdata import SignalTypes
from models.op_message import OpMessage, KNPOpMessage, KNPOpSumMessage
from .signal_flag_group import SignalFlagGroup
from .types import EventStatus, AlarmId, SourceId, RawSignalFlagsStorage, FinalizeCode
from .utils import extract_message, add_signal_flag
from ..lib.types.type_aliases import NkaSysNum


class SignalFlagProcessor:
    """
    Класс для обработки сигнальных признаков из агрегатора.
    Отвечает за группировку признаков и подготовку их к сохранению в БД.
    """

    def __init__(self):
        # Структура: (nka_id, alarm_id, signal_id) -> source_id -> {bis_id:RawSignalFlag}
        self._all_raw_flags: RawSignalFlagsStorage = defaultdict(lambda: defaultdict(dict))

        # Структура для хранения групп сигнальных признаков
        # nka_id -> alarm_id -> signal_id -> SignalFlagGroup
        self._signal_flag_groups: DefaultDict[
            NkaSysNum, DefaultDict[AlarmId, DefaultDict[SignalTypes, SignalFlagGroup]]] \
            = defaultdict(lambda: defaultdict(lambda: defaultdict(SignalFlagGroup)))

        # Множество групп, которые нужно сохранить в БД
        # Каждый элемент - кортеж (nka_id, alarm_id, signal_id, group)
        self._groups_to_save: List[Tuple[NkaSysNum, AlarmId, SignalTypes, SignalFlagGroup]] = []

        # Добавляем блокировку для синхронизации доступа к общим ресурсам
        self._lock = threading.Lock()

    def add_local_message(self, stored_message: Union[OpMessage, KNPOpMessage, KNPOpSumMessage]) -> None:
        """Функция для добавления сигнальных флагов напрямую в процессор из основного (обобщающего) процесса."""

        flags = extract_message(stored_message)
        for flag_params in flags:
            add_signal_flag(raw_flags=self._all_raw_flags, **flag_params)

    def prepare_all_flags(self, flags_data: RawSignalFlagsStorage) -> None:
        """Объединение флагов, полученных от дочерних процессов для последуюющей обработки в процессоре.
           Это для обработчика zmq сообщения будут приходить из разных процессов в формате, как в агрегаторе"""
        with self._lock:
            for composite_key, source_flags in flags_data.items():
                for source_id, bis_flags in source_flags.items():
                    self._all_raw_flags[composite_key][source_id].update(bis_flags)

    def process_all_raw_flags_to_signal_flag_groups(self) -> None:
        """
        Обрабатывает сигнальные признаки из собственного хранилища и группирует их.
        """
        # Защищаем доступ к _all_raw_flags блокировкой во время итерации и очистки
        # Также защищаем доступ к _signal_flag_groups и _groups_to_save, так как они изменяются в этом методе
        with self._lock:
            for signal_key, signal_flags in self._all_raw_flags.items():
                if signal_flags:
                    # Получаем компоненты ключа
                    nka_id, alarm_id, signal_id = signal_key
                    # Получаем или создаем группу для данной комбинации nka_id, alarm_id, signal_id
                    current_signal_group = self._signal_flag_groups[nka_id][alarm_id][signal_id]

                    # ситуация повторяется, обновляем дескриптор, но пользователя не информируем дополнительно
                    # у новой ситуации будет признак нефинализированности
                    if current_signal_group.finalize_code != FinalizeCode.in_progress:
                        # сохранять содержимое старого дескриптора в ТЛБД нет необходимости т.к. это было сделано при финализации
                        # создаем новый дескриптор для заполнения с чистого листа
                        current_signal_group = SignalFlagGroup()
                        self._signal_flag_groups[nka_id][alarm_id][signal_id] = current_signal_group

                    current_signal_group.event_status = EventStatus.active

                    # Перебираем все СП от всех возможных источников Source
                    for source_id, bis_flags in signal_flags.items():
                        for bis_id, current_signal_flag in bis_flags.items():
                            is_ground_control_value_has_changed = current_signal_flag[
                                                                      'alarm_value'] != current_signal_group.alarm_value \
                                if current_signal_group.alarm_value is not None else False
                            # особая обработка ВНКУ по потребностям эксплуатанта (новое значение ВНКУ --- новое событие, о котором надо уведомлять)
                            if (alarm_id == AlarmId.ground_control_call and source_id == SourceId.KNP) \
                                    and is_ground_control_value_has_changed:
                                # нужно финализировать группу со старым значением ВНКУ и сохранить изменения в базу и открыть новую группу
                                current_signal_group.finalize_code = FinalizeCode.value_changed
                                # Добавляем текущую группу в список для сохранения
                                self._groups_to_save.append((nka_id, alarm_id, signal_id, current_signal_group))
                                current_signal_group = SignalFlagGroup()  # конкретный СП будет пересоздан
                                self._signal_flag_groups[nka_id][alarm_id][signal_id] = current_signal_group

                            # Добавляем сырой сигнальный признак в группу
                            current_signal_group.add_raw_flag_to_group(source_id, bis_id, current_signal_flag)

                    # Добавляем текущую группу в список для сохранения
                    self._groups_to_save.append((nka_id, alarm_id, signal_id, current_signal_group))

            # Очищаем словарь после обработки всех флагов, находясь под блокировкой
            self._all_raw_flags.clear()

    def get_signal_flag_groups(self):
        return self._signal_flag_groups

    def get_groups_to_save(self):
        """Получить список групп для сохранения в БД"""
        return self._groups_to_save

    def clear_groups_to_save(self):
        """Очистить список групп для сохранения в БД"""
        self._groups_to_save.clear()

    def clear_flag_groups(self) -> None:
        """Очистить накопленные группы СП"""
        self._signal_flag_groups.clear()
