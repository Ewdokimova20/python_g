import datetime
from typing import List

from global_data.config_schema import config
from .client_service import decode_combination_id, logger
from .data_saver import SignalFlagPersistence
from .processor import SignalFlagProcessor
from .types import EventStatus, SourceId, NotificationStatus, FinalizeCode
from ..lib.types.type_aliases import NkaSysNum


class SignalFlagFinalizer:
    """Класс для финализации и подтверждения групп СП (автоматическое и ручное подтверждение)."""
    def __init__(self, processor: SignalFlagProcessor, data_saver: SignalFlagPersistence):
        self.processor = processor
        self.data_saver = data_saver

    def finalize_timeout(self) -> None:
        """Функция для финализирования группы сигнальных признаков, в которой не появлялись свежие СП в течение заданного времени.
            Проверяем время у каждого СП в SignalFlagGroup,
            если в SignalFlagGroup нет ни одного свежего СП(RawSignalFlag), то финализизируем всю группу СП.
        """
        timeout_threshold = datetime.timedelta(seconds=config['opmessage']['auto_finalize_timeout'])
        time_now = datetime.datetime.now()
        signal_flag_groups = self.processor.get_signal_flag_groups()
        for nka_id, alarms in signal_flag_groups.items():
            for alarm_id, alarm_val in alarms.items():
                for signal_id, current_signal_group in alarm_val.items():
                    should_finalize = False
                    if current_signal_group.event_status == EventStatus.finalized:
                        continue
                    for source_id, signal_flags in current_signal_group.raw_flags.items():
                        if not signal_flags:
                            continue
                        should_finalize = True  # если СП не приходило ни с одного источника в течение заданного времени, то finalized
                        for bis_id, raw_flag in signal_flags.items():
                            if raw_flag['last_appear_timestamp'] is not None \
                                    and (abs(time_now - raw_flag['last_appear_timestamp']) < timeout_threshold):
                                should_finalize = False
                                break  # Выходим из цикла, если нашли свежий СП в SignalFlagGroup
                        if not should_finalize:
                            break
                    if should_finalize:  # Финализируем группу и меняем её статус, это изменение нужно сохранить в базу
                        current_signal_group.event_status = EventStatus.finalized
                        current_signal_group.finalize_code = FinalizeCode.timeout
                        self.data_saver.update_group_in_db(current_signal_group)

    def change_notification_status(self, nka_id: NkaSysNum) -> None:
        """Функция для изменения статуса подтверждения СП (красная цветовая рамка вокруг СП)
            При выходе НКА из зоны видимости через заданное время изменяем статус на approved.
        """
        signal_flag_groups = self.processor.get_signal_flag_groups()
        timeout_threshold = datetime.timedelta(seconds=config['opmessage']['auto_approve_timeout'])
        time_now = datetime.datetime.now()
        for alarm_id, alarm_val in signal_flag_groups.get(nka_id, {}).items():  # SignalFlagStorage
            for signal_id, current_signal_group in alarm_val.items():  # SignalFlagGroup
                if not current_signal_group:
                    continue
                if current_signal_group.event_status == EventStatus.active:
                    continue
                should_change_status = False
                if current_signal_group.bis_by_source[SourceId.KNP] is not None \
                        or current_signal_group.bis_by_source[
                    SourceId.KNPSum] is not None:  # для источника КНП проверяем время
                    for source_id, source_signal_flags in current_signal_group.raw_flags.items():
                        should_change_status = True
                        if source_signal_flags:
                            # Проверяем, превышен ли таймаут для всех сигнальных признаков
                            should_change_status = all(
                                abs(time_now - signal_descriptor['last_appear_timestamp']) > timeout_threshold
                                for signal_descriptor in source_signal_flags.values()
                            )
                            if not should_change_status:
                                break
                else:  # если источник только БИС сразу изменяем на approved
                    should_change_status = True
                if should_change_status:
                    current_signal_group.notification_status = NotificationStatus.approved
                    self.data_saver.update_group_in_db(current_signal_group)

    def delete_client_representation(self, deleted_combinations: List[int]) -> None:
        """Ф-я подтверждения ознакомлениф клиента с конкретными группами сигнальных признаков с удалением из аккумулятора"""

        # если оператор не указал конкретные просмотренные комбинации, то считаем что ознакомление было со всеми
        finalize_code = FinalizeCode.user_deleted
        signal_flag_groups = self.processor.get_signal_flag_groups()
        if len(deleted_combinations) == 0:
            groups_to_update = []
            for nka_id, nka_groups_val in signal_flag_groups.items():
                for alarm_id, alarm_val in nka_groups_val.items():
                    for current_signal_group in alarm_val.values():
                        # проверяем ситуацию двойной финализации (за исключением удаления ситуации)
                        # если ситуация уже была финализирована, то первопричина более релевантна
                        # также данный подход позволяет избегать избыточных обращений к ТЛБД
                        # Пример: попытка финализации ситуации ВНКУ по причине выхода из ЗРВ, хотя она была финализирована по причине зануления ВНКУ
                        if current_signal_group.finalize_code != FinalizeCode.in_progress:
                            pass
                        current_signal_group.finalize_code = finalize_code
                        current_signal_group.event_status = EventStatus.finalized
                        groups_to_update.append(current_signal_group)
            self.data_saver.update_groups_in_transaction(groups_to_update)
            self.processor.clear_flag_groups()

        for combination_id in deleted_combinations:
            nka_id, alarm_id, signal_id, bis_id, _ = decode_combination_id(combination_id)
            # проверяем, что обощенное событие, соответствующее финализируемой записи существует (иначе игнорируем некорректный запрос)
            if signal_id not in signal_flag_groups.get(nka_id, {}).get(alarm_id, {}):
                raise KeyError('Попыка удалить несуществующую комбинацию')

            current_signal_group = signal_flag_groups[nka_id][alarm_id][signal_id]
            # удалем всю информацию о ситуации по запросу пользователя. При повторе она станет новой
            current_signal_group.finalize_code = finalize_code
            current_signal_group.event_status = EventStatus.finalized
            self.data_saver.update_group_in_db(current_signal_group)
            signal_flag_groups = self.processor.get_signal_flag_groups()
            signal_flag_groups[nka_id][alarm_id].pop(signal_id)

    def approve_client_representation(self, approved_combinations: List[int]) -> None:
        """Ф-я подтверждения ознакомления клиента с конкретными сигнальными признаками"""

        # если оператор не указал конкретные просмотренные комбинации, то считаем что ознакомление было со всеми
        current_time = datetime.datetime.now()
        if len(approved_combinations) == 0:
            groups_to_update = []
            signal_flag_groups = self.processor.get_signal_flag_groups()
            for nka_id, nka_signal_groups in signal_flag_groups.items():
                for alarm_id, alarm_val in nka_signal_groups.items():
                    for signal_flag_group in alarm_val.values():
                        # если ситуация финализирована, то перестаем её обновлять.
                        # Единственное развитие --- её удаление, но тогда запись будет выполнена в рамках finalize
                        if signal_flag_group.finalize_code == FinalizeCode.in_progress:
                            signal_flag_group.notification_status = NotificationStatus.approved
                            signal_flag_group.approved_timestamp = current_time
                            # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
                            # записываем в базу время первого отключения
                            groups_to_update.append(signal_flag_group)
            self.data_saver.update_groups_in_transaction(groups_to_update)

        for combination_id in approved_combinations:
            nka_id, alarm_id, signal_id, _, _ = decode_combination_id(combination_id)
            signal_flag_groups = self.processor.get_signal_flag_groups()
            try:
                signal_flag_group = signal_flag_groups[nka_id][alarm_id][signal_id]
            except KeyError:
                logger.info(f'Попытка отключить сигнализацию для несуществующей ситуации {combination_id}')
                raise KeyError('При подтверждении событий возникли ошибки. Подробности указаны в журналах логов')
            signal_flag_group.notification_status = NotificationStatus.approved
            signal_flag_group.approved_timestamp = current_time
            # обновляем состояние в ТЛБД т.к. запись создается при добавлении в аккумулятор
            # записываем в базу время первого отключения
            self.data_saver.update_group_in_db(signal_flag_group)
