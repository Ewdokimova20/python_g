import datetime
import logging
from typing import List, Union

from models.op_message import KNPOpMessage, KNPOpSumMessage, OpMessage
from .client_service import SignalFlagClientService
from .data_saver import SignalFlagPersistence
from .finalizer import SignalFlagFinalizer
from .processor import SignalFlagProcessor
from .types import SignalFlagsForClient, RawSignalFlagsStorage, SIGNAL_FLAGS_DEFINE_STEP
from ..lib.types.type_aliases import NkaSysNum

logger = logging.getLogger('signal_flags')


class SignalFlagService:
    """Класс фасад для работы со всеми возможными операциями,
       выполняемыми над оперативными сообщениями(сигнальными признаками)."""

    def __init__(self):
        self.processor = SignalFlagProcessor()
        self.data_saver = SignalFlagPersistence(self.processor)
        self.finalizer = SignalFlagFinalizer(self.processor, self.data_saver)
        self.client_service = SignalFlagClientService(self.processor)
        self.latest_update_signal_flag = datetime.datetime.now()

    def add_operative_message(self, stored_message: Union[OpMessage, KNPOpMessage, KNPOpSumMessage]) -> None:
        return self.processor.add_local_message(stored_message)

    def process_signal_flags(self, time_now) -> None:
        """Обработка сигнальных признаков из агрегатора и обобщение их по группам."""
        if (time_now - self.latest_update_signal_flag).total_seconds() > SIGNAL_FLAGS_DEFINE_STEP:
            self.latest_update_signal_flag = time_now
            self.finalizer.finalize_timeout()
            self.processor.process_all_raw_flags_to_signal_flag_groups()
            self.data_saver.flush_to_db()  # сохранение групп СП в базу вместе с источниками этих групп СП

    def change_notification_status(self, nka_id: NkaSysNum) -> None:
        """Функция для изменения статуса подтверждения группы сигнальных признаков (красная цветовая рамка вокруг СП)."""
        self.finalizer.change_notification_status(nka_id)

    def as_dict_for_client(self) -> List[SignalFlagsForClient]:
        """Функция для отображения групп СП на клиенте."""
        return self.client_service.as_dict_for_client()

    def ground_control_call_lists(self) -> List[SignalFlagsForClient]:
        """Функция для отображения групп СП на клиенте."""
        return self.client_service.ground_control_call_lists

    def delete_combinations(self, deleted_combinations: List[int]) -> None:
        """Функция для удаления групп сигнальных признаков клиентом."""
        return self.finalizer.delete_client_representation(deleted_combinations)

    def approve_combinations(self, approved_combinations: List[int]) -> None:
        """Функция для подтверждения ознакомления с сигнальным признаком (жирный шрифт у СП)."""
        return self.finalizer.approve_client_representation(approved_combinations)

    def get_status(self) -> str:
        """Признак наличия новых СП."""
        return self.client_service.get_status()

    def flush_to_db(self) -> None:
        """Сохранение групп СП в базу."""
        return self.data_saver.flush_to_db()

    def load_data(self, data: RawSignalFlagsStorage) -> None:
        """Загружает состояние счетчиков, пришедшие с сокета"""
        self.processor.prepare_all_flags(data)


signal_flag_service = SignalFlagService()
