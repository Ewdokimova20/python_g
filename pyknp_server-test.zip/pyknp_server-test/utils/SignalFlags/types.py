import datetime
from enum import IntEnum
from typing import Dict, Optional, List, DefaultDict, NamedTuple

from typing_extensions import TypedDict

from global_data.appdata import SignalTypes
from utils.lib.types.type_aliases import BisId, NkaSysNum

UNDEFINED_BIS_ID = 9999
UNDEFINED_BIS = 99
DATE_PERMANENT_FILTER = datetime.datetime(year=2100, month=1, day=1)

SIGNAL_FLAGS_DEFINE_STEP = 10
"""Период обработки сигнальных признаков, с"""


class SourceId(IntEnum):
    """Кем сформировано СП"""
    undefined = 0,  # сигнальный признак был выявлен сетью БИС
    BIS = 1,  # сигнальный признак был выявлен сетью БИС
    KNP = 2,  # сигнальный признак был выявлен СПО КНП
    KNPSum = 3  # сигнальный признак был выявлен СПО КНП по обобщенной ЦИ


class AlarmId(IntEnum):  # недопустимо использование идентификаторов меньших или равных нулю
    """Числовой представления выявленного СП"""
    ground_control_call = 1,  # Выявлен сигнал Вызов НКУ
    unreliable_frame = 2,  # Недостоверность навигационного кадра
    unreliable_signal = 3,  # Негодность НС
    unreliable_digital_info = 4,  # Негодность ЦИ
    absent_signal = 5,  # Отсутствет сигнал НКА, ожидаемый в ЗРВ и излучаемый согласно ЦБД
    tk_inconsistency = 6,  # Несоответствие значений оцифровки метки времени в принятой ЦИ текущему времени
    tb_inconsistency = 7,  # Несоответствие значения tb значению tk
    EI_inconsistency = 8,  # Несоответствие параметров ЭИ в обобщенной ЦИ с заложенными СИ
    clock_inconsistency = 9,  # Несоответствие параметров ЧВП в обобщенной ЦИ с заложенными СИ
    almanac_inconsistency = 10,  # Несоответствие параметров альманаха в обобщенной ЦИ с заложенными СИ
    generalized_DI = 11,  # Результат обобщения признаков 6-10 нужно для интерфейса
    generalized_signals_validity = 12,  # годность навигационных сигналов в таблице обобщенных признаков нужно для интерфейса
    generalized_receive_status = 13,  # статусы приёма сигналов НКА в таблице обобщенных признаков нужно для интерфейса


class FinalizeCode(IntEnum):
    """Код причины завершения конкретного СП. Используется для отражения причины завершения ситуации."""
    in_progress = 0,  # ситуация не завершена и должна быть загружена из ТЛБД при запуске
    value_changed = 1,  # значение СП изменилось (на штатное или иное нештатное)
    became_emitted = 2,  # отсутствусющий сигнал стал излучаться (описывает ОГ глобально, не для единичного БИС) #fixme не использовалось
    out_of_sight = 3,  # НКА вышел из ЗРВ соответствующего ПЭ (на основании прогноза по альманаху)  # fixme возможно стоит вернуть, но там конфликт с завершением по времени был
    timeout = 4  # СП не приходил в течение заданного времени
    user_deleted = 9,  # ситуация завершена пользователем и удалена из аккумулятора (только для БД, в хранилище СПО КНП не встречается)


class EventStatus(IntEnum):
    """Статус актуальности ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
    finalized = 0,  # ЕМВ: подразумевает отсутствие событий по всем источникам/бис входящим в данное обобщенное событие.
    active = 1,  # ЕМВ: подразумевает наличие событий хотя бы по одному источнику/бис, входящими в данное обобщенное событие.


class NotificationStatus(IntEnum):
    """Статус подтверждения ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
    approved = 0,  # Сообщение не выделено жирным шрифтом
    new = 1,  # Сообщение выделено жирным шрифтом


class SoundAlarmStatus(IntEnum):
    """Заглушена или нет звуковая сигнализация события"""
    undefined = 0,  # неопределенное значение, соответствующее незаполненному состоянию
    unmuted = 1,  # звуковая сигнализация включена для события
    muted = 2,  # звуковая сигнализация отключена для события


class RawSignalFlag(TypedDict):
    """Описание одного сигнального признака."""
    alarm_id: AlarmId
    alarm_value: int
    first_appear_timestamp: datetime.datetime
    last_appear_timestamp: datetime.datetime


class SignalKey(NamedTuple):
    nka_id: NkaSysNum
    alarm_id: AlarmId
    signal_id: SignalTypes


# Структура: (nka_id, alarm_id, signal_id) -> source_id ->  (bis_id:RawSignalFlag)
RawSignalFlagsStorage = Dict[SignalKey, DefaultDict[SourceId, Dict[BisId, RawSignalFlag]]]


class SignalFlagsForClient(TypedDict):
    """
    Typed dict для представления одной группы сигнальных признаков для отображения на клиент
    """
    nka: int
    """Системный номер НКА, для которого выявлен СП"""
    signal_type: int
    """Сигнал, для которого выявлен СП. ОДЗ: appdata.SIGNAL_TYPES"""
    message: Dict[str, Optional[int]]
    """Информация, которую передает СП"""
    sources: List[dict]
    """Словарь для хранения всех бисов, с которых приходило СП, для каждого Source_id"""
    first_at: datetime.datetime
    """Момент первого выявления данной комбинации"""
    last_at: datetime.datetime
    """Момент позднейшего выявления сигнального признака данной комбинации"""
    combination: int
    """Идентификатор комбинации СП. Формируется ф-ей encode_combination_id"""
    event_status: int
    """Статус актуальности ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
    notification_status: int
    """Статус подтверждения ситуации (обобщенного СП), выдаваемый на клиент для отображения"""
    sound_status: int
    """Заглушена или нет звуковая сигнализация события"""


class SourcesForClient(TypedDict):
    """Для отображения источников signal_flag_group на клиенте."""
    bis: BisId
    station: int
    source: int


class CombinationInfo(TypedDict):
    nka: NkaSysNum
    alarm: AlarmId
    signal: SignalTypes
    bis: BisId
    source: int
    present: datetime.datetime


class FiltersDict(TypedDict):
    nka: Dict[NkaSysNum, datetime.datetime]
    combination: Dict[int, CombinationInfo]
    allowed_durations: List[int]
