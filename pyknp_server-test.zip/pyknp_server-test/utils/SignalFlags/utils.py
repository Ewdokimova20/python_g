from datetime import datetime
from typing import Union, List, TYPE_CHECKING

from global_data.appdata import SignalTypes, FREQ_SIGNAL_TYPES, CODE_SIGNAL_TYPES
from models.op_message import OpMessage, KNPOpMessage, KNPOpSumMessage
from .types import AlarmId, SourceId, SignalKey, RawSignalFlagsStorage, RawSignalFlag, UNDEFINED_BIS_ID, UNDEFINED_BIS, \
    SourcesForClient
from ..caches import cache_bis
from ..lib.types.type_aliases import NkaSysNum, BisId
from ..signals import FD, CD
from ..signals.common import format_ground_call_control_raw_value

if TYPE_CHECKING:
    from .signal_flag_group import SignalFlagGroup

def encode_combination_id(nka_id: NkaSysNum, alarm_id: AlarmId, signal_id: SignalTypes, bis_id: BisId, source_id: SourceId) -> int:
    """Ф-я взаимододнозначного пересета вектора идентификаторов в идентификатор комбинации

    Ограничения:
    Число НКА --- не регулируется, может быть любым
    Идентификаторы сигнальным признаков --- не более 19 штук (сейчас двукратный запас)
    Идентификаторы сигналов --- не более 1000 (сейчас четырехкратный запас)
    Идентификаторы БИС --- не более 10 000 штук (более чем десятикратный запас)
    Идентификатор источника --- не более 9 (сейчас восьмикратный запас)
    """
    return (((nka_id * 100 + alarm_id) * 1000 + signal_id) * 10000 + bis_id) * 10 + source_id


def decode_combination_id(combination_id: int) -> list:
    """Преобразование идентификатора комбинации в перечень идентификаторов составляющих

    См. описание encode_combination_id в части ограничений"""
    source_id = combination_id % 10
    combination_id //= 10
    bis_id = combination_id % 10000
    combination_id //= 10000
    signal_id = combination_id % 1000
    combination_id //= 1000
    alarm_id = combination_id % 100
    return [combination_id // 100, alarm_id, signal_id, bis_id, source_id]


def extract_message(stored_message: Union[OpMessage, KNPOpMessage, KNPOpSumMessage]) -> list:
    """ Обработка оперативного сообщения и извлечение сигнальных признаков"""

    """Определяем источник на основе типа данных"""
    source_id = SourceId.BIS
    if isinstance(stored_message, KNPOpMessage):
        source_id = SourceId.KNP
    elif isinstance(stored_message, KNPOpSumMessage):
        source_id = SourceId.KNPSum

    """Выделям набор сигнальных признаков для сохранения каждого"""
    message_signal_flags = {}
    if source_id == SourceId.BIS or source_id == SourceId.KNP:
        if stored_message.ground_control_call:
            message_signal_flags[AlarmId.ground_control_call] = stored_message.ground_control_call
        if stored_message.unreliable_frame:
            message_signal_flags[AlarmId.unreliable_frame] = stored_message.unreliable_frame
        if stored_message.unreliable_signal:
            message_signal_flags[AlarmId.unreliable_signal] = stored_message.unreliable_signal
        if stored_message.unreliable_digital_info:
            message_signal_flags[AlarmId.unreliable_digital_info] = stored_message.unreliable_digital_info
        if stored_message.not_in_sight:
            message_signal_flags[AlarmId.absent_signal] = 1
        if stored_message.tk_inconsistency:
            message_signal_flags[AlarmId.tk_inconsistency] = stored_message.tk_inconsistency
        if stored_message.tb_inconsistency:
            message_signal_flags[AlarmId.tb_inconsistency] = stored_message.tb_inconsistency
    elif source_id == SourceId.KNPSum:
        if stored_message.EI_inconsistency:
            message_signal_flags[AlarmId.EI_inconsistency] = stored_message.tk
        if stored_message.clock_inconsistency:
            message_signal_flags[AlarmId.clock_inconsistency] = stored_message.tk
        if stored_message.almanac_inconsistency:
            message_signal_flags[AlarmId.almanac_inconsistency] = stored_message.tk

    # Добавляем каждый сигнальный признак
    result = []
    for alarm_id, alarm_value in message_signal_flags.items():
        signal_flag_key = SignalKey(nka_id=stored_message.nka_id, alarm_id=alarm_id,
                                    signal_id=stored_message.signal_type)
        result.append({
            'signal_flag_key': signal_flag_key,
            'source_id': source_id,
            'bis_id': stored_message.bis_id,
            'alarm_id': alarm_id,
            'alarm_value': alarm_value,
            'alarm_timestamp': stored_message.timestamp
        })
    return result


def add_signal_flag(raw_flags: RawSignalFlagsStorage, signal_flag_key: SignalKey, alarm_id: AlarmId, bis_id: BisId,
                    source_id: SourceId, alarm_value: int, alarm_timestamp: datetime) -> None:
    """
    Добавление или обновление единичного сигнального признака в существующей структуре флагов

    Args:
        raw_flags: структура для хранения флагов
        signal_flag_key: ключ составной (nka_id, alarm_id, signal_id)
        alarm_id: идентификатор сообщения
        bis_id: идентификатор БИС
        source_id: идентификатор источника
        alarm_value: значение
        alarm_timestamp: временная метка
    """

    existing_flag = raw_flags[signal_flag_key][source_id].get(bis_id)

    if existing_flag is None:
        # Создаем новый флаг
        flag = RawSignalFlag(
            alarm_id=alarm_id,
            alarm_value=alarm_value,
            first_appear_timestamp=alarm_timestamp,
            last_appear_timestamp=alarm_timestamp,
        )
    else:
        # Обновляем существующий флаг
        flag = existing_flag
        flag['alarm_value'] = alarm_value
        flag['last_appear_timestamp'] = max(flag['last_appear_timestamp'], alarm_timestamp)

    # Сохраняем флаг в структуру
    raw_flags[signal_flag_key][source_id][bis_id] = flag


def format_alarm_value(alarm_id: AlarmId, signal_id: SignalTypes, alarm_value: int) -> Union[int, str, None]:
    """Форматирование значения сигнального признака в зависимости от типа"""

    # преобразование SignalFlagGroup.alarm_value в нужный формат для отображения на клиенте
    alarm_param_value = None
    if alarm_id == AlarmId.ground_control_call:
        alarm_param_value = format_ground_call_control_raw_value(signal_id, alarm_value)
    elif alarm_id == AlarmId.tk_inconsistency:  # перевод tk в формат 'd.%m.%Y %H:%M:%S'
        alarm_param_value = (datetime.fromtimestamp(alarm_value)) \
            .strftime("%d.%m.%Y %H:%M:%S")
    elif alarm_id == AlarmId.tb_inconsistency:  # перевод tb в формат '%H:%M:%S'
        if signal_id in FREQ_SIGNAL_TYPES:
            tb_time_format = FD.common.tb_to_datetime(alarm_value).strftime("%H:%M:%S")
            alarm_param_value = tb_time_format
        elif signal_id in CODE_SIGNAL_TYPES:
            tb_time_format = CD.common.tb_to_datetime(alarm_value).strftime("%H:%M:%S")
            alarm_param_value = tb_time_format
    else:
        alarm_param_value = alarm_value

    return alarm_param_value


def get_all_sources(signal_flag_group: 'SignalFlagGroup') -> List[dict]:
    """Получение списка всех источников для группы сигнальных признаков"""
    all_sources = []
    for source_id, bises in signal_flag_group.bis_by_source.items():
        if not bises:
            continue

        for bis_id in bises:
            if bis_id == UNDEFINED_BIS_ID:
                all_sources.append(SourcesForClient(bis=UNDEFINED_BIS,
                                                    station=UNDEFINED_BIS,
                                                    source=source_id))
            else:
                bis = cache_bis.get_item_by_id(bis_id)
                all_sources.append(SourcesForClient(bis=bis.bis_number,
                                                    station=bis.station_id,
                                                    source=source_id))
    return all_sources
