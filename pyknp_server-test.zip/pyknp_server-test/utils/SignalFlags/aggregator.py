import datetime
import logging
import os
import threading
from collections import defaultdict
from typing import Union

from communication.types import ZMQTopic
from models.op_message import OpMessage, KNPOpMessage, KNPOpSumMessage
from .types import RawSignalFlagsStorage
from .utils import extract_message, add_signal_flag

SEND_INTERVAL_SECONDS = 3  # интервал передачи текущего состояния кэша в секундах
logger = logging.getLogger('signal_flags')


class SignalFlagAggregator:
    """
    Класс для агрегации сигнальных признаков от разных источников.
    Отвечает только за сбор и хранение СП в памяти.
    """

    def __init__(self):
        # Структура: (nka_id, alarm_id, signal_id) -> source_id -> {bis_id:RawSignalFlag}
        self._raw_flags: RawSignalFlagsStorage = defaultdict(lambda: defaultdict(dict))
        self._last_sent_at = datetime.datetime.min
        self._zmq_manager = None
        self._lock = threading.Lock()

    def set_zmq_manager(self, zmq_manager):
        """Установка ZMQ клиента для отправки данных"""
        self._zmq_manager = zmq_manager

    def add_operative_message(self, stored_message: Union[OpMessage, KNPOpMessage, KNPOpSumMessage]) -> None:
        """Обработка оперативного сообщения и извлечение сигнальных признаков"""
        flags = extract_message(stored_message)

        # Блокируем доступ к _raw_flags
        # иногда вызывается из потока zmq в main process через general_validity.load_data, а иногда из основного потока main process
        with self._lock:
            for flag_params in flags:
                add_signal_flag(raw_flags=self._raw_flags, **flag_params)

        if (datetime.datetime.now() - self._last_sent_at).seconds >= SEND_INTERVAL_SECONDS:
            with self._lock:
                self._send_accumulated_flags()  # fixme а если время не подошло, а потом следующие сообщения придут не быстро

    def _send_accumulated_flags(self) -> None:
        """Отправка накопленных флагов в главный процесс"""
        if not self._raw_flags:  # Если нет данных, не отправляем
            return

        try:
            # Отправляем весь словарь целиком
            self._zmq_manager.publish_data(
                topic=ZMQTopic.SIGNAL_FLAGS,
                data=self._raw_flags
            )
            logger.debug(f'Успешная отправка сигнальных признаков с процесса {os.getpid()}')

            # После успешной отправки очищаем
            self._raw_flags.clear()
            self._last_sent_at = datetime.datetime.now()

        except Exception as e:
            logger.error(f'Ошибка при отправке состояния флагов: {e}', exc_info=True)


signal_flags_aggregator = SignalFlagAggregator()
