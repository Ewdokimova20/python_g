"""Модуль содержит класс для определения статуса обобщенного оперативного сообщения"""

import datetime
from dataclasses import field, dataclass, asdict
from enum import IntEnum
from typing import Optional, Dict, Union, List, Any

from typing_extensions import TypedDict

from global_data.appdata import NKA_SIGNALS, MEAS_PACKET_TYPE, DI_PACKET_TYPE, SIGNALS_NAME, FREQ_SIGNAL_TYPES
from global_data.config_schema import config
from utils.SignalFlags import signal_flag_service, EventStatus, NotificationStatus, SoundAlarmStatus, SourceId, AlarmId, \
    UNDEFINED_BIS
from utils.caches import cache_bis
from utils.reception_control.message_counters.general_message_counter import general_message_counters
from utils.statuses.nka_reception_status.common import SignalReceptionStatus
from utils.statuses.nka_reception_status.general_nka_reception_status import general_nka_statuses
from utils.validity.general_validity import general_validity
from utils.validity.types import ValidityStatus


class OpmessageStatus(IntEnum):
    UNDEFINED = 0  # Не определено
    ABSENT = 1  # Отсутствует
    INACCURATE = 2  # Признак получен только по источнику БИС
    UNCONFIRMED = 3  # Не подтвержено: для подтверждения признака не хватает числа БИСов по истончику КНП (сколько по источнику БИС не важно)
    CONFIRMED = 4  # Присутствует: на основании числа БИСов больше порогового по истончику КНП (сколько по источнику БИС не важно)


def set_note_for_ground_control_call(message: str, signal_type: int):
    """Формирует примечание для ВНКУ на основании типа сигнала и значения признака"""
    if signal_type in FREQ_SIGNAL_TYPES:
        label_map = {'01': 'ВНКУ1', '10': 'ВНКУ2', '11': 'ВНКУ3'}
    elif signal_type in [SIGNALS_NAME['L1OCd'], SIGNALS_NAME['L2КСИ'], SIGNALS_NAME['L3OCd']]:
        label_map = {'0100': 'ВНКУ1', '0010': 'ВНКУ2', '0110': 'ВНКУ3'}
    elif signal_type in [SIGNALS_NAME['L1SCd'], SIGNALS_NAME['L2SCd']]:
        label_map = {'010': 'ВНКУ1', '001': 'ВНКУ2', '011': 'ВНКУ3'}
    else:
        label_map = {}
    label = label_map.get(message)
    return f'{message} ({label})' if label else message


@dataclass
class GeneralizedFlagData:
    """
    Модель данных о состоянии приема 1с измерений для одной комбинации БИС/НКА/Тип сигнала
    """

    status: Union[OpmessageStatus, ValidityStatus, SignalReceptionStatus] = field(default=OpmessageStatus.UNDEFINED)
    """Общий статус события, зависящий от типа события (статус достоверности, статус приема/годности)"""
    event_status: EventStatus = field(default=EventStatus.finalized)
    """Статус актуальности события"""
    notification_status: NotificationStatus = field(default=NotificationStatus.approved)
    """Статус подтверждения события"""
    alarm_status: SoundAlarmStatus = field(default=SoundAlarmStatus.undefined)
    """Заглушена или нет звуковая сигнализация события"""
    message: Optional[str] = field(default=None)
    """Флаг, показывающий, что процент измерений в ЗРВ от общего количества измерений превышает установленный порог."""
    sources: Optional[Dict[SourceId, Union[dict, List[str]]]] = field(default=None)
    """Источники"""
    note: Optional[str] = field(default=None)
    """Примечание, котороде добавляется только для ВНКУ"""

    def to_dict(self):
        """Преобразует в словарь, исключая note со значением None"""

        def dict_factory(data):
            return {k: v for k, v in data if not (k == 'note' and v is None)}

        return asdict(self, dict_factory=dict_factory)


class NotificationFlags(TypedDict):
    have_new_messages: NotificationStatus
    alarm_status: SoundAlarmStatus


class GeneralizedOpmessage:
    """Класс для определения статуса обобщенного оперативного сообщения"""

    def __init__(self):
        self.generalized_opmessage: Dict[int, Dict[int, Dict[AlarmId, GeneralizedFlagData]]] = {}
        """Статусы обобщённых по всем источникам оперативных сообщений.
        Уровни: НКА, сигнал, сигнальный признак: статус, сообщение, сигнализация """
        self.signal_flags: list = []
        """Список оперативных сообщений."""
        self.notification_flags: NotificationFlags = {'alarm_status': SoundAlarmStatus.undefined,
                                                      'have_new_messages': NotificationStatus.approved}
        """Обобщенное состояние наличия/отуствия оперативных сообщения."""
        self._init_generalized_opmessage_structures()

    def _init_generalized_opmessage_structures(self):
        """Инициализация структуры"""
        ALARMID_STATUS_MAP = {
            AlarmId.generalized_signals_validity: ValidityStatus.UNDEFINED,
            AlarmId.generalized_receive_status: SignalReceptionStatus.UNDEFINED,
        }
        for nka in NKA_SIGNALS:
            self.generalized_opmessage[nka] = {}

            for signal_type in NKA_SIGNALS[nka]:
                self.generalized_opmessage[nka][signal_type] = {}

                for opmessage_type in AlarmId:
                    status = ALARMID_STATUS_MAP.get(opmessage_type, OpmessageStatus.UNDEFINED)
                    self.generalized_opmessage[nka][signal_type][opmessage_type] = GeneralizedFlagData(status=status)

    def define_one_generalized_opmessage_status(self, sources):
        """Определение статуса для обобщенного оперативного сообщения: обобщение по НКА и типу сигнала"""
        bis_from_knp_source = []
        bis_from_bis_source = []
        status = OpmessageStatus.UNCONFIRMED
        for source in sources:
            if source['bis'] != UNDEFINED_BIS:
                if source['source'] in [SourceId.KNP, SourceId.KNPSum]:
                    bis_from_knp_source.append(f'{source["station"]}/{source["bis"]}')
                if source['source'] == SourceId.BIS:
                    bis_from_bis_source.append(f'{source["station"]}/{source["bis"]}')
            else:
                status = OpmessageStatus.CONFIRMED
                all_sources = {SourceId.KNP: bis_from_knp_source, SourceId.BIS: bis_from_bis_source}
                return status, all_sources
        if not bis_from_knp_source and bis_from_bis_source:
            status = OpmessageStatus.INACCURATE
        elif len(bis_from_knp_source) < config['bis_control']['min_amount_bis_for_generalized_opmessage']:
            status = OpmessageStatus.UNCONFIRMED
        elif len(bis_from_knp_source) >= config['bis_control']['min_amount_bis_for_generalized_opmessage']:
            status = OpmessageStatus.CONFIRMED
        all_sources = {SourceId.KNP: bis_from_knp_source, SourceId.BIS: bis_from_bis_source}
        return status, all_sources

    def define_generalized_DI_opmessage_status(self):
        """Функция для определения статуса оперативного сообщения для ЦИ(обобщение признака 6,7,8,9,10)"""

        INCONSISTENCY_ALARMID = [
            AlarmId.tk_inconsistency,
            AlarmId.tb_inconsistency,
            AlarmId.EI_inconsistency,
            AlarmId.clock_inconsistency,
            AlarmId.almanac_inconsistency
        ]

        for nka, nka_dict in self.generalized_opmessage.items():
            for signal_type, signal_dict in nka_dict.items():
                event_status = EventStatus.finalized
                notification_status = NotificationStatus.approved
                alarm_status = SoundAlarmStatus.undefined

                for opmessage_type, opmessage_data in signal_dict.items():
                    if opmessage_type in INCONSISTENCY_ALARMID:
                        if opmessage_data.event_status == EventStatus.active:
                            event_status = EventStatus.active
                        if opmessage_data.notification_status == NotificationStatus.new:
                            notification_status = NotificationStatus.new
                        if opmessage_data.alarm_status == SoundAlarmStatus.unmuted:
                            alarm_status = SoundAlarmStatus.unmuted

                if event_status == EventStatus.active or notification_status == NotificationStatus.new:
                    self.generalized_opmessage[nka].setdefault(signal_type, {})[AlarmId.generalized_DI] = \
                        GeneralizedFlagData(
                            event_status=event_status,
                            notification_status=notification_status,
                            alarm_status=alarm_status,
                            status=OpmessageStatus.CONFIRMED,
                            message=None,
                            sources=None
                        )

    def define_generalized_receive_status_opmessage_status(self):
        """Функция для определения статуса приёма сигналов НКА, основано на статусах из nka_status.py"""

        for nka, nka_dict in self.generalized_opmessage.items():
            for signal_type, signal_dict in nka_dict.items():
                event_status = EventStatus.active
                notification_status = NotificationStatus.approved
                alarm_status = SoundAlarmStatus.unmuted

                status = general_nka_statuses.nka_signal_generalized_statuses.get(nka, {}).get(signal_type, {}).get(
                    MEAS_PACKET_TYPE, SignalReceptionStatus.UNDEFINED)
                if status == SignalReceptionStatus.OUT_OF_SIGHT:
                    all_bis = cache_bis.get_bis_list()
                    for bis in all_bis:
                        one_nka_counter = \
                            general_message_counters.get_counter(bis.station_id, bis.bis_number, nka, signal_type, DI_PACKET_TYPE)
                        if one_nka_counter is not None:
                            counter_flag = True if one_nka_counter.get('c', 0) > 0 else False
                            last_receive_time = one_nka_counter.get('t', None)
                            if last_receive_time is not None:
                                time_flag = True if abs(
                                    (datetime.datetime.now() - last_receive_time).total_seconds()) < 240 else False
                                if counter_flag and time_flag:
                                    status = SignalReceptionStatus.OK

                for opmessage_type, opmessage_data in signal_dict.items():
                    if opmessage_type == AlarmId.absent_signal and opmessage_data.alarm_status != SoundAlarmStatus.undefined:
                        event_status = opmessage_data.event_status
                        notification_status = opmessage_data.notification_status
                        alarm_status = opmessage_data.alarm_status

                self.generalized_opmessage[nka][signal_type][AlarmId.generalized_receive_status] = \
                    GeneralizedFlagData(
                        event_status=event_status,
                        notification_status=notification_status,
                        alarm_status=alarm_status,
                        status=status,
                        message=None,
                        sources=None
                    )

    def define_generalized_signals_validity_opmessage_status(self):
        """Функция для определения годности навигационных сигналов, основано на статусах из signals_validity.py"""

        signals_validity_statuses = general_validity.get_signals_generalized_validity()  # общий статус validity
        nka_bis_validity = general_validity.nka_bis_validity  # статусы по каждому БИС отдельно

        for nka, nka_dict in self.generalized_opmessage.items():
            for signal_type, signal_dict in nka_dict.items():
                general_status = signals_validity_statuses.get(nka, {}).get(signal_type, ValidityStatus.UNDEFINED)
                all_sources = None
                if general_status == ValidityStatus.VALID or general_status == ValidityStatus.INVALID:  # для этих двух статусов необходимо вывести источники
                    valid_bis_sources = []
                    invalid_bis_sources = []
                    for station, bis_validity in nka_bis_validity[nka][signal_type].items():
                        for bis, status in bis_validity.items():
                            if status == ValidityStatus.VALID:
                                valid_bis_sources.append(f'{station}/{bis}')
                            elif status == ValidityStatus.INVALID:
                                invalid_bis_sources.append(f'{station}/{bis}')
                    if valid_bis_sources or invalid_bis_sources:
                        all_sources = {SourceId.BIS: {'valid': valid_bis_sources, 'invalid': invalid_bis_sources}}

                self.generalized_opmessage[nka][signal_type][AlarmId.generalized_signals_validity] = \
                    GeneralizedFlagData(
                        event_status=EventStatus.active,
                        notification_status=NotificationStatus.approved,
                        alarm_status=SoundAlarmStatus.unmuted,
                        status=general_status,
                        message=None,
                        sources=all_sources
                    )

    def define_generalized_opmessage(self):
        """Функция для определения статуса для каждого обобщенного оперативного сообщения"""

        for nka, nka_dict in self.generalized_opmessage.items():
            for signal_type, signal_dict in nka_dict.items():
                for opmessage_type in signal_dict.keys():
                    if opmessage_type not in [AlarmId.generalized_signals_validity, AlarmId.generalized_receive_status]:
                        self.generalized_opmessage[nka][signal_type][opmessage_type] = \
                            GeneralizedFlagData(
                                event_status=EventStatus.finalized,
                                notification_status=NotificationStatus.approved,
                                alarm_status=SoundAlarmStatus.undefined,
                                status=OpmessageStatus.ABSENT,
                                message=None,
                                sources=None
                            )

        self.signal_flags = signal_flag_service.as_dict_for_client()  # fixme может брать из процессора все СП
        for signal_flag in self.signal_flags:
            nka = signal_flag['nka']
            signal_type = signal_flag['signal_type']
            if signal_type in NKA_SIGNALS.get(nka, []):
                if signal_flag['event_status'] == EventStatus.active or signal_flag[
                    'notification_status'] == NotificationStatus.new:
                    signal_type = signal_flag['signal_type']
                    alarm_id = signal_flag['message']['type']
                    message = signal_flag['message']['value']
                    note = None
                    if alarm_id == AlarmId.ground_control_call:
                        # формируем примечание с названием ВНКУ (ВНКУ1, ВНКУ2...)
                        if message == '10000':
                            message = None
                        note = set_note_for_ground_control_call(message, signal_type)
                    status, all_sources = self.define_one_generalized_opmessage_status(signal_flag['sources'])
                    self.generalized_opmessage[nka][signal_type][alarm_id] = \
                        GeneralizedFlagData(
                            event_status=signal_flag['event_status'],
                            notification_status=signal_flag['notification_status'],
                            alarm_status=signal_flag['sound_status'],
                            status=status,
                            message=message,
                            sources=all_sources,
                        )
                    # добавляем примечание с названием ВНКУ, если это ВНКУ
                    if note:
                        self.generalized_opmessage[nka][signal_type][alarm_id].note = note

        self.define_generalized_DI_opmessage_status()
        self.define_generalized_signals_validity_opmessage_status()
        self.define_generalized_receive_status_opmessage_status()

    def update_generalized_opmessage(self, nka_list=[], combinations=[]):
        """Функция для обновления статуса обобщенного оперативного сообщения определённого НКА"""

        self.signal_flags = signal_flag_service.as_dict_for_client()  # fixme может брать из процессора все СП
        for signal_flag in self.signal_flags:
            sources = signal_flag['sources']
            nka = signal_flag['nka']
            signal_type = signal_flag['signal_type']
            combination = signal_flag['combination']
            if signal_type in NKA_SIGNALS.get(nka, []):
                if nka in nka_list or combination in combinations:
                    status, all_sources = self.define_one_generalized_opmessage_status(sources)
                    self.generalized_opmessage[nka][signal_type][signal_flag['message']['type']] = \
                        GeneralizedFlagData(
                            event_status=signal_flag['event_status'],
                            notification_status=signal_flag['notification_status'],
                            alarm_status=signal_flag['sound_status'],
                            status=status,
                            message=signal_flag['message']['value'],
                            sources=all_sources
                        )

        self.define_generalized_DI_opmessage_status()

    def define_notification_flags(self) -> NotificationFlags:
        """Функция для определения наличия новых оперативных сообщений
            и сигнализации для оперативных сообщений"""
        self.notification_flags['alarm_status'] = SoundAlarmStatus.undefined
        self.notification_flags['have_new_messages'] = NotificationStatus.approved

        if self.signal_flags:
            for signal_flag in self.signal_flags:
                if signal_flag['notification_status'] == NotificationStatus.new and signal_flag[
                    'sound_status'] == SoundAlarmStatus.unmuted:
                    self.notification_flags['alarm_status'] = SoundAlarmStatus.unmuted
                if signal_flag['notification_status'] == NotificationStatus.new:
                    self.notification_flags['have_new_messages'] = NotificationStatus.new
            return self.notification_flags

    def get_all_messages(self) -> Dict[int, Dict[int, Dict[AlarmId, Dict[str, Any]]]]:
        """Получить представление всех сообщений в виде вложенных словарей"""
        return {
            nka: {
                signal_type: {
                    opmessage_type: data.to_dict()
                    for opmessage_type, data in signal_dict.items()
                }
                for signal_type, signal_dict in nka_dict.items()
            }
            for nka, nka_dict in self.generalized_opmessage.items()
        }

    def get_messages_without_ground_call_and_unreliable(self) -> Dict[int, Dict[int, Dict[AlarmId, Dict[str, Any]]]]:
        """Получить представление сообщений в виде вложенных словарей для AlarmId >= 5"""
        return {
            nka: {
                signal_type: {
                    alarm_id: alarm_data.to_dict()
                    for alarm_id, alarm_data in signal_dict.items()
                    if alarm_id >= AlarmId.absent_signal
                }
                for signal_type, signal_dict in nka_dict.items()
            }
            for nka, nka_dict in self.generalized_opmessage.items()
        }

    def get_ground_call_messages(self) -> Dict[int, Dict[int, Dict[str, Any]]]:
        """
        Получить представление сообщений для AlarmId.ground_call
        в структуре: nka -> signal_type -> словарь с данными
        """
        result = {}
        for nka, nka_dict in self.generalized_opmessage.items():
            nka_result = {}
            for signal_type, signal_dict in nka_dict.items():
                ground_call_data = signal_dict.get(AlarmId.ground_control_call)
                should_display = (ground_call_data.event_status or ground_call_data.alarm_status)
                if ground_call_data is not None and should_display:
                    nka_result[signal_type] = ground_call_data.to_dict()

            if nka_result:
                result[nka] = nka_result

        return result

    def get_unreliable_messages(self) -> Dict[int, Dict[int, Dict[AlarmId, Dict[str, Any]]]]:
        """
        Получить представление сообщений для AlarmId:
        - unreliable_frame
        - unreliable_signal
        - unreliable_digital_info
        в структуре: nka -> signal_type -> AlarmId -> словарь с данными
        """
        unreliable_alarm_ids = {
            AlarmId.unreliable_frame,
            AlarmId.unreliable_signal,
            AlarmId.unreliable_digital_info
        }  # типы событий, которые включаем в выдачу

        result = {}
        for nka, nka_dict in self.generalized_opmessage.items():
            nka_result = {}
            for signal_type, signal_dict in nka_dict.items():
                signal_result = {}
                for alarm_id, alarm_data in signal_dict.items():
                    if alarm_id in unreliable_alarm_ids:
                        should_display = bool(alarm_data.event_status or alarm_data.alarm_status)
                        if should_display:
                            signal_result[alarm_id] = alarm_data.to_dict()

                    if signal_result:
                        nka_result[signal_type] = signal_result

            if nka_result:
                result[nka] = nka_result

        return result

    def get_all_messages_separately(self):
        return {
            'ground_control_call': self.get_ground_call_messages(),
            'unreliable_events': self.get_unreliable_messages(),
            'general_data': self.get_messages_without_ground_call_and_unreliable()
        }


generalized_opmessage = GeneralizedOpmessage()
