import datetime
from functools import wraps
from math import sqrt, sin, cos, isclose, fmod
from typing import Tuple

from cachetools import TTLCache, cached
from pymatrix import Matrix

from utils.coordinates.coordinates import Coordinates

__all__ = ['current_celestial_state',
           ]

datetime_2000 = datetime.datetime(year=2000, day=1, month=1)
DAU = 149597870000.0  # астрономическая единица
DSL = 299792458.0  # Скорость света в вакууме, м/сек.
D2PI = 6.28318530717959  # Число 2*pi, рад.
DDCEN = 2.737850787132101E-5  # Число веков в одном дне

recalc_sun_position_cache = TTLCache(maxsize=100, ttl=300)
"""Кэш для рассчитанных значений положения Солнца (recalc_sun_position_cache)"""


def round_time(func):
    """Декоратор, который округляет датувремя перед передачей в функцию recalc_sun_position_cache"""

    @wraps(func)
    def wrapper(*args, **kwargs):
        self = args[0] if args else None
        current_time = kwargs.get('current_time')

        if len(args) > 1 and isinstance(args[1], datetime.datetime):
            current_time = args[1]

        if current_time is None:
            return func(*args, **kwargs)

        # Округление до ближайшей минуты
        rounded_time = current_time.replace(second=0, microsecond=0)
        if current_time.second >= 30:
            rounded_time += datetime.timedelta(minutes=1)

        return func(self, rounded_time)

    return wrapper


class AstroSystem:
    e_s: Matrix

    @round_time
    @cached(recalc_sun_position_cache)  # кэшировать результаты расчета для разных времен
    def recalc_sun_position(self, current_time: datetime.datetime) -> None:
        """Пересчитывает положение Солнца в системе координат GCRS.

        Этот метод вычисляет положение Солнца в геоцентрической системе координат
        (GCRS) на основе переданного времени. Результаты кэшируются для повышения
        производительности при повторных вызовах с теми же временными параметрами.

        Args:
            current_time (datetime.datetime): Текущая дата и время, для которых необходимо вычислить положение Солнца.

        Returns:
            None: Метод не возвращает значений, но обновляет внутреннее состояние объекта, сохраняя вычисленные координаты Солнца в атрибуте `self.e_s`.

        Notes:
            - Время преобразуется в юлианскую дату.
            - Координаты Солнца нормализуются для использования в дальнейшем.
        """

        timestamp_2000 = current_time.timestamp() - datetime_2000.timestamp()

        day_Julian_UTC = (
                timestamp_2000 / 86400.0  # Переводи МВ в ШВ МДВ в число суток
                + 1461.0 * 2 + 1.0  # кол-во дней в 4-х годах для перевода в число суток от 1996 г. для МВ в ШВ для 2000 г.
                - (3 * 60 * 60) / 86400.0  # 3ч разницы МДВ-UTC
                - 2923.5  # перевод в юлианскую дату
        )

        tau = day_Julian_UTC * DDCEN
        # Вычисляемые координаты Солнца в GCRS, м
        sun_position_GCRS = gloSunEph(tau)
        # формируем матрицу перехода для перевода координат Солнца из ИСК в ЗСК и нормируем
        m = gloC2T(tau, day_Julian_UTC)
        self.e_s = self.normalize_matrix(m * sun_position_GCRS)  # пересчитываем координаты из ИСК в ЗСК

    def get_emmit_point(self, nka_mass_center: Coordinates.XYZ, fca_offset: Coordinates.XYZ,
                        calc_time: datetime.datetime = None) -> Coordinates.XYZ:
        """Пересчет координат из ЦМ в ФЦА. Теория в ИКД для кодовых сигналов 2021 Приложение П.

        Args:
            nka_mass_center (Coordinates.XYZ): координаты центра масс КА.
            fca_offset (Coordinates.XYZ): смещение фазового центра антенны.
            calc_time (datetime.datetime): по-умолчанию None, вроде как всегда None

        Returns:
            Coordinates.XYZ: координаты для ФЦА (фазового центра антенн).
        """

        # проверка корректности входных данных
        if (nka_mass_center.x == 0) and (nka_mass_center.y == 0) and (nka_mass_center.z == 0):
            return nka_mass_center
        if (fca_offset.x == 0) and (fca_offset.y == 0) and (fca_offset.z == 0):
            return nka_mass_center

        if calc_time is not None:
            # если мы сюда попали, то нам было передано tb в коде оперативного сравнения обобщ. кадров с СИ
            # тогда у нас не посчитано current_celestial_state.e_s для tb, надо посчитать
            self.recalc_sun_position(current_time=calc_time)

        # Вектор координат центра массы КА
        nka_mass_center_matrix = Matrix.from_list([[nka_mass_center.x], [nka_mass_center.y], [nka_mass_center.z]])

        # вычисляем орт e_r от Земли до НКА, e_n с учетом Солнца, e_b --- правая тройка к ним
        e_r, e_n, e_b = self.calculate_ort_axes(nka_mass_center_matrix)

        # Создаем матрицу перехода E из ортов e_r, e_b, e_n
        transition_matrix = Matrix.from_list([
            [e_r[0][0], e_b[0][0], e_n[0][0]],
            [e_r[1][0], e_b[1][0], e_n[1][0]],
            [e_r[2][0], e_b[2][0], e_n[2][0]]
        ])

        # Применяем смещение к вектору fca_offset
        transition_offset = transition_matrix * Matrix.from_list([[fca_offset.x], [fca_offset.y], [fca_offset.z]])

        # Вычисляем новые координаты (в ИКД знак "-" это не правильно)
        nka_fca_x, nka_fca_y, nka_fca_z = Matrix.elements(nka_mass_center_matrix + transition_offset)

        return Coordinates.XYZ(x=nka_fca_x, y=nka_fca_y, z=nka_fca_z)

    def calculate_ort_axes(self, nka_mass_center_matrix: Matrix) -> Tuple[Matrix, Matrix, Matrix]:
        """
        Вычисляет орты осей бортовой системы координат.

        Args:
            nka_mass_center_matrix (Matrix): Вектор центра масс НКА.

        Returns:
            Tuple[Matrix, Matrix, Matrix]: Кортеж из трёх ортов (e_r, e_n, e_b).
        """

        # Вычисляем e_r оси r бортовой системы координат
        e_r = self.normalize_matrix(nka_mass_center_matrix)
        # Вычисляем e_n как векторное произведение normalize_matrix(-e_r * self.e_s)
        e_n = self.normalize_matrix(Matrix.cross(-e_r, self.e_s))
        # Вычисляем e_b как векторное произведение normalize_matrix(-e_r * e_n)
        e_b = self.normalize_matrix(Matrix.cross(-e_r, e_n))

        return e_r, e_n, e_b

    @staticmethod
    def normalize_matrix(input_vector: Matrix) -> Matrix:  # 3x1
        """Функция нормализации вектора (деление вектора на его длину).

        Args:
            input_vector (Matrix): входной вектор.

        Returns:
            Matrix: нормализованный вектор.
        """

        return Matrix.dir(input_vector)


current_celestial_state = AstroSystem()


def gloSunEph(tau: float) -> Matrix:
    # Шаги по методике, приложение Е
    ec = 0.016719  # "эксцентриситет орбиты Солнца"
    # Е.1 Средняя аномалия Солнца
    M = 6.2400601269 + 628.3019551714 * tau - 0.0000026820 * tau * tau
    # Е.2 Эксцентрическая аномалия Солнца
    E = solveKeplerEquation(ec, M)
    # Е.3
    rc = DAU * (1 - ec * cos(E))
    # Е.4
    tau -= rc / (DSL * 86400.0 * 36525)
    # Повтор Е.1 Средняя аномалия Солнца
    M = 6.2400601269 + tau * (628.3019551714 + tau * (-0.0000026820))
    # Повтор Е.2 Эксцентрическая аномалия находится из уравнения Кеплера
    E = solveKeplerEquation(ec, M)
    # Повтор Е.3 Расстояние до Солнца
    rc = DAU * (1 - ec * cos(E))
    # Е.5 Синус и косинус истинной аномалии
    snuc = sqrt(1 - ec * ec) * sin(E) / (1 - ec * cos(E))
    cnuc = (cos(E) - ec) / (1 - ec * cos(E))
    # Е.6 Средняя тропическая долгота перигея орбиты Солнца
    omc = -7.6281824375 + tau * (0.0300101976 + tau * 0.0000079741)
    # Е.7 Средний наклон эклиптики к экватору
    eps = 0.4090926006 - 0.0002270711 * tau
    # Е.8 Координаты Солнца находятся в ИСК!
    comc = cos(omc)
    somc = sin(omc)
    xic = cnuc * comc - snuc * somc
    etac = (snuc * comc + cnuc * somc) * cos(eps)
    tauc = (snuc * comc + cnuc * somc) * sin(eps)
    return Matrix.from_list([[rc * xic * 1000.0], [rc * etac * 1000.0], [rc * tauc * 1000.0]])


def solveKeplerEquation(e: float, M: float) -> float:
    nc = 0  # счетчик итераций
    Ec = 0.0
    while nc < 10:
        E0 = Ec
        Ec = M + e * sin(E0)
        if isclose(E0, Ec, abs_tol=1e-15):
            break
    return Ec


def gloC2T(tau: float, UTC: float) -> Matrix:
    # Вычисление аргументов нутации
    Npsi, Neps = gloNut89(tau)
    eps = 0.4090928042 + tau * (-0.2269655e-3 + tau * (-0.29e-8 + tau * 0.88e-8))
    nut = gloNutMat89(Npsi, Neps, eps)

    # Вычисление матрицы прецессии
    p = gloPrecMat89(tau)

    # Вычисление матрицы поворота
    Nalpha = Npsi * cos(eps)
    UT1 = UTC
    gst = gloGMST(UT1, fmod(UT1, 1)) + Nalpha
    # А.8
    rr = gloRZ(gst)

    nutp = nut * p  # Матрица прецессии и нутации

    return rr * nutp  # Сформировать матрицу перехода


def gloNut89(tau: float):
    lp = trunc2Pi(6.24003594 + tau * (628.30195602 + tau * (-2.7974e-6 + tau * (-5.82e-8))))
    f = trunc2Pi(1.62790193 + tau * (8433.46615831 + tau * (-6.42717e-5 + tau * 5.33e-8)))
    d = trunc2Pi(5.19846951 + tau * (7771.37714617 + tau * (-3.34085e-5 + tau * 9.21e-8)))
    om = trunc2Pi(2.182438624 + tau * (-33.757045936 + tau * (3.61429e-5 + tau * 3.88e-8)))

    Npsi = -0.83386e-4 * sin(om) + 0.9997e-6 * sin(2 * om) - 0.63932e-5 * sin(2 * (f - d + om)) \
           + 0.6913e-6 * sin(lp) - 0.11024e-5 * sin(f + om)
    Neps = 0.44615e-4 * cos(om) + 0.27809e-5 * cos(2 * (f - d + om)) + 0.474e-6 * cos(2 * (f + om))
    return Npsi, Neps


def trunc2Pi(angle: float) -> float:
    result = fmod(angle, D2PI)
    if result < 0:
        result += D2PI
    return result


def gloNutMat89(Npsi: float, Neps: float, eps0: float) -> Matrix:  # 3x3
    # Вычислить истинный наклон экватора к эклиптике
    eps = eps0 + Neps
    ce = cos(eps)
    se = sin(eps)
    ce0 = cos(eps0)
    se0 = sin(eps0)
    cnpsi = cos(Npsi)
    snpsi = sin(Npsi)

    return Matrix.from_list([[cnpsi, -snpsi * ce0, -snpsi * se0],
                             [snpsi * ce, cnpsi * ce * ce0 + se * se0, cnpsi * ce * se0 - se * ce0],
                             [snpsi * se, cnpsi * se * ce0 - ce * se0, cnpsi * se * se0 + ce * ce0]])


def gloPrecMat89(tau: float) -> Matrix:  # 3x3
    # Параметры прецессии согласно РД 50-25645.325-89
    zt = tau * (0.111808609e-1 + tau * (0.146356e-5 + tau * 0.872e-7))
    za = tau * (0.111808609e-1 + tau * (0.53072e-5 + tau * 0.883e-7))
    th = tau * (0.97171735e-2 + tau * (-0.20685e-5 + tau * (-0.2028e-6)))
    # Косинусы и синусы этих параметров
    czt = cos(zt)
    szt = sin(zt)
    cza = cos(za)
    sza = sin(za)
    cth = cos(th)
    sth = sin(th)

    return Matrix.from_list([[czt * cza * cth - szt * sza, -szt * cza * cth - czt * sza, -cza * sth],
                             [czt * sza * cth + szt * cza, -szt * sza * cth + czt * cza, -sza * sth],
                             [czt * sth, -szt * sth, cth]])


def gloGMST(UT1day: float, UT1Frac: float) -> float:
    ERA = trunc2Pi(D2PI * (
            0.7790572732640 + 0.00273781191135448 * UT1day + UT1Frac))  # Угол поворота Земли в плоскости экватора CIRS
    tau = UT1day * DDCEN  # Промежуток времени от J2000 в юлианских столетиях
    # Вычисление полинома по схеме Горнера
    return trunc2Pi(ERA +
                    0.0000000703270726 +  # 2Pi*1,1192901e-8
                    (0.0223603658710194 +  # 2Pi*0.0035587627577160
                     (0.0000067465784654 +  # 2Pi*1.073751311e-6
                      (-0.0000000000021332 +  # 2Pi*3.3950e-13
                       (-0.0000000001452308 +  # 2Pi*2.31142e-11
                        (-0.0000000000001784)  # 2Pi*2.839e-14
                        * tau) * tau) * tau) * tau) * tau)


def gloRZ(angle: float) -> Matrix:  # 3x3
    c = cos(angle)
    s = sin(angle)
    return Matrix.from_list([[c, s, 0.0],
                             [-s, c, 0.0],
                             [0.0, 0.0, 1]])
