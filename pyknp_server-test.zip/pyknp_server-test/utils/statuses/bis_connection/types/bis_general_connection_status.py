from enum import IntEnum


class BisGeneralConnectionStatus(IntEnum):
    UNDEFINED = -1
    FAULT = 0
    PACKET_ERROR = 1
    SOME_FAULT = 2
    SOME_PACKET_ERROR = 3
    OK = 4
