from enum import IntEnum


class BisConnectionStatus(IntEnum):
    """Перечисление состояний обмена с БИС"""
    OK = 2
    PACKET_ERROR = 1
    FAULT = 0
    UNDEFINED = -1
