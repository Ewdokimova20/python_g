from collections import defaultdict

from utils.caches import cache_bis
from utils.reception_control.message_counters.general_message_counter import general_message_counters
from utils.statuses.bis_connection.get_current_bis_connection_status import get_current_bis_communication_status
from utils.statuses.bis_connection.types import BisConnectionStatus
from utils.statuses.bis_connection.types.bis_general_connection_status import BisGeneralConnectionStatus


class BisConnectionState:
    """
    Класс для хранения состояния обмена с БИС.

    Управляет статусами связи с различными БИС с помощью иерархического словаря.

    Работает на стороне основного процесса (обобщающего)

    Возможные статусы:
        - UNDEFINED: Нет данных о последнем пакете
        - OK: Связь исправна
        - FAULT: Превышена допустимая задержка получения пакетов
        - PACKET_ERROR: Проблемы с получением постоянных пакетов (1с измерения и ЦИ [0x11, 0x21])

    Attributes:
        state (defaultdict): Двухуровневый словарь статусов связи с БИС.
            Первый уровень - номер станции,
            Второй уровень - номер БИС,
            Значение - статус связи.
    """

    def __init__(self):
        """
        Инициализирует состояние связи с БИС.

        Создает двухуровневый словарь статусов со значением по умолчанию UNDEFINED
        и автоматически заполняет его известными БИС.
        """
        self.state = defaultdict(lambda: defaultdict(lambda: BisConnectionStatus.UNDEFINED))
        self._init_state()

    def _init_state(self) -> None:
        """
        Инициализирует словарь статусов для всех известных БИС.

        Заполняет структуру state значениями по умолчанию для каждой пары
        (номер станции, номер БИС) из кэша.
        """
        all_bis = cache_bis.get_all().keys()
        for bis_number, station_number in all_bis:
            # Просто обращение к элементу инициализирует его значением по умолчанию
            _ = self.state[station_number][bis_number]

    def define(self) -> None:
        """
        Обновляет статусы связи для всех известных БИС.

        Определяет текущее состояние связи с каждым БИС на основе:
        - Времени последнего полученного пакета
        - Времени получения постоянных пакетов
        - Заданной допустимой задержки получения пакетов

        Использует служебный счетчик сообщений для оценки состояния.
        """
        all_bis = cache_bis.get_all().keys()
        for bis_number, station_number in all_bis:
            self.state[station_number][bis_number] = get_current_bis_communication_status(
                station_number,
                bis_number,
                general_message_counters
            )

    def get_state(self):
        """
        Возвращает полный словарь статусов связи с БИС.

        Returns:
            defaultdict: Словарь статусов для всех БИС.
        """
        return self.state

    def get_status(self, station: int, bis_number: int) -> 'BisConnectionStatus':
        """
        Получает статус связи для конкретного БИС на указанной станции.

        Args:
            station (int): Номер станции.
            bis_number (int): Номер БИС.

        Returns:
            BisConnectionStatus: Статус связи с указанным БИС.
        """
        return self.state[station][bis_number]

    def get_general_status(self) -> 'BisGeneralConnectionStatus':
        """
        Выдаёт обобщённый статус по всем БИС.

        Правила:
        - Игнорируем UNDEFINED.
        - Если после фильтрации остался один уникальный статус — возвращаем его.
        - Если несколько разных статусов:
            - Если есть хотя бы один FAULT — возвращаем SOME_FAULT
            - Иначе, если есть хотя бы один PACKET_ERROR — возвращаем SOME_PACKET_ERROR
            - Иначе — возвращаем UNDEFINED
        - Если после фильтрации ничего не осталось — возвращаем UNDEFINED.
        """
        statuses = []

        for station, bis_dict in self.state.items():
            for bis_number, status in bis_dict.items():
                if status != BisConnectionStatus.UNDEFINED:
                    statuses.append(status)

        unique_statuses = set(statuses)

        if not unique_statuses:
            return BisGeneralConnectionStatus.UNDEFINED

        if len(unique_statuses) == 1:
            single_status = unique_statuses.pop()
            return BisGeneralConnectionStatus(single_status)

        if BisConnectionStatus.FAULT in unique_statuses:
            return BisGeneralConnectionStatus.SOME_FAULT

        if BisConnectionStatus.PACKET_ERROR in unique_statuses:
            return BisGeneralConnectionStatus.SOME_PACKET_ERROR

        # Ни одно из условий не подошло — возвращаем UNDEFINED
        return BisGeneralConnectionStatus.UNDEFINED


bis_connection_state = BisConnectionState()
