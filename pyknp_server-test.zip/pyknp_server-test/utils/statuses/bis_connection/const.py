from datetime import timedelta

from global_data.config_schema import config

ACCEPTABLE_BIS_CONNECTION_DELAY = timedelta(seconds=config['bis_control']['acceptable_packets_delay'])
"""Порог в секундах, определяющий допустимую задержку пакетов от БИС"""

CONSTANTLY_TRASMITTED_PACKET_IDS = [0x11, 0x21]
"""Номера пакетов (в соответствии с 14Ц181.4000-0Д3), которые должны постоянно передаваться от БИС"""
