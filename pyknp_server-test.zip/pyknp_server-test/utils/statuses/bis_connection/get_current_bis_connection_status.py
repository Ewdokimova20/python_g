from datetime import datetime
from typing import TYPE_CHECKING

from utils.statuses.bis_connection.const import ACCEPTABLE_BIS_CONNECTION_DELAY, CONSTANTLY_TRASMITTED_PACKET_IDS
from utils.statuses.bis_connection.types import BisConnectionStatus

if TYPE_CHECKING:
    from utils.reception_control.message_counters.base_message_counter import BaseMessageCounter


def get_current_bis_communication_status(station: int, bis_num: int,
                                         message_counters_instance: 'BaseMessageCounter') -> 'BisConnectionStatus':
    """
    Определяет текущий статус связи с БИС.

    Args:
        station (int): Номер станции.
        bis_num (int): Номер БИС.
        message_counters_instance (BaseMessageCounter): Экземпляр счетчика сообщений,
            используемый для отслеживания времени последних пакетов (PartialMessageCounter или GeneralMessageCounter).
        time_now (datetime, optional): Текущее время для сравнения.
            По умолчанию используется текущее системное время.

    Returns:
        BisConnectionStatus: Статус связи с БИС:
            - UNDEFINED: Нет данных о последнем пакете
            - OK: Связь исправна
            - FAULT: Превышена допустимая задержка получения пакетов
            - PACKET_ERROR: Проблемы с получением постоянных пакетов (1с измерения и ЦИ [0x11, 0x21])

    Notes:
        Статус определяется на основе:
        - Времени последнего полученного пакета
        - Времени получения постоянных пакетов
        - Заданной допустимой задержки получения пакетов
    """
    time_now = datetime.now()
    latest_packet_time = message_counters_instance.get_latest_packet_time(station, bis_num)
    if latest_packet_time:
        if time_now > latest_packet_time + ACCEPTABLE_BIS_CONNECTION_DELAY:
            return BisConnectionStatus.FAULT
        else:
            status = BisConnectionStatus.OK
            for packet_id in CONSTANTLY_TRASMITTED_PACKET_IDS:
                latest_packet_id_time = message_counters_instance.get_latest_packet_time_for_packet_type(station, bis_num,
                                                                                                         packet_id)
                if latest_packet_id_time:
                    if time_now > latest_packet_id_time + ACCEPTABLE_BIS_CONNECTION_DELAY:
                        status = BisConnectionStatus.PACKET_ERROR
                else:
                    status = BisConnectionStatus.PACKET_ERROR
            return status

    return BisConnectionStatus.UNDEFINED
