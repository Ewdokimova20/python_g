"""Модуль класса формирования статусов приёма сигналов НКА"""
from collections import Counter

from global_data.appdata import NKA_SIGNALS, MEAS_PACKET_TYPE, DI_PACKET_TYPE, SIGNALS_WITH_DI
from global_data.config_schema import config
from utils.caches import cache_bis
from utils.reception_control.message_counters.general_message_counter import general_message_counters
from utils.statuses.nka_reception_status.base_nka_reception_status import BaseNkaReceptionStatus
from utils.statuses.nka_reception_status.common import SignalReceptionStatus
from utils.visibility.current_visibility import current_visibility_for_client


class GeneralNkaReceptionStatus(BaseNkaReceptionStatus):
    """
    Класс состояний приёма нав. сигналов для основного процесса (обобщающего).
    Вычисляет состояния для всех НКА и сигналов по видам пакетов (ЦИ или измерения) с обобщением по всем станциям
    """

    def __init__(self):
        super().__init__(counter_service=general_message_counters, visibility_service=current_visibility_for_client,
                         bis_cache=cache_bis)

        self.nka_signal_generalized_statuses = dict()
        """Обобщённые  по всем БИС состояния приёма каждого сигнала каждого НКА."""
        # FIXME Используются только в обобщенных сигнальных признаках, переделать там на новые счетчики состояния приема (если надо)

        self.bis_nka_generalized_statuses = dict()
        """
        @DEPRECATED
        Обобщённые по всем сигналам состояния приёма каждого НКА для каждого БИС
        """
        # FIXME Нигде не используются, раньше были в табличке статусов по всем БИС, сейчас просто болтается со своей функцией define_generalized_bis_nka_statuses

        # Инициализируем дополнительные структуры данных
        self.init_additional_structures()

    def init_additional_structures(self) -> None:
        """Инициализация структур состояния приёма сигналов"""
        # Получаем все БИС
        all_bis = cache_bis.get_all().keys()

        # Инициализируем дополнительные словари
        self.nka_signal_generalized_statuses = dict()
        self.bis_nka_generalized_statuses = dict()

        # Единый цикл для инициализации всех структур
        for nka, nka_signals in NKA_SIGNALS.items():
            # Инициализация для nka_signal_generalized_statuses
            self.nka_signal_generalized_statuses[nka] = dict()

            # Инициализация для каждого сигнала НКА
            for signal in nka_signals:
                # Инициализация обобщенных статусов сигналов
                self.nka_signal_generalized_statuses[nka][signal] = {
                    MEAS_PACKET_TYPE: SignalReceptionStatus.OUT_OF_SIGHT
                }
                if signal in SIGNALS_WITH_DI:
                    self.nka_signal_generalized_statuses[nka][signal][DI_PACKET_TYPE] = SignalReceptionStatus.OUT_OF_SIGHT

                # Инициализация для каждой станции и БИС
                for bis_number, station_number in all_bis:
                    # Инициализация bis_nka_generalized_statuses
                    self.bis_nka_generalized_statuses.setdefault(station_number, {})
                    self.bis_nka_generalized_statuses[station_number].setdefault(bis_number, {})
                    self.bis_nka_generalized_statuses[station_number][bis_number][nka] = SignalReceptionStatus.OUT_OF_SIGHT

    def define_packets_statuses(self):
        """Функция определяет состояния получения пакетов по всем комбинациям станция-БИС-НКА-сигнал"""
        super().define_packets_statuses()
        self.define_generalized_nka_signal_statuses()

    def define_generalized_nka_signal_statuses(self):
        """
        DEPRECATED??: Пока используется в обобщенном контроле!
        Этот метод раньше отдавал в API обобщенные статусы приема ЦИ и измерений для таблицы по НКА и сигналам.
        Сейчас такой таблицы нет, есть пока только отдельные статусы в контроле поступления ЦИ и измерений (utils.reception_control).

        Этот метод не удален потому, что наверно нужно будет сделать новую таблицу статусов, но возможно статусы будут браться уже из reception_control,
        а также потому, что данные из словаря, который тут заполняется, используются в generalized_op_message, где возможно надо переделать на reception_control
        FIXME Удалить этот метод, если статусы будут считаться по MeasReceptionControl/DIReceptionControl (там тоже есть счетчики)

        Функция определяет обобщённые по всем БИС состояния приёма навигационных сигналов и ЦИ каждого НКА
        """
        for nka, nka_stat in self.nka_statuses.items():
            for signal, signal_stat in nka_stat.items():
                for packet, packet_stat in signal_stat.items():
                    station_status = dict()
                    for station, station_stat in packet_stat.items():
                        station_status[station] = SignalReceptionStatus.OUT_OF_SIGHT
                        for bis, bis_stat in station_stat.items():
                            if self.nka_statuses[nka][signal][packet][station][bis] > station_status[station]:
                                station_status[station] = self.nka_statuses[nka][signal][packet][station][bis]
                    if len(station_status) == 0:
                        status = SignalReceptionStatus.OUT_OF_SIGHT
                    else:
                        status = max(station_status.values())
                        # Если сигнал не принимается, но число станций меньше порогового, то состояние неподтверждено
                        if status == SignalReceptionStatus.UNAVAILABLE:
                            station_num_for_each_status = Counter(station_status.values())
                            if station_num_for_each_status[SignalReceptionStatus.UNAVAILABLE] < \
                                    config['bis_control']['station_receiving_error_threshold']:
                                status = SignalReceptionStatus.UNAVAILABLE_UNCONFIRMED
                    self.nka_signal_generalized_statuses[nka][signal][packet] = status

    def define_generalized_bis_nka_statuses(self):
        """
        @DEPRECATED: Этот метод устарел. Раньше он отдавал в API обобщенные статусы приема ЦИ и измерений для таблицы по НКА для каждого БИС.
        Сейчас такой таблицы нет.
        FIXME Удалить этот метод, если статусы приема от НКА по БИС больше не нужны

        Функция определяет обобщённые по всем сигналам состояния приёма каждого НКА для каждой БИС
        """
        all_bis = cache_bis.get_all().keys()
        for bis_num, station in all_bis:
            for nka, nka_signals in NKA_SIGNALS.items():
                status_list = list()
                for signal in nka_signals:
                    for packet_type in self.nka_statuses[nka][signal].keys():
                        status_list.append(self.nka_statuses[nka][signal][packet_type][station][bis_num])
                status_counter = Counter(status_list)
                c_keys = status_counter.keys()
                if SignalReceptionStatus.OK in c_keys:
                    if SignalReceptionStatus.ERROR not in c_keys and SignalReceptionStatus.UNAVAILABLE not in c_keys:
                        status = SignalReceptionStatus.OK
                    else:
                        status = SignalReceptionStatus.ERROR
                elif SignalReceptionStatus.ERROR in c_keys:
                    status = SignalReceptionStatus.ERROR
                elif SignalReceptionStatus.ERROR_IN_MAYBE in c_keys:
                    if SignalReceptionStatus.UNAVAILABLE not in c_keys:
                        status = SignalReceptionStatus.ERROR_IN_MAYBE
                    else:
                        status = SignalReceptionStatus.ERROR
                elif SignalReceptionStatus.UNAVAILABLE in c_keys:
                    status = SignalReceptionStatus.UNAVAILABLE
                else:
                    status = SignalReceptionStatus.OUT_OF_SIGHT

                self.bis_nka_generalized_statuses[station][bis_num][nka] = status


general_nka_statuses = GeneralNkaReceptionStatus()
