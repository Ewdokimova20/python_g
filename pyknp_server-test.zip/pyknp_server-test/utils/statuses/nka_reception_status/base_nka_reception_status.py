from datetime import datetime, timedelta
from typing import Optional, TYPE_CHECKING, Union

from global_data.appdata import NKA_SIGNALS, MEAS_PACKET_TYPE, DI_PACKET_TYPE, SIGNALS_WITH_DI, SignalTypes
from global_data.config_schema import config
from utils.signals.types import DIOrMeasPacketID
from utils.statuses.nka_reception_status.common import SignalReceptionStatus
from utils.visibility.types import VisibilityStatus

if TYPE_CHECKING:
    from utils.reception_control.message_counters.base_message_counter import BaseMessageCounter
    from utils.visibility.current_visibility.current_visibility import CurrentVisibility
    from utils.visibility.current_visibility.current_visibility_for_client import CurrentVisibilityForClient
    from utils.caches.bis_cache import BisCache


class BaseNkaReceptionStatus:
    """
    Базовый класс для обработки состояний приема навигационных сигналов
    Является родителем для класса дочернего процесса PartialNkaReceptionStatus и GeneralNkaReceptionStatus
    """

    ALLOWED_PACKET_DELAY_FOR_SIGNAL_STATUS = timedelta(seconds=config['bis_control']['allowed_delay_for_signal_status'])
    """Пороговое значение допустимой задержки последнего пакета, с"""

    MEAS_COUNT_THRESHOLD = 5
    """Пороговое значение допустимого числа измерений на интервале проверки, шт."""

    def __init__(self, counter_service, visibility_service, bis_cache):
        self.counter_service = counter_service
        """Инстанс используемого актуального счетчика пакетов (частного или интегрального по всем)"""

        self.visibility_service: Union['CurrentVisibility', 'CurrentVisibilityForClient'] = visibility_service
        """Инстанс используемого экземпляра для текущей видимости (частной или интегральной по всем)"""

        self.saved_total_counter: Optional['BaseMessageCounter'] = None
        """Инстанс с состоянием счетчиков пакетов с момента предыдущего определения"""

        self.bis_cache: Optional['BisCache'] = bis_cache
        """Инстанс кэша БИС"""

        self.time_saved = datetime.now()
        """Время сохранения счётчика пакетов"""

        self.nka_statuses = dict()
        """Состояния приёма сигналов НКА по всем БИС. Уровни: НКА, сигнал, пакет, станция, БИС"""

        self.init_statuses_structures()

    def get_status(self, station: int, bis_number: int, nka: int, signal: int,
                   packet_type: DIOrMeasPacketID) -> Optional['SignalReceptionStatus']:
        """Возвращает статус приема для указанных БИС, НКА, типа сигнала и вида пакета"""
        try:
            return self.nka_statuses[nka][signal][packet_type][station][bis_number]
        except KeyError:
            return None

    def init_statuses_structures(self) -> None:
        """Инициализация структур состояния приёма сигналов"""
        all_bis = self.bis_cache.get_all().keys()
        for nka, nka_signals in NKA_SIGNALS.items():
            self.nka_statuses[nka] = dict()
            for signal in nka_signals:
                self.nka_statuses[nka][signal] = dict()
                self.nka_statuses[nka][signal][MEAS_PACKET_TYPE] = dict()
                if signal in SIGNALS_WITH_DI:
                    self.nka_statuses[nka][signal][DI_PACKET_TYPE] = dict()
                for bis_number, station_number in all_bis:
                    self.nka_statuses[nka][signal][MEAS_PACKET_TYPE].setdefault(station_number, {})
                    self.nka_statuses[nka][signal][MEAS_PACKET_TYPE][station_number][bis_number] \
                        = SignalReceptionStatus.UNDEFINED
                    if signal in SIGNALS_WITH_DI:
                        self.nka_statuses[nka][signal][DI_PACKET_TYPE].setdefault(station_number, {})
                        self.nka_statuses[nka][signal][DI_PACKET_TYPE][station_number][bis_number] \
                            = SignalReceptionStatus.UNDEFINED

    def define_one_packet_status(self, nka, signal, packet, station, bis, time_now):
        """Функция определяет состояния получения пакета для одной кобминации станция-БИС-НКА-сигнал"""
        # По-умолчанию состояние не определено. Если станции или НКА нет в словаре видимости,
        # то состояние останется неопределённым. Если чего-то нет в счётчиках, то состояние останется неопределённым.
        # Так сделано, поскольку наборы счётчиков инициализируются конфигурационными параметрами.
        # Если не задано существование какого-то БИС или НКА, то и состояние по нему определять не следует.
        # Если НКА вне зоны видимости, то и состояние по сигналу будет соответствующее
        # Для ЦИ оцениваем только время последнего прихода пакета. Для измерений: и время последнего прихода, и счётчик
        # Если НКА в зоне необязательного приёма, то в случае отсутствия сигнала выставляется состояние "неопределено"
        # Если нехватает измерений в зоне необязательного приёма, то выставляется особое состояние

        if not self.saved_total_counter:
            return SignalReceptionStatus.OUT_OF_SIGHT

        visibility_status = self.visibility_service.get_status(station, nka)
        if visibility_status <= VisibilityStatus.OUT_OF_SIGHT:
            return SignalReceptionStatus.OUT_OF_SIGHT

        previous_counter_state = self.get_previous_counter_state(station, bis, nka, signal, packet)
        current_counter_state = self.get_current_counter_state(station, bis, nka, signal, packet)

        if not current_counter_state or not previous_counter_state:
            if visibility_status >= VisibilityStatus.GUARANTEED:
                return SignalReceptionStatus.UNAVAILABLE
            else:
                return SignalReceptionStatus.ERROR_IN_MAYBE

        time_difference = time_now - current_counter_state['t']

        return self._calculate_status(packet, time_difference, current_counter_state,
                                      previous_counter_state, visibility_status)

    def _calculate_status(self, packet, time_difference, current_counter_state,
                          previous_counter_state, visibility_status):
        """Вспомогательный метод для расчета статуса"""
        if time_difference <= self.ALLOWED_PACKET_DELAY_FOR_SIGNAL_STATUS:
            if packet == DI_PACKET_TYPE:
                return SignalReceptionStatus.OK
            elif packet == MEAS_PACKET_TYPE:
                packet_delta = current_counter_state['c'] - previous_counter_state['c']
                if packet_delta >= self.MEAS_COUNT_THRESHOLD:
                    return SignalReceptionStatus.OK
                elif visibility_status is VisibilityStatus.MAYBE:
                    return SignalReceptionStatus.ERROR_IN_MAYBE
                else:
                    return SignalReceptionStatus.ERROR
        elif visibility_status is VisibilityStatus.MAYBE:
            return SignalReceptionStatus.UNDEFINED
        else:
            return SignalReceptionStatus.UNAVAILABLE

    def get_previous_counter_state(self, station: int, bis_num: int, nka: int, signal: 'SignalTypes', packet: DIOrMeasPacketID):
        return self.saved_total_counter.get_counter(station, bis_num, nka, signal, packet)

    def get_current_counter_state(self, station: int, bis_num: int, nka: int, signal: 'SignalTypes', packet: DIOrMeasPacketID):
        return self.counter_service.get_counter(station, bis_num, nka, signal, packet)

    def define_packets_statuses(self) -> None:
        """Функция определяет состояния получения пакетов по всем комбинациям станция-БИС-НКА-сигнал и пишет их в свой словарь"""
        time_now = datetime.now()

        for nka, nka_stat in self.nka_statuses.items():
            for signal, signal_stat in nka_stat.items():
                for packet, packet_stat in signal_stat.items():
                    for station, station_stat in packet_stat.items():
                        for bis, bis_stat in station_stat.items():
                            status = self.define_one_packet_status(nka, signal, packet, station, bis, time_now)
                            self.nka_statuses[nka][signal][packet][station][bis] = status

        self.saved_total_counter = self.counter_service.create_snapshot()
        self.time_saved = time_now
