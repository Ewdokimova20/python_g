from utils.statuses.nka_reception_status.base_nka_reception_status import BaseNkaReceptionStatus


class PartialNkaReceptionStatus(BaseNkaReceptionStatus):
    """
    Класс состояний приёма нав. сигналов для процессов обработки (дочерних).
    Вычисляет статусы для использования в этом же процессе, в основной процесс ничего не отправляет (там статусы считаются свои)
    Ожидается, что в процессе обработки будет обрабатываться несколько БИС (3-4), поэтому иерархия по БИС сохранена (не все БИС, поэтому Partial)
    """

    def __init__(self, counter_service, visibility_service, bis_cache):
        super().__init__(counter_service=counter_service, visibility_service=visibility_service, bis_cache=bis_cache)
