from enum import IntEnum


class SignalReceptionStatus(IntEnum):
    """Перечисление флагов приема и годности сигналов"""
    OK = 10  # прием
    UNAVAILABLE_UNCONFIRMED = 5  # неподтвержденное отсутствие сигнала
    ERROR = 4  # нестабильный приём
    ERROR_IN_MAYBE = 3  # сбой в зоне необязательного приёма
    UNAVAILABLE = 2  # отсутствует
    UNDEFINED = 1  # не определено
    OUT_OF_SIGHT = 0  # вне зоны радиовидимости
    NOT_ON_AIR = -1  # сигнал не излучается
