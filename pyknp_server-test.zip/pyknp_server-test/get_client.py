import argparse
import sys  # Импортируем sys для выхода с кодом ошибки

import requests

parser = argparse.ArgumentParser(description='KNP client downloader')
parser.add_argument("-id", dest="project_id", help='Project ID', type=int, required=True)
parser.add_argument("-name", dest="package_name", help='Package Name', required=True)
parser.add_argument("-url", dest="api_url", help='Gitlab API v4 url', default='https://gitlab.iss-reshetnev.ru/api/v4')
parser.add_argument("-token", dest="token", help='Gitlab token', required=True)
args = parser.parse_args()

print(f"Используемые параметры: Project ID={args.project_id}, Package Name={args.package_name}, API URL={args.api_url}")

packages_list_url = f"{args.api_url}/projects/{args.project_id}/packages"
# Используем params для токена, это более безопасно, чем в URL
params = {'private_token': args.token}  # GitLab API использует private_token или job_token

print(f"Запрос списка пакетов: {packages_list_url}")

total_pkg_list = []
page = 1
per_page = 100  # Увеличим кол-во пакетов на страницу для уменьшения запросов

while True:
    try:
        # Делаем запрос для получения пакетов с пагинацией
        packages_list_response = requests.get(packages_list_url, params={**params, 'page': page, 'per_page': per_page})
        packages_list_response.raise_for_status()  # Проверяем на ошибки HTTP (4xx, 5xx)

        packages_list = packages_list_response.json()

        if not packages_list:
            break  # Если список пуст, значит, достигли последней страницы

        total_pkg_list.extend(packages_list)
        print(f"Получено пакетов на странице {page}: {len(packages_list)}")

        # Проверяем, есть ли следующая страница (менее надежно, чем проверка пустого списка, но как альтернатива)
        # if 'next' not in packages_list_response.links:
        #     break
        page += 1

    except requests.exceptions.RequestException as e:
        print(f"Ошибка при получении списка пакетов со страницы {page}: {e}", file=sys.stderr)
        sys.exit(1)  # Выходим с кодом ошибки

if not total_pkg_list:
    print(f"Не найдено ни одного пакета для проекта с ID {args.project_id}", file=sys.stderr)
    sys.exit(1)

print(f"Всего получено пакетов: {len(total_pkg_list)}")

# Фильтруем пакеты по имени и сортируем по ID в убывающем порядке, чтобы найти самый последний
filtered_pakages = [pack for pack in total_pkg_list if pack.get('name') == args.package_name]

if not filtered_pakages:
    print(f"Не найдено пакетов с именем '{args.package_name}' в проекте с ID {args.project_id}", file=sys.stderr)
    sys.exit(1)

filtered_pakages.sort(key=lambda x: x.get('id', 0), reverse=True)  # Используем .get() на случай отсутствия 'id'
target_package = filtered_pakages[0]

print('Найден самый последний пакет с нужным именем:')
print(f"  ID: {target_package.get('id')}")
print(f"  Имя: {target_package.get('name')}")
print(f"  Версия: {target_package.get('version')}")
print(f"  Тип: {target_package.get('package_type')}")

target_package_id = target_package.get('id')
target_package_type = target_package.get('package_type')
target_package_name = target_package.get('name')
target_package_version = target_package.get('version')

if not all([target_package_id, target_package_type, target_package_name, target_package_version]):
    print("Ошибка: Не удалось получить все необходимые данные о целевом пакете.", file=sys.stderr)
    sys.exit(1)

# URL для получения списка файлов пакета
# Согласно документации GitLab API, это /projects/:id/packages/:package_id/package_files
package_file_list_url = f"{args.api_url}/projects/{args.project_id}/packages/{target_package_id}/package_files"
print(f"Запрос списка файлов пакета: {package_file_list_url}")

try:
    package_file_list_response = requests.get(package_file_list_url, params=params)
    package_file_list_response.raise_for_status()  # Проверяем на ошибки HTTP
    file_list = package_file_list_response.json()

except requests.exceptions.RequestException as e:
    print(f"Ошибка при получении списка файлов пакета: {e}", file=sys.stderr)
    sys.exit(1)

if not file_list:
    print(f"Не найдено файлов для пакета '{target_package_name}' версии '{target_package_version}' (ID: {target_package_id})",
          file=sys.stderr)
    sys.exit(1)

print('Список файлов в пакете:')
for file_info in file_list:
    print(f"  - {file_info.get('file_name')} (ID: {file_info.get('id')})")

# В вашем исходном коде брался первый файл из списка. Сохраним это поведение.
# Если нужна другая логика (например, скачать файл с определенным именем), ее нужно будет добавить.
target_file = file_list[0]
target_file_name = target_file.get('file_name')
target_file_id = target_file.get('id')

if not all([target_file_name, target_file_id]):
    print("Ошибка: Не удалось получить все необходимые данные о целевом файле.", file=sys.stderr)
    sys.exit(1)

# URL для скачивания файла. Для urlretrieve токен нужно добавить в URL как параметр.
# Используем private_token, как и в остальных запросах.
file_url = f"{args.api_url}/projects/{str(args.project_id)}/packages/{target_package_type}/{target_package_name}/{target_package_version}/{target_file_name}?access_token={args.token}"
print(f"URL для скачивания файла: {file_url}")

print(f"Начинается скачивание файла '{target_file_name}'...")
try:
    # Используем urlretrieve для скачивания файла
    # Для аутентификации с urlretrieve нужно добавить токен в URL или использовать другую библиотеку
    # requests.get с сохранением в файл может быть более гибким с аутентификацией через params
    # Давайте перейдем на requests.get для консистентности с остальным кодом и лучшей обработки ошибок
    with requests.get(file_url, params=params, stream=True) as r:
        r.raise_for_status()  # Проверяем на ошибки HTTP при скачивании
        with open(target_file_name, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

    print(f'Успешно скачан файл "{target_file_name}" версии "{target_package_version}"')

except requests.exceptions.RequestException as e:
    print(f"Ошибка при скачивании файла '{target_file_name}': {e}", file=sys.stderr)
    sys.exit(1)
except IOError as e:
    print(f"Ошибка при записи файла '{target_file_name}': {e}", file=sys.stderr)
    sys.exit(1)
