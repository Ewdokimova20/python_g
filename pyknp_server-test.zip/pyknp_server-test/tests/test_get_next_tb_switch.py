from datetime import datetime

from utils.SI.si_embedding_verification.utils.get_next_tb_switch import get_next_tb_switch


def test_get_next_tb_switch_before_half_hour():
    # Время: 2025-06-24 11:10:15 (до 30 минут)
    dt = datetime(2025, 6, 24, 11, 10, 15)
    # Ожидаемое время: 2025-06-24 11:30:00
    expected = dt.replace(minute=30, second=0, microsecond=0)
    result = get_next_tb_switch(dt)
    assert result == expected


def test_get_next_tb_switch_at_exact_minute_0():
    # Время: 2025-06-24 11:00:00 (ровно 0 минут)
    dt = datetime(2025, 6, 24, 11, 0, 0)
    # Ожидаемое время: 2025-06-24 11:30:00
    expected = dt.replace(minute=30, second=0, microsecond=0)
    result = get_next_tb_switch(dt)
    assert result == expected


def test_get_next_tb_switch_after_half_hour():
    # Время: 2025-06-24 11:45:00 (после 30 минут)
    dt = datetime(2025, 6, 24, 11, 45, 0)
    # Ожидаемое время: 2025-06-24 12:00:00 (следующий час)
    expected = datetime(2025, 6, 24, 12, 0, 0)
    result = get_next_tb_switch(dt)
    assert result == expected


def test_get_next_tb_switch_at_30_minutes():
    # Время: 2025-06-24 11:30:00 (ровно 30 минут)
    dt = datetime(2025, 6, 24, 11, 30, 0)
    # Ожидаемое время: 2025-06-24 12:00:00 (следующий час)
    expected = datetime(2025, 6, 24, 12, 0, 0)
    result = get_next_tb_switch(dt)
    assert result == expected
