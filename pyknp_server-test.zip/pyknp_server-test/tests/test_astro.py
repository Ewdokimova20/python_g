import datetime
import json

import pytest
from pymatrix import Matrix

from utils.astro import current_celestial_state
from utils.coordinates.coordinates import Coordinates


@pytest.fixture
def test_data():
    # Путь до JSON из эксельки Санжарова
    path = "tests/test_data/astro_efemeride.json"

    with open(path, 'r') as file:
        # Данные из эксельки Санжарова
        data = json.load(file)
    # Смещение антенны, взято из файла Санжарова
    fca_offset = Coordinates.XYZ(x=-0.97500002384185791, y=-0.95999997854232788, z=0.0)
    return data, fca_offset


def test_get_emmit_point(test_data):
    data, fca_offset = test_data
    for json_object in data:
        # Устанавливаем дату и время
        current_celestial_state.recalc_sun_position(
            datetime.datetime(
                json_object['year'],
                json_object['month'],
                json_object['day'],
                json_object['hour'],
                json_object['minute'],
                json_object['seconds'],
            )
        )
        nka_mass_center = Coordinates.XYZ(x=json_object['Xcentrmass'],
                                          y=json_object['Ycentrmass'],
                                          z=json_object['Zcentrmass'])

        # Получаем эмитирующую точку
        x, y, z = current_celestial_state.get_emmit_point(nka_mass_center, fca_offset)

        # Ожидаемые значения
        x_old = json_object['Xphasecentr']
        y_old = json_object['Yphasecentr']
        z_old = json_object['Zphasecentr']

        # Проверка разницы
        diff_x = x_old - x
        diff_y = y_old - y
        diff_z = z_old - z

        assert abs(diff_x) <= 0.00675, f"Разница по X для id {json_object['id']} превышает допустимый предел 0.00675м."
        assert abs(diff_y) <= 0.00675, f"Разница по Y для id {json_object['id']} превышает допустимый предел 0.00675м."
        assert abs(diff_z) <= 0.00675, f"Разница по Z для id {json_object['id']} превышает допустимый предел 0.00675м."


def test_calculate_ort_axes(test_data):
    data, _ = test_data
    for json_object in data:
        # Устанавливаем дату и время
        current_celestial_state.recalc_sun_position(
            datetime.datetime(
                json_object['year'],
                json_object['month'],
                json_object['day'],
                json_object['hour'],
                json_object['minute'],
                json_object['seconds'],
            )
        )

        nka_mass_center = Coordinates.XYZ(x=json_object['Xcentrmass'],
                                          y=json_object['Ycentrmass'],
                                          z=json_object['Zcentrmass'])
        # Вектор координат центра массы КА
        nka_mass_center_matrix = Matrix.from_list([[nka_mass_center.x], [nka_mass_center.y], [nka_mass_center.z]])

        e_r, e_n, e_b = current_celestial_state.calculate_ort_axes(nka_mass_center_matrix)

        assert abs(Matrix.dot(e_r, e_n)) <= 1e-15, f"Векторы e_r и e_n не перпендикулярны для id {json_object['id']}."
        assert abs(Matrix.dot(e_r, e_b)) <= 1e-15, f"Векторы e_r и e_b не перпендикулярны для id {json_object['id']}."
        assert abs(Matrix.dot(e_n, e_b)) <= 1e-15, f"Векторы e_n и e_b не перпендикулярны для id {json_object['id']}."

        # Проверка ориентации системы координат
        orientation_check = Matrix.dot(e_r, Matrix.cross(e_b, e_n))
        assert orientation_check > 0, f"Левая система координат для id {json_object['id']}."
