if __name__ == '__main__':
    print(__name__)
    import time
    from main import prepare_config

    prepare_config()
    from data import *
    from utils.PDOP import PDOPCalculator, AlmanacClass, PDOPThread
    from scripts.run import prepare_db
    from math import asin, pi
    from queue import Queue
    from db.db_connection import db

    y = prepare_db(db)

    alm = AlmanacClass.Almanac()
    a = alm.get_almanac_from_base(5, 7, 986)  # 12 сент 2022
    PDOPcalc = PDOPCalculator.PDOPcalculator()
    PDOPcalc.almanac.get_almanac_from_base(5, 7, 986)
    PDOPcalc.queueout = Queue()

    print('проверка корректности расчета максимального перерыва навигации по известному массиву значений PDOP:')
    # везде и всегда поле доступно
    print('1. везде и всегда поле доступно')
    TERR = 1
    MODE = 1
    np = 65341#7011 #41346
    nt = 200 #2880
    PDOPs = []

    file_object = open('PDOPS_0.txt', 'w')
    for i in range(0, nt, 1):
        #p = []
        for j in range(0, np, 1):
            #p.append(2)
            nn = 2
            file_object.write(nn.__str__())
            file_object.write('\n')
        #PDOPs.append(p)
    file_object.close()

    #print('массив значений PDOP сформирован')
    #PDOPcalc.particalpdops = PDOPs
    #print('значения PDOP присвоены в класс')

    ii = 0
    if ii == 0:
        PDOPcalc.time_points_count = nt
        PDOPcalc.points_count = np
        av0 = PDOPcalc.get_availability(zoneid=TERR, mode=MODE)
    else:
        av0 = '-1'
   # print('доступность рассчитана')
    print(av0)
    print('Доступность: ', av0['Доступность'], 'Максимальный перерыв: ', av0['Максимальный перерыв навигации'])

    # поле доступно почти всегда, введен искусственный перерыв
    print('2. поле доступно почти всегда, введен искусственный перерыв')
    np = 65341 #7011 #41346
    nt = 200 #2880
    pointnum1 = 7000  # условный номер точки, в которой есть перерыв
    breaklen1 = 71  # длительность перерыва
    starttime1 = 15

    pointnum2 = 62150
    breaklen2 = 111
    starttime2 = 53

    file_object = open('PDOPS_0.txt', 'w')
    for i in range(0, nt, 1):
        for j in range(0, np, 1):
            nn = 2
            if (j == pointnum1) & (i >= starttime1) & (i <= (starttime1 + breaklen1)): nn = 7
            if (j == pointnum2) & (i >= starttime2) & (i <= (starttime2 + breaklen2)): nn = 7
            file_object.write(nn.__str__())
            file_object.write('\n')
        #PDOPs.append(p)
    file_object.close()
    PDOPcalc.particalpdops = PDOPs
    ii = 0
    if ii == 0:
        av1 = PDOPcalc.get_availability(zoneid=TERR, mode=MODE)
    else:
        av1 = '-1'
    #print('доступность рассчитана')
    print(av1)
    print('Доступность: ', av1['Доступность'], 'Максимальный перерыв: ', av1['Максимальный перерыв навигации'])

    ## везде и всегда поле недоступно
    print('3. везде и всегда поле недоступно')
    np = 65341#7011#41346
    nt = 200#2880
    file_object = open('PDOPS_0.txt', 'w')
    for i in range(0, nt, 1):
        #p = []
        for j in range(0, np, 1):
            #p.append(2)
            nn = 7
            file_object.write(nn.__str__())
            file_object.write('\n')
        #PDOPs.append(p)
    file_object.close()
    av2 = PDOPcalc.get_availability(zoneid=TERR, mode=1)
    print('Доступность: ', av2['Доступность'], 'Максимальный перерыв: ', av2['Максимальный перерыв навигации'])




    TERR = 0
    a2 = PDOPcalc.get_pdop_for_date_grid_and_constellation(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], TERR, 12, 9, 2022, 1)
    av2 = PDOPcalc.get_availability(zoneid=TERR, mode=1)
    print('Доступность: ', av2['Доступность'], 'Максимальный перерыв: ', av2['Максимальный перерыв навигации'])

    a3 = PDOPcalc.get_pdop_for_date_grid_and_constellation(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], TERR, 12, 9, 2022, 0)
    av3 = PDOPcalc.get_availability(zoneid=TERR, mode=0)
    print('Доступность: ', av3['Доступность'], 'Максимальный перерыв: ', av3['Максимальный перерыв навигации'])




    # проверка возможности параллельного запуска двух расчетов PDOP с разными режимами.

    PDOPcalc2 = PDOPCalculator.PDOPcalculator()  # экземпляр класса
    PDOPcalc2.almanac.get_almanac_from_base(5, 7, 986)
    q2 = Queue()
    PDOPcalc2.queueout = q2

    PDOPcalc3 = PDOPCalculator.PDOPcalculator()
    PDOPcalc3.almanac.get_almanac_from_base(5, 7, 986)
    q3 = Queue()
    PDOPcalc3.queueout = q3

    PDOPcalc4 = PDOPCalculator.PDOPcalculator()
    PDOPcalc4.almanac.get_almanac_from_base(5, 7, 986)
    q4 = Queue()
    PDOPcalc3.queueout = q4


    PDOPcalc5 = PDOPCalculator.PDOPcalculator()
    PDOPcalc5.almanac.get_almanac_from_base(5, 7, 986)
    q5 = Queue()
    PDOPcalc3.queueout = q5


    thr1 = PDOPThread.PDOPThread()
    thr2 = PDOPThread.PDOPThread()
    thr3 = PDOPThread.PDOPThread()
    thr4 = PDOPThread.PDOPThread()
    thr1.PDOPcalc = PDOPcalc2
    thr2.PDOPcalc = PDOPcalc3
    thr3.PDOPcalc = PDOPcalc4
    thr4.PDOPcalc = PDOPcalc5

    #thr1.createthread(
    #    [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 1, 12, 9, 2022, q2, 0])

   # thr2.createthread(
   #     [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 1, 12, 9, 2022, q3,  1])

  #  thr3.createthread(
 #       [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 0, 12, 9, 2022,  q4, 0])

    #thr4.createthread(
#        [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 0, 12, 9, 2022,  q5, 1])

    #print('2: ', PDOPcalc2.result_PDOP)
    #print('3: ', PDOPcalc3.av)
    #print('4: ', PDOPcalc4.result_PDOP)
    #print('5: ', PDOPcalc5.av)

    for i in range(0, 0, 1):
        time.sleep(1)
        print(i, ':  ', thr1.getstatepercentage(), thr2.getstatepercentage(), thr3.getstatepercentage(), thr4.getstatepercentage())
        print('2: ', PDOPcalc2.result_PDOP)
        print('3: ', PDOPcalc3.av)
        print('4: ', PDOPcalc4.result_PDOP)
        print('5: ', PDOPcalc5.av)


    alm = AlmanacClass.Almanac()
    a = alm.get_almanac_from_base(5, 7, 986)  # 12 сент 2022
    PDOPcalc = PDOPCalculator.PDOPcalculator()
    PDOPcalc.almanac.get_almanac_from_base(5, 7, 986)
    PDOPcalc.queueout = Queue()

    # проверка расчета доступности (с предварительным расчетом PDOP и подгрузкой из файла)
    #PDOPcalc.get_point_grid(zone=0, mode=0) # для расчета достпуности по загруженному списку частных PDOP, необходимо искуственно сформировать сетку точек, так ка она отсутствует в экземпляре класса.
    #st1 = time.perf_counter()
    #PDOPcalc.read_PDOPS_from_file('PDOP_and_avail_2023_02_14.txt', 41346, 2881) # загрузка из файла (около 5 минут), на 1 сутки с шагом 30 сек, глобально. минус 4 Гб ОЗУ
    # если бы проводился штатный расчет, это заняло бы около 6 часов.
    #en1 = time.perf_counter()
    #st2 = time.perf_counter()
    #q = PDOPcalc.get_availability(1) #расчет доступности по загруженному списку частных PDOP (* строго говоря, рассчитывается не только доступность, но и максимальный перерыв навигации)
    #en2 = time.perf_counter()

    #print('длительность считывания файла с PDOP: ', en1 - st1)
    #print('длительность расчета доступности: ', en2 - st2)
    #print('результат расчета доступности: ', q)


    ## сравнение 2-х функций расчета УМ КА
    compare = 0
    if (compare == 1):
        point = [-4681214.280546703, -787543.5600413944, 4245603.216247341]
        alm = AlmanacClass.Almanac()
        a = alm.get_almanac_from_base(5, 7, 986)  # 12 сент 2022

        n = 100000
        for j in range(0, 1, 1):
            s1 = time.perf_counter()
            for i in range(0, n, 1):
                el1 = AlmanacClass.get_elevation_angle(alm, 0, point, 1)
            s2 = time.perf_counter()
            print(s2 - s1)
        s3 = time.perf_counter()
        for i in range(0, n, 1):
            satellite_xyzs = alm.alman_to_xyz(0)
            vkp = satellite_xyzs[1 - 1 * 0]
            geometrical_distance = ((vkp[0] - point[0]) ** 2 + (vkp[1] - point[1]) ** 2 + (vkp[2] - point[2]) ** 2) ** (
                0.5)
            k_x = (vkp[0] - point[0]) / geometrical_distance
            k_y = (vkp[1] - point[1]) / geometrical_distance
            k_z = (vkp[2] - point[2]) / geometrical_distance
            from utils.PDOP.AlmanacClass import r_earth

            r_bis_length = ((point[0]) ** 2 + (point[1]) ** 2 + (point[2]) ** 2) ** (0.5)
            el2 = asin(((k_x * point[0])
                        + (k_y * point[1])
                        + (k_z * point[2])) / r_bis_length) * 180.0 / pi
        s4 = time.perf_counter()

        print('Расчет через т кос: ', s4 - s3, 'Расчет из методики', s2 - s1)
        print(el1 - el2)



    GLOB = 1
    RUS = 0
    TERR = GLOB#0 * RUS + 1 * GLOB
    time_start1 = time.perf_counter()
    # расчет PDOP
    MODE = 1 #
    PDOP = PDOPcalc.get_pdop_for_date_grid_and_constellation(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], TERR, 12, 9, 2022, mode=MODE)
    time_end1 = time.perf_counter()
    print(time_end1 - time_start1, PDOP)
    # сохранение PDOP в файл
    PDOPcalc.save_PDOPs_to_file('PDOP_and_avail_2023_03_01.txt')
    print(time_end1 - time_start1)
    # расчет доступности
    time_start2 = time.perf_counter()
    PDOPcalc.get_point_grid(TERR, MODE)
    Availability = PDOPcalc.get_availability(TERR, MODE)
    time_end2 = time.perf_counter()
    # запись метаданных в файл
    with open('PDOP_and_avail_2023_03_01_1.txt', 'w') as file_object:
        file_object.write(Availability['Доступность'].__str__())
        file_object.write('\n')
    with open('PDOP_and_avail_2023_03_01_1.txt', 'a') as file_object:
#        file_object.write(Availability['всего точек в перерывами'].__str__())
        file_object.write('\n')
    with open('PDOP_and_avail_2023_03_01_1.txt', 'a') as file_object:
        file_object.write(Availability['Максимальный перерыв навигации'].__str__())
        file_object.write('\n')
    with open('PDOP_and_avail_2023_03_01_1.txt', 'a') as file_object:
 #       for i in Availability['Номера точек и моментов времени, где PDOP < 6 ']: file_object.write(i.__str__())
        file_object.write('\n')
    with open('PDOP_and_avail_2023_03_01_1.txt', 'a') as file_object:
        file_object.write('Число точек во времени:')
        file_object.write(PDOPcalc.time_points_count.__str__())
        file_object.write('\n')
    with open('PDOP_and_avail_2023_03_01_1.txt', 'a') as file_object:
        file_object.write('Число точек в пространстве:')
        file_object.write(PDOPcalc.points_count.__str__())
        file_object.write('\n')
    file_object.close()

#    PDOPcalc.read_PDOPS_from_file('PDOP_and_avail_2023_03_01.txt', PDOPcalc.points_count, PDOPcalc.time_points_count)
#    q = PDOPcalc.get_availability(TERR, MODE)
#    print(q)
