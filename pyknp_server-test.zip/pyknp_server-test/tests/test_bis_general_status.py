from collections import defaultdict
from unittest.mock import patch, MagicMock

import pytest

# Мокаем все проблемные импорты перед импортом класса

with patch.dict('sys.modules', {
    'utils.caches': MagicMock(),
    'utils.caches.cache_bis': MagicMock(),
    'utils.reception_control.message_counters.general_message_counter': MagicMock(),
    'utils.statuses.bis_connection.get_current_bis_connection_status': MagicMock(),
}):
    from utils.statuses.bis_connection.types import BisConnectionStatus
    from utils.statuses.bis_connection.types import BisGeneralConnectionStatus
    from utils.statuses.bis_connection.bis_connection_state import BisConnectionState


@pytest.fixture
def bis_connection_state():
    bis_state = BisConnectionState()
    bis_state.state = defaultdict(lambda: defaultdict(lambda: BisConnectionStatus.UNDEFINED))
    return bis_state


class TestBisConnectionStateGeneralStatus:

    def set_state(self, bis_state, states):
        """
        Заполняет bis_state.state тестовыми данными.
        states: list of tuples (station, bis, status)
        """
        for station, bis, status in states:
            bis_state.state[station][bis] = status

    def test_ok_and_undefined(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.OK),
            (1, 18, BisConnectionStatus.UNDEFINED),
            (2, 17, BisConnectionStatus.OK),
            (2, 18, BisConnectionStatus.UNDEFINED),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.OK

    def test_undefined_packet_error_and_fault_three(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.PACKET_ERROR),
            (2, 17, BisConnectionStatus.FAULT),
            (2, 18, BisConnectionStatus.FAULT),
            (3, 17, BisConnectionStatus.FAULT),
            (3, 18, BisConnectionStatus.UNDEFINED),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_FAULT

    def test_undefined_packet_error_fault_three_ok_five(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.PACKET_ERROR),
            (2, 17, BisConnectionStatus.FAULT),
            (2, 18, BisConnectionStatus.FAULT),
            (3, 17, BisConnectionStatus.FAULT),
            (3, 18, BisConnectionStatus.UNDEFINED),
            (4, 17, BisConnectionStatus.OK),
            (4, 18, BisConnectionStatus.OK),
            (5, 17, BisConnectionStatus.OK),
            (5, 18, BisConnectionStatus.OK),
            (6, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_FAULT

    def test_undefined_packet_error_and_ok_five(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.PACKET_ERROR),
            (2, 17, BisConnectionStatus.OK),
            (2, 18, BisConnectionStatus.OK),
            (3, 17, BisConnectionStatus.OK),
            (3, 18, BisConnectionStatus.OK),
            (4, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_PACKET_ERROR

    def test_undefined_fault_and_ok_five(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.FAULT),
            (2, 17, BisConnectionStatus.OK),
            (2, 18, BisConnectionStatus.OK),
            (3, 17, BisConnectionStatus.OK),
            (3, 18, BisConnectionStatus.OK),
            (4, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_FAULT

    def test_undefined_and_all_fault(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.UNDEFINED),
            (2, 17, BisConnectionStatus.FAULT),
            (2, 18, BisConnectionStatus.FAULT),
            (3, 17, BisConnectionStatus.FAULT),
            (3, 18, BisConnectionStatus.FAULT),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.FAULT

    def test_undefined_and_all_packet_error(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.UNDEFINED),
            (2, 17, BisConnectionStatus.PACKET_ERROR),
            (2, 18, BisConnectionStatus.PACKET_ERROR),
            (3, 17, BisConnectionStatus.PACKET_ERROR),
            (3, 18, BisConnectionStatus.PACKET_ERROR),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisConnectionStatus.PACKET_ERROR

    def test_all_undefined(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.UNDEFINED),
            (1, 18, BisConnectionStatus.UNDEFINED),
            (2, 17, BisConnectionStatus.UNDEFINED),
            (2, 18, BisConnectionStatus.UNDEFINED),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.UNDEFINED

    def test_mixed_fault_and_ok(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.FAULT),
            (1, 18, BisConnectionStatus.OK),
            (2, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_FAULT

    def test_mixed_packet_error_and_ok(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.PACKET_ERROR),
            (1, 18, BisConnectionStatus.OK),
            (2, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_PACKET_ERROR

    def test_mixed_fault_and_packet_error(self, bis_connection_state):
        states = [
            (1, 17, BisConnectionStatus.FAULT),
            (1, 18, BisConnectionStatus.PACKET_ERROR),
            (2, 17, BisConnectionStatus.OK),
        ]
        self.set_state(bis_connection_state, states)
        # Приоритет SOME_FAULT, т.к. есть FAULT
        assert bis_connection_state.get_general_status() == BisGeneralConnectionStatus.SOME_FAULT
