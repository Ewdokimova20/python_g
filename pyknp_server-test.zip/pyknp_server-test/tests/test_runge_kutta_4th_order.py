import pytest

from models.common import next_state
from utils.coordinates.coordinates import Coordinates


@pytest.fixture
def setup_calculate():
    t_start = 11700
    t_stop = 12300
    step = 60
    delta = 0.0005
    init_coordinates, expected_values = calculate_final_state(t_start, t_stop, step)
    return init_coordinates, expected_values, delta


def calculate_final_state(t_start, t_stop, step):
    # Перевод в метры
    x, y, z = (el * 1e3 for el in (7003.008789, -12206.626953, 21280.765625))
    Vx, Vy, Vz = (el * 1e3 for el in (0.7835417, 2.8042530, 1.3525150))
    ax, ay, az = (el * 1e3 for el in (0, 1.7 * 1e-09, -5.41 * 1e-09))

    # Проверочные значения
    x_check, y_check, z_check = (el * 1e3 for el in (7523.174853, -10506.961865, 21999.238892))
    Vx_check, Vy_check, Vz_check = (el * 1e3 for el in (0.950126101, 2.855688134, 1.040678119))

    xyz = Coordinates.XYZ(x=x, y=y, z=z)
    vel = Coordinates.Vxyz(Vx=Vx, Vy=Vy, Vz=Vz)
    acc = Coordinates.Axyz(Ax=ax, Ay=ay, Az=az)

    init_coordinates = Coordinates(xyz=xyz, vel=vel, acc=acc)

    for _ in range(1, t_stop - t_start, step):
        init_coordinates = next_state(init_coordinates, step)

    return init_coordinates, (x_check, y_check, z_check, Vx_check, Vy_check, Vz_check)


def test_check_x(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    x = init_coordinates.xyz[0]
    expected_x = expected_values[0]
    assert abs(x - expected_x) < delta, f"Проверочное значение x: {expected_x}, полученное значение: {x}"


def test_check_y(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    y = init_coordinates.xyz[1]
    expected_y = expected_values[1]
    assert abs(y - expected_y) < delta, f"Проверочное значение y: {expected_y}, полученное значение: {y}"


def test_check_z(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    z = init_coordinates.xyz[2]
    expected_z = expected_values[2]
    assert abs(z - expected_z) < delta, f"Проверочное значение z: {expected_z}, полученное значение: {z}"


def test_check_Vx(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    Vx = init_coordinates.vel[0]
    expected_Vx = expected_values[3]
    assert abs(Vx - expected_Vx) < delta, f"Проверочное значение x: {expected_Vx}, полученное значение: {Vx}"


def test_check_Vy(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    Vy = init_coordinates.vel[1]
    expected_Vy = expected_values[4]
    assert abs(Vy - expected_Vy) < delta, f"Проверочное значение y: {expected_Vy}, полученное значение: {Vy}"


def test_check_Vz(setup_calculate):
    init_coordinates, expected_values, delta = setup_calculate
    Vz = init_coordinates.vel[2]
    expected_Vz = expected_values[5]
    assert abs(Vz - expected_Vz) < delta, f"Проверочное значение z: {expected_Vz}, полученное значение: {Vz}"
