print ("Hello")

if __name__ == '__main__': # точка входа для независимого запуска
    print(__name__)
    import time
    from main import prepare_config

    prepare_config()

    from data import *
    from utils.PDOP import PDOPCalculator, AlmanacClass
    from utils.PDOP.AlmanacClass import get_date_by_n4_na, get_n4_na_by_date, get_elevation_angles, get_visibility_intervals
    from utils.PDOP.PDOPCalculator import lat_lon_to_xyz
    from scripts.run import prepare_db
    from utils.PDOP.AlmanacClass import NKA_almanac
    from queue import Queue
    from db.db_connection import db

    print(get_n4_na_by_date(2023,7,3))
    y = prepare_db(db)

    print(y)

    # демонстрация работы функций классов для расчета PDOP и работы с Альманахом
    points = []
    points.append([0, 3197.1e3, 5500.48*1e3])
    points.append([1999.026545*1e3, 1e3 * 2963.68, 5264.44 * 1e3])

    alm = AlmanacClass.Almanac()
    r = alm.get_almanac_from_base(5, 7, 986) #alm.get_almanac_from_base(5, 7, 979) # 5 сент 22 #alm.getalmanacfrombase(2, 7, 975) # 22 авг 2022 #alm.getalmanacfrombase(1, 7, 965) # 22 авг 2022
    print('Загруженный альманах: \n ', alm.almdict)

    # верификация функций расчета даты по N4, Na и наоборот.
    for i in range(1, 1462, 1):
        x = get_date_by_n4_na(4, i)
        y = get_n4_na_by_date(x[2], x[1], x[0])

    date = get_date_by_n4_na(alm.almdict[1].N4, alm.almdict[1].Na) # alm.alm['Na']
    print('Дата альманаха: \n', date)

    nkas0 = [1, 3, 5]

    time_start = 0
    time_end = 86400
    time_step = 1000
    time1 = range(time_start, time_end, time_step)
    Na1 = 986
    els = get_elevation_angles(alm, time_start, time_end, time_step, points, nkas0)
    print('Углы места: \n', els)
    npoint = 0
    nkas = 0
    ntime = 0
    n = 0
    for i in els: # по КА
        ntime = ntime + 1
        npoint = 0
        for j in i:
            npoint = npoint + 1
            nkas = 0
            for k in j:
                n = n +1
                nkas = nkas + 1
                print('Номер ',n , ' КА ', nkas0[nkas-1], 'Точка ', npoint, 'время', time1[ntime-1], 'Угол места: ', k, 'градусов')
        #nkas = 0

    vis_intervals = get_visibility_intervals(alm, points, [1, 3, 9], 5, time_start, time_end, time_step)
    print('Рассчитанные интервалы радиовидимости: \n', vis_intervals)

    satellite_xyz = alm.alman_to_xyz(0)
    print('Координаты КА на начальный момент времени: \n', satellite_xyz)

    # расчет PDOP
    PDOPc = PDOPCalculator.PDOPcalculator()
    PDOPc.almanac = alm
    PDOPc.queueout = Queue()

    PDOP = PDOPc.get_pdop_for_grid_and_time_interval(time_start, time_end, time_step, points, 5)
    print('Значения PDOP: \n', PDOP)

    pdopcalc = PDOPCalculator.PDOPcalculator()
    grid = pdopcalc.get_point_grid(0, mode=0)
    print('неравномерная сетка (РФ): ', len(grid), '\n')

    grid2 = pdopcalc.get_point_grid(0, mode=1)
    print('равномерная сетка (РФ): ', len(grid2), '\n')

    grid3 = pdopcalc.get_point_grid(1, mode=0)
    print('неравномерная сетка (глоб): ', len(grid3), '\n')

    grid4 = pdopcalc.get_point_grid(1, mode=1)
    print('равномерная сетка (глоб): ', len(grid4), '\n')


    f = open('D:\Work_Krat\Programs\Python\PDOP\XYZs.txt', 'w') # вывод рассчитанных координат точек в файл для проверки
    for xyz in grid:
        s = xyz[0].__str__()
        f.write(s)
        f.write(' ')
        s = xyz[1].__str__()
        f.write(s)
        f.write(' ')
        s = xyz[2].__str__()
        f.write(s)
        f.write('\n')

    print(get_n4_na_by_date(2001, 9, 6))  # 615 из ИКД
    print(get_n4_na_by_date(2022, 7, 15)) # 927
    print(get_date_by_n4_na(7, 1452))
    print(get_date_by_n4_na(7, 615))  # 6 сентября 2021
    print(get_date_by_n4_na(7, 926))  # 14 июля 2022
    print(get_date_by_n4_na(7, 965))  # 22 августа 2022

    nka_mask = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

    rus = 0
    glob = 1

    #nka_mask = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    #nka_mask = [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1]
    #NKAmask = [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1]
    # [730, 747, 744, 759, 756, 733, 745, 743, 702, 723, 705 (753), 758, 721, 752, 757, 736, 751, 754, 720, 719, 755, 706 (735), 732, 760]

    tic = time.perf_counter()
    #PDOP = PDOPCalculator.PDOPcalculator.GetPDOPforDateGridAndConstellation(PDOPCalculator, NKAmask, Rus, 14, 7, 2022)

    #PDOP = PDOPCalculator.PDOPcalculator.getpdopfordategridandconstellation(PDOPCalculator, NKAmask, Rus, 5, 9, 2022)
    PDOPc = PDOPCalculator.PDOPcalculator()
    PDOPc.almanac = alm
    PDOPc.queueout = Queue()
    nka_mask = [1, 2, 3 ,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
    PDOP = PDOPc.get_pdop_for_date_grid_and_constellation(nka_mask, glob, 12, 9, 2022, mode=0)
    toc = time.perf_counter()

    #print(PDOP)
    print('РФ:')
    print('Длительность рассчета, сек: ', toc - tic)
    print('средний PDOP без ограничения (<6): ', PDOP['out']['PDOP0'])
    print('средний PDOP с ограничением: ', PDOP['out']['PDOP'])
    print('Уровень доступности (не по 243): ', PDOP['out']['availability'])

    #fn = 'D:\Work_Krat\Programs\Python\PDOPforKNPServer\pyknp_server\PDOPrus.txt'
    fn = 'D:\Work_Krat\Programs\Python\PDOPforKNPServer\pyknp_server\PDOP.txt'
    f2 = open(fn, 'w')
    for i in PDOPc.particalpdops:
        for j in i:
            s = j.__str__()
            f2.write(s)
            f2.write('\n')
    f2.close()

    # расчет геометрического фактора для Евпатории по КА, излучающим L3
    eupatory = [[45.2, 33.3]] # координаты Евпатории
    # [730, 747, 744, 759, 756, 733, 745, 743, 702, 723, 705 (753), 758, 721, 752, 757, 736, 751, 754, 720, 719, 755, 706 (735), 732, 760]
    #nka_mask = [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1]
    #nka_mask = [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1]# без 57
    nka_mask = [4,5,11,12,15,21,24] #[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]

    alm.get_almanac_from_base(5, 7, 986) # загрузили из базы за 6 сетнября 2022 альманах на 5е сентября
    grid_xyz = lat_lon_to_xyz(eupatory)
    [day, month, year] = get_date_by_n4_na(7, 986)
    pdop_eup = PDOPc.get_pdop_for_point_and_time_interval(0, 86400*14, 300, grid_xyz[0], 5)#PDOPc.get_pdop_for_date_grid_and_constellation(nka_mask, 0, day, month, year, mode=0)
    #print(pdopeup)

    fn = 'D:\Work_Krat\Programs\Python\PDOPforKNPServer\pyknp_server\PDOP_Eupatory2908-1109.txt'
    f2 = open(fn, 'w')
    for i in pdop_eup:
        s = i.__str__()
        f2.write(s)
        f2.write('\n')
    f2.close()

    # расчет зон вимимости КА в системной точке № 22 из Красноярска
    del alm
    alm = AlmanacClass.Almanac()
    alm.get_almanac_from_base(5, 7, 986)
    xyz = lat_lon_to_xyz([[56, 93]])
    time_start = 0
    time_stop = 86400 * 2
    time_step = 300
    #for i in range(0,24,1):
    #    print(i)
    #if (i!=21):  alm.alm.__delitem__(i)

    el = get_elevation_angles(alm, time_start, time_stop, time_step, xyz, [21]) # 21 - это номер элемента в массиве,и не имеет отношения к системному номеру, нужно будет поправить  # КА нумеруются от нуля, 21 элемент  = 22 я системная точка
    vis = get_visibility_intervals(alm, xyz, [21], 5, time_start, time_stop, time_step)
    print(el)
    for i in el: print(i[0][0])
    print(vis)

    from utils.PDOP.AlmanacClass import Almanac
    alm1 = Almanac(**{})
    alm2 = Almanac(**{'n4': 7, 'na': 986,'nnka': 5})
    alm3 = Almanac(**{'dd': 12, 'mm': 9, 'yyyy': 2022, 'nnka': 5})
    alm4 = Almanac(**{'dd': 12, 'mm': 9, 'yyyy': 2022, 'nnka': 5})

    PDOPc2 = PDOPCalculator.PDOPcalculator()
    PDOPc2.almanac = alm4
    PDOPc2.queueout = Queue()
    nka_mask2 = list(range(1, 25, 1)) #[1, 2, 3 ,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
    PDOP2 = PDOPc2.get_pdop_for_date_grid_and_constellation(nka_mask2, glob, 12, 9, 2022, mode=0)

    nka_template0 = NKA_almanac(0, 27, 22, 4, 985, 0, 0, 0, 0, 0.005, 0, 0 ,0)
    alm4.append_nka_to_almanac(27, nka_template0)
    s = alm4.alman_to_xyz(0)

    PDOPc3 = PDOPCalculator.PDOPcalculator()
    PDOPc3.almanac = alm4
    PDOPc3.queueout = Queue()
    nka_mask3 = list(range(1, 25, 2)) #[1, 2, 3 ,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
    PDOP3 = PDOPc3.get_pdop_for_date_grid_and_constellation(nka_mask3, glob, 12, 9, 2022, mode=0)

    PDOPc4 = PDOPCalculator.PDOPcalculator()
    PDOPc4.almanac = alm4
    PDOPc4.queueout = Queue()
    nka_mask4 = list(range(1, 25, 8)) #[1, 2, 3 ,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
    PDOP4 = PDOPc4.get_pdop_for_date_grid_and_constellation(nka_mask4, glob, 12, 9, 2022, mode=0)

    print('qwe')

