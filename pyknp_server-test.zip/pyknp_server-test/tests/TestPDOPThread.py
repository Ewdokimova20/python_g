print ("Hello")

if __name__ == '__main__': # точка входа для независимого запуска
    print(__name__)
    import time
    from main import prepare_config

    prepare_config()
    from data import *
    from utils.PDOP import PDOPCalculator, AlmanacClass, PDOPThread
    from scripts.run import prepare_db
    from utils.PDOP.AlmanacClass import NKA_almanac
    from math import sin, cos, acos

    y = prepare_db(db)

    print(y)

    Points = []
    Points.append([0, 1e3*3197.1, 5500.48*1e3])
    Points.append([1999.026545*1e3, 1e3 * 2963.68, 5264.44 * 1e3])

    alm = AlmanacClass.Almanac()
    a = alm.get_almanac_from_base(5, 7, 986) # 12 сент 2022
    PDOPcalc = PDOPCalculator.PDOPcalculator()
    PDOPcalc.almanac.get_almanac_from_base(5,7,986)
    from queue import Queue
    PDOPcalc.queueout = Queue()

    xyz = alm.alman_to_xyz(0)

    for i in range(1, 25, 1): print(xyz[i])

    alm2 = AlmanacClass.Almanac() # проверка примера из ИКД с КР
    template = NKA_almanac(0,0,0,0,0,33571.625,0.01953124999975,-0.00012947082519531,6.103515625e-5,0.000432968139648438,0.57867431640625,-0.29396724009277,1)
    a2 = alm2.append_nka_to_almanac(0, template)
    x2 = alm2.alman_to_xyz(86400 + 51300)
    xe = [10697.116424527978 * 1e3, 21058.292414091822 * 1e3, -9635.6794316575106 * 1e3, -0.68610081793104882 * 1e3, -1.1365486509759850 * 1e3, -3.2499858708515017 * 1e3] # эталонный ВКП из ИКД
    for i in range(0, 6, 1): print(x2[0][i]-xe[i])


    alm3 = AlmanacClass.Almanac()
    template3 = NKA_almanac(0,0,0,0,0,27122.09375,-2655.76171875,0.011929512,0.000549316,0.001482010,0.440277100,-0.189986229, 0)
    a3 = alm3.append_nka_to_almanac(0,template3)
    x3 = alm3.alman_to_xyz(33300)
    xe2 = [10947.021572 * 1e3, 13078.978287 * 1e3, 18922.03362 * 1e3, -3.375497 * 1e3, -0.161453 * 1e3, 2.060844 * 1e3] # эталонный ВКП из ИКД
    print('проверка примера из ИКД с ЧР: ')
    print('разность по X: ', xe2[0] - x3[0][0])
    print('разность по Y: ', xe2[1] - x3[0][1])
    print('разность по Z: ', xe2[2] - x3[0][2])
    #for i in range(0, 6, 1): print(x3[0][i]-xe2[i])

    PDOPcalc = PDOPCalculator.PDOPcalculator()
    PDOPcalc.almanac.get_almanac_from_base(5, 7, 986)
    from queue import Queue
    PDOPcalc.queueout = Queue()

    P = PDOPcalc.get_pdop_for_point_and_moment(29880, -4681214.280546703, -787543.5600413944, 4245603.216247341, 5)

    P = PDOPcalc.get_pdop_for_point_and_moment_multi(29880, -4681214.280546703, -787543.5600413944, 4245603.216247341, 5)
#    for time1 in range(0, 12*10800, 60): # код для верификации функции расчета координат КА по альманаху
#        P2 = PDOPcalc.get_pdop_for_point_and_moment(time1, -4681214.280546703, -787543.5600413944, 4245603.216247341, 5)
#        print(P2)

    thr1 = PDOPThread.PDOPThread()
    thr2 = PDOPThread.PDOPThread()

    q0 = Queue
    q1 = Queue

    #thr1.createthread([[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 1, 12, 9, 2022, q0, 0])
    thr2.createthread([[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 1, 12, 9, 2022, q1, 1])

    PDOP = PDOPcalc.get_pdop_for_date_grid_and_constellation(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 0, 12, 9, 2022, 1)

    print('1. запрос состояния расчта без его предварительного запуска.')
    Pthr = PDOPThread.PDOPThread()
    print(Pthr.getstatus(), Pthr.getcomment()) # true означает, что ведется расчет, false - что расчет не начат или уже завершен (thread.is_alive)
    print(Pthr.getresult())

    Rus = 0
    print('2. запуск расчета и запрос его статуса и результата (до завершения)')
    NKAmask = [tmpvar for tmpvar in range(1, 25, 1)]
    Pthr.createthread([NKAmask, Rus, 12, 9, 2022, q0, 0]) # запуск потока
    print(Pthr.getthreadstatus(), Pthr.getstatus(), Pthr.getcomment())
    print(Pthr.getresult())

    print('3. запуск расчета и запрос его статуса и результата (после завершения) - ожидайте 60 секунд')
    NKAmask = [tmpvar for tmpvar in range(1, 25, 1)]
    Pthr.createthread([NKAmask, Rus, 12, 9, 2022]) # запуск потока
    print(Pthr.getthreadstatus(), Pthr.getcomment())
    time.sleep(60)
    print(Pthr.getthreadstatus(), Pthr.getcomment())
    print(Pthr.getresult()['PDOP0']) # отображаю только срнеднее значение PDOP без ограничения (<=>6), чтобы не заполнять вывод.
    result = Pthr.getresult()

    time.sleep(300)
    print('4. запуск расчета и запрос его статуса и результата (после принудительной остановки)')
    NKAmask = [tmpvar for tmpvar in range(1, 25, 1)]
    Pthr.createthread([NKAmask, Rus, 12, 9, 2022])  # запуск потока
    Pthr.stop()
    time.sleep(1)
    print(Pthr.getthreadstatus(), Pthr.getcomment())
    print(Pthr.getresult()['PDOP0'])

    for second_test_num in range(0, 4, 1): # переменная для проверки во второй "пачке" тестов ()
        Pthr = PDOPThread.PDOPThread()
        NKAmask = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24] # !!!
        NKAmask = [tmpvar for tmpvar in range(1, 25, 1)]
        Pthr.createthread([NKAmask, Rus, 12, 9, 2022])

        if second_test_num == 1: Pthr.createthread([NKAmask, Rus, 12, 9, 2022]) # тест для проверки корректности принудительного закрытия потока, если расчет уже был запущен

        print('*' * 30, second_test_num, '*' * 30)
        for show_state_and_percent_num in range(0, 17, 1):
            print(Pthr.getcomment())    #print(Pthr.PDOPcalc.comment)
            if Pthr.getcomment() == 'FINISHED': print(Pthr.PDOPcalc.result_PDOP)
            print(Pthr.PDOPcalc.result_PDOP['PDOP0'], Pthr.PDOPcalc.result_PDOP['PDOP']) #, Pthr.PDOPcalc.result_PDOP['Availability']) #print(Pthr2.PDOPcalc.result_PDOP)
            if ((len(Pthr.q0.queue) == 0) & (Pthr.getcomment == 'FINISHED')): print('FINISHED'); print('!!!'); print(Pthr.PDOPcalc.result_PDOP['PDOP0'], Pthr.PDOPcalc.result_PDOP['PDOP'], Pthr.PDOPcalc.result_PDOP['availability'])
            if (len(Pthr.q0.queue) == 1):
                print(Pthr.q0.queue[0])
                Pthr.q0.get(0)
            if (second_test_num == 2) & (show_state_and_percent_num == 3):
                Pthr.stop()
                print(show_state_and_percent_num, 'стоп')
            print(Pthr.getresult()['PDOP0'])
            time.sleep(1)

    print('pause')
    pause = 0
