import datetime

import pytest

from utils.astro import current_celestial_state


class TestSunPosition:
    """Класс для тестов функции AstroSystem.recalc_sun_position.
       Для запуска тестов в терминале: pytest
    """

    @pytest.fixture
    def astro_instance(self):
        """Фикстура для создания экземпляра класса"""
        return current_celestial_state

    def check_sun_position(self, astro_instance, current_time, expected_e_s, delta):
        """Вспомогательный метод для проверки позиции Солнца"""
        astro_instance.recalc_sun_position(current_time)

        # Используем pytest.approx для сравнения с допустимой погрешностью
        assert astro_instance.e_s[0][0] == pytest.approx(expected_e_s[0], abs=delta[0])
        assert astro_instance.e_s[1][0] == pytest.approx(expected_e_s[1], abs=delta[1])
        assert astro_instance.e_s[2][0] == pytest.approx(expected_e_s[2], abs=delta[2])

    def test_sun_position_on_equinox(self, astro_instance):
        """Тесты на позицию Солнца во время равноденствий"""
        # Весеннее равноденствие - полночь
        current_time = datetime.datetime(2025, 3, 20, 3, 0)
        self.check_sun_position(astro_instance, current_time, [-1, 0, 0], [0.01, 0.05, 0.05])

        # Весеннее равноденствие - полдень
        current_time = datetime.datetime(2025, 3, 20, 15, 0)
        self.check_sun_position(astro_instance, current_time, [1, 0, 0], [0.01, 0.05, 0.05])

        # Осеннее равноденствие - полночь
        current_time = datetime.datetime(2024, 9, 22, 3, 0)
        self.check_sun_position(astro_instance, current_time, [-1, 0, 0], [0.01, 0.05, 0.05])

        # Осеннее равноденствие - полдень
        current_time = datetime.datetime(2024, 9, 22, 15, 0)
        self.check_sun_position(astro_instance, current_time, [1, 0, 0], [0.01, 0.05, 0.05])

    def test_sun_position_on_solstice(self, astro_instance):
        """Тесты на позицию Солнца во время солнцестояний"""
        # Летнее солнцестояние - полночь
        current_time = datetime.datetime(2025, 6, 21, 3, 0)
        self.check_sun_position(astro_instance, current_time, [-1, 0, 0.4], [0.1, 0.03, 0.05])
        assert astro_instance.e_s[2][0] > 0  # z положительна

        # Летнее солнцестояние - полдень
        current_time = datetime.datetime(2025, 6, 21, 15, 0)
        self.check_sun_position(astro_instance, current_time, [1, 0, 0.4], [0.1, 0.03, 0.05])
        assert astro_instance.e_s[2][0] > 0  # z положительна

        # Зимнее солнцестояние - полночь
        current_time = datetime.datetime(2024, 12, 21, 3, 0)
        self.check_sun_position(astro_instance, current_time, [-1, 0, -0.4], [0.1, 0.03, 0.05])
        assert astro_instance.e_s[2][0] < 0  # z отрицательна

        # Зимнее солнцестояние - полдень
        current_time = datetime.datetime(2024, 12, 21, 15, 0)
        self.check_sun_position(astro_instance, current_time, [1, 0, -0.4], [0.1, 0.03, 0.05])
        assert astro_instance.e_s[2][0] < 0  # z отрицательна
