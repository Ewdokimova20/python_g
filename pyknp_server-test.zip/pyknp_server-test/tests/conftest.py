def pytest_html_report_title(report):
    report.title = "Тест КНП СПО"
