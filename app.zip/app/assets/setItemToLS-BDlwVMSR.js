const o=e=>{const t=localStorage.getItem(e);return t?JSON.parse(t):null},s=(e,t)=>{localStorage.setItem(e,JSON.stringify(t))};export{o as g,s};
