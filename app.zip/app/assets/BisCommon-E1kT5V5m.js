import{_ as e,c,o}from"./index-B9ncFhZ9.js";const n={};function r(t,s){return o(),c("div")}const a=e(n,[["render",r]]);export{a as default};
